# ============================================================
# media_player_promax_top.sdc
# 用于：TF 图片轮播 + HDMI(视频+音频) 整合工程，单 PLL 五路时钟架构
#
# 取代原 timing.sdc。两者不能同时登记：timing.sdc 用的是
# derive_clocks + rename_clock，且写死了 sys_pll_m0/video_pll_m0 的 pin
# 路径，合并成单 PLL 后那些 pin 不存在，rename_clock 会拿到空集合，
# 它的 set_clock_groups 会无声失效——这种失败不报错，所以必须整份换掉。
#
# 本文件改用 create_generated_clock 直接在 PLL 输出引脚上建时钟，
# 5 路全部显式声明，不再依赖 derive_clocks 自动推导。
# ============================================================

# ------------------------------------------------------------
# 1. 板级输入主时钟：50MHz
# ------------------------------------------------------------
create_clock -name clk -period 20.000 -waveform {0.000 10.000} [get_ports {clk}]

# ------------------------------------------------------------
# 2. 单 PLL 的 5 路输出（实例 u_sys_pll，见 IP/sys_pll_single.v）
#
#    注意下标：合并后 video_clk 在 clkc[3]、hdmi_5x_clk 在 clkc[4]，
#    与原 video_pll 的 clkc[0]/clkc[1] 不同。
# ------------------------------------------------------------
create_generated_clock -name sd_card_clk     -source [get_ports {clk}] -master_clock clk -multiply_by 2 \
    [get_pins {u_sys_pll/pll_inst.clkc[0]}]
create_generated_clock -name ext_mem_clk     -source [get_ports {clk}] -master_clock clk -multiply_by 2.5 \
    [get_pins {u_sys_pll/pll_inst.clkc[1]}]
create_generated_clock -name ext_mem_clk_sft -source [get_ports {clk}] -master_clock clk -multiply_by 2.5 -phase 180 \
    [get_pins {u_sys_pll/pll_inst.clkc[2]}]
create_generated_clock -name video_clk       -source [get_ports {clk}] -master_clock clk -divide_by 2 \
    [get_pins {u_sys_pll/pll_inst.clkc[3]}]
create_generated_clock -name hdmi_5x_clk     -source [get_ports {clk}] -master_clock clk -multiply_by 2.5 \
    [get_pins {u_sys_pll/pll_inst.clkc[4]}]

# ------------------------------------------------------------
# 3. SDRAM 的 180° 相位对
#
#    ext_mem_clk_sft 的唯一消费者是 sdram U3 的 Clk_sft，即 SDRAM 硬核
#    的采样时钟。硬核自带 I/O 窗口，把这条转发出去的 DQ 路径当成 fabric
#    的 setup 路径分析会产生一个恒定的伪违例。
# ------------------------------------------------------------
set_false_path -from [get_clocks {ext_mem_clk}] -to [get_clocks {ext_mem_clk_sft}]
set_false_path -from [get_clocks {ext_mem_clk_sft}] -to [get_clocks {ext_mem_clk}]

# ------------------------------------------------------------
# 4. hold 不确定度
#
#    5 路时钟现在同出一个 PLL、同一颗 die，域内 launch/capture 共用全局
#    时钟树。工具默认的 0.100ns hold 不确定度超过 25~125MHz 下真实的
#    PLL 抖动 + 时钟树偏斜预算，会在 ±15ps 带里反复报出一批
#    寄存器→异步RAM读地址的局部路径。0.050ns 保留真实余量，同时避免这个
#    余量假象驱使人去手工插延迟 LUT。
#
#    【这是本文件唯一放松分析严格度的一条】不需要可以直接删掉，
#    不影响其余约束。
# ------------------------------------------------------------
set_clock_uncertainty -hold 0.050 [get_clocks {clk sd_card_clk ext_mem_clk ext_mem_clk_sft video_clk hdmi_5x_clk}]

# ------------------------------------------------------------
# 5. 时钟组
#和set_false_path的区别是，但set_false_path只是告诉工具不要分析这条路径，但不一定不存在时序关系，时钟组的意思是他们之间没有任何关系，工具不会分析他们之间的路径。
#    sd_card_clk(ctrl 域) 与 video_clk(pix 域) 之间只剩同步器/异步FIFO
#    式的跨域，声明为异步。
#
#    注意：这里【故意不再】声明 video_clk 与 hdmi_5x_clk 互斥
#    （原 timing.sdc 里有 set_clock_groups -exclusive）。那条语义是错的：
#    两者并非互斥时钟，且 lane_lvds_10_1 里的 S_odd_even 是一条真实存在的
#    pixel→serial 路径（pixel 域翻转 → serial 域两拍同步 → 边沿检测出
#    S_load_en）。合并后两路同出一个 PLL、整数 1:5、相对偏斜为 0，属同步
#    关系，应当真实收敛，该路径有完整 8ns 预算。
# ------------------------------------------------------------
set_clock_groups -asynchronous \
    -group [get_clocks {sd_card_clk}] \
    -group [get_clocks {video_clk}]

# ------------------------------------------------------------
# 6. 跨时钟域同步器的时序例外
#
#    */s1 覆盖 common/reset_sync.v 与 common/sync_2ff.v 的第一级触发器
#    （全工程只有这两个模块声明了 reg s1）。其余各条是 framebuf4bank /
#    fat32 里带 bundled-data 的 toggle 同步器第一级。
# ------------------------------------------------------------
set_false_path -from [get_ports {rst_n}]
set_false_path -to [get_regs -hier {*/s1}]
set_false_path -to [get_regs -hier {*/request_sync1_mem}]
set_false_path -to [get_regs -hier {*/index_sync1_mem[*]}]
set_false_path -to [get_regs -hier {*/ack_sync1}]
set_false_path -to [get_regs -hier {*/req_sync1}]
set_false_path -to [get_regs -hier {*/index_sync1[*]}]
set_false_path -to [get_regs -hier {*/busy_sync1}]
set_false_path -to [get_regs -hier {*/commit_sync1}]
# 第十三讲：media_frame_reader 缩略图模式位，随 request toggle 跨 pix->mem
set_false_path -to [get_regs -hier {*/thumb_sync1_mem}]

# rst_n_video 是读 FIFO 的异步压下复位，它在 pix 域的释放沿不是一次
# 进 ext_mem_clk 的数据搬运，只切这一条复位扇出；FIFO 的格雷指针跨域
# 仍然按下面第 7 节真实收敛。
set_false_path -from [get_nets {u_rst_sync_video/s2}] \
    -to [get_clocks {ext_mem_clk}]

# 写侧跨时钟域 FIFO(async_command_fifo)的格雷指针同步第一级
set_false_path -to [get_regs -hier {u_media_sdram_write_cdc/u_fifo/wr_gray_sync1[*]}]
set_false_path -to [get_regs -hier {u_media_sdram_write_cdc/u_fifo/rd_gray_sync1[*]}]

# ------------------------------------------------------------
# 7. 时序范围
#
#    读 FIFO(rfifo_32_32_512, 实例 u_read_fifo)用格雷指针跨域。不整域声明
#    为 false，而是把每个跨域限制在一个源时钟周期内：
#      wr_to_rd_cross_inst 源时钟是 .clkw = ext_mem_clk (125MHz -> 8ns)
#      rd_to_wr_cross_inst 源时钟是 .clkr = video_clk   (25MHz  -> 40ns)
# ------------------------------------------------------------
set_max_delay -from [get_regs -hier {u_media_video_pipeline/u_reader/u_read_fifo/wr_to_rd_cross_inst/primary_addr_gray_reg[*]}] \
    -to [get_regs -hier {u_media_video_pipeline/u_reader/u_read_fifo/wr_to_rd_cross_inst/sync_r1[*]}] \
    8.000 -datapath_only
set_max_delay -from [get_regs -hier {u_media_video_pipeline/u_reader/u_read_fifo/rd_to_wr_cross_inst/primary_addr_gray_reg[*]}] \
    -to [get_regs -hier {u_media_video_pipeline/u_reader/u_read_fifo/rd_to_wr_cross_inst/sync_r1[*]}] \
    40.000 -datapath_only

# 限制每条 ODDR 到管脚的路径。这是每条 lane 的数字延迟上限，
# 不是对完整上升/下降沿配对偏斜或模拟眼图的声明。
set_max_delay -from [get_clocks {hdmi_5x_clk}] \
    -to [get_ports {HDMI_CLK_P HDMI_D0_P HDMI_D1_P HDMI_D2_P}] \
    8.000 -datapath_only
