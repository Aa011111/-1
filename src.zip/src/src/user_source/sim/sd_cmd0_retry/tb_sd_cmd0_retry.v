`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// sd_spi_init CMD0 重试回归（SPI 线级卡模型）
//
// 背景：JTAG 下载到 SRAM 时卡不断电。如果 Flash 里的程序正在读卡，卡会停在
// 读到一半的扇区里；新程序拉低片选发 CMD0，收到的是残留数据字节（MSB=0），
// 旧代码直接报 ERR_CMD0_R1 = 0x02。
//
// 场景：
//   1 fresh      刚上电的卡（SD 模式，要 >=74 个时钟后才认 CMD0）
//   2 spi_idle   已在 SPI 模式、空闲（上一个程序刚好读完一个扇区）
//   3 mid_block  已在 SPI 模式、还有 515 字节（令牌 + 512 + CRC）没吐完
//   4 long_left  还有 2000 字节没吐完（要重试好几次）
//   5 dead       卡不应答（MISO 一直被上拉成 1）
//   6 stuck_low  MISO 一直是 0
// 新代码：1~4 初始化成功，5 报 0x01，6 报 0x02 且 R1=00。
// 旧代码（+OLD）：3、4 报 0x02，其余同上——用来证明模型确实复现了板上的现象。
//
// 跑法见 run.do（新代码 DIV=4 / DIV=125）和 run_old.do（旧代码）。
// -----------------------------------------------------------------------------

module sd_spi_card_model (
    input  wire sclk,
    input  wire cs_n,
    input  wire mosi,
    output wire miso
);
    // ---- 场景配置，tb 在复位期间用层次化引用直接改 ----
    reg     spi_mode;       // 0 = 刚上电（SD 模式），1 = 已在 SPI 模式
    reg     in_idle;
    integer pending;        // 选中后还要先吐出去的残留数据字节数
    reg     dead;           // 不驱动 MISO
    reg     stuck_low;      // MISO 恒 0
    integer acmd41_busy;    // ACMD41 先回几次 0x01 再回 0x00
    integer power_clocks;   // 片选高时收到的时钟数（74 时钟规则）
    integer cmd0_accepted;  // 卡真正解析到的 CMD0 次数
    integer cs_glitch_err;  // 一个字节没收完片选就抬高了

    reg [7:0] rx_shift;
    integer   rx_cnt;
    reg [7:0] cmd [0:5];
    integer   cmd_idx;
    reg [7:0] txq [0:31];
    integer   q_head, q_tail;
    reg [7:0] tx_cur;
    integer   tx_cnt;
    reg       app_cmd;

    assign miso = stuck_low ? 1'b0 : (dead || cs_n) ? 1'bz : tx_cur[7];

    task configure;
        input        mode;
        input integer left;
        input        is_dead;
        input        is_stuck;
        begin
            spi_mode      = mode;
            in_idle       = 1'b0;
            pending       = left;
            dead          = is_dead;
            stuck_low     = is_stuck;
            acmd41_busy   = 3;
            power_clocks  = 0;
            cmd0_accepted = 0;
            cs_glitch_err = 0;
            rx_shift      = 8'hff;
            rx_cnt        = 0;
            cmd_idx       = 0;
            q_head        = 0;
            q_tail        = 0;
            tx_cur        = 8'hff;
            tx_cnt        = 0;
            app_cmd       = 1'b0;
        end
    endtask

    initial configure(1'b0, 0, 1'b0, 1'b0);

    task push;
        input [7:0] b;
        begin
            txq[q_tail % 32] = b;
            q_tail = q_tail + 1;
        end
    endtask

    // 残留数据：0x20~0x5F，MSB=0 且永远不是 0x01，正好会被旧代码当成 R1
    task load_next;
        begin
            if (pending > 0) begin
                tx_cur  = 8'h20 + (pending % 64);
                pending = pending - 1;
            end
            else if (q_head != q_tail) begin
                tx_cur = txq[q_head % 32];
                q_head = q_head + 1;
            end
            else begin
                tx_cur = 8'hff;
            end
        end
    endtask

    task respond;          // NCR = 1：先一个 0xFF 再 R1
        input [7:0] r1;
        begin
            push(8'hff);
            push(r1);
        end
    endtask

    task execute;
        reg [5:0]  idx;
        reg [31:0] arg;
        begin
            idx = cmd[0][5:0];
            arg = {cmd[1], cmd[2], cmd[3], cmd[4]};
            if (!spi_mode) begin
                // SD 模式只认 CMD0，而且上电后要先给够 74 个时钟
                if (idx == 6'd0 && power_clocks >= 74) begin
                    cmd0_accepted = cmd0_accepted + 1;
                    spi_mode = 1'b1;
                    in_idle  = 1'b1;
                    app_cmd  = 1'b0;
                    respond(8'h01);
                end
            end
            else begin
                case (idx)
                    6'd0: begin
                        cmd0_accepted = cmd0_accepted + 1;
                        in_idle = 1'b1;
                        app_cmd = 1'b0;
                        respond(8'h01);
                    end
                    6'd8: begin
                        respond({7'd0, in_idle});
                        push(8'h00); push(8'h00); push({4'h0, arg[11:8]}); push(arg[7:0]);
                    end
                    6'd55: begin
                        app_cmd = 1'b1;
                        respond({7'd0, in_idle});
                    end
                    6'd41: begin
                        if (app_cmd && acmd41_busy > 0) begin
                            acmd41_busy = acmd41_busy - 1;
                            respond(8'h01);
                        end
                        else if (app_cmd) begin
                            in_idle = 1'b0;
                            respond(8'h00);
                        end
                        else begin
                            respond(8'h05);
                        end
                        app_cmd = 1'b0;
                    end
                    6'd58: begin
                        respond({7'd0, in_idle});
                        push(8'hc0); push(8'hff); push(8'h80); push(8'h00);
                    end
                    default: respond({5'd0, 1'b1, 1'b0, in_idle});   // illegal command
                endcase
            end
        end
    endtask

    task got_byte;
        input [7:0] b;
        begin
            if (pending > 0) begin
                // 还在吐上一个扇区：主机发什么都不理
            end
            else if (cmd_idx == 0) begin
                if (b[7:6] == 2'b01) begin
                    cmd[0]  = b;
                    cmd_idx = 1;
                end
            end
            else begin
                cmd[cmd_idx] = b;
                cmd_idx = cmd_idx + 1;
                if (cmd_idx == 6) begin
                    cmd_idx = 0;
                    execute;
                end
            end
        end
    endtask

    always @(negedge cs_n) begin
        rx_cnt = 0;
        tx_cnt = 0;
        load_next;
    end

    always @(posedge cs_n) begin
        if (rx_cnt != 0)
            cs_glitch_err = cs_glitch_err + 1;
        rx_cnt = 0;
    end

    always @(posedge sclk) begin
        if (cs_n) begin
            power_clocks = power_clocks + 1;
        end
        else begin
            rx_shift = {rx_shift[6:0], mosi};
            rx_cnt   = rx_cnt + 1;
            if (rx_cnt == 8) begin
                rx_cnt = 0;
                got_byte(rx_shift);
            end
        end
    end

    always @(negedge sclk) begin
        if (!cs_n) begin
            tx_cnt = tx_cnt + 1;
            if (tx_cnt == 8) begin
                tx_cnt = 0;
                load_next;
            end
            else begin
                tx_cur = {tx_cur[6:0], 1'b1};
            end
        end
    end
endmodule

module tb_sd_cmd0_retry;
    parameter integer DIV  = 4;     // SPI 分频：4 = 12.5MHz（快），125 = 板上实际的 400kHz
    parameter integer FULL = 1;     // 0 = 只跑 fresh / mid_block（DIV=125 时省时间）

    reg clk   = 1'b0;
    reg rst_n = 1'b0;
    reg init_start = 1'b0;
    always #5 clk = ~clk;           // 100MHz

    wire        init_busy, init_done, init_ready;
    wire [7:0]  error_code, last_r1;
    wire [5:0]  last_cmd;
    wire [31:0] ocr;
    wire [15:0] acmd41_attempts;
    wire        card_high_capacity;
    wire        sd_cs_n, sd_sclk, sd_mosi;
    tri1        sd_miso;            // 板上 RN19 10k 上拉

    sd_spi_init #(
        .SPI_CLK_DIV          (DIV),
        .POWER_UP_BYTES       (10),
        .MAX_RESPONSE_BYTES   (16),
        .MAX_ACMD41_ATTEMPTS  (64),
        .STARTUP_DELAY_CYCLES (200)
    ) dut (
        .clk(clk), .rst_n(rst_n), .init_start(init_start),
        .init_busy(init_busy), .init_done(init_done), .init_ready(init_ready),
        .error_code(error_code), .card_high_capacity(card_high_capacity),
        .ocr(ocr), .last_cmd(last_cmd), .last_r1(last_r1),
        .acmd41_attempts(acmd41_attempts),
        .sd_cs_n(sd_cs_n), .sd_sclk(sd_sclk), .sd_mosi(sd_mosi), .sd_miso(sd_miso)
    );

    sd_spi_card_model card (
        .sclk(sd_sclk), .cs_n(sd_cs_n), .mosi(sd_mosi), .miso(sd_miso)
    );

    integer errors = 0;
    reg     old_rtl;

    task run_case;
        input [8*12-1:0] name;
        input            mode;
        input integer    left;
        input            is_dead;
        input            is_stuck;
        input            exp_ready;
        input [7:0]      exp_err;
        input            check_r1;
        input [7:0]      exp_r1;
        integer          waited;
        reg              got;
        begin
            rst_n = 1'b0;
            card.configure(mode, left, is_dead, is_stuck);
            repeat (10) @(posedge clk);
            rst_n = 1'b1;
            repeat (5) @(posedge clk);
            init_start = 1'b1;
            @(posedge clk);
            init_start = 1'b0;

            got    = 1'b0;
            waited = 0;
            while (!got && waited < 20_000_000) begin
                @(posedge clk);
                waited = waited + 1;
                if (init_done) got = 1'b1;
            end

            if (!got) begin
                $display("FAIL %0s: init_done never came", name);
                errors = errors + 1;
            end
            else if (init_ready !== exp_ready || error_code !== exp_err ||
                     (check_r1 && last_r1 !== exp_r1) || card.cs_glitch_err != 0) begin
                $display("FAIL %0s: ready=%0d err=%02h last_r1=%02h cmd0_accepted=%0d cs_glitch=%0d (expect ready=%0d err=%02h%s)",
                         name, init_ready, error_code, last_r1, card.cmd0_accepted, card.cs_glitch_err,
                         exp_ready, exp_err, check_r1 ? " + r1" : "");
                errors = errors + 1;
            end
            else begin
                $display("PASS %0s: ready=%0d err=%02h last_r1=%02h cmd0_accepted=%0d left=%0d  t=%0.2fms",
                         name, init_ready, error_code, last_r1, card.cmd0_accepted, card.pending,
                         waited / 100000.0);
            end
        end
    endtask

    initial begin
        old_rtl = $test$plusargs("OLD");
        $display("---- sd_spi_init CMD0 retry, DIV=%0d, %0s RTL ----", DIV, old_rtl ? "OLD" : "NEW");

        //        name           spi  left  dead  stuck ready err    chk r1
        run_case("fresh",        0,   0,    0,    0,    1,    8'h00, 0,  8'h00);
        if (old_rtl)
            run_case("mid_block",1,   515,  0,    0,    0,    8'h02, 0,  8'h00);
        else
            run_case("mid_block",1,   515,  0,    0,    1,    8'h00, 0,  8'h00);

        if (FULL != 0) begin
            run_case("spi_idle", 1,   0,    0,    0,    1,    8'h00, 0,  8'h00);
            if (old_rtl)
                run_case("long_left",1, 2000, 0,    0,    0,    8'h02, 0,  8'h00);
            else
                run_case("long_left",1, 2000, 0,    0,    1,    8'h00, 0,  8'h00);
            run_case("dead",     0,   0,    1,    0,    0,    8'h01, 0,  8'h00);
            run_case("stuck_low",0,   0,    0,    1,    0,    8'h02, 1,  8'h00);
        end

        if (errors == 0) $display("ALL PASS");
        else             $display("%0d ERROR(S)", errors);
        $finish;
    end
endmodule
