# 对照：旧 sd_spi_init（没有 CMD0 重试）在同一个卡模型下的表现：vsim -c -do run_old.do
# 预期 mid_block / long_left 报 0x02，复现板上的 5302 1。
vlib work_old
vlog -work work_old ../../hdl_source/fat32/sd_spi_byte_engine.v ../../hdl_source/fat32/sd_spi_command.v ../../hdl_source/fat32/sd_spi_init.v.bak_before_cmd0retry tb_sd_cmd0_retry.v
vsim -c -quiet -lib work_old -gDIV=4 tb_sd_cmd0_retry +OLD
run -all
quit -f
