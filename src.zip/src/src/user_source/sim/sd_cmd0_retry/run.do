# sd_spi_init CMD0 重试回归（新代码）：vsim -c -do run.do
onbreak {resume}
vlib work
vlog ../../hdl_source/fat32/sd_spi_byte_engine.v ../../hdl_source/fat32/sd_spi_command.v ../../hdl_source/fat32/sd_spi_init.v tb_sd_cmd0_retry.v
# 全部 6 个场景，SPI 12.5MHz
vsim -c -quiet -onfinish stop -gDIV=4 tb_sd_cmd0_retry
run -all
quit -sim
# 板上实际的 400kHz（只跑 fresh / mid_block，省时间）
vsim -c -quiet -gDIV=125 -gFULL=0 tb_sd_cmd0_retry
run -all
quit -f
