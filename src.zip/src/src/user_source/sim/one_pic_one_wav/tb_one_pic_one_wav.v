`timescale 1ns/1ps
// 一图一音回归：
//   A. fat32_volume_scanner 认 MUSIC1~4.WAV（大小写、序号越界、过小文件），
//      不再认 MUSIC.WAV
//      13 张图扩展：扫描器按 IMAGE_COUNT=13 例化，另外覆盖两位数文件名
//      PIC10/PIC13/MUSIC10/music13、越界的 PIC14/MUSIC14、非法的 PIC2X
//   B. 顶层 48kHz 节拍 + 播放控制块 + wav_stream_player：头部跳过 / 循环 /
//      中途切曲 / 缺音频的图静音 / 任何时候节拍都是 48kHz
// 扇区内容：偶数字节 = 扇区内样本序号，奇数字节 = 文件标记，
// 所以样本高字节就能看出它来自哪个文件。

// ---------------- 假 SD 扇区读口 ----------------
module fake_sd #(
    parameter integer LATENCY = 200,
    parameter integer MODE    = 0      // 0 = 播放图样，1 = FAT32 卡镜像
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        req,
    input  wire [31:0] lba,
    output reg         busy,
    output reg         valid,
    output wire [7:0]  byte_o,
    output reg  [8:0]  index,
    output reg         done
);
    reg [31:0] cur;
    integer    cnt;
    reg [10:0] pos;

    // 播放图样：高字节标记文件（按 LBA 区间），低字节 = 扇区内样本序号
    function [7:0] file_tag;
        input [31:0] l;
        begin
            if (l >= 1000 && l < 1100)      file_tag = 8'hE8;
            else if (l >= 2000 && l < 2100) file_tag = 8'hD0;
            else if (l >= 3000 && l < 3100) file_tag = 8'hB8;
            else                            file_tag = 8'h11;
        end
    endfunction

    function [7:0] dir_byte;   // 根目录扇区 2032 里的目录项
        input [8:0] i;
        reg [4:0] off; reg [3:0] e;
        reg [87:0] name; reg [31:0] clu; reg [31:0] sz;
        begin
            e = i[8:5]; off = i[4:0];
            case (e)
                4'd0: begin name = "PIC1    BMP"; clu = 3;   sz = 921654; end
                4'd1: begin name = "MUSIC   WAV"; clu = 100; sz = 100000; end // 已不再识别
                4'd2: begin name = "MUSIC2  WAV"; clu = 200; sz = 4140;   end
                4'd3: begin name = "music4  wav"; clu = 300; sz = 1000;   end
                4'd4: begin name = "MUSIC5  WAV"; clu = 400; sz = 9000;   end // 13 张时有效
                4'd5: begin name = "MUSIC3  WAV"; clu = 500; sz = 100;    end // 不足一扇区
                4'd6: begin name = "PIC13   BMP"; clu = 600; sz = 921654; end
                4'd7: begin name = "pic10   bmp"; clu = 610; sz = 921654; end
                4'd8: begin name = "PIC14   BMP"; clu = 620; sz = 921654; end // 序号越界
                4'd9: begin name = "MUSIC10 WAV"; clu = 700; sz = 5120;   end
                4'd10: begin name = "music13 wav"; clu = 710; sz = 2048;  end
                4'd11: begin name = "MUSIC14 WAV"; clu = 720; sz = 9000;  end // 序号越界
                4'd12: begin name = "PIC2X   BMP"; clu = 630; sz = 921654; end // 非法序号
                4'd13: begin name = "PIC1 0  BMP"; clu = 640; sz = 921654; end // 中间有空格
                default: begin name = 88'd0; clu = 0; sz = 0; end
            endcase
            if (off <= 10)       dir_byte = name[(10-off)*8 +: 8];
            else if (off == 11)  dir_byte = (name == 0) ? 8'h00 : 8'h20;
            else if (off == 20)  dir_byte = clu[23:16];
            else if (off == 21)  dir_byte = clu[31:24];
            else if (off == 26)  dir_byte = clu[7:0];
            else if (off == 27)  dir_byte = clu[15:8];
            else if (off >= 28)  dir_byte = sz[(off-28)*8 +: 8];
            else                 dir_byte = 8'h00;
        end
    endfunction

    function [7:0] img_byte;
        input [31:0] l; input [8:0] i;
        begin
            img_byte = 8'h00;
            if (l == 0) begin   // VBR：spc=8, rsvd=32, 2 FAT x 1000, root=2
                case (i)
                    0: img_byte = 8'hEB; 12: img_byte = 8'h02; 13: img_byte = 8'd8;
                    14: img_byte = 8'd32; 16: img_byte = 8'd2;
                    34: img_byte = 8'h10;                 // total = 0x100000
                    36: img_byte = 8'hE8; 37: img_byte = 8'h03;  // fatsz = 1000
                    44: img_byte = 8'd2;
                    510: img_byte = 8'h55; 511: img_byte = 8'hAA;
                    default: img_byte = 8'h00;
                endcase
            end else if (l == 32'd2032) begin
                img_byte = dir_byte(i);
            end
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy <= 0; valid <= 0; done <= 0; index <= 0; cnt <= 0; pos <= 0; cur <= 0;
        end else begin
            valid <= 0; done <= 0;
            if (!busy && req) begin
                busy <= 1; cur <= lba; cnt <= LATENCY; pos <= 0;
            end else if (busy) begin
                if (cnt > 0) cnt <= cnt - 1;
                else if (pos < 1024) begin
                    if (pos[0] == 1'b0) begin   // 每 2 拍一个字节
                        valid  <= 1;
                        index  <= pos[9:1];
                    end
                    pos <= pos + 1;
                end else begin
                    done <= 1; busy <= 0;
                end
            end
        end
    end
    // 字节在 valid 拍有效（用 assign：always @(*) 在 0 时刻不执行，首字节会是 X）
    assign byte_o = (MODE == 1) ? img_byte(cur, index) :
                    (index[0] ? file_tag(cur) : index[8:1]);
endmodule

module tb_one_pic_one_wav;
    reg sd_clk = 0, rd_clk = 0, rst_n = 0;
    always #5  sd_clk = ~sd_clk;   // 100MHz
    always #20 rd_clk = ~rd_clk;   // 25MHz
    integer errors = 0;

    // ============ A. 扫描器 ============
    reg scan_start = 0;
    wire scan_done; wire [7:0] fs_error;
    wire s_req, s_busy, s_valid, s_done; wire [31:0] s_lba; wire [7:0] s_byte; wire [8:0] s_idx;
    wire [12:0] track_valid_s; wire [13*32-1:0] track_lba_s, track_sec_s;
    wire [12:0] res_valid; wire [13*32-1:0] res_cluster, res_size;

    fake_sd #(.LATENCY(20), .MODE(1)) u_sd_scan (
        .clk(sd_clk), .rst_n(rst_n), .req(s_req), .lba(s_lba), .busy(s_busy),
        .valid(s_valid), .byte_o(s_byte), .index(s_idx), .done(s_done));

    fat32_volume_scanner #(.IMAGE_COUNT(13), .INDEX_W(4)) u_scan (
        .clk(sd_clk), .rst_n(rst_n), .scan_start(scan_start), .scan_busy(), .scan_done(scan_done),
        .fs_error(fs_error), .partition_lba(), .sectors_per_cluster(), .fat_start_lba(),
        .data_start_lba(), .max_cluster(), .resource_valid(res_valid),
        .resource_cluster(res_cluster), .resource_size(res_size),
        .sector_req(s_req), .sector_lba(s_lba), .sector_busy(s_busy), .sector_valid(s_valid),
        .sector_byte(s_byte), .sector_byte_index(s_idx), .sector_done(s_done), .sector_error(8'd0),
        .track_valid(track_valid_s), .track_start_lba(track_lba_s), .track_sectors(track_sec_s),
        .diag2_code());

    task check32;
        input [8*24-1:0] what; input [31:0] got, exp;
        begin
            if (got !== exp) begin
                $display("FAIL %0s: got %0d expect %0d", what, got, exp); errors = errors + 1;
            end else $display("ok   %0s = %0d", what, got);
        end
    endtask

    // ============ B. 节拍 + 播放控制 + 播放器 ============
    reg  [1:0]   pending_index = 0;
    reg          ext_ready = 0;
    // MUSIC1/2/4.WAV 在，MUSIC3.WAV 缺
    reg  [3:0]   track_valid = 4'b1011;
    // track0: LBA 1000(E8) 4 扇区；track1: 2000(D0) 100 扇区；track3: 3000(B8) 3 扇区
    wire [127:0] track_start_lba = {32'd3000, 32'd0, 32'd2000, 32'd1000};
    wire [127:0] track_sectors   = {32'd3,    32'd0, 32'd100,  32'd4};

    reg          wav_play_enable;
    reg  [16:0]  wav_gap_cnt;
    reg  [31:0]  wav_play_lba, wav_play_sectors;
    wire         wav_writer_idle, wav_stream_end;
    reg          end_s1, wav_stream_end_sd;
    always @(posedge sd_clk) begin end_s1 <= wav_stream_end; wav_stream_end_sd <= end_s1; end

    // ---- 与 top_tf_hdmi_audio.v 中同一段逐行一致 ----
    localparam integer AUDIO_CLOCK_HZ  = 25_000_000;
    localparam integer AUDIO_SAMPLE_HZ = 48_000;
    reg  [24:0]  sample_rate_acc;
    reg          sample_tick;
    always @(posedge rd_clk or negedge rst_n) begin
        if (!rst_n) begin
            sample_rate_acc <= 25'd0;
            sample_tick     <= 1'b0;
        end
        else if (sample_rate_acc >= AUDIO_CLOCK_HZ - AUDIO_SAMPLE_HZ) begin
            sample_rate_acc <= sample_rate_acc + AUDIO_SAMPLE_HZ - AUDIO_CLOCK_HZ;
            sample_tick     <= 1'b1;
        end
        else begin
            sample_rate_acc <= sample_rate_acc + AUDIO_SAMPLE_HZ;
            sample_tick     <= 1'b0;
        end
    end

    localparam [16:0] WAV_GAP_CYCLES = 17'd100_000;
    wire [1:0]  wav_want_index   = pending_index;
    wire [31:0] wav_want_lba     = track_start_lba[wav_want_index*32 +: 32];
    wire [31:0] wav_want_sectors = track_sectors[wav_want_index*32 +: 32];
    wire        wav_ready_sd     = ext_ready && track_valid[wav_want_index];

    always @(posedge sd_clk or negedge rst_n) begin
        if (!rst_n) begin
            wav_play_enable  <= 1'b0;
            wav_gap_cnt      <= 17'd0;
            wav_play_lba     <= 32'd0;
            wav_play_sectors <= 32'd0;
        end
        else if (!wav_ready_sd) begin
            wav_play_enable <= 1'b0;
            wav_gap_cnt     <= 17'd0;
        end
        else if (wav_play_enable) begin
            if (wav_stream_end_sd || (wav_want_lba != wav_play_lba)) begin
                wav_play_enable <= 1'b0;
                wav_gap_cnt     <= 17'd0;
            end
        end
        else if (!wav_writer_idle) begin
            wav_gap_cnt <= 17'd0;
        end
        else if (wav_gap_cnt >= WAV_GAP_CYCLES - 17'd1) begin
            if (!wav_stream_end_sd) begin
                wav_play_lba     <= wav_want_lba;
                wav_play_sectors <= wav_want_sectors;
                wav_play_enable  <= 1'b1;
            end
        end
        else begin
            wav_gap_cnt <= wav_gap_cnt + 17'd1;
        end
    end

    wire p_req, p_busy, p_valid, p_done; wire [31:0] p_lba; wire [7:0] p_byte; wire [8:0] p_idx;
    // 长延迟：让切曲大概率落在扇区读到一半的时候
    fake_sd #(.LATENCY(60000), .MODE(0)) u_sd_play (
        .clk(sd_clk), .rst_n(rst_n), .req(p_req), .lba(p_lba), .busy(p_busy),
        .valid(p_valid), .byte_o(p_byte), .index(p_idx), .done(p_done));

    wire signed [15:0] sample; wire sample_valid;
    wav_stream_player #(.ADDR_WIDTH(12), .SAMPLES_PER_SECTOR(256), .HEADER_BYTES(44)) u_player (
        .wr_clk(sd_clk), .wr_rst_n(rst_n), .play_enable(wav_play_enable),
        .start_lba(wav_play_lba), .total_sectors(wav_play_sectors),
        .sd_req(p_req), .sd_lba(p_lba), .sd_busy(p_busy), .sd_valid(p_valid), .sd_byte(p_byte),
        .sd_byte_index(p_idx), .sd_done(p_done), .sd_error(8'd0), .writer_idle(wav_writer_idle),
        .rd_clk(rd_clk), .rd_rst_n(rst_n), .sample_tick(sample_tick), .sample_out(sample),
        .sample_valid(sample_valid), .sample_ready(1'b1), .sample_counter(), .stream_active(),
        .stream_end(wav_stream_end), .buffer_low());

    // 送 HDMI 的节拍 = sample_valid：任何时候都必须是 48kHz
    integer valid_count = 0;
    always @(posedge rd_clk) if (sample_valid) valid_count = valid_count + 1;

    // 监视：记录每段非静音样本的来源与第一个样本
    reg [7:0] last_src = 0;
    reg [7:0] expect_src = 8'hE8;
    reg [7:0] prev_lo = 0;
    integer   starts_e8 = 0, starts_d0 = 0, starts_b8 = 0, nonzero = 0;
    always @(posedge rd_clk) if (sample_valid && sample != 0) begin
        nonzero = nonzero + 1;
        if (sample[15:8] != last_src || (sample[7:0] == 8'd22 && prev_lo != 8'd21)) begin
            $display("%t  audio from tag 0x%02h, first sample lo=%0d", $time, sample[15:8], sample[7:0]);
            if (sample[7:0] != 8'd22) begin
                $display("FAIL: track did not start right after 44-byte header"); errors = errors + 1;
            end
            case (sample[15:8])
                8'hE8: starts_e8 = starts_e8 + 1;
                8'hD0: starts_d0 = starts_d0 + 1;
                8'hB8: starts_b8 = starts_b8 + 1;
            endcase
        end
        if (sample[15:8] != expect_src) begin
            $display("FAIL %t: sample from 0x%02h, expected 0x%02h", $time, sample[15:8], expect_src);
            errors = errors + 1;
        end
        last_src = sample[15:8];
        prev_lo  = sample[7:0];
    end

    task check_rate;   // 10ms 内应有 480 个样本
        input [8*24-1:0] what;
        integer c0;
        begin
            c0 = valid_count;
            #10_000_000;
            if (valid_count - c0 < 479 || valid_count - c0 > 481) begin
                $display("FAIL %0s: %0d samples in 10ms, expect 480", what, valid_count - c0);
                errors = errors + 1;
            end else $display("ok   %0s: %0d samples / 10ms (48kHz)", what, valid_count - c0);
        end
    endtask

    initial begin
        #100 rst_n = 1;
        // ---- A ----
        @(posedge sd_clk) scan_start <= 1; @(posedge sd_clk) scan_start <= 0;
        wait (scan_done); #1;
        $display("---- A. scanner ----");
        check32("fs_error",          fs_error, 0);
        check32("track_valid",       track_valid_s, 13'b1_0010_0001_1010);
        check32("track1 lba",        track_lba_s[1*32 +: 32],  2032 + 198*8);
        check32("track1 sectors",    track_sec_s[1*32 +: 32],  8);
        check32("track3 lba",        track_lba_s[3*32 +: 32],  2032 + 298*8);
        check32("track3 sectors",    track_sec_s[3*32 +: 32],  1);
        check32("track4 lba",        track_lba_s[4*32 +: 32],  2032 + 398*8);
        check32("track4 sectors",    track_sec_s[4*32 +: 32],  17);
        check32("track9 lba",        track_lba_s[9*32 +: 32],  2032 + 698*8);
        check32("track9 sectors",    track_sec_s[9*32 +: 32],  10);
        check32("track12 lba",       track_lba_s[12*32 +: 32], 2032 + 708*8);
        check32("track12 sectors",   track_sec_s[12*32 +: 32], 4);
        check32("resource_valid",    res_valid, 13'b1_0010_0000_0001);
        check32("pic1 cluster",      res_cluster[0*32 +: 32],  3);
        check32("pic10 cluster",     res_cluster[9*32 +: 32],  610);
        check32("pic13 cluster",     res_cluster[12*32 +: 32], 600);
        check32("pic13 size",        res_size[12*32 +: 32],    921654);

        // ---- B ----
        $display("---- B. player ----");
        check_rate("before ingest done");
        ext_ready = 1;
        // track0 只有 4 扇区：等它至少循环一次
        wait (starts_e8 >= 2);
        $display("ok   track0 looped");
        // 切到 1：此时正在读扇区（latency 60000 拍），写侧不在 IDLE
        #200000;
        @(posedge sd_clk) pending_index <= 1;
        $display("%t  switch -> PIC2 (writer_idle=%0d)", $time, wav_writer_idle);
        // 旧曲的残余样本在 play_enable 拉低时就被丢弃，之后只许听到新曲
        wait (!u_player.play_sync2); expect_src = 8'hD0;
        wait (starts_d0 >= 1);
        #2000000;
        // 切到 2：没有 MUSIC3.WAV -> 静音，但节拍不能断
        @(posedge sd_clk) pending_index <= 2;
        wait (!u_player.play_sync2); #1000;
        begin : silent
            integer n0;
            n0 = nonzero;
            check_rate("PIC3 (no MUSIC3.WAV)");
            if (nonzero != n0) begin
                $display("FAIL: PIC3 has no track but audio was not silent"); errors = errors + 1;
            end else $display("ok   PIC3 silent");
        end
        // 切到 3：MUSIC4.WAV 从头放
        expect_src = 8'hB8;
        @(posedge sd_clk) pending_index <= 3;
        wait (starts_b8 >= 1);
        $display("ok   PIC4 plays MUSIC4.WAV");
        check_rate("while playing");
        if (errors == 0) $display("==== PASS ====");
        else             $display("==== FAIL: %0d errors ====", errors);
        $finish;
    end

    initial begin #200_000_000; $display("==== FAIL: timeout ===="); $finish; end
endmodule
