`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 触控屏 FOC=NN 自检：vsim -c -do run.do
//
// 串口 media_uart_console 的 focus_cfg_* 直接接 thumbnail_controller
// （IMAGE_COUNT=13, FOCUS_COUNT=11，与顶层一致），转场/播放控制用行为模型。
//
//   1. FOC=05 全屏下也回 OK、也照设焦点（index 4）
//   2. THUMB 进缩略图：焦点落在当前图（index 0），覆盖掉之前的 FOC
//   3. THUMB 后紧跟 FOC=03（控制器还在 S_QUEUE/S_BLACK）不丢 -> index 2
//   4. FOC=01 / FOC=11 两端 -> index 0 / 10
//   5. FOC=12、FOC=13、FOC=99 超出 11 格 -> ERR，焦点不动
//   6. FOC=00、FOC=1A、FOC=5（一位）、FOC=005（三位）-> ERR，焦点不动
//   7. 方向键 FOCUS_COUNT=11 循环：10 右移 -> 0，0 左移 -> 10，永远不到 11/12
//   8. FOC=08 + SEL -> 回全屏，当前图 = index 7
//   9. 同拍方向键 + FOC：FOC 优先
// 全部通过打印 TEST_PASS。
// -----------------------------------------------------------------------------
module tb_touch_foc;
    localparam integer CLK_PERIOD_NS = 10;
    localparam integer CPB = 16;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD_NS/2) clk = ~clk;

    reg host_tx = 1'b1;
    integer errors = 0;

    // ---------------- 串口控制台 ----------------
    wire uart_txd;
    wire next_event, prev_event, thumb_cfg_valid, thumb_cfg_enabled, select_event_u;
    wire focus_cfg_valid;
    wire [7:0] focus_cfg_index;
    reg  [3:0] current_index = 4'd0;

    media_uart_console #(
        .CLKS_PER_BIT(CPB), .INDEX_W(4), .FOCUS_COUNT(11)
    ) u_console (
        .clk(clk), .rst_n(rst_n), .uart_rxd(host_tx), .uart_txd(uart_txd),
        .report_enable(1'b0), .media_id(current_index), .auto_enabled(1'b0),
        .error_code(8'h00),
        .next_event(next_event), .prev_event(prev_event),
        .auto_cfg_valid(), .auto_cfg_enabled(),
        .period_cfg_valid(), .period_cfg_cycles(),
        .volume(), .brightness(),
        .thumb_cfg_valid(thumb_cfg_valid), .thumb_cfg_enabled(thumb_cfg_enabled),
        .select_event(select_event_u),
        .focus_cfg_valid(focus_cfg_valid), .focus_cfg_index(focus_cfg_index),
        .contrast(), .bright_cfg_valid(), .contrast_cfg_valid(),
        .key_bright_event(1'b0), .key_bright_value(8'h00),
        .key_contrast_event(1'b0), .key_contrast_value(8'h00),
        .vis_cfg(), .diag_code()
    );

    // ---------------- 缩略图控制器 ----------------
    // 直接驱动的方向键 / 设焦点（测 7、9 用），与串口那一路或起来
    reg tb_right = 1'b0;
    reg tb_focus_v = 1'b0;
    reg [3:0] tb_focus_i = 4'd0;

    wire view_mode, select_event, transition_req, transition_owned, auto_hold;
    wire [3:0] focus_index, select_index;

    // 转场行为模型：req 后 30 拍给一拍全黑放行
    reg fade_busy = 1'b0;
    reg [7:0] fade_cnt = 8'd0;
    reg fade_release = 1'b0;
    always @(posedge clk) begin
        fade_release <= 1'b0;
        if (transition_req && !fade_busy) begin
            fade_busy <= 1'b1;
            fade_cnt  <= 8'd0;
        end else if (fade_busy) begin
            fade_cnt <= fade_cnt + 8'd1;
            if (fade_cnt == 8'd30) begin
                fade_release <= 1'b1;
                fade_busy    <= 1'b0;
            end
        end
    end
    always @(posedge clk)
        if (select_event) current_index <= select_index;

    // 和 media_video_pipeline 一样：缩略图下 SEL 当确认
    wire key_confirm = select_event_u && view_mode;

    thumbnail_controller #(
        .BLACK_TIMEOUT_CYCLES(32'd5000), .IMAGE_COUNT(13), .INDEX_W(4), .FOCUS_COUNT(11)
    ) u_tc (
        .clk(clk), .rst_n(rst_n),
        .key_right(next_event || tb_right), .key_left(prev_event),
        .key_confirm(key_confirm), .key_mode(1'b0),
        .mode_cfg_valid(thumb_cfg_valid), .mode_cfg_thumb(thumb_cfg_enabled),
        .focus_cfg_valid(focus_cfg_valid || tb_focus_v),
        .focus_cfg_index(tb_focus_v ? tb_focus_i : focus_cfg_index[3:0]),
        .image_complete(13'h1FFF),
        .current_index(current_index), .select_busy(1'b0),
        .transition_busy(fade_busy), .transition_black(fade_release && transition_owned),
        .view_mode(view_mode), .focus_index(focus_index),
        .select_event(select_event), .select_index(select_index),
        .transition_req(transition_req), .transition_owned(transition_owned),
        .auto_hold(auto_hold)
    );

    // ---------------- 回复监视：只记最近一行 ----------------
    wire [7:0] mon_data;
    wire mon_valid;
    uart_rx_byte #(.CLKS_PER_BIT(CPB)) u_monitor (
        .clk(clk), .rst_n(rst_n), .rx(uart_txd),
        .data(mon_data), .valid(mon_valid), .framing_error()
    );
    reg [8*8-1:0] last_line = 0;   // 不含 CRLF，右对齐
    reg [8*8-1:0] cur_line = 0;
    integer line_count = 0;
    always @(posedge clk)
        if (mon_valid) begin
            if (mon_data == 8'h0A) begin
                last_line  <= cur_line;
                cur_line   <= 0;
                line_count <= line_count + 1;
            end else if (mon_data != 8'h0D)
                cur_line <= {cur_line[8*7-1:0], mon_data};
        end

    task host_send_byte(input [7:0] v);
        integer i;
        begin
            @(negedge clk);
            host_tx = 1'b0; #(CPB*CLK_PERIOD_NS);
            for (i = 0; i < 8; i = i + 1) begin
                host_tx = v[i];
                #(CPB*CLK_PERIOD_NS);
            end
            host_tx = 1'b1; #(CPB*CLK_PERIOD_NS);
        end
    endtask

    // 发一行 + CRLF，不等回复
    task send_line(input [8*16-1:0] line, input integer len);
        integer i;
        begin
            for (i = 0; i < len; i = i + 1)
                host_send_byte(line[8*(len-1-i) +: 8]);
            host_send_byte(8'h0D);
            host_send_byte(8'h0A);
        end
    endtask

    // 发一行 + CRLF，等一行回复，再留时间让控制器把转场走完
    task cmd(input [8*16-1:0] line, input integer len);
        integer base, guard;
        begin
            base = line_count;
            send_line(line, len);
            guard = 0;
            while (line_count == base && guard < 100000) begin
                @(posedge clk);
                guard = guard + 1;
            end
            if (line_count == base) begin
                $display("TEST_FAIL no reply to %0s", line);
                errors = errors + 1;
            end
            repeat (300) @(posedge clk);
        end
    endtask

    task check(input cond, input [8*40-1:0] what);
        begin
            if (cond) $display("ok   %0s", what);
            else begin
                errors = errors + 1;
                $display("FAIL %0s (reply=%0s view=%0d focus=%0d current=%0d)",
                         what, last_line, view_mode, focus_index, current_index);
            end
        end
    endtask

    localparam [8*8-1:0] OK  = "OK";
    localparam [8*8-1:0] ERR = "ERR";
    integer k;
    reg seen_bad;
    // FOC 真正打进控制器那一拍，控制器处在什么状态（测 3 用）
    reg [1:0] state_at_foc = 2'd0;
    always @(posedge clk)
        if (focus_cfg_valid) state_at_foc <= u_tc.state;

    initial begin
        repeat (5) @(posedge clk);
        rst_n = 1'b1;
        repeat (20) @(posedge clk);

        // 1
        cmd("FOC=05", 6);
        check(last_line == OK && focus_index == 4 && !view_mode, "1 FOC=05 in full -> OK, focus 4");

        // 2
        cmd("THUMB", 5);
        check(view_mode && focus_index == 0, "2 THUMB -> focus = current (0)");

        // 3：FULL 回去；THUMB 发完不等，紧跟 FOC=03。把转场拉长到
        // FOC 生效时控制器仍不在 S_IDLE，才算测到"转场途中不丢"
        cmd("FULL", 4);
        force u_tc.transition_black = 1'b0;     // 卡在 S_BLACK，靠超时兜底出来
        send_line("THUMB", 5);
        send_line("FOC=03", 6);
        repeat (40) @(posedge clk);
        release u_tc.transition_black;
        repeat (6000) @(posedge clk);
        check(state_at_foc != 2'd0 && view_mode && focus_index == 2,
              "3 FOC during transition not lost -> 2");

        // 4
        cmd("FOC=01", 6); check(last_line == OK && focus_index == 0,  "4 FOC=01 -> 0");
        cmd("FOC=11", 6); check(last_line == OK && focus_index == 10, "4 FOC=11 -> 10");

        // 5
        cmd("FOC=12", 6); check(last_line == ERR && focus_index == 10, "5 FOC=12 -> ERR");
        cmd("FOC=13", 6); check(last_line == ERR && focus_index == 10, "5 FOC=13 -> ERR");
        cmd("FOC=99", 6); check(last_line == ERR && focus_index == 10, "5 FOC=99 -> ERR");

        // 6
        cmd("FOC=00",  6); check(last_line == ERR && focus_index == 10, "6 FOC=00 -> ERR");
        cmd("FOC=1A",  6); check(last_line == ERR && focus_index == 10, "6 FOC=1A -> ERR");
        cmd("FOC=5",   5); check(last_line == ERR && focus_index == 10, "6 FOC=5 -> ERR");
        cmd("FOC=005", 7); check(last_line == ERR && focus_index == 10, "6 FOC=005 -> ERR");

        // 7：焦点在 10，右移 wrap 到 0；左移 wrap 到 10；再右移 30 次不出 0..10
        cmd("NEXT", 4); check(focus_index == 0,  "7 right 10 -> 0 (skip 12/13)");
        cmd("PREV", 4); check(focus_index == 10, "7 left 0 -> 10");
        seen_bad = 1'b0;
        for (k = 0; k < 30; k = k + 1) begin
            @(negedge clk) tb_right = 1'b1;
            @(negedge clk) tb_right = 1'b0;
            if (focus_index > 10) seen_bad = 1'b1;
        end
        // 10 + 30 = 40，40 mod 11 = 7
        check(!seen_bad && focus_index == 7, "7 30 rights stay in 0..10");

        // 8
        cmd("FOC=08", 6);
        cmd("SEL", 3);
        repeat (400) @(posedge clk);
        check(!view_mode && current_index == 7, "8 FOC=08 + SEL -> full, PIC8");

        // 9：同拍方向键 + 直接设焦点，直接设焦点赢
        cmd("THUMB", 5);
        @(negedge clk) begin tb_right = 1'b1; tb_focus_v = 1'b1; tb_focus_i = 4'd3; end
        @(negedge clk) begin tb_right = 1'b0; tb_focus_v = 1'b0; end
        @(posedge clk);
        check(focus_index == 3, "9 FOC wins over same-cycle arrow");

        if (errors == 0) $display("TEST_PASS touch_foc");
        else             $display("TEST_FAIL touch_foc (%0d errors)", errors);
        $finish;
    end
endmodule
