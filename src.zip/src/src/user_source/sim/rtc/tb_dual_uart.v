`timescale 1ns/1ps
// 双串口合并自检：uart_rx_merge + media_uart_console
//   1) 上电时 CH340 路一直为低（USB 没插）：触控屏路发 TIM= 照样执行，无帧错
//   2) CH340 路恢复空闲高：从 CH340 路发 TIM= 也能执行
//   3) CH340 路中途又被拉低（拔 USB）：之后触控屏路仍可用
module tb_dual_uart;
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0;

    reg rx_a = 1'b1;     // 触控屏
    reg rx_b = 1'b0;     // CH340，上电时没插 USB
    wire rx_m;
    wire txd;
    wire        set_valid;
    wire [23:0] set_bcd;
    wire [7:0]  diag;

    uart_rx_merge #(.CLKS_PER_BIT(868)) u_merge (
        .clk(clk), .rst_n(rst_n), .rx_a(rx_a), .rx_b(rx_b),
        .rx_out(rx_m), .a_alive(), .b_alive()
    );

    media_uart_console #(.INDEX_W(4), .FOCUS_COUNT(11)) u_console (
        .clk (clk), .rst_n (rst_n),
        .uart_rxd (rx_m), .uart_txd (txd),
        .report_enable (1'b0), .media_id (4'd0), .auto_enabled (1'b0), .error_code (8'h00),
        .next_event (), .prev_event (), .auto_cfg_valid (), .auto_cfg_enabled (),
        .period_cfg_valid (), .period_cfg_cycles (), .volume (), .brightness (),
        .thumb_cfg_valid (), .thumb_cfg_enabled (), .select_event (),
        .focus_cfg_valid (), .focus_cfg_index (),
        .contrast (), .bright_cfg_valid (), .contrast_cfg_valid (),
        .key_bright_event (1'b0), .key_bright_value (8'h00),
        .key_contrast_event (1'b0), .key_contrast_value (8'h00),
        .vis_cfg (), .rtc_set_valid (set_valid), .rtc_set_bcd (set_bcd),
        .diag_code (diag)
    );

    integer errors = 0;
    reg [23:0] last_set;
    integer    sets = 0;
    always @(posedge clk) if (set_valid) begin sets = sets + 1; last_set = set_bcd; end

    task send(input which, input [7:0] b);
        integer k;
        begin
            if (which) rx_b = 1'b0; else rx_a = 1'b0;
            #8680;
            for (k = 0; k < 8; k = k + 1) begin
                if (which) rx_b = b[k]; else rx_a = b[k];
                #8680;
            end
            if (which) rx_b = 1'b1; else rx_a = 1'b1;
            #8680;
        end
    endtask

    task line(input which, input [8*10-1:0] s);
        integer k;
        begin
            for (k = 9; k >= 0; k = k - 1) send(which, s[8*k +: 8]);
            send(which, 8'h0D);
            send(which, 8'h0A);
            #50000;
        end
    endtask

    task check_set(input integer n, input [23:0] v, input [8*40-1:0] what);
        begin
            if (sets != n || last_set !== v || diag != 8'h00) begin
                $display("FAIL %0s: sets=%0d last=%h diag=%h", what, sets, last_set, diag);
                errors = errors + 1;
            end else
                $display("PASS %0s", what);
        end
    endtask

    initial begin
        #200 rst_n = 1;
        #500_000;
        line(1'b0, "TIM=111111");
        check_set(1, 24'h111111, "touch port works while USB line stuck low");

        rx_b = 1'b1;                 // 插上 USB
        #500_000;
        line(1'b1, "TIM=222222");
        check_set(2, 24'h222222, "USB port works");
        line(1'b0, "TIM=090807");
        check_set(3, 24'h090807, "touch port still works");

        rx_b = 1'b0;                 // 拔掉 USB：这一刻会有一次帧错（预期内）
        #1_000_000;
        line(1'b0, "TIM=235959");
        if (sets != 4 || last_set !== 24'h235959) begin
            $display("FAIL touch port after USB unplugged: sets=%0d last=%h", sets, last_set);
            errors = errors + 1;
        end else
            $display("PASS touch port after USB unplugged (diag=%h, 72 expected here)", diag);

        if (errors == 0) $display("ALL DUAL UART TESTS PASSED");
        else             $display("DUAL UART TESTS FAILED: %0d", errors);
        $finish;
    end
endmodule
