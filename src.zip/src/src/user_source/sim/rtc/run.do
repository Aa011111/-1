# DS3231 RTC self-check: vsim -c -do run.do  (then: python render.py)
if {[file exists work]} { vdel -lib work -all }
vlib work
foreach f {uart_rx_byte uart_tx_byte uart_line_parser uart_command_engine uart_response_tx uart_status_reporter uart_cmd_core media_uart_console} {
    vlog -quiet ../../hdl_source/uart/$f.v
}
vlog -quiet ../../hdl_source/rtc/ds3231_rtc.v
vlog -quiet ../../hdl_source/rtc/rtc_clock_osd.v
vlog -quiet -sv ds3231_model.v tb_rtc.v tb_rtc_osd.v
vsim -quiet -c -voptargs=+acc tb_rtc
run -all
quit -sim
vsim -quiet -c -voptargs=+acc tb_rtc_osd
run -all
quit -sim
# 双串口（触控屏 + 板载 CH340）合并：
#   vlog ../../hdl_source/uart/uart_rx_merge.v; vlog -sv tb_dual_uart.v; vsim -c tb_dual_uart
quit -f
