`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// AM2302 / DHT22 单总线读取 + 温度超限判定（ctrl = sd_card_clk 域）
//
// 依据《AM2302 湿敏电容数字温湿度模块 V1.2》7.2~7.4 节：
//   上电后等 2s 越过不稳定期，期间不能发起始信号；
//   主机拉低 SDA 0.8~20ms（典型 1ms）作为起始信号，然后释放（开漏，靠上拉变高）；
//   传感器拉低 80us + 拉高 80us 应答，随后高位先出 40bit：
//     湿度 16bit（x10）| 温度 16bit（x10，bit15=1 为负温度，其余为绝对值）| 校验 8bit
//     校验 = 前四个字节相加取低 8 位
//   每 bit：50us 低 + 高电平，高 26~28us = "0"，高 70us = "1"；
//   两次读取间隔 >= 2s；读到的是上一次的测量值（周期读取，不影响报警）。
// 板级：SDA 接 J2 第 8 脚（丝印 GPIOB_7 -> RN31 47R -> FPGA 网络 GPIOB10 = J3），
//   FPGA 侧只会拉低或放高阻，空闲靠上拉（模块自带上拉，pin.adc 再开内部 PULLUP）。
//   传感器请用 3V3 供电，SDA 电平才不会超过 FPGA 的 3.3V IO。
//
// 判定 bit 值：测高电平宽度，> BIT1_MIN_US 判 1。0/1 的高电平分别是 22~30us /
// 68~75us，取中间 48us。各等待都有超时，任何一步超时 / 校验错都算一次失败，
// 回到 IDLE 等下一个周期重读。
//
// temp_alarm（带回差）：温度 >= ALARM_TEMP_X10 置位，< ALARM_TEMP_X10 - HYST_X10 清除。
// 传感器失联（连续 FAIL_LIMIT 次失败）只清 data_valid，temp_alarm 保持最后一次
// 有效值：高温烧坏传感器时报警不会自己消失；上电从未读到过数据时是 0（不误报）。
// -----------------------------------------------------------------------------
module am2302_reader #(
    parameter integer CLK_FREQ_HZ    = 100_000_000,
    parameter integer POWERUP_MS     = 2000,   // 手册：上电 2s 内不能发指令
    parameter integer PERIOD_MS      = 2500,   // 手册：读取间隔 >= 2s
    parameter integer START_US       = 2000,   // 起始信号拉低，0.8~20ms
    parameter integer ALARM_TEMP_X10 = 400,    // 40.0℃ 报警
    parameter integer HYST_X10       = 20,     // 回差 2.0℃，< 38.0℃ 解除
    parameter integer FAIL_LIMIT     = 3       // 连续失败几次判失联
) (
    input  wire        clk,
    input  wire        rst_n,
    inout  wire        sda,                    // 单总线，开漏

    output reg  [15:0] humi_x10,               // 湿度 x10（%RH）
    output reg  [15:0] temp_x10,               // 温度 x10，传感器原始格式：bit15 = 负号
    output reg         data_valid,             // 1 = 最近有成功读数
    output reg         read_ok_pulse,          // 每次校验通过 1 拍
    output reg         temp_alarm              // 1 = 温度超限
);
    localparam integer CYC_US       = CLK_FREQ_HZ / 1_000_000;
    localparam integer POWERUP_CYC  = (CLK_FREQ_HZ / 1000) * POWERUP_MS;
    localparam integer PERIOD_CYC   = (CLK_FREQ_HZ / 1000) * PERIOD_MS;
    localparam integer START_CYC    = CYC_US * START_US;
    localparam integer REL_TO_CYC   = CYC_US * 100;  // 释放后等线回高
    localparam integer RESP_TO_CYC  = CYC_US * 200;  // Tgo 最大 45us，留余量
    localparam integer PHASE_TO_CYC = CYC_US * 120;  // 80us 应答 / 50us 低 / 75us 高的超时
    localparam integer BIT1_MIN_CYC = CYC_US * 48;
    localparam integer CLEAR_X10    = ALARM_TEMP_X10 - HYST_X10;

    localparam [3:0] S_POWERUP  = 4'd0,
                     S_IDLE     = 4'd1,
                     S_START    = 4'd2,
                     S_REL_HI   = 4'd3,   // 释放后等线被上拉回高
                     S_RESP_LO  = 4'd4,   // 等传感器拉低应答
                     S_RESP_LO2 = 4'd5,   // 应答低 80us
                     S_RESP_HI  = 4'd6,   // 应答高 80us
                     S_BIT_LO   = 4'd7,   // 每 bit 前 50us 低
                     S_BIT_HI   = 4'd8,   // 每 bit 高电平，测宽度
                     S_CHECK    = 4'd9;

    // 主机只拉低，不主动驱动高
    reg drive_low;
    assign sda = drive_low ? 1'b0 : 1'bz;

    // 第一级叫 s1，被 media_player_promax_top.sdc 的 */s1 通配 false_path 覆盖
    (* async_reg = "true" *) reg s1, s2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1 <= 1'b1;
            s2 <= 1'b1;
        end else begin
            s1 <= sda;
            s2 <= s1;
        end
    end
    wire line = s2;

    reg [3:0]  state;
    reg [31:0] cnt;
    reg [5:0]  bit_idx;
    reg [39:0] shreg;
    reg [3:0]  fail_cnt;

    wire [7:0] sum8 = shreg[39:32] + shreg[31:24] + shreg[23:16] + shreg[15:8];
    wire       sum_ok = (sum8 == shreg[7:0]);
    wire [15:0] new_temp = shreg[23:8];
    wire       new_neg  = new_temp[15];
    wire [14:0] new_mag = new_temp[14:0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= S_POWERUP;
            cnt           <= 32'd0;
            bit_idx       <= 6'd0;
            shreg         <= 40'd0;
            fail_cnt      <= 4'd0;
            drive_low     <= 1'b0;
            humi_x10      <= 16'd0;
            temp_x10      <= 16'd0;
            data_valid    <= 1'b0;
            read_ok_pulse <= 1'b0;
            temp_alarm    <= 1'b0;
        end else begin
            read_ok_pulse <= 1'b0;
            cnt           <= cnt + 32'd1;

            case (state)
            S_POWERUP: if (cnt >= POWERUP_CYC - 1) begin
                cnt   <= 32'd0;
                state <= S_START;
            end

            S_IDLE: if (cnt >= PERIOD_CYC - 1) begin
                cnt   <= 32'd0;
                state <= S_START;
            end

            S_START: begin
                drive_low <= 1'b1;
                if (cnt >= START_CYC - 1) begin
                    drive_low <= 1'b0;
                    cnt       <= 32'd0;
                    state     <= S_REL_HI;
                end
            end

            S_REL_HI: if (line) begin
                cnt   <= 32'd0;
                state <= S_RESP_LO;
            end else if (cnt >= REL_TO_CYC) begin
                state <= S_CHECK;           // 线一直被拉着（短路 / 无上拉）
            end

            S_RESP_LO: if (!line) begin
                cnt   <= 32'd0;
                state <= S_RESP_LO2;
            end else if (cnt >= RESP_TO_CYC) begin
                state <= S_CHECK;           // 无应答（没接 / 没电）
            end

            S_RESP_LO2: if (line) begin
                cnt   <= 32'd0;
                state <= S_RESP_HI;
            end else if (cnt >= PHASE_TO_CYC) begin
                state <= S_CHECK;
            end

            S_RESP_HI: if (!line) begin
                cnt     <= 32'd0;
                bit_idx <= 6'd0;
                state   <= S_BIT_LO;
            end else if (cnt >= PHASE_TO_CYC) begin
                state <= S_CHECK;
            end

            S_BIT_LO: if (line) begin
                cnt   <= 32'd0;
                state <= S_BIT_HI;
            end else if (cnt >= PHASE_TO_CYC) begin
                state <= S_CHECK;
            end

            S_BIT_HI: if (!line) begin
                // 第 40 bit 之后传感器还会拉低 50us 再释放，这个下降沿同样结束本 bit
                shreg   <= {shreg[38:0], (cnt >= BIT1_MIN_CYC)};
                cnt     <= 32'd0;
                bit_idx <= bit_idx + 6'd1;
                state   <= (bit_idx == 6'd39) ? S_CHECK : S_BIT_LO;
            end else if (cnt >= PHASE_TO_CYC) begin
                state <= S_CHECK;
            end

            // 成功和各种超时都汇到这里；bit_idx == 40 且校验对才算成功
            S_CHECK: begin
                cnt   <= 32'd0;
                state <= S_IDLE;
                if (bit_idx == 6'd40 && sum_ok) begin
                    humi_x10      <= shreg[39:24];
                    temp_x10      <= new_temp;
                    data_valid    <= 1'b1;
                    read_ok_pulse <= 1'b1;
                    fail_cnt      <= 4'd0;
                    if (!new_neg && new_mag >= ALARM_TEMP_X10)
                        temp_alarm <= 1'b1;
                    else if (new_neg || new_mag < CLEAR_X10)
                        temp_alarm <= 1'b0;
                end else if (fail_cnt >= FAIL_LIMIT - 1) begin
                    data_valid <= 1'b0;
                end else begin
                    fail_cnt <= fail_cnt + 4'd1;
                end
                bit_idx <= 6'd0;
            end

            default: begin
                cnt   <= 32'd0;
                state <= S_IDLE;
            end
            endcase
        end
    end
endmodule
