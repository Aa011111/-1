
// ===================== 第十四讲：KEY3/KEY4 按键调亮度/对比度 =====================
// 本工程 pin.adc 里只有 key1(B2)/key2(C1)/rst_n(A2)，KEY3/KEY4 的板级引脚
// 还没有核实过。没约束的输入口 TD 会随便挑一个管脚，悬空读进来就是乱按，
// 所以默认【关闭】：不开时顶层没有 key3/key4 端口，亮度/对比度只走串口
// BRT=XX / CON=XX，其余行为与开启时完全一样。
// 开启步骤：
//   1) 查板子原理图，在 constraints_source/pin.adc 末尾把 key3 / key4 两行
//      取消注释并填上真实 LOCATION；
//   2) 把下面这一行的注释去掉。
// `define LESSON14_KEY34

module top(
    input                       clk,
    input                       rst_n,
    input                       key1,           // 手动下一张
    input                       key2,           // 自动播放 开/关

    output [5:0]                seg_sel,
    output [7:0]                seg_data,

    // HDMI TMDS
    output                      HDMI_CLK_P,
    output                      HDMI_D2_P,
    output                      HDMI_D1_P,
    output                      HDMI_D0_P,

    // HDMI DDC
    output                      HDMI_DDC_SCL,
    inout                       HDMI_DDC_SDA,

    // TF card SPI
    output                      sd_ncs,
    output                      sd_dclk,
    output                      sd_mosi,
    input                       sd_miso,

    // 第五讲 系统稳定性：串口控制台（CH340 / USB-TTL）
    // 引脚沿用 11 UART环回与命令控制 那 4 课板级基线的 F12 / D12，
    // 约束见 constraints_source/pin.adc
    // J2 排针上的触控屏串口（N3 / P4）已删除，只剩板载 CH340（USB 口）这一路
    input                       usb_uart_rxd,   // F12
    output                      usb_uart_txd,   // D12

    // 双屏协同：本工程是外部疏散屏（RS-485 从机）。主机（火灾检测板）每 1s 发来
    // 火警等级，预警 -> PIC12，火灾 -> PIC13；目标图没进 SDRAM -> 片内 ROM 逃生画面。
    // SP3485 的 DE 与 /RE 并联接 EN。J2 排针，丝印 -> 排阻 -> FPGA 网络 -> 管脚见 rs485/README.md：
    //   rs485_rxd = RO（J2-18 丝印 GPIOB_15，H1），rs485_de = EN（J2-20 丝印 GPIOB_17，G3），
    //   rs485_txd = DI（J2-22 丝印 GPIOB_19，L5）
    input                       rs485_rxd,
    output                      rs485_txd,
    output                      rs485_de,

    // DS3231 实时时钟模块（I2C，开漏），屏幕正中显示 HH:MM:SS，见 rtc/README.md：
    //   rtc_scl = J2-24 丝印 GPIOB_21 -> RN34 -> GPIOB9  = H3
    //   rtc_sda = J2-26 丝印 GPIOB_23 -> RN34 -> GPIOB11 = F3
    //   模块 VCC 接 J2-29（3V3），GND 接 J2-30
    inout                       rtc_scl,
    inout                       rtc_sda,

    // 光敏电阻模块（4 线 LM393），自动亮度，见 light_sensor/README.md：
    //   light_do = J2-10 丝印 GPIOB_9 -> RN31 -> GPIOB6 = H4（光弱 = 高）
    //   AO 不是端口：它必须接 J1-37 丝印 GPIOA_32 -> RN28 -> GPIOB33 = R16（ADC_CH_7），
    //   由 ambient_light_ctrl 里的 EG_PHY_ADC 直接采。J2-14(M2) 不是 ADC 脚，读不了模拟量。
    //   模块 VCC 必须接 3V3（J1-29 或 J2-29）：ADC_VREF = 3V3，接 5V 会让 AO 超量程、灌进 FPGA。
    input                       light_do,

    // SW4 拨动开关 = 光敏自动亮度总开关（6_EX_DEVICE "4 bit Switch"）：
    //   SW4 公共端 SW_4 在 3V3 / GND 之间二选一 -> RN38 120R -> SWKEY_4 -> C5
    //   读到 LIGHT_SW_ON_LEVEL = 启用；拨到另一边画面不再跟环境光变，只剩手动亮度
    input                       light_en_sw
`ifdef LESSON14_KEY34
    ,
    // 第十四讲：短按 +16，按住 1s 起每 200ms -16（低有效，同 key1/key2）
    input                       key3,           // 亮度
    input                       key4            // 对比度
`endif
);

parameter MEM_DATA_BITS = 32;
parameter ADDR_BITS     = 21;
parameter FRAME_PIXELS  = 32'd307200;   // 640*480
// SDRAM 图片存储格式：1 = RGB565 两像素一字（每张 153600 字，8MB 可放 13 张），
// 0 = 原来的一像素一字 24 位（每张 307200 字，最多 6 张）。
// loader 和 pipeline(reader) 必须用同一个值，所以只在这里定义一次。
parameter PACK_RGB565   = 1;
// 13 张图：PIC1 通知 / PIC2~11 展馆内容 / PIC12 火灾预警 / PIC13 火灾发生，
// MUSIC1~13.WAV 一一对应（缺哪首那张图就静音）。
// 13 x 153600 = 1996800 字 < 2^21，SDRAM 装得下；PACK_RGB565=0 时最多只能 6 张。
parameter IMAGE_COUNT   = 13;
parameter INDEX_W       = 4;            // >= clog2(IMAGE_COUNT)
// 参与 KEY1/KEY2/串口 NEXT PREV/自动轮播/开机首图的图片：PIC1~11（bit0 = PIC1）。
// PIC12/13 平时不出现，留给火灾检测触发；缩略图里能看到、也能选中（调试用）。
parameter [12:0] NAV_MASK = 13'b0_0111_1111_1111;
// 缩略图 4x4，每格 160x120，13 张全部显示，后 3 格空着
parameter THUMB_COLS    = 4;
parameter THUMB_ROWS    = 4;
parameter CELL_W        = 4;            // >= clog2(THUMB_COLS*THUMB_ROWS)，且 >= INDEX_W
// 触控屏扩展：缩略图只显示、只可选 PIC1~11（和 NAV_MASK 一致），PIC12/13 那两格
// 与末尾 3 格一样只画底色。焦点在 0~10 循环，串口 FOC=01~11 直接设焦点。
parameter THUMB_COUNT   = 11;
// 第五讲串口接入后这两个不再是写死的常量，而是 media_uart_console 里
// volume / brightness 寄存器的复位值——上电与串口未介入时的行为和改造前
// 逐位相同（都是 255），下过 VOL=/BRT= 命令后由命令值接管。
parameter AUDIO_VOLUME     = 8'd255;    // 0~255 线性增益，255 约为原样输出
parameter VIDEO_BRIGHTNESS = 8'd255;    // 0~255 画面亮度，255 = 原样
parameter VIDEO_CONTRAST   = 8'd128;    // 第十四讲：0~255 对比度，128 = 原样
// 光敏自动亮度：1 = 送像素链路的亮度 = 自动系数 × 手动亮度(BRT=/KEY3)；0 = 只用手动亮度，
// 画面与改造前逐位相同。LIGHT_USE_ADC：1 = AO 走片内 ADC 连续调光（AO 要接 J1-37），
// 0 = 只用 DO 两档（AO 还没改线到 J1-37 时先用这个）。
parameter AUTO_BRIGHT_EN   = 1;
parameter LIGHT_USE_ADC    = 1;
// SW4 读到这个电平 = 启用光敏（1 = 拨向 3V3 那边）。上板发现方向反了只改这个。
// AUTO_BRIGHT_EN=0 时 SW4 不起作用。
parameter LIGHT_SW_ON_LEVEL = 1'b1;
// 夜间模式：右上角时钟（本机 DS3231）的小时落在 NIGHT_START_HOUR ~ NIGHT_END_HOUR 之间时，
// 画面亮度固定 NIGHT_BRIGHTNESS（不再跟光敏 / BRT= / KEY3），WAV 声音静音。
// 火警优先：报警（PIC12/13 / ROM 逃生画面）期间不进夜间模式，报警解除后再回来。
// 时间读不到（--:--:--）按白天处理。小时用 BCD 写：8'h19 = 19 点。
// START > END 表示跨零点（默认 19:00 ~ 次日 07:00，含 19:00:00，不含 07:00:00）。
// NIGHT_MODE_EN=0 关掉整个功能，和改造前逐位相同。
parameter       NIGHT_MODE_EN    = 1;
parameter [7:0] NIGHT_START_HOUR = 8'h19;
parameter [7:0] NIGHT_END_HOUR   = 8'h07;
parameter [7:0] NIGHT_BRIGHTNESS = 8'd128;  // 最大亮度的一半

// 第七讲FAT32升级：PIC1~4.BMP各自固定一块SDRAM区，开机摄入一次性写完，
// 播放切换只改读地址，不用再重新加载。
// 第八讲四bank帧缓存架构：bank基地址不再由顶层算好传给桥接模块，而是
// media_frame_loader / media_frame_reader 各自用 IMAGE_WORDS 在内部推导
// （bank_base(i) = i * IMAGE_WORDS），顶层只需保证两边的 IMAGE_WORDS 一致。
//
// 【SDRAM 单端口读写仲裁 = 时间互斥】重要，改这里之前先读明白：
// 官方 frame_read_write 内部靠 O_wr_busy/O_rd_busy 互看来协调写和读共用
// 同一个 SDRAM 端口。换成 loader/reader 分离后这层仲裁没有了——两个模块
// 各自直连 SDRAM 控制器、互不知晓。本工程用时间互斥替代：
//   摄入期 player_enable=0 -> reader 的 controller_init_done 被门控为0，
//                             一条读指令都不发，屏幕全黑（与原display_valid=0一致）
//   摄入完 player_enable=1 -> loader 永久 idle，app_wr_en 恒 0
// player_enable 取 display_valid（= 摄入结束 且 至少有一张图加载成功），
// 不是光看摄入结束——否则一张图都没有时 reader 会去读未初始化的 SDRAM 显示雪花。
// 两者永不并发。后续若要加"运行时重载单张图"，必须先补真正的仲裁器。

wire Sdr_init_done;
wire Sdr_init_ref_vld;
wire Sdr_busy;

wire sd_card_clk;
wire ext_mem_clk;
wire ext_mem_clk_sft;
wire video_clk;
wire hdmi_5x_clk;

// 视频输出（来自 media_video_pipeline 的 rgb_video_adapter，已寄存一拍）
wire        hs_raw;
wire        vs_raw;
wire        de_raw;
wire [23:0] vout_data_raw;
// 四边环绕频谱叠加后（整体延迟 5 拍）。下游 OSD 链 / 坐标计数 / AXIS 全部用这一套
wire        hs;
wire        vs;
wire        de;
wire [23:0] vout_data;
wire [7:0]  vis_cfg_sd;           // 串口 VIS=XX（ctrl 域），经 u_cfg_sd_to_video 进 video 域
wire [7:0]  vis_cfg_video;
wire        pipeline_video_clk;   // = video_clk 直通，本工程不使用
wire [9:0]  pipeline_video_x;     // 与 video_rgb 对齐的列坐标，本工程不使用

wire [3:0]  state_code;
wire [6:0]  seg_data_0;

// ===== 摄入侧（sd_card_clk 域）=====
wire [IMAGE_COUNT-1:0] resource_valid;    // FAT32扫描到的PIC1~13.BMP位图
wire [IMAGE_COUNT-1:0] ingest_complete;   // fat32本地记录（对照调试用，不驱动播放）
wire        ingest_done;       // 开机摄入(不论成败)全部尝试完成，1拍脉冲
wire [7:0]  ingest_diag_code;  // 调试用：resource_valid==0时的具体故障码
wire [7:0]  ingest_diag2_code; // 调试用：目录项名字匹配到第几步/属性位
wire [7:0]  ingest_last_r1;    // 调试用：SD 初始化最后一条命令的 R1（diag=02 时上数码管左两位）
wire [6:0]  seg_data_1, seg_data_2, seg_data_3, seg_data_4;
// 火警显示（等级来自 RS-485 主机），全部 ctrl(sd) 域，见 u_fire_alarm_ctrl
wire        alarm_sd;           // 任一报警
wire        fire_sd;            // 火灾
wire [INDEX_W-1:0] alarm_index_sd;  // 该显示的火灾图：PIC12(11) / PIC13(12)
wire        alarm_pic_sd;       // 1 = 火灾图在 SDRAM 里，像素域改读它
wire        rom_screen_sd;      // 1 = 火灾图不可用，片内 ROM 逃生画面兜底
wire        alarm_video;        // video 域
wire        rom_screen_video;
wire [INDEX_W-1:0] shown_index_sd;  // 屏幕上实际是哪张（火灾图覆盖时 = alarm_index）
wire [1:0]  remote_level_sd;    // 双屏协同：主机经 485 发来的火警等级 0/1/2
wire [7:0]  rs485_diag_code;    // 0x75 = 3.5s 收不到主机，只上数码管
reg         ingest_kicked;
// 原来 SW1 应急模式会门住摄入启动；现在有报警时更要把 PIC12/13 读进来，
// 所以复位释放后无条件发起摄入
wire        ingest_start = ~ingest_kicked;
reg         ingest_finished;   // ingest_done 锁存成电平（display_valid 的前提之一）

// fat32 -> loader 的像素流
wire        ingest_load_start;
wire [INDEX_W-1:0] ingest_image_index;
wire        ingest_pixel_valid;
wire [23:0] ingest_pixel_rgb;
wire        ingest_frame_commit;
wire [7:0]  ingest_decode_error;

// loader -> 写侧跨时钟域 -> SDRAM
wire        loader_load_busy;
wire        loader_load_done;
wire [IMAGE_COUNT-1:0] loader_image_complete;  // 播放以这个为准（额外校验了像素数和落盘字数）
wire [7:0]  loader_memory_error;
wire        loader_app_wr_en;
wire [ADDR_BITS-1:0] loader_app_wr_addr;
wire [3:0]  loader_app_wr_mask;
wire [31:0] loader_app_wr_data;
wire        wr_cdc_src_full;
wire        wr_cdc_overflow;
wire        wr_cdc_dst_idle;
wire        wr_cdc_idle_sd;         // dst_idle 同步回 sd 域
wire        sdr_init_done_sd;       // Sdr_init_done 同步到 sd 域给 loader 用

// 按键事件（sd_card_clk 域）
wire        key_next_event;
wire        key_prev_event;
wire        key_toggle_auto_event;
wire        key_init_event;
wire        key_thumb_toggle_event;   // 第十三讲：KEY1 长按 = 缩略图/全屏切换

// ===== 第五讲：串口控制台（sd_card_clk 域，与按键/摄入/播放控制同域）=====
wire        uart_next_event;
wire        uart_prev_event;
wire        uart_auto_cfg_valid;
wire        uart_auto_cfg_enabled;
wire        uart_period_cfg_valid;
wire [31:0] uart_period_cfg_cycles;
wire [7:0]  uart_volume_sd;        // ctrl 域，消费方在 video 域，见下方 cdc
wire [7:0]  uart_brightness_sd;
wire        uart_thumb_cfg_valid;   // 第十三讲：串口 THUMB / FULL
wire        uart_thumb_cfg_enabled;
wire        uart_select_event;      // 第十五讲：串口 SEL = 缩略图下确认选择
wire        uart_focus_cfg_valid;   // 触控屏：串口 FOC=NN = 直接设缩略图焦点
wire [7:0]  uart_focus_cfg_index;   // 0 起
wire [7:0]  uart_diag_code;       // 0x71 行溢出 / 0x72 帧错，只上数码管
wire [7:0]  player_error_sd;       // player_video_error 从 pix 域搬回 ctrl 域
// 写侧故障码。声明提前到这里、赋值仍留在下面数码管那一段：串口控制台的
// error_code 也要用它，而它原来是"声明+赋值合一"写在数码管段里的，
// 在这里直接引用会先被隐式 net 规则造成一根 1 位线，再和下面的显式声明撞车。
wire [7:0]  write_path_error;

// 按键与串口两个来源并联。media_player_control 的 issue_request 是单拍
// 事件驱动，两根脉冲同拍到达时只会执行一次（另一根丢失）——人手按键和
// 人手敲命令在同一拍撞上的概率可以不考虑，不值得为它加仲裁。
wire        next_event_all  = key_next_event | uart_next_event;
wire        prev_event_all  = key_prev_event | uart_prev_event;
// AUTO ON/OFF 走 auto_cfg_*（明确设定），不和 KEY2 的 toggle 混在一起：
// toggle 语义下串口无法确定最终状态，命令式配置才能"说开就是开"。
wire [7:0]  video_volume;          // video_clk 域，给 pcm_media_tone
wire [7:0]  video_brightness;      // video_clk 域，给 media_video_pipeline
wire [7:0]  video_contrast;        // 第十四讲：video_clk 域，给 media_video_pipeline
wire [7:0]  video_brightness_eff;  // 光敏：自动 × 手动后的亮度，video_clk 域，给 pipeline / 频谱环带

// ===== 第十四讲：画面参数（亮度/对比度），ctrl(sd) 域 =====
wire [7:0]  uart_contrast_sd;      // 串口最后一次 CON= 的值
wire        uart_bright_cfg_valid; // BRT= / CON= 设定脉冲
wire        uart_contrast_cfg_valid;
wire [7:0]  picture_brightness_sd; // picture_param_ctrl 持有的最终值
wire [7:0]  picture_contrast_sd;
wire        key_bright_event_sd;   // KEY3/KEY4 改了参数，给串口打日志
wire        key_contrast_event_sd;

// ===== 播放侧（media_video_pipeline）=====
wire [INDEX_W-1:0] player_active_index;    // pix 域
wire [INDEX_W-1:0] player_display_index;   // pix 域，火灾图覆盖后屏幕上实际那张
wire [INDEX_W-1:0] player_pending_index;   // ctrl(sd) 域
wire        player_auto_enabled;    // ctrl(sd) 域
wire        player_frame_start;
wire        player_reader_busy;
wire        player_underflow;
wire [7:0]  player_video_error;     // pix 域，已合并 reader/control/underflow
wire        player_thumb_mode;      // 第十三讲：ctrl(sd) 域，当前是否缩略图模式
wire        player_thumb_frame;     // 第十三讲：pix 域，按帧锁定后的显示模式

wire        display_valid;

wire App_rd_en;
wire [ADDR_BITS-1:0] App_rd_addr;
wire Sdr_rd_en;
wire [MEM_DATA_BITS-1:0] Sdr_rd_dout;
wire App_wr_en;
wire [ADDR_BITS-1:0] App_wr_addr;
wire [MEM_DATA_BITS-1:0] App_wr_din;
wire [3:0] App_wr_dm;

// HDMI 1.4b 音频发射相关
wire        pll_lock;
wire        audio_valid;
wire [23:0] audio_left_data;
wire [23:0] audio_right_data;
wire        acr_valid;
wire [19:0] acr_cts;
wire [19:0] acr_n;

wire signed [15:0] audio_sample_left;
wire signed [15:0] audio_sample_right;

// ===== 第十一讲 WAV音频播放（一图一音）=====
// 48kHz 采样节拍（video 域，一拍宽），取代原琶音源 pcm_media_tone 的 sample_valid
reg  [24:0]        sample_rate_acc;
reg                sample_tick;
// MUSIC1~13.WAV 对应 PIC1~13.BMP（sd 域，扫描完成后不再变，打包 {12,...,1,0}）
wire [IMAGE_COUNT-1:0]    track_valid;
wire [IMAGE_COUNT*32-1:0] track_start_lba;
wire [IMAGE_COUNT*32-1:0] track_sectors;
// 摄入结束后交出来的扇区读口（sd 域）
wire               wav_ext_ready;
wire               wav_sd_req;
wire [31:0]        wav_sd_lba;
wire               wav_sd_busy;
wire               wav_sd_done;
wire               wav_sd_valid;
wire [7:0]         wav_sd_byte;
wire [8:0]         wav_sd_byte_index;
wire [7:0]         wav_sd_error;
// 播放控制（sd 域）与播放器读侧输出（video 域）
reg                wav_play_enable;
reg  [16:0]        wav_gap_cnt;
reg  [31:0]        wav_play_lba;      // 正在放的文件：播放期间保持不变的起始扇区/扇区数
reg  [31:0]        wav_play_sectors;
wire               wav_writer_idle;
wire               wav_stream_end_sd;
wire signed [15:0] wav_sample;
wire               wav_sample_valid;
wire               wav_stream_end;
wire signed [15:0] wav_sample_scaled;
// 音画同步淡入淡出（video 域）
wire [7:0]         fade_alpha_pix;
wire               fade_active_pix;
wire [7:0]         fade_gain;
reg  [7:0]         audio_volume_eff;

// OSD 需要的播放器状态：第八讲后 active_index / video_error 由
// media_video_pipeline 直接在 pix 域输出，不再需要原来那套 sd->video 的
// 整包 toggle 跨域；只剩 auto_enabled 这一根 ctrl 域慢变电平要同步过来。
// （auto_play_video 的同步器实例见下方 reset_sync 之后，那里 rst_n_video 才已声明）
wire [INDEX_W-1:0] media_id_video = player_display_index;
wire [7:0]  player_error_video = player_video_error;
wire        auto_play_video;

// OSD 像素坐标与帧起点（由最终 de/vs 反推，和 vout_data 天然对齐）
reg  [11:0] osd_pixel_x;
reg  [11:0] osd_pixel_y;
reg         de_d;
reg         vs_d;
wire        osd_frame_start = vs & ~vs_d;
wire [23:0] vout_data_osd;      // 第八讲：状态条叠加后
wire [23:0] vout_data_sub;      // 第九讲：滚动字幕叠加后
wire [23:0] vout_data_ts;       // 第九讲：原时间戳叠加后（时间戳已删除，直通 vout_data_sub）
wire [23:0] vout_data_param;    // 第十四讲：亮度/对比度参数面板叠加后
wire [23:0] vout_data_rtc;      // DS3231 实时时钟（屏幕正中 HH:MM:SS）叠加后
wire [23:0] vout_data_final;    // 火灾兜底：ROM 逃生画面整屏替换后，送 AXIS 的最终像素

// DS3231 实时时钟：I2C 读写在 ctrl(sd) 域，显示在 video 域
wire        rtc_set_valid_sd;   // 串口 TIM=HHMMSS
wire [23:0] rtc_set_bcd_sd;
wire [23:0] rtc_time_bcd_sd;    // {时十, 时个, 分十, 分个, 秒十, 秒个}
wire        rtc_time_valid_sd;
wire [24:0] rtc_time_video;     // {valid, bcd}

// 第九讲 OSD字幕叠加：字幕文本源在 ctrl(sd) 域，经 toggle+2FF+帧边界提交
// 搬到 video 域。SUBTITLE_ENABLE 是字幕总开关，接常量；将来要做"按键关字幕"
// 就把它换成一根 ctrl 域寄存器，跨域这一段不用动。
wire [95:0] subtitle_text_sd;
wire [5:0]  subtitle_length_sd;
wire        subtitle_enable_sd;
wire        subtitle_commit_sd;
wire [95:0] subtitle_text_video;
wire [5:0]  subtitle_length_video;
wire        subtitle_enable_video;

wire        axis_s_user;
wire        axis_s_valid;
wire        axis_s_last;
wire [23:0] axis_s_data;
wire        axis_s_ready;

wire        edid_trig;
wire        edid_valid;
wire [7:0]  edid_data;

wire [9:0]  tmds_ch0_data;
wire [9:0]  tmds_ch1_data;
wire [9:0]  tmds_ch2_data;
wire [9:0]  tmds_clk_data;

// 统一复位：TF 图像链路 + HDMI 音频链路（仅作异步压下源，各域同步释放见下方 reset_sync）
wire rst_all;
assign rst_all = ~rst_n | ~pll_lock;

// 单 PLL 出全部 5 路时钟，频率与原来的 sys_pll + video_pll 三 PLL 方案逐路相同。
// pll_lock 现在来自真正产生这些时钟的 PLL，不再借用一个输出全悬空的音频 PLL。
sys_pll_single u_sys_pll(
    .refclk     (clk),
    .reset      (1'b0),
    .clk0_out   (sd_card_clk),      // 100MHz
    .clk1_out   (ext_mem_clk),      // 125MHz
    .clk2_out   (ext_mem_clk_sft),  // 125MHz @180°
    .clk3_out   (video_clk),        // 25MHz
    .clk4_out   (hdmi_5x_clk),      // 125MHz
    .locked     (pll_lock)
);

// ===================== 各时钟域复位同步释放 =====================
// rst_all 只保证异步压下（断电/PLL失锁瞬间立即生效，不等时钟）；
// 每个时钟域各配一个 reset_sync，在本域时钟沿上同步释放，
// 消除释放瞬间跨域恢复时间（recovery time）竞争。
// clk 域沿用原来的裸 rst_n（不叠加 pll_lock），只整形释放沿，行为与改造前一致。
wire rst_n_clk;
wire rst_n_sd;
wire rst_n_mem;
wire rst_n_video;

reset_sync u_rst_sync_clk (
    .clk         (clk),
    .ext_rst_n   (rst_n),
    .rst_n_sync  (rst_n_clk)
);

reset_sync u_rst_sync_sd (
    .clk         (sd_card_clk),
    .ext_rst_n   (~rst_all),
    .rst_n_sync  (rst_n_sd)
);

reset_sync u_rst_sync_mem (
    .clk         (ext_mem_clk),
    .ext_rst_n   (~rst_all),
    .rst_n_sync  (rst_n_mem)
);

reset_sync u_rst_sync_video (
    .clk         (video_clk),
    .ext_rst_n   (~rst_all),
    .rst_n_sync  (rst_n_video)
);

// auto_enabled 是 ctrl(sd) 域的慢变电平，OSD 在 video 域用，过2FF同步
sync_2ff u_auto_play_video_sync (
    .clk         (video_clk),
    .rst_n       (rst_n_video),
    .async_in    (player_auto_enabled),
    .sync_out    (auto_play_video)
);

// 写侧跨时钟域模块的 dst_idle 是 mem 域电平，摄入状态机在 sd 域要用，过2FF。
// 空闲态是1，所以 RESET_VAL 也取1，复位期间不会误判成"还在搬运"。
sync_2ff #(.RESET_VAL(1'b1)) u_wr_cdc_idle_sync (
    .clk         (sd_card_clk),
    .rst_n       (rst_n_sd),
    .async_in    (wr_cdc_dst_idle),
    .sync_out    (wr_cdc_idle_sd)
);

// SDRAM 初始化完成是 mem 域电平，loader 在 sd 域要用，过2FF
sync_2ff u_sdr_init_done_sync (
    .clk         (sd_card_clk),
    .rst_n       (rst_n_sd),
    .async_in    (Sdr_init_done),
    .sync_out    (sdr_init_done_sd)
);

// ===================== 火警显示：等级来自 RS-485 主机 =====================
// 在 sd 域判定（remote=2 火灾 PIC13，remote=1 预警 PIC12），
// 并按"目标图有没有真的进 SDRAM"二选一：
//   alarm_pic  -> media_video_pipeline 在像素域把 reader 改读火灾图（整屏、不转场）
//   rom_screen -> emergency_screen 用片内 ROM 整屏覆盖（不依赖 TF 卡 / SDRAM）
// 摄入没结束、没插卡、卡坏、PIC12/13.BMP 坏，都落到 rom_screen。
fire_alarm_ctrl #(
    .IMAGE_COUNT        (IMAGE_COUNT),
    .INDEX_W            (INDEX_W),
    .WARN_INDEX         (11),     // PIC12 火灾预警
    .FIRE_INDEX         (12)      // PIC13 火灾发生
) u_fire_alarm_ctrl (
    .clk            (sd_card_clk),
    .rst_n          (rst_n_sd),
    .remote_level   (remote_level_sd),   // 双屏协同：主机发来的火警等级
    // display_valid：摄入结束且 reader 已放行（只有它为 1 时 SDRAM 里的图才读得出来）
    .player_ready   (display_valid),
    .image_complete (loader_image_complete),
    .alarm          (alarm_sd),
    .fire           (fire_sd),
    .alarm_index    (alarm_index_sd),
    .alarm_pic      (alarm_pic_sd),
    .rom_screen     (rom_screen_sd)
);

// 屏幕上实际显示的那张（sd 域），给数码管 / 串口 / 字幕用
assign shown_index_sd = alarm_pic_sd ? alarm_index_sd : player_pending_index;

// ===================== 双屏协同：RS-485 从机 =====================
// 收主机 STATUS 帧 -> remote_level 进上面的 fire_alarm_ctrl（预警 PIC12 / 火灾 PIC13，
// 图不在 SDRAM 时照样退到 ROM 逃生画面，MUSIC12/13 也跟着放），并回 ACK 告诉主机
// 此刻屏上是什么。主机掉线时 remote_level 保持最后的值（火场里主机板坏了，
// 疏散画面不能自己消失），只能由主机一帧"正常"解除。协议见 rs485/README.md。
// ACK 里同时带上本机 DS3231 的时分秒：主机（src_zhu）不接时钟模块，靠它显示时间。
// 主机每 200ms 轮询一次（原来 1s），本机校时（TIM=）后主机约 0.3s 内跟上。
rs485_alarm_slave #(
    .CLK_FREQ_HZ     (100_000_000),
    .BAUD            (9600),
    .REPLY_DELAY_MS  (2),
    .LINK_TIMEOUT_MS (3500),
    .MY_ADDR         (8'h01)
) u_rs485_alarm_slave (
    .clk             (sd_card_clk),
    .rst_n           (rst_n_sd),
    // 0 正常 / 1 PIC12 / 2 PIC13 / 3 ROM 逃生画面
    .shown_state     (rom_screen_sd ? 8'd3 :
                      !alarm_pic_sd ? 8'd0 :
                      (alarm_index_sd == 12) ? 8'd2 : 8'd1),
    .local_flags     (8'd0),             // 本机不接传感器，ACK 里的本地原因位恒 0
    // 同在 sd 域，ds3231_rtc 的寄存器输出，不用跨域
    .time_bcd        (rtc_time_bcd_sd),
    .time_valid      (rtc_time_valid_sd),
    .rs485_rxd       (rs485_rxd),
    .rs485_txd       (rs485_txd),
    .rs485_de        (rs485_de),
    .remote_level    (remote_level_sd),
    .remote_flags    (),
    .link_lost       (),
    .diag_code       (rs485_diag_code)
);

// 慢变单比特电平，2FF 即可。alarm 给音频增益和频谱火警特效用，rom_screen 给 emergency_screen
sync_2ff u_alarm_video_sync (
    .clk         (video_clk),
    .rst_n       (rst_n_video),
    .async_in    (alarm_sd),
    .sync_out    (alarm_video)
);

sync_2ff u_rom_screen_video_sync (
    .clk         (video_clk),
    .rst_n       (rst_n_video),
    .async_in    (rom_screen_sd),
    .sync_out    (rom_screen_video)
);

// 复位释放后打一拍发起摄入，不用等SDRAM就绪——loader 内部自己看
// controller_init_done，SDRAM没准备好它就不发burst，不需要在这里额外判断。
always @(posedge sd_card_clk or negedge rst_n_sd) begin
    if (!rst_n_sd)
        ingest_kicked <= 1'b0;
    else
        ingest_kicked <= 1'b1;
end

// ingest_done 是1拍脉冲，锁存成电平当 player_enable：
// 摄入全部尝试完成之前不让 reader 碰 SDRAM（单端口时间互斥，见文件头说明）
always @(posedge sd_card_clk or negedge rst_n_sd) begin
    if (!rst_n_sd)
        ingest_finished <= 1'b0;
    else if (ingest_done)
        ingest_finished <= 1'b1;
end

// ===================== TF卡FAT32扫描与开机一次性摄入 =====================
fat32_storage_ingest_top #(
    // 100MHz下125对应400kHz，识别阶段(CMD0~CMD58)必须不超过这个速度，
    // 否则真实SD卡常见CMD0握手不上（对照老驱动SD/sd_card_top.v的
    // SPI_LOW_SPEED_DIV=248算出来的200kHz，这里给得更宽松一点）
    .INIT_SPI_CLK_DIV          (125),
    .READ_SPI_CLK_DIV          (4),           // 12.5MHz，数据传输阶段
    .BMP_WIDTH                 (640),
    .BMP_HEIGHT                (480),
    .INIT_STARTUP_DELAY_CYCLES (10_000_000),  // 100ms @ 100MHz sd_card_clk
    // 第十三讲 不同分辨率适配：除 640x480 外也接受 1280x960 的 BMP，
    // bmp24_decoder 在解码时 2x2 求平均缩成 640x480（比最近邻抽取质量好，
    // 下游 loader/SDRAM/reader 全部无感）。1280x960 文件约 3.7MB，
    // SPI 12.5MHz 下要读 3~4 秒，watchdog 从 2s 放宽到 8s。
    // 照片缩放自适应：再放开 640x480 ~ 4096x4096 的任意尺寸，居中裁成 4:3
    // 后最近邻缩到 640x480（1280x960 仍走上面的 2x2 平均）。
    // 读卡约 1MB/s：1920x1080 (6MB) 约 6s，2592x1944 (15MB) 约 15s，
    // watchdog 放宽到 20s（parameter integer 上限约 21s）。更大的图会超时被跳过。
    .IMAGE_TIMEOUT_CYCLES      (2_000_000_000), // 20s @ 100MHz
    .ALLOW_2X_SOURCE           (1),
    .ALLOW_SCALE_SOURCE        (1),
    .MAX_SOURCE_DIM            (4096),
    .IMAGE_COUNT               (IMAGE_COUNT),
    .INDEX_W                   (INDEX_W)
) u_fat32_storage_ingest (
    .clk                (sd_card_clk),
    .rst_n              (rst_n_sd),
    .start              (ingest_start),
    .busy               (),
    .ingest_done        (ingest_done),
    .card_ready         (),
    .resource_valid     (resource_valid),
    .image_complete     (ingest_complete),
    .diag_code          (ingest_diag_code),
    .diag2_code         (ingest_diag2_code),
    .diag_last_r1       (ingest_last_r1),
    .sd_ncs             (sd_ncs),
    .sd_dclk            (sd_dclk),
    .sd_mosi            (sd_mosi),
    .sd_miso            (sd_miso),
    .cdc_idle           (wr_cdc_idle_sd),
    .load_start         (ingest_load_start),
    .load_busy          (loader_load_busy),
    .load_done          (loader_load_done),
    .image_index        (ingest_image_index),
    .pixel_valid        (ingest_pixel_valid),
    .pixel_rgb          (ingest_pixel_rgb),
    .frame_commit       (ingest_frame_commit),
    .decode_error       (ingest_decode_error),
    // 第十一讲：MUSIC1~13.WAV 位置 + 摄入结束后交给 wav_stream_player 的扇区读口
    .track_valid        (track_valid),
    .track_start_lba    (track_start_lba),
    .track_sectors      (track_sectors),
    .ext_ready          (wav_ext_ready),
    .ext_sector_req     (wav_sd_req),
    .ext_sector_lba     (wav_sd_lba),
    .ext_sector_busy    (wav_sd_busy),
    .ext_sector_done    (wav_sd_done),
    .ext_sector_valid   (wav_sd_valid),
    .ext_sector_byte    (wav_sd_byte),
    .ext_sector_byte_index(wav_sd_byte_index),
    .ext_sector_error   (wav_sd_error)
);

// ===================== 第八讲：帧加载器（写侧）=====================
// 跑在 sd_card_clk 域，跟 bmp24_decoder 同域，像素流直连不需要跨域。
// V_FLIP=1 顶替原 frame_fifo_write 的 WRITE_V_FLIP：BMP 自底向上存储，
// 写地址按行倒序落盘，否则画面上下颠倒。
media_frame_loader #(
    .ADDR_WIDTH   (ADDR_BITS),
    .IMAGE_WORDS  (FRAME_PIXELS),
    .FIFO_DEPTH   (512),
    .BURST_SIZE   (128),
    .STALL_TIMEOUT(65535),
    .V_FLIP       (1),
    .FRAME_WIDTH  (640),
    .FRAME_HEIGHT (480),
    .PACK_RGB565  (PACK_RGB565),
    .IMAGE_COUNT  (IMAGE_COUNT),
    .INDEX_W      (INDEX_W)
) u_media_frame_loader (
    .clk                 (sd_card_clk),
    .rst_n               (rst_n_sd),
    .load_start          (ingest_load_start),
    .image_index         (ingest_image_index),
    .pixel_valid         (ingest_pixel_valid),
    .pixel_rgb           (ingest_pixel_rgb),
    .frame_commit        (ingest_frame_commit),
    .decode_error        (ingest_decode_error),
    .load_busy           (loader_load_busy),
    .load_done           (loader_load_done),
    .image_complete      (loader_image_complete),
    .memory_error        (loader_memory_error),
    // loader 在 sd 域，SDRAM 状态信号在 mem 域，要跨域。
    // controller_init_done 是 loader 里唯一真正参与逻辑的一根（门控
    // start_burst/pop_allowed），过 sync_2ff；上电拉高后就不再变，同步后
    // 只是晚两拍看到 SDRAM 就绪，行为无影响。
    // controller_busy / refresh_active 在 media_frame_loader 内部是悬空输入
    // （讲义注释说明：控制器自己处理 busy/refresh，这两根不是逐字 ready，
    //  不能用来打断正在进行的写 burst），这里接着只是保持接口完整。
    .controller_init_done(sdr_init_done_sd),
    .controller_busy     (Sdr_busy),
    .refresh_active      (Sdr_init_ref_vld),
    .app_wr_en           (loader_app_wr_en),
    .app_wr_addr         (loader_app_wr_addr),
    .app_wr_mask         (loader_app_wr_mask),
    .app_wr_data         (loader_app_wr_data)
);

// 写侧跨时钟域：sd_card_clk(100MHz) -> ext_mem_clk(125MHz)。
// 按 BURST_SIZE 成块搬运，dst 侧输出的 app_wr_en 仍是连续128拍的真burst。
// 307200/128=2400 整除（PACK_RGB565=1 时每张 153600 字 = 1200 块，同样整除），
// 块指针机制能把整帧搬干净，不留尾巴。
media_sdram_write_cdc #(
    .ADDR_WIDTH     (ADDR_BITS),
    .FIFO_ADDR_WIDTH(9),
    .BURST_SIZE     (128)
) u_media_sdram_write_cdc (
    .src_clk        (sd_card_clk),
    .src_rst_n      (rst_n_sd),
    .src_wr_en      (loader_app_wr_en),
    .src_wr_addr    (loader_app_wr_addr),
    .src_wr_mask    (loader_app_wr_mask),
    .src_wr_data    (loader_app_wr_data),
    .src_full       (wr_cdc_src_full),
    .src_overflow   (wr_cdc_overflow),
    .dst_clk        (ext_mem_clk),
    .dst_rst_n      (rst_n_mem),
    .dst_app_wr_en  (App_wr_en),
    .dst_app_wr_addr(App_wr_addr),
    .dst_app_wr_mask(App_wr_dm),
    .dst_app_wr_data(App_wr_din),
    .dst_idle       (wr_cdc_dst_idle)
);

// ===================== 第八讲：按键事件 =====================
// 原 media_playback_selector 里的按键裁决部分，index 管理交给了
// media_video_pipeline 内的 media_player_control（帧消隐期原子提交防撕裂）
media_key_events #(
    .CLK_FREQ_HZ  (100_000_000),
    .LONG_PRESS_MS(1000),
    .IMAGE_COUNT  (IMAGE_COUNT)
) u_media_key_events (
    .clk              (sd_card_clk),
    .rst_n            (rst_n_sd),
    .key_next         (key1),
    .key_auto         (key2),
    .ingest_done      (ingest_done),
    .ready            (display_valid),
    // 只数参与轮播的那几张：火灾图不算，"只有一张图时不开轮播"的判断才对
    .image_complete   (loader_image_complete & NAV_MASK),
    .thumb_mode       (player_thumb_mode),        // 第十五讲：缩略图下 KEY2 短按=返回，不门控
    .next_event       (key_next_event),
    .prev_event       (key_prev_event),
    .toggle_auto_event(key_toggle_auto_event),
    .init_event       (key_init_event),
    .thumb_toggle_event(key_thumb_toggle_event)   // 第十三讲：KEY1 长按
);

// ===================== 第五讲：串口控制台 =====================
// 第五讲 3.2 的"可观测性层"：uart_status_reporter 把 banner / 图片切换 /
// 参数变更 / 错误码打成 CR/LF 文本行；11 UART环回与命令控制 那 4 课的三层
// 命令架构反过来收 NEXT / PREV / AUTO / VOL= / BRT= / PRD= / STATUS。
// 整块跑在 sd_card_clk（= ctrl 域），控制口直连 media_video_pipeline 已经
// 留好的 next/prev/auto_cfg/period_cfg，一根新信号都不用往下游插。
//
// report_enable 接 display_valid：摄入成功、真的开始显示时才打
// "MEDIA PLAYER READY"，而不是复位一释放就打（那时 SD 卡还没读）。
//
// error_code 的优先级和数码管那两组诊断码保持同一套语义，取最靠近故障
// 现场的一个：写侧 > 读侧/控制 > 摄入。UART 自身的行溢出/帧错【不】进
// 这个口（走 uart_diag_code 上数码管），否则一次帧错就会让 error_code
// 长期非 0，把 reporter 的 PIC 行全挡住（reporter ST_IDLE 里 ERR 优先于 PIC）。
wire ingest_failed = ingest_finished && !display_valid;
wire [7:0] uart_error_code =
    (write_path_error != 8'h00) ? write_path_error :
    (player_error_sd  != 8'h00) ? player_error_sd  :
    // 摄入失败但 diag_code 恰好是 0 时给一个兜底码，保证串口上能看见
    // "出事了"，而不是一片安静（数码管那边由 fail_reason 兜）
    ingest_failed ? ((ingest_diag_code != 8'h00) ? ingest_diag_code : 8'h70) :
                    8'h00;

// 控制台只接板载 CH340 一路（J2 触控屏串口已删除）。
//   RX：仍经 uart_rx_merge，借用它的 2FF 同步和"掉线屏蔽"——USB 没插时 CH340
//       的 TXD 可能被拉低，不屏蔽 console 会一直报帧错 0x72。原触控屏那一路
//       rx_a 恒接 1（空闲态），永远判不在线，综合时整路被优化掉。
//   TX：console 的 uart_txd 只送 D12
wire uart_rxd_merged;
wire uart_txd_console;
assign usb_uart_txd = uart_txd_console;

uart_rx_merge #(
    .CLKS_PER_BIT (868),            // 100MHz / 115200，与 console 一致
    .DEAD_BITS    (20),
    .ALIVE_BITS   (20)
) u_uart_rx_merge (
    .clk     (sd_card_clk),
    .rst_n   (rst_n_sd),
    .rx_a    (1'b1),                // 原 J2 触控屏 RX，已删除
    .rx_b    (usb_uart_rxd),
    .rx_out  (uart_rxd_merged),
    .a_alive (),
    .b_alive ()
);

media_uart_console #(
    .CLK_FREQ_HZ       (100_000_000),   // sd_card_clk
    .BAUD_RATE         (115_200),       // -> CLKS_PER_BIT = 868
    .DEFAULT_VOLUME    (AUDIO_VOLUME),
    .DEFAULT_BRIGHTNESS(VIDEO_BRIGHTNESS),
    .DEFAULT_CONTRAST  (VIDEO_CONTRAST),
    .INDEX_W           (INDEX_W),
    .FOCUS_COUNT       (THUMB_COUNT)
) u_media_uart_console (
    .clk               (sd_card_clk),
    .rst_n             (rst_n_sd),
    .uart_rxd          (uart_rxd_merged),
    .uart_txd          (uart_txd_console),
    // 状态输入：pending_index 与本模块同域，不用跨域取 active_index。
    // 火灾图覆盖时报火灾图（报警一起、PIC 行就会打出 12/13）
    .report_enable     (display_valid),
    .media_id          (shown_index_sd),
    .auto_enabled      (player_auto_enabled),
    .error_code        (uart_error_code),
    // 控制输出
    .next_event        (uart_next_event),
    .prev_event        (uart_prev_event),
    .auto_cfg_valid    (uart_auto_cfg_valid),
    .auto_cfg_enabled  (uart_auto_cfg_enabled),
    .period_cfg_valid  (uart_period_cfg_valid),
    .period_cfg_cycles (uart_period_cfg_cycles),
    .volume            (uart_volume_sd),
    .brightness        (uart_brightness_sd),
    .thumb_cfg_valid   (uart_thumb_cfg_valid),     // 第十三讲：THUMB / FULL
    .thumb_cfg_enabled (uart_thumb_cfg_enabled),
    .select_event      (uart_select_event),        // 第十五讲：SEL
    .focus_cfg_valid   (uart_focus_cfg_valid),     // 触控屏：FOC=NN
    .focus_cfg_index   (uart_focus_cfg_index),
    // 第十四讲：CON= 对比度 + 两路设定脉冲；按键改值时回灌给 reporter 打日志
    .contrast          (uart_contrast_sd),
    .bright_cfg_valid  (uart_bright_cfg_valid),
    .contrast_cfg_valid(uart_contrast_cfg_valid),
    .key_bright_event  (key_bright_event_sd),
    .key_bright_value  (picture_brightness_sd),
    .key_contrast_event(key_contrast_event_sd),
    .key_contrast_value(picture_contrast_sd),
    .vis_cfg           (vis_cfg_sd),
    .rtc_set_valid     (rtc_set_valid_sd),     // TIM=HHMMSS 校时
    .rtc_set_bcd       (rtc_set_bcd_sd),
    .diag_code         (uart_diag_code)
);

// ===================== DS3231 实时时钟 =====================
// 每 100ms 经 I2C 读一次时分秒；串口 TIM=HHMMSS 校时（写完立即读回）。
// 读不到（没接 / 不应答）时 time_valid=0，屏幕显示 --:--:--。
ds3231_rtc #(
    .CLK_FREQ_HZ (100_000_000),     // sd_card_clk
    .I2C_HZ      (100_000),
    .POLL_MS     (100)
) u_ds3231_rtc (
    .clk           (sd_card_clk),
    .rst_n         (rst_n_sd),
    .scl           (rtc_scl),
    .sda           (rtc_sda),
    .set_valid     (rtc_set_valid_sd),
    .set_bcd       (rtc_set_bcd_sd),
    .time_bcd      (rtc_time_bcd_sd),
    .time_valid    (rtc_time_valid_sd),
    .read_ok_pulse ()
);

// 时间 + valid 共 25 位，每秒才变一次，用 cdc_bus_commit 整包搬进 video 域。
// 第一级同步器同样叫 commit_sync1，已被 sdc 第 6 节通配覆盖，不用加约束。
// 复位值 valid=0：上电第一次读到之前显示 --:--:--。
cdc_bus_commit #(
    .WIDTH    (25),
    .RESET_VAL(25'd0)
) u_rtc_time_to_video (
    .src_clk   (sd_card_clk),
    .src_rst_n (rst_n_sd),
    .src_data  ({rtc_time_valid_sd, rtc_time_bcd_sd}),
    .src_busy  (),
    .dst_clk   (video_clk),
    .dst_rst_n (rst_n_video),
    .dst_data  (rtc_time_video),
    .dst_update()
);

// ===================== 第十四讲：画面参数控制 =====================
// 讲义 3.3：KEY3 短按加亮度/长按减亮度，KEY4 短按加对比度/长按减对比度；
// 串口 BRT= / CON= 直接设定绝对值。两路汇到 picture_param_ctrl 一个地方，
// 输出的 brightness/contrast 才是真正送去像素链路的值。
// 没开 LESSON14_KEY34 时按键口接 1（永远松开），只剩串口。
`ifdef LESSON14_KEY34
wire key_bright_n   = key3;
wire key_contrast_n = key4;
`else
wire key_bright_n   = 1'b1;
wire key_contrast_n = 1'b1;
`endif

picture_param_ctrl #(
    .CLK_FREQ_HZ       (100_000_000),   // sd_card_clk
    .DEBOUNCE_MS       (20),
    .LONG_PRESS_MS     (1000),
    .REPEAT_MS         (200),
    .DEFAULT_BRIGHTNESS(VIDEO_BRIGHTNESS),
    .DEFAULT_CONTRAST  (VIDEO_CONTRAST),
    .BRIGHT_STEP       (8'd16),
    .CONTRAST_STEP     (8'd16)
) u_picture_param_ctrl (
    .clk                (sd_card_clk),
    .rst_n              (rst_n_sd),
    .ready              (display_valid),
    .key_bright_n       (key_bright_n),
    .key_contrast_n     (key_contrast_n),
    .uart_bright_valid  (uart_bright_cfg_valid),
    .uart_bright_value  (uart_brightness_sd),
    .uart_contrast_valid(uart_contrast_cfg_valid),
    .uart_contrast_value(uart_contrast_sd),
    .brightness         (picture_brightness_sd),
    .contrast           (picture_contrast_sd),
    .key_bright_event   (key_bright_event_sd),
    .key_contrast_event (key_contrast_event_sd)
);

// ===================== 光敏电阻：环境光自动亮度 =====================
// AO -> 片内 ADC(CH7, R16 = J1-37) -> 平均 + IIR -> 光照曲线 -> 死区 + 每 20ms 一级爬坡 -> auto_level
// ADC 连续不应答（或 LIGHT_USE_ADC=0）时退回 DO 两档：暗 176 / 亮 255。
// SW4 拨到关：auto_level 平滑爬回 255（最多约 5s），等于只用手动亮度；拨回开再平滑降下来。
// 最终亮度 = auto_level × (手动亮度+1) / 256：手动 BRT=FF（默认）时就是纯自动；
// BRT= / KEY3 仍然能在自动值上整体压暗。参数面板 B: 显示的仍是手动值，
// 否则自动亮度每变一级面板就会弹一次。
wire [7:0]  light_auto_level_sd;
wire [11:0] light_code_sd;          // 调试：滤波后的 ADC 码，越小越亮
wire        light_adc_ok_sd;
wire        light_dark_sd;

ambient_light_ctrl #(
    .CLK_FREQ_HZ   (100_000_000),   // sd_card_clk
    .USE_ADC       (LIGHT_USE_ADC),
    .ADC_CHANNEL   (3'd7),          // R16 = J1-37
    .ADC_CLK_DIV   (16),            // 6.25MHz，手册上限 16MHz
    .SAMPLE_MS     (1),
    .AVG_SHIFT     (6),
    .IIR_SHIFT     (3),
    .RAMP_MS       (20),
    .DEADBAND      (8'd4),
    .DO_DARK_LEVEL (8'd176),
    .EN_ACTIVE_LEVEL(LIGHT_SW_ON_LEVEL)
) u_ambient_light_ctrl (
    .clk        (sd_card_clk),
    .rst_n      (rst_n_sd),
    .light_do   (light_do),
    .light_en   (light_en_sw),
    .auto_level (light_auto_level_sd),
    .light_code (light_code_sd),
    .adc_ok     (light_adc_ok_sd),
    .light_dark (light_dark_sd)
);

// ===================== 夜间模式（默认 19:00 ~ 次日 07:00） =====================
// 判定在 sd 域：时间（ds3231_rtc 输出）和 alarm_sd 都在这个域，直接用。
// 亮度、音量都经下面的 u_cfg_sd_to_video 送 video 域，不用另开跨域。
// 到点那一拍亮度直接跳到 128，不走光敏的爬坡（一天只发生两次）。
// 夜里 WAV 播放器照常走，只是音量为 0，早上 07:00 接着当前位置出声。
wire [7:0] rtc_hour_bcd_sd = rtc_time_bcd_sd[23:16];
wire       night_hours_sd  = (NIGHT_START_HOUR > NIGHT_END_HOUR)
                           ? (rtc_hour_bcd_sd >= NIGHT_START_HOUR || rtc_hour_bcd_sd < NIGHT_END_HOUR)
                           : (rtc_hour_bcd_sd >= NIGHT_START_HOUR && rtc_hour_bcd_sd < NIGHT_END_HOUR);
reg        night_sd;
always @(posedge sd_card_clk or negedge rst_n_sd) begin
    if (!rst_n_sd)
        night_sd <= 1'b0;
    else
        night_sd <= (NIGHT_MODE_EN != 0) && rtc_time_valid_sd && night_hours_sd && !alarm_sd;
end
wire [7:0] volume_eff_sd = night_sd ? 8'd0 : uart_volume_sd;

// 255 × 256 >> 8 = 255：自动、手动都满时逐位原样
wire [16:0] bright_mix_mul = {9'd0, light_auto_level_sd} * ({9'd0, picture_brightness_sd} + 17'd1);
reg  [7:0]  final_brightness_sd;
always @(posedge sd_card_clk or negedge rst_n_sd) begin
    if (!rst_n_sd)
        final_brightness_sd <= VIDEO_BRIGHTNESS;
    else
        final_brightness_sd <= night_sd                ? NIGHT_BRIGHTNESS :
                               (AUTO_BRIGHT_EN != 0) ? bright_mix_mul[15:8] : picture_brightness_sd;
end

// volume / brightness 的消费方都在 video_clk 域（pcm_media_tone 和
// media_video_pipeline 的 brightness 口），要从 ctrl 域搬过去。
// 两个都是 8 位 bundled data，不能逐位 2FF（见 common/sync_2ff.v 的合同
// 边界），所以合成一条 16 位总线用一个 cdc_bus_commit 搬——省一套握手，
// 两个量本来也总是一起慢变。
// RESET_VAL 取两个默认值拼起来，上电两域天然一致，不依赖第一次搬运。
// 第十四讲：总线从 16 位扩成 24 位，把对比度也捎上；亮度/对比度改取
// picture_param_ctrl 的输出（串口 + 按键合并后的最终值）。
// 按键连发 200ms 一次，远慢于本模块一次搬运（两域各 3~4 拍），不会丢值。
// 四边频谱：再扩到 32 位，最高字节捎上 VIS=XX（复位值 12 与命令引擎 DEFAULT_VIS 一致）。
// 光敏：再扩到 40 位，最高字节 = 自动 × 手动后的最终亮度（给 pipeline/频谱），
// [15:8] 仍是手动亮度（给参数面板）。爬坡 20ms 一级，远慢于一次搬运。
wire [39:0] audio_video_cfg_video;
cdc_bus_commit #(
    .WIDTH    (40),
    .RESET_VAL({VIDEO_BRIGHTNESS, 8'h12, VIDEO_CONTRAST, VIDEO_BRIGHTNESS, AUDIO_VOLUME})
) u_cfg_sd_to_video (
    .src_clk   (sd_card_clk),
    .src_rst_n (rst_n_sd),
    .src_data  ({final_brightness_sd, vis_cfg_sd, picture_contrast_sd, picture_brightness_sd, volume_eff_sd}),  // 夜间音量 0
    .src_busy  (),
    .dst_clk   (video_clk),
    .dst_rst_n (rst_n_video),
    .dst_data  (audio_video_cfg_video),
    .dst_update()
);
assign video_volume     = audio_video_cfg_video[7:0];
assign video_brightness = audio_video_cfg_video[15:8];
assign video_contrast   = audio_video_cfg_video[23:16];
assign vis_cfg_video    = audio_video_cfg_video[31:24];
assign video_brightness_eff = audio_video_cfg_video[39:32];

// 反向：player_video_error 在 pix 域产出，reporter 在 ctrl 域要用它报 ERR。
// 同样是 8 位慢变 bundled data（一次故障置上就不怎么变），用 cdc_bus_commit。
cdc_bus_commit #(
    .WIDTH(8)
) u_player_error_to_sd (
    .src_clk   (video_clk),
    .src_rst_n (rst_n_video),
    .src_data  (player_error_video),
    .src_busy  (),
    .dst_clk   (sd_card_clk),
    .dst_rst_n (rst_n_sd),
    .dst_data  (player_error_sd),
    .dst_update()
);

// ===================== 数码管状态码 =====================
// 末位 state_code：0=还在摄入中；1=摄入结束但一张图都没扫到；
// 2=扫到文件但参与轮播的图（PIC1~11）全部摄入失败；E=火灾报警但火灾图
// 不可用、正在显示 ROM 逃生画面。火灾图正常覆盖时显示 12 / 13。
// 13 张图扩展：原来 3~6 = 正在显示图 0~3，一位十六进制放不下 13 张，
// 改成正常显示时最右两位显示两位十进制图号 01~13（十位常亮，"01" 和
// 状态码 "1" 靠十位亮不亮区分）。index 源仍是 pending_index（sd 域）。
// 诊断码四位整体左移一位（原来最左一位一直空着），见下面 seg_scan。
//
// display_valid 只看参与轮播的图：只有火灾图加载成功时不算"有图可放"，
// 否则开机首图落位找不到目标，reader 会去读 bank0 的空数据。
assign display_valid = ingest_finished && ((loader_image_complete & NAV_MASK) != 0);
wire [3:0] fail_reason = (resource_valid == 0) ? 4'd1 : 4'd2;
// ROM 逃生画面时末位显示 E
wire       show_pic_no = !rom_screen_sd && ingest_finished && display_valid;
wire [4:0] pic_no      = shown_index_sd + 1'b1;           // 1~13
wire       pic_tens    = pic_no >= 5'd10;
wire [3:0] pic_ones    = pic_tens ? pic_no - 5'd10 : pic_no[3:0];
assign state_code = rom_screen_sd    ? 4'hE :
                    !ingest_finished ? 4'd0 :
                     display_valid   ? pic_ones :
                                       fail_reason;
wire [6:0] seg_pic_tens;
seg_decoder seg_decoder_pic_tens(
    .bin_data          ({3'b000, pic_tens}),
    .seg_data          (seg_pic_tens)
);

seg_decoder seg_decoder_m0(
    .bin_data          (state_code),
    .seg_data          (seg_data_0)
);

// 调试用第一组：出故障时显示具体故障码。第八讲后这一组有了两个来源，
// 按"谁更接近故障现场"排优先级：
//   loader_memory_error 非0 -> 写侧故障（0x41~0x46，见 media_frame_loader.v）
//   否则                    -> ingest_diag_code（SD初始化0x00~0x0c / FAT32扫描0x10~0x22）
// 0x47 是本顶层补的一个码，接在 loader 自己的 0x41~0x46 之后：写侧跨时钟域
// FIFO 溢出。loader 看不到它（它没有 ready 反压输入），只能在这里报出来。
// 声明在上方 UART 段之前（那里也要用），这里只赋值
assign write_path_error = (loader_memory_error != 8'h00) ? loader_memory_error :
                          (wr_cdc_overflow              ) ? 8'h47 : 8'h00;

wire [7:0] diag_primary = (write_path_error != 8'h00) ? write_path_error :
                                                        ingest_diag_code;

seg_decoder seg_decoder_diag_hi(
    .bin_data          (diag_primary[7:4]),
    .seg_data          (seg_data_3)
);

seg_decoder seg_decoder_diag_lo(
    .bin_data          (diag_primary[3:0]),
    .seg_data          (seg_data_4)
);

// 调试用第二组：读侧故障码优先（0x61帧溢出/0x62FIFO溢出/0x63显示下溢/
// 0x64短帧/0x51~0x53控制错误，见 media_frame_reader.v 与 media_player_control.v），
// 没有读侧故障时看串口自身故障（0x71 命令被丢弃 / 0x72 接收帧错，见
// uart/media_uart_console.v），都没有才退回显示 diag2_code（目录项名字
// 匹配深度+属性位）。
// 串口故障排在读侧之后：读侧故障会花屏，串口故障只是这一条命令没生效，
// 后者不该把前者顶掉。
// 双屏协同：485 收不到主机（0x75）排在串口之后。
// SD 卡 CMD0 回错（写侧组 = 02）时，这一组改成显示卡实际回的 R1 字节，排查用：
//   00 = MISO 被拉低；7F/3F/1F/0F/07/03 = 时钟错位；其他值 = 卡不在空闲态（正在读块/已在 SPI 模式）
wire [7:0] diag_secondary = (diag_primary       == 8'h02) ? ingest_last_r1     :
                            (player_error_video != 8'h00) ? player_error_video :
                            (uart_diag_code     != 8'h00) ? uart_diag_code     :
                            (rs485_diag_code    != 8'h00) ? rs485_diag_code    :
                                                            ingest_diag2_code;

seg_decoder seg_decoder_diag2_hi(
    .bin_data          (diag_secondary[7:4]),
    .seg_data          (seg_data_1)
);

seg_decoder seg_decoder_diag2_lo(
    .bin_data          (diag_secondary[3:0]),
    .seg_data          (seg_data_2)
);

// 诊断码只在真正出故障时才显示，正常摄入成功、显示图片时这4位数码管熄灭，
// 恢复"只看末位"的干净体验，也不再同时驱动这么多段线，避免分时复用时
// 相邻位互相"借光"。第八讲新增：读写侧运行时故障也要点亮（否则
// underflow/FIFO溢出这类只在正常显示中才会发生的故障永远看不见）。
// 13 张图扩展：末位 1/2 现在也可能是图号个位，不能再拿 state_code 判故障
// 原来应急模式下会关掉诊断码；现在 ROM 画面往往正是 TF 卡出事引起的，
// 诊断码照常亮，方便看是哪一步失败
wire show_diag = (ingest_finished && !display_valid) ||
                 (write_path_error   != 8'h00) ||
                 (player_error_video != 8'h00) ||
                 (uart_diag_code     != 8'h00) ||   // 第五讲：串口故障也要点亮
                 (rs485_diag_code    != 8'h00);     // 双屏协同：收不到主机

// 6 位数码管从左到右：[读侧诊断 高/低][写侧诊断 高/低][图号十位][末位]
seg_scan seg_scan_m0(
    .clk               (clk),
    .rst_n             (rst_n_clk),
    .seg_sel           (seg_sel),
    .seg_data          (seg_data),
    .seg_data_0        ({1'b1, show_diag ? seg_data_1 : 7'b1111_111}),
    .seg_data_1        ({1'b1, show_diag ? seg_data_2 : 7'b1111_111}),
    .seg_data_2        ({1'b1, show_diag ? seg_data_3 : 7'b1111_111}),
    .seg_data_3        ({1'b1, show_diag ? seg_data_4 : 7'b1111_111}),
    .seg_data_4        ({1'b1, show_pic_no ? seg_pic_tens : 7'b1111_111}),
    .seg_data_5        ({1'b1,seg_data_0})
);

// ===================== 第八讲：视频读取流水线 =====================
// 一个实例顶掉原来的 video_timing_data + frame_read_write读侧 + video_delay。
// 内部：video_timing_ctrl(时序) + media_player_control(index管理+帧消隐期原子提交)
//      + media_frame_reader(mem/pix双域 异步FIFO+prefetch+128字burst+in-flight流水)
//      + video_fade_transition(第十讲启用，见下方 FADE_FRAMES 说明)
//      + rgb_video_adapter(整组寄存一拍+消隐防护)
//
// 第十讲 图片转场特效：FADE_FRAMES 由 0(硬切旁路) 改为 16。
//   手动 next(KEY1短按 / 串口NEXT)：淡出16帧 -> 全黑时才把请求放给
//     media_player_control -> 帧边界切 index -> 淡入16帧，全程约0.55秒@60fps。
//     转场进行中再按 next 会被丢弃（fade_busy）。
//   自动轮播 / prev / 首图落位：切换由 control 内部发起、无法预先淡出，
//     改走 Wipe 揭示，按新图 index 选 左->右 / 右->左 / 百叶窗 / 棋盘百叶窗。
//   取值约束：256 要能被整除，且 <=16（ramp_out 只有5位）——可选 8 / 16。
//   改回 0 即恢复硬切，像素逐位与改造前相同。
// 注意：brightness(串口BRT=) 只在 FADE_FRAMES!=0 的分支里生效（和转场
//   alpha 合成一个乘数），旁路分支直接透传像素，所以改造前 BRT= 实际不起作用。
// 转场模块内三组跨域 2FF 的第一级 req_sync1/busy_sync1/commit_sync1 已被
//   media_player_promax_top.sdc 的通配 false_path 覆盖，不需要新增约束。
// 讲义与仿真见 hdl_source/transition/README.md。
//
// 轮播周期按 ctrl_clk=sd_card_clk=100MHz 折算：3s = 300_000_000 拍，
// 与改造前 media_playback_selector 的 AUTO_PLAY_MS=3000 一致。
// 注意讲义原件的默认值 250_000_000 是按 25MHz 像素时钟算的10秒，这里不能照抄。
media_video_pipeline #(
    .IMAGE_WORDS          (FRAME_PIXELS),
    .PACK_RGB565          (PACK_RGB565),
    .IMAGE_COUNT          (IMAGE_COUNT),
    .INDEX_W              (INDEX_W),
    .NAV_MASK             (NAV_MASK),
    .THUMB_COLS           (THUMB_COLS),
    .THUMB_ROWS           (THUMB_ROWS),
    .CELL_W               (CELL_W),
    .THUMB_COUNT          (THUMB_COUNT),
    .FIFO_DEPTH           (512),
    .FIFO_MARGIN          (16),
    .H_ACT (640), .H_FP (16), .H_SYNC (96), .H_BP (48),
    .V_ACT (480), .V_FP (10), .V_SYNC (2),  .V_BP (33),
    .DEFAULT_PERIOD_CYCLES(32'd300_000_000),
    .MIN_PERIOD_CYCLES    (32'd50_000_000),
    .MAX_PERIOD_CYCLES    (32'd3_000_000_000),
    .FADE_FRAMES          (16)          // 第十讲：0=硬切，16=淡入淡出/Wipe转场
) u_media_video_pipeline (
    // 控制域 = sd_card_clk，与按键、摄入同域
    .ctrl_clk            (sd_card_clk),
    .ctrl_rst_n          (rst_n_sd),
    // 第五讲：按键与串口并联；period_cfg / auto_cfg 这四根原来接死成常量，
    // 现在由 media_uart_console 的 PRD= / AUTO 命令驱动。周期的范围校验
    // 仍由 media_player_control 负责（越界回 control_error=0x51，reporter
    // 自动打一行 ERR 51），UART 侧不重复校验。
    .next_event          (next_event_all),
    .prev_event          (prev_event_all),
    .init_event          (key_init_event),
    .toggle_auto_event   (key_toggle_auto_event),
    .period_cfg_valid    (uart_period_cfg_valid),
    .period_cfg_cycles   (uart_period_cfg_cycles),
    .auto_cfg_valid      (uart_auto_cfg_valid),
    .auto_cfg_enabled    (uart_auto_cfg_enabled),
    // 播放以 loader 的 image_complete 为准：它除了流程走完，还校验了
    // 像素数==307200 且落盘字数==307200（565 打包时 153600），比 fat32 本地那份更严
    .image_complete      (loader_image_complete),
    // 必须用 display_valid 而不是 ingest_finished：一张图都没加载成功时
    // ingest_finished 照样是 1，reader 会去读 bank0 未初始化的 SDRAM，
    // 屏幕显示雪花——改造前这种情况是黑屏（display_valid=0 把 vout_data 清零）。
    // 时间互斥不受影响：第一张图加载完 loader_image_complete 就非 0 了，
    // 但那时 ingest_finished 还是 0，display_valid 仍为 0，reader 不会插进来。
    .player_enable       (display_valid),
    // 第十三讲 图片缩放与缩略图：KEY1 长按翻转 / 串口 THUMB、FULL 明确设定。
    // 缩略图 = 4x4 铺满整屏、每格 160x120（4:1 最近邻），13 张 + 3 格空。
    // 第十五讲 缩略图交互选择：焦点与 active_index 分开（pipeline 内的
    // control/thumbnail_controller 持有），缩略图下按键含义：
    //   KEY1 短按/NEXT = 焦点右移   KEY2 长按/PREV = 焦点左移
    //   KEY1 长按/SEL  = 确认选择   KEY2 短按/FULL = 返回全屏（不换图）
    // 进/出缩略图和确认都带一次淡出淡入；缩略图期间自动轮播暂停。
    .thumb_toggle_event  (key_thumb_toggle_event),
    .thumb_cfg_valid     (uart_thumb_cfg_valid),
    .thumb_cfg_enabled   (uart_thumb_cfg_enabled),
    .confirm_event       (uart_select_event),
    .focus_cfg_valid     (uart_focus_cfg_valid),
    .focus_cfg_index     (uart_focus_cfg_index[INDEX_W-1:0]),
    .thumb_mode          (player_thumb_mode),
    .thumb_frame_pix     (player_thumb_frame),
    // 火灾图覆盖：像素域改读 alarm_index，整屏、不转场；底下的播放器照常运行，
    // 报警解除后回到它当时的状态。缩略图模式也会被强制成全屏
    .alarm_show          (alarm_pic_sd),
    .alarm_index         (alarm_index_sd),

    // 存储域 = ext_mem_clk。信号名映射见讲义3.3：
    // Sdr_rd_en 是"读数据有效"（frame_read_write.v:32 原注释 read_data_valid），
    // 与 reader 期望的 sdram_rd_valid 语义一致，直接对接
    .mem_clk             (ext_mem_clk),
    .mem_rst_n           (rst_n_mem),
    .controller_init_done(Sdr_init_done),
    .controller_busy     (Sdr_busy),
    .refresh_active      (Sdr_init_ref_vld),
    .app_rd_en           (App_rd_en),
    .app_rd_addr         (App_rd_addr),
    .sdram_rd_valid      (Sdr_rd_en),
    .sdram_rd_data       (Sdr_rd_dout),

    // 像素域 = video_clk
    // 第五讲：亮度由串口 BRT=XX 命令给，经 u_cfg_sd_to_video 从 ctrl 域搬来。
    // 没下过命令时是 VIDEO_BRIGHTNESS(255)，与改造前的常量 8'd255 等价。
    // 光敏：改接自动 × 手动后的 video_brightness_eff，pipeline 内部帧边界锁存，不会半屏两种亮度
    .brightness          (video_brightness_eff),
    // 第十四讲：对比度，pipeline 内部在 frame_start 与亮度一起锁存
    .contrast            (video_contrast),
    .pix_clk             (video_clk),
    .pix_rst_n           (rst_n_video),
    .video_clk           (pipeline_video_clk),
    .video_hs            (hs_raw),
    .video_vs            (vs_raw),
    .video_de            (de_raw),
    .video_rgb           (vout_data_raw),
    .video_x             (pipeline_video_x),

    .active_index        (player_active_index),
    .display_index       (player_display_index),
    .pending_index       (player_pending_index),
    .auto_enabled        (player_auto_enabled),
    .frame_start         (player_frame_start),
    .reader_busy         (player_reader_busy),
    .reader_underflow    (player_underflow),
    .video_error         (player_video_error),
    // 第十一讲：转场 alpha 给 sync_fade_gain
    .fade_alpha_pix      (fade_alpha_pix),
    .fade_active_pix     (fade_active_pix)
);

// 原来这里有一句 vout_data = display_valid ? vout_data_raw : 24'd0。
// 第八讲后这个门控挪进 pipeline 内部了：player_enable 同时门住
// reader 的读请求、pixel_consume 和 rgb_video_adapter 的 de_in，
// 摄入期天然黑屏，顶层不用再套一层。

// ===================== 四边环绕音频频谱（替代第十二讲波形条）=====================
// 接在 pipeline 输出之后、所有 OSD 之前：
//   pipeline ──*_raw──> 频谱 ──hs/vs/de/vout_data（延迟 5 拍）──> 状态条 ... ──> AXIS
// 本模块内部是 5 级流水，hs/vs/de/rgb 一起延迟，下游时序自洽，下游模块一个不用改；
// OSD 文字都叠在频谱上面。屏幕四边 40 像素宽的环带，见 spectrum/spectrum_border_overlay.v。
// 音频抽头和原波形条一样取音量缩放后真正送 HDMI 的样本：频谱跟随 VOL= 和转场淡入淡出。
// VIS=XX：高 4 位非 0 打开，低 4 位 = 每帧旋转像素，默认 12（开，2 像素/帧）。
// 缩略图模式下关掉（四边环带会压住边上那圈缩略图）；火灾图覆盖时 thumb_frame 被强制为 0，ROM 兜底时由 emergency_screen 整屏盖掉。
// 报警（PIC12 预警 / PIC13 火灾）时 LED 环换成火警特效：四边火焰 + 红色晕染呼吸（alarm_fx_demo.py 的 A_haze）。
// 环带 LED 颜色跟随 brightness；火警特效的火焰/晕染不缩放，和工程 1 一样。
spectrum_border_overlay #(
    .COEF_FILE   ("spectrum_coef.hex")
) u_spectrum_border_overlay (
    .clk          (video_clk),
    .rst_n        (rst_n_video),
    .cfg          (vis_cfg_video),
    .thumb        (player_thumb_frame),
    .alarm        (alarm_video),
    .brightness   (video_brightness_eff), // 环带颜色跟随最终亮度（自动 × BRT=/KEY）
    .sample_valid (audio_valid),
    .sample       (audio_sample_left),
    .hs_in        (hs_raw),
    .vs_in        (vs_raw),
    .de_in        (de_raw),
    .rgb_in       (vout_data_raw),
    .hs_out       (hs),
    .vs_out       (vs),
    .de_out       (de),
    .rgb_out      (vout_data),
    .overrun      ()
);

// ===================== OSD 状态叠加 =====================
// 由最终 de/vs 反推有效区坐标：de 拉高期间逐点计 x，de 下降沿进一行，vs 上升沿归零
always @(posedge video_clk or negedge rst_n_video) begin
    if (!rst_n_video) begin
        osd_pixel_x <= 12'd0;
        osd_pixel_y <= 12'd0;
        de_d        <= 1'b0;
        vs_d        <= 1'b0;
    end
    else begin
        de_d <= de;
        vs_d <= vs;

        if (de) begin
            osd_pixel_x <= osd_pixel_x + 12'd1;
        end
        else begin
            osd_pixel_x <= 12'd0;
            if (de_d)
                osd_pixel_y <= osd_pixel_y + 12'd1;
        end

        if (vs & ~vs_d)
            osd_pixel_y <= 12'd0;
    end
end

status_osd_overlay #(
    .OSD_X   (8),
    .OSD_Y   (8),
    .INDEX_W (INDEX_W)
) u_status_osd_overlay (
    .clk          (video_clk),
    .rst_n        (rst_n_video),
    .frame_start  (osd_frame_start),
    .active_index (media_id_video),
    .auto_enabled (auto_play_video),
    .error_code   (player_error_video),
    .in_de        (de),
    .in_rgb       (vout_data),
    .pixel_x      (osd_pixel_x),
    .pixel_y      (osd_pixel_y),
    .out_rgb      (vout_data_osd),
    .out_de       (),
    .osd_pixel    ()
);

// ===================== 第九讲：滚动字幕 + 时间戳 =====================
// 叠加顺序（都挂在同一套 osd_pixel_x/y 上，各自只改自己那块区域的像素）：
//   vout_data ──状态条(8,8)──> vout_data_osd ──底部滚动字幕──> vout_data_sub
//             ──(直通)──> vout_data_ts ──> AXIS ──> HDMI
// 右上角原来的 MM:SS 运行计时(timestamp_osd)已删除，那个位置改放实时时钟
// （见下面 u_rtc_clock_osd）。状态条在 x 8~47，字幕在 440~463 行，互不相交，
// 所以串联顺序不影响画面。
//
// 【时序】status_osd_overlay 是纯组合（第八讲留下的），后面两级都在模块内部
// 把字模查表预取寄存了一拍，送给 video_rgb_to_axis_640x480 的组合路径只剩
// 一级 mux + 底条混合。整条链在 video_clk(25MHz/40ns) 下余量充足。

osd_subtitle_source #(
    .INDEX_W         (INDEX_W)
) u_osd_subtitle_source (
    .clk             (sd_card_clk),
    .rst_n           (rst_n_sd),
    // 用 ctrl 域的 pending_index：它和 UART 文本源同域，跨域链路保持一致。
    // 比屏幕上的 active_index 早最多一帧，撕裂由下面的帧边界提交兜住。
    // 火灾图覆盖时换成火灾图的字幕
    .media_index     (shown_index_sd),
    .subtitle_enable (1'b1),
    .text            (subtitle_text_sd),
    .length          (subtitle_length_sd),
    .enable          (subtitle_enable_sd),
    .commit          (subtitle_commit_sd)
);

// 96 位文本 sd_card_clk -> video_clk。2FF 第一级 reg 名是 commit_sync1，
// 已被 media_player_promax_top.sdc 第 6 节的 */commit_sync1 通配覆盖，
// 不需要为这个实例新增时序例外。
subtitle_frame_commit u_subtitle_frame_commit (
    .src_clk     (sd_card_clk),
    .src_rst_n   (rst_n_sd),
    .src_commit  (subtitle_commit_sd),
    .src_text    (subtitle_text_sd),
    .src_length  (subtitle_length_sd),
    .src_enable  (subtitle_enable_sd),
    .dst_clk     (video_clk),
    .dst_rst_n   (rst_n_video),
    .frame_start (osd_frame_start),
    .dst_text    (subtitle_text_video),
    .dst_length  (subtitle_length_video),
    .dst_enable  (subtitle_enable_video)
);

osd_scroll_subtitle #(
    .H_ACTIVE    (640),
    .BAND_Y      (440),          // 底部字幕带 440~463 行
    .BAND_H      (24),
    .BAND_MARGIN (8),
    .SCROLL_DIV  (0),            // 每帧移 1 像素，约 60 像素/秒
    .ENABLE_CJK  (1),
    .USE_MULT    (0),            // 底条用移位近似混合，不占 DSP
    .BAND_ALPHA  (8'd128)        // 半透明，图片能透出来
) u_osd_scroll_subtitle (
    .clk             (video_clk),
    .rst_n           (rst_n_video),
    .de              (de),
    .frame_start     (osd_frame_start),
    .pixel_x         (osd_pixel_x),
    .pixel_y         (osd_pixel_y),
    .rgb_in          (vout_data_osd),
    .enable          (subtitle_enable_video),
    .text            (subtitle_text_video),
    .length          (subtitle_length_video),
    .rgb_out         (vout_data_sub),
    .subtitle_active ()
);

// 右上角 MM:SS 运行计时(timestamp_osd)已删除，实时时钟移到该位置
assign vout_data_ts = vout_data_sub;

// 第十二讲的音频波形条（promax_audio_waveform，x 64~575 / y 368~431）已删除，
// 由 OSD 链最前面的四边环绕频谱 u_spectrum_border_overlay 替代。

// ===================== 第十四讲：亮度/对比度参数面板 =====================
// 叠加在 OSD 链最末端：vout_data_ts ──参数面板──> vout_data_param ──> AXIS
// 区域：x 4~125 / y 20~63（左上角，状态条 y=8~15 的正下方），和右上角实时时钟
//   (x 472~635)、字幕带(440~463 行)都不相交；压在频谱环带上面。
// 调一次 BRT=/CON=/KEY3/KEY4 就亮 180 帧(≈3s)，刚改的那一行黄色高亮。
// 值取 video_clk 域的 video_brightness/video_contrast，模块内部在
// osd_frame_start 锁存，和画面生效同帧。
picture_param_osd #(
    .OSD_X       (8),
    .OSD_Y       (24),
    .SHOW_FRAMES (180),
    .ALWAYS_SHOW (0)
) u_picture_param_osd (
    .clk         (video_clk),
    .rst_n       (rst_n_video),
    .de          (de),
    .frame_start (osd_frame_start),
    .pixel_x     (osd_pixel_x),
    .pixel_y     (osd_pixel_y),
    .brightness  (video_brightness),
    .contrast    (video_contrast),
    .rgb_in      (vout_data_ts),
    .rgb_out     (vout_data_param),
    .osd_active  ()
);

// ===================== DS3231 实时时钟显示 =====================
// vout_data_param ──右上角 HH:MM:SS──> vout_data_rtc ──> 火灾兜底
// 字模放大 4 倍（字形 16x24），文字右缘与状态条左缘对称留 8 像素边距：
// 区域：暗底 x 472~635 / y 4~35，文字 x 476~631 / y 8~31。和状态条(x 8~47)、
// 参数面板(x 4~125)、字幕带（440~463 行）都不相交。
// 缩略图模式下关掉（会压住缩略图）；ROM 逃生画面由下一级整屏盖掉。
// enable 在模块内部 frame_start 锁存，切模式不会半屏出现。
rtc_clock_osd #(
    .H_ACTIVE   (640),
    .V_ACTIVE   (480),
    .PANEL_PAD  (4),
    .SCALE_SHIFT(2),             // 4 倍：字形 16x24，文字区 156x24
    .TEXT_X     (476),           // 640-8-156，右对齐
    .TEXT_Y     (8),             // 与状态条同一行起
    .TEXT_COLOR (24'hFFFFFF)
) u_rtc_clock_osd (
    .clk          (video_clk),
    .rst_n        (rst_n_video),
    .enable       (!player_thumb_frame),
    .de           (de),
    .frame_start  (osd_frame_start),
    .pixel_x      (osd_pixel_x),
    .pixel_y      (osd_pixel_y),
    .time_bcd     (rtc_time_video[23:0]),
    .time_valid   (rtc_time_video[24]),
    .rgb_in       (vout_data_param),
    .rgb_out      (vout_data_rtc),
    .clock_active ()
);

// ===================== 火灾兜底：整屏逃生画面 =====================
// 挂在 OSD 链最末端，有报警但火灾图不可用（rom_screen）时整屏替换（上面的
// 频谱/状态条/字幕一并盖掉），其余时候 rgb 直通。只用 video_clk 和片内 ROM，
// 不碰 SDRAM / TF 卡，所以 TF 卡完全读不出来也能出画面（pipeline 在
// player_enable=0 时照样输出完整的 de 时序，只是像素全黑）。
// 进出在 frame_start 锁存，不会半屏切换。
emergency_screen #(
    .INIT_FILE    ("emergency_screen.hex"),
    .ARROW_SPEED  (2),
    .ARROW_DIR    (1'b0)          // 0 = 箭头向右流动（和底图平面图里的出口方向一致）
) u_emergency_screen (
    .clk           (video_clk),
    .rst_n         (rst_n_video),
    .enable        (rom_screen_video),
    .de            (de),
    .frame_start   (osd_frame_start),
    .pixel_x       (osd_pixel_x),
    .pixel_y       (osd_pixel_y),
    .rgb_in        (vout_data_rtc),
    .rgb_out       (vout_data_final),
    .screen_active ()
);

sdram U3(
    .Clk               (ext_mem_clk),
    .Clk_sft           (ext_mem_clk_sft),
    .Rst               (~rst_n_mem),
    .Sdr_init_done     (Sdr_init_done),
    .Sdr_init_ref_vld  (Sdr_init_ref_vld),
    .Sdr_busy          (Sdr_busy),
    .App_wr_en         (App_wr_en),
    .App_wr_addr       (App_wr_addr),
    .App_wr_dm         (App_wr_dm),
    .App_wr_din        (App_wr_din),
    .App_rd_en         (App_rd_en),
    .App_rd_addr       (App_rd_addr),
    .Sdr_rd_en         (Sdr_rd_en),
    .Sdr_rd_dout       (Sdr_rd_dout)
);

// 原来这里有一整块"播放器状态 sd_card_clk -> video_clk"的 toggle 跨域打包
// （media_id + auto_play + error_code 三项一起搬）。第八讲后 active_index 和
// video_error 由 media_video_pipeline 直接在 pix 域产出，只剩 auto_enabled
// 一根慢变电平要搬，已在上面的 u_auto_play_video_sync 里用 sync_2ff 解决。

// ===================== 第十一讲：WAV音频播放（一图一音）=====================
// 音频链（全部在 video_clk 域，除 wav_stream_player 写侧在 sd_card_clk 域）：
//
//   TF卡 MUSICn.WAV ──扇区读口(sd域)──> wav_stream_player ──> pcm_content_mux(音量) ──> HDMI 发射核
//
// 1. 采样节拍：下面的相位累加器出一拍宽、48kHz 的 sample_tick（25MHz 下
//    平均 520.83 拍一次），和原来琶音源 pcm_media_tone 内部的节拍公式相同。
//    wav_stream_player 每个节拍都输出一个样本——没在放时输出静音——所以
//    从上电、摄入期间到播放，送 HDMI 的 audio_valid 一直是稳定的 48kHz，
//    audio_arc_calculate 算出的 CTS 不受播放/切曲影响。
// 2. 音量：用户音量(串口 VOL=) × 转场增益(sync_fade_gain) 合成一个 8 位
//    有效音量。无转场时增益=255，有效音量与 VOL= 逐位相同。
// 3. 循环播放：放完一遍（读侧缓冲也排空）后拉低 play_enable 1ms 再拉高，
//    从头再放。读 TF 出错同样走这条路，等于每 1ms 自动重试一次。
// 4. 一图一音：MUSICn.WAV 跟 PICn.BMP 配对。当前图（pending_index）换了，
//    就走第 3 条同一条路：停、等写侧空闲、间隔 1ms、换参数、从头放。
//    当前图没有 MUSICn.WAV 就静音（原来的 MUSIC.WAV 回退和琶音源都已删掉）。
//    同步精度：
//    - 手动 NEXT / 缩略图 SEL：pending_index 在转场全黑那一刻才变，新曲在
//      黑场里起播（预填充 <1ms），再随 sync_fade_gain 和画面一起淡入。
//    - 自动轮播 / PREV（Wipe 揭示，alpha 不动）：pending_index 比画面早
//      最多一帧（16.7ms）变，音频是硬切，可能有一声轻微的"咔"。
//    循环只循环本图的音频；音频比停留时间长就被切图截断。

// ---- 48kHz 采样节拍（video 域）----
localparam integer AUDIO_CLOCK_HZ  = 25_000_000;   // video_clk
localparam integer AUDIO_SAMPLE_HZ = 48_000;

always @(posedge video_clk or negedge rst_n_video) begin
    if (!rst_n_video) begin
        sample_rate_acc <= 25'd0;
        sample_tick     <= 1'b0;
    end
    else if (sample_rate_acc >= AUDIO_CLOCK_HZ - AUDIO_SAMPLE_HZ) begin
        sample_rate_acc <= sample_rate_acc + AUDIO_SAMPLE_HZ - AUDIO_CLOCK_HZ;
        sample_tick     <= 1'b1;
    end
    else begin
        sample_rate_acc <= sample_rate_acc + AUDIO_SAMPLE_HZ;
        sample_tick     <= 1'b0;
    end
end

// ---- 播放控制（sd 域）----
localparam [16:0] WAV_GAP_CYCLES = 17'd100_000;   // 1ms @ 100MHz sd_card_clk

// 当前图该放哪个文件。pending_index 与本块同在 sd 域，不用跨域。
// 有报警就放 MUSIC12/13——即使画面落到 ROM 兜底（比如只是 PIC13.BMP 坏了、
// 卡本身还能读），报警音也照样能出来。卡真坏了读扇区会出错，走下面第 3 条
// 每 1ms 重试一次，HDMI 静音，不影响画面。
wire [INDEX_W-1:0] wav_want_index = alarm_sd ? alarm_index_sd : player_pending_index;
wire [31:0] wav_want_lba     = track_start_lba[wav_want_index*32 +: 32];
wire [31:0] wav_want_sectors = track_sectors[wav_want_index*32 +: 32];
wire        wav_ready_sd     = wav_ext_ready && track_valid[wav_want_index];

// stream_end 是读侧(video 域)电平，搬回 sd 域
sync_2ff u_wav_end_sync (
    .clk         (sd_card_clk),
    .rst_n       (rst_n_sd),
    .async_in    (wav_stream_end),
    .sync_out    (wav_stream_end_sd)
);

always @(posedge sd_card_clk or negedge rst_n_sd) begin
    if (!rst_n_sd) begin
        wav_play_enable  <= 1'b0;
        wav_gap_cnt      <= 17'd0;
        wav_play_lba     <= 32'd0;
        wav_play_sectors <= 32'd0;
    end
    else if (!wav_ready_sd) begin
        // 摄入还没结束 / 当前图没有 MUSICn.WAV：不播，播放器按节拍输出静音
        wav_play_enable <= 1'b0;
        wav_gap_cnt     <= 17'd0;
    end
    else if (wav_play_enable) begin
        // 放完一遍（循环），或换了图、该放的文件变了（切曲）
        if (wav_stream_end_sd || (wav_want_lba != wav_play_lba)) begin
            wav_play_enable <= 1'b0;
            wav_gap_cnt     <= 17'd0;
        end
    end
    else if (!wav_writer_idle) begin
        // 中途切曲时写侧可能还在等一个扇区读完，回到 IDLE 之前不开始计间隔
        wav_gap_cnt <= 17'd0;
    end
    // 低电平保持够 1ms、且上一轮的 stream_end 已经撤掉才重新开始。
    // 参数在使能的同一拍锁存，播放期间保持不变
    else if (wav_gap_cnt >= WAV_GAP_CYCLES - 17'd1) begin
        if (!wav_stream_end_sd) begin
            wav_play_lba     <= wav_want_lba;
            wav_play_sectors <= wav_want_sectors;
            wav_play_enable  <= 1'b1;
        end
    end
    else begin
        wav_gap_cnt <= wav_gap_cnt + 17'd1;
    end
end

// ---- WAV 流式播放器（写侧 sd 域 / 读侧 video 域）----
wav_stream_player #(
    .ADDR_WIDTH         (12),       // 4096 x 16bit = 8KB，约 85ms @ 48kHz
    .SAMPLES_PER_SECTOR (256),
    .HEADER_BYTES       (44)        // 跳过 make_music_wav.py 写的标准 WAV 头
) u_wav_stream_player (
    .wr_clk         (sd_card_clk),
    .wr_rst_n       (rst_n_sd),
    .play_enable    (wav_play_enable),
    .start_lba      (wav_play_lba),
    .total_sectors  (wav_play_sectors),
    .sd_req         (wav_sd_req),
    .sd_lba         (wav_sd_lba),
    .sd_busy        (wav_sd_busy),
    .sd_valid       (wav_sd_valid),
    .sd_byte        (wav_sd_byte),
    .sd_byte_index  (wav_sd_byte_index),
    .sd_done        (wav_sd_done),
    .sd_error       (wav_sd_error),
    .writer_idle    (wav_writer_idle),

    .rd_clk         (video_clk),
    .rd_rst_n       (rst_n_video),
    .sample_tick    (sample_tick),
    .sample_out     (wav_sample),
    .sample_valid   (wav_sample_valid),
    .sample_ready   (1'b1),

    .sample_counter (),
    .stream_active  (),
    .stream_end     (wav_stream_end),
    .buffer_low     ()
);

// ---- 音画同步淡入淡出：转场 alpha -> 音频增益 ----
// 本工程像素域和音频域都是 video_clk，同步器只是多两拍延迟，保留讲义结构，
// 将来音频链换独立时钟（如 12.288MHz）时这里不用改。
sync_fade_gain u_sync_fade_gain (
    .pix_clk     (video_clk),
    .pix_rst_n   (rst_n_video),
    .frame_start (player_frame_start),
    .alpha_pix   (fade_alpha_pix),
    .fade_active (fade_active_pix),
    .aud_clk     (video_clk),
    .aud_rst_n   (rst_n_video),
    .gain_aud    (fade_gain)
);

// 有效音量 = 用户音量 × (增益+1) / 256。增益=255 时恰好等于用户音量。
// 报警期间画面不跟底下的转场走，报警音也不跟着淡，固定满增益
wire [7:0] fade_gain_eff = alarm_video ? 8'd255 : fade_gain;
always @(posedge video_clk or negedge rst_n_video) begin
    if (!rst_n_video)
        audio_volume_eff <= AUDIO_VOLUME;
    else
        audio_volume_eff <= ({8'd0, video_volume} * ({8'd0, fade_gain_eff} + 16'd1)) >> 8;
end

// ---- WAV 样本音量缩放 ----
// pcm_content_mux 本是"4 路媒体音源选 1 + 音量"，这里只有一路 WAV，
// 四个输入都接它、media_id 固定 0，只用它的音量乘法与饱和。纯组合，
// 和 wav_sample_valid 同拍对齐。
pcm_content_mux u_wav_volume (
    .sample0    (wav_sample),
    .sample1    (wav_sample),
    .sample2    (wav_sample),
    .sample3    (wav_sample),
    .media_id   (2'd0),
    .volume     (audio_volume_eff),
    .sample_out (wav_sample_scaled)
);

// 原来这里有琶音源 pcm_media_tone + 二选一 audio_source_mux，一图一音后删掉：
// 只剩 WAV 一路，单声道左右相同，直接送 HDMI。
assign audio_valid        = wav_sample_valid;
assign audio_sample_left  = wav_sample_scaled;
assign audio_sample_right = wav_sample_scaled;

// 16bit 样本左对齐到发射核要求的 24bit
assign audio_left_data  = {audio_sample_left,  8'h00};
assign audio_right_data = {audio_sample_right, 8'h00};

audio_arc_calculate #(
    .ACR_N         (6144)
) u_audio_arc_calculate (
    .I_clk         (video_clk),
    .I_rst         (~rst_n_video),
    .I_audio_valid (audio_valid),
    .O_acr_valid   (acr_valid),
    .O_acr_cts     (acr_cts),
    .O_acr_n       (acr_n)
);

// ===================== RGB/DE 转 AXIS 视频 =====================
video_rgb_to_axis_640x480 u_video_rgb_to_axis_640x480(
    .I_clk         (video_clk),
    .I_rst         (~rst_n_video),
    .I_vs          (vs),
    .I_de          (de),
    .I_rgb         (vout_data_final),   // OSD 链最末端（频谱+状态条+字幕+参数面板+ROM 逃生画面）
    .O_video_user  (axis_s_user),
    .O_video_valid (axis_s_valid),
    .O_video_last  (axis_s_last),
    .O_video_data  (axis_s_data)
);

// 上电后自动打一拍，触发一次 EDID 读取
startup_pulse #(
    .CNT_MAX(20'd100000)
) u_startup_pulse (
    .I_clk   (video_clk),
    .I_rst   (~rst_n_video),
    .O_pulse (edid_trig)
);

// ===================== 带音频的 HDMI 1.4b 发射 =====================
hdmi_1_4b_transmitter_core_wrapper #(
    .DEVICE                 ( "EG"       ),
    .HTOTAL                 ( 800        ),
    .HSA                    ( 96         ),
    .HFP                    ( 16         ),
    .HBP                    ( 48         ),
    .HACTIVE                ( 640        ),
    .VTOTAL                 ( 525        ),
    .VSA                    ( 2          ),
    .VFP                    ( 10         ),
    .VBP                    ( 33         ),
    .VACTIVE                ( 480        ),
    .VIDEO_VIC              ( 1          ),
    .VIDEO_TPG              ( "Disable"  ),
    .VIDEO_FORMAT           ( "RGB"      ),
    .AUDIO_SAMPLE_RATE      ( "48K"      ),
    .IIC_SCL_DIV            ( 250        )
) u_hdmi_1_4b_transmitter_core_wrapper(
    .I_pixel_clk        (video_clk),
    .I_rst              (~rst_n_video),
    .I_edid_read_trig   (edid_trig),
    .O_edid_read_valid  (edid_valid),
    .O_edid_read_data   (edid_data),

    .I_axis_s_user      (axis_s_user),
    .I_axis_s_valid     (axis_s_valid),
    .I_axis_s_last      (axis_s_last),
    .I_axis_s_data      (axis_s_data),
    .O_axis_s_ready     (axis_s_ready),

    .I_audio_valid      (audio_valid),
    .I_audio_left_data  (audio_left_data),
    .I_audio_right_data (audio_right_data),
    .I_acr_valid        (acr_valid),
    .I_acr_cts          (acr_cts),
    .I_acr_n            (acr_n),

    .O_video_locked     (),
    .O_ddc_scl          (HDMI_DDC_SCL),
    .IO_ddc_sda         (HDMI_DDC_SDA),

    .O_ch0_tmds_data    (tmds_ch0_data),
    .O_ch1_tmds_data    (tmds_ch1_data),
    .O_ch2_tmds_data    (tmds_ch2_data),
    .O_clk_tmds_data    (tmds_clk_data)
);

hdmi_phy_wrapper #(
    .DEVICE ( "EG" )
) u_hdmi2phy_wrapper(
    .I_pixel_clk        (video_clk),
    .I_serial_clk       (hdmi_5x_clk),
    .I_rst              (rst_all),
    .I_tmds_channel_0   (tmds_ch0_data),
    .I_tmds_channel_1   (tmds_ch1_data),
    .I_tmds_channel_2   (tmds_ch2_data),
    .I_tmds_channel_clk (tmds_clk_data),
    .O_tmds_ch0_p       (HDMI_D0_P),
    .O_tmds_ch1_p       (HDMI_D1_P),
    .O_tmds_ch2_p       (HDMI_D2_P),
    .O_tmds_clk_p       (HDMI_CLK_P)
);

endmodule
