`timescale 1ns/1ps

module promax_scale_line_buffer #(
    parameter integer DEPTH = 640,
    parameter integer ADDRESS_WIDTH = 10
) (
    input  wire                     clk,
    input  wire                     write_enable,
    input  wire [ADDRESS_WIDTH-1:0] write_address,
    input  wire [26:0]              write_data,
    input  wire                     read_enable,
    input  wire [ADDRESS_WIDTH-1:0] read_address,
    output reg  [26:0]              read_data
);
    reg [26:0] memory [0:DEPTH-1] /* fehdl force_ram=1, ram_style="bram" */;

    always @(posedge clk) begin
        if (write_enable)
            memory[write_address] <= write_data;
        if (read_enable)
            read_data <= memory[read_address];
    end
endmodule

// -----------------------------------------------------------------------------
// 照片缩放自适应（ALLOW_SCALE_SOURCE=1 时生效）：
//   除 640x480 直通、1280x960 2x2 平均这两条原有路径外，再接受任意
//   EXPECTED_WIDTH..MAX_SOURCE_DIM x EXPECTED_HEIGHT..MAX_SOURCE_DIM 的 24 位 BMP。
//   做法是"居中裁剪铺满"：先在源图中间裁出一块 4:3 区域（crop_w x crop_h），
//   再用最近邻抽成 640x480，源列 sx = crop_x0 + ceil(ox*crop_w/640)，行同理。
//   抽取用累加器（Bresenham）逐像素判定，不需要除法器、不需要行缓存，
//   输出仍是每帧恰好 307200 个、按流顺序排列的像素，下游 loader/SDRAM/reader 无感。
//   只做缩小：裁剪区一定 >= 640x480（宽图裁宽、高图裁高，另一边保持原尺寸）。
//   640x480 源图走这条通用路径时累加器每拍都命中，输出与原来逐位相同。
// -----------------------------------------------------------------------------
module bmp24_decoder #(
    parameter integer EXPECTED_WIDTH = 640,
    parameter integer EXPECTED_HEIGHT = 480,
    parameter integer ALLOW_2X_SOURCE = 0,
    parameter integer ALLOW_SCALE_SOURCE = 0,
    parameter integer MAX_SOURCE_DIM = 4096
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        file_start,
    input  wire [31:0] file_size,
    input  wire        file_valid,
    input  wire [7:0]  file_byte,
    input  wire [31:0] file_byte_offset,
    input  wire        file_end,
    input  wire [7:0]  upstream_error,
    output reg         header_accepted,
    output reg         pixel_valid,
    output reg  [23:0] pixel_rgb,
    output reg  [15:0] pixel_x,
    output reg  [15:0] pixel_y,
    output reg         frame_commit,
    output reg         bmp_done,
    output reg  [7:0]  bmp_error,
    output reg         top_down,
    output reg  [31:0] pixel_offset,
    output reg  [31:0] row_stride,
    output wire        source_scale_2x
);
    localparam ERR_NONE        = 8'h00;
    localparam ERR_SIGNATURE   = 8'h31;
    localparam ERR_DIMENSIONS  = 8'h32;
    localparam ERR_PLANES      = 8'h33;
    localparam ERR_BPP         = 8'h34;
    localparam ERR_COMPRESSION = 8'h35;
    localparam ERR_OFFSET      = 8'h36;
    localparam ERR_TRUNCATED   = 8'h37;
    localparam ERR_UPSTREAM    = 8'h38;
    // 行跨度/像素数据字节数改为按头里的实际宽高通用计算（640/1280 两种尺寸
    // 算出的值与原来查表的常量相同）

    reg [7:0] header [0:53];
    reg decode_enabled;
    reg [31:0] byte_in_row;
    reg [31:0] physical_row;
    reg [31:0] pixels_received;
    reg [1:0] channel_phase;
    reg [7:0] blue_hold;
    reg [7:0] green_hold;
    reg [15:0] x_count;
    // 每行有效像素字节数（宽*3）。原来是 source_width 寄存、每拍现乘 3，
    // 这个比较串在每个像素字节的使能上；改成头校验时一次算好存起来，值不变。
    reg [31:0] source_width3;
    reg [31:0] source_height;
    reg source_is_2x;
    reg [7:0] pair_red;
    reg [7:0] pair_green;
    reg [7:0] pair_blue;
    wire row_pair_write_enable;
    wire row_pair_read_enable;
    wire [9:0] row_pair_address;
    wire [26:0] row_pair_write_data;
    wire [26:0] row_pair_read_data;
    reg signature_ok_q;
    reg signed [31:0] parsed_height_q;
    reg [31:0] absolute_height_q;
    reg [31:0] parsed_width_q;
    reg [31:0] parsed_offset_q;
    reg [31:0] parsed_stride_q;
    reg [31:0] required_bytes_q;
    reg [31:0] required_end_q;
    reg [31:0] dib_size_q;
    reg [31:0] header_file_size_q;
    reg [15:0] planes_q;
    reg [15:0] bpp_q;
    reg [31:0] compression_q;

    // ---- 缩放自适应：裁剪几何（头解析阶段算好）+ 行/列累加器 ----
    // 尺寸上限 MAX_SOURCE_DIM=4096 -> 13 位足够；超限的图在 validate_header 里拒掉，
    // 这里截位算出的几何值不会被用到。
    reg        crop_wide_q;      // 源图比 4:3 宽：裁左右；否则裁上下
    reg [12:0] crop_w;
    reg [12:0] crop_h;
    reg [12:0] crop_x0;
    reg [13:0] crop_x1;          // crop_x0 + crop_w（开区间）
    reg [12:0] crop_y0;
    reg [13:0] crop_y1;
    reg [13:0] acc_x;            // 列累加器：每个裁剪区内源像素 +640，>=crop_w 则输出并 -crop_w
    reg [13:0] acc_y;            // 行累加器：同理 +480 / -crop_h
    reg [13:0] acc_x_plus;       // 在像素的第 2 个字节（G）预先算好，第 3 个字节（R）直接用
    reg        col_hit;
    reg        col_in_crop;
    reg        row_keep;         // 当前源行是否输出
    reg [15:0] out_x;
    reg [15:0] out_y;
    wire [12:0] src_w13 = parsed_width_q[12:0];
    wire [12:0] src_h13 = absolute_height_q[12:0];
    // floor(4H/3)：4H <= 32764 < 2^16，(n*0xAAAB)>>17 对所有 16 位 n 精确等于 floor(n/3)
    wire [15:0] four_h = {1'b0, src_h13, 2'b00};
    wire [32:0] four_h_div3_mul = four_h * 17'h0AAAB;
    wire [12:0] four_h_div3 = four_h_div3_mul[29:17];
    wire [14:0] three_w = {2'b00, src_w13} + {1'b0, src_w13, 1'b0};

    // 行判定：源行 r 落在裁剪区内才推进累加器；返回 {keep, acc_new}
    function [14:0] row_step;
        input [15:0] r;
        input [13:0] acc;
        input [12:0] y0;
        input [13:0] y1;
        input [12:0] h;
        reg   [13:0] plus;
        begin
            // 位宽不同的无符号比较，Verilog 自动零扩展
            if (r >= y0 && r < y1) begin
                plus = acc + 14'd480;
                if (plus >= {1'b0, h})
                    row_step = {1'b1, plus - {1'b0, h}};
                else
                    row_step = {1'b0, plus};
            end else begin
                row_step = {1'b0, acc};
            end
        end
    endfunction
    wire [14:0] row_step_first = row_step(16'd0, {1'b0, crop_h} - 14'd480,
                                          crop_y0, crop_y1, crop_h);
    wire [14:0] row_step_next  = row_step(physical_row[15:0] + 16'd1, acc_y,
                                          crop_y0, crop_y1, crop_h);

    assign source_scale_2x = source_is_2x;
    assign row_pair_address = x_count[10:1];
    assign row_pair_write_data = {
        {1'b0, pair_red} + {1'b0, file_byte},
        {1'b0, pair_green} + {1'b0, green_hold},
        {1'b0, pair_blue} + {1'b0, blue_hold}
    };
    assign row_pair_write_enable = file_valid && decode_enabled &&
                                   file_byte_offset >= pixel_offset &&
                                   physical_row < source_height &&
                                   byte_in_row < source_width3 &&
                                   channel_phase == 2'd2 && source_is_2x &&
                                   !physical_row[0] && x_count[0];
    assign row_pair_read_enable = file_valid && decode_enabled &&
                                  file_byte_offset >= pixel_offset &&
                                  physical_row < source_height &&
                                  byte_in_row < source_width3 &&
                                  channel_phase == 2'd0 && source_is_2x &&
                                  physical_row[0] && !x_count[0];

    promax_scale_line_buffer #(
        .DEPTH(EXPECTED_WIDTH),
        .ADDRESS_WIDTH(10)
    ) u_scale_line_buffer (
        .clk(clk),
        .write_enable(row_pair_write_enable),
        .write_address(row_pair_address),
        .write_data(row_pair_write_data),
        .read_enable(row_pair_read_enable),
        .read_address(row_pair_address),
        .read_data(row_pair_read_data)
    );

    function [7:0] average_four;
        input [8:0] first_row_pair;
        input [7:0] second_row_first;
        input [7:0] second_row_second;
        reg [9:0] total;
        begin
            total = {1'b0, first_row_pair} +
                    {2'b00, second_row_first} +
                    {2'b00, second_row_second} + 10'd2;
            average_four = total[9:2];
        end
    endfunction

    function [15:0] le16;
        input integer offset;
        begin
            le16 = {header[offset+1], header[offset]};
        end
    endfunction

    function [31:0] le32;
        input integer offset;
        begin
            le32 = {header[offset+3], header[offset+2], header[offset+1], header[offset]};
        end
    endfunction

    task validate_header;
        begin
            if (!signature_ok_q) begin
                bmp_error <= ERR_SIGNATURE;
                decode_enabled <= 1'b0;
            end else if (!((parsed_width_q == EXPECTED_WIDTH &&
                            absolute_height_q == EXPECTED_HEIGHT) ||
                           (ALLOW_2X_SOURCE != 0 &&
                            parsed_width_q == EXPECTED_WIDTH*2 &&
                            absolute_height_q == EXPECTED_HEIGHT*2) ||
                           (ALLOW_SCALE_SOURCE != 0 &&
                            parsed_width_q >= EXPECTED_WIDTH &&
                            parsed_width_q <= MAX_SOURCE_DIM &&
                            absolute_height_q >= EXPECTED_HEIGHT &&
                            absolute_height_q <= MAX_SOURCE_DIM)) ||
                         dib_size_q < 40) begin
                bmp_error <= ERR_DIMENSIONS;
                decode_enabled <= 1'b0;
            end else if (planes_q != 1) begin
                bmp_error <= ERR_PLANES;
                decode_enabled <= 1'b0;
            end else if (bpp_q != 24) begin
                bmp_error <= ERR_BPP;
                decode_enabled <= 1'b0;
            end else if (compression_q != 0) begin
                bmp_error <= ERR_COMPRESSION;
                decode_enabled <= 1'b0;
            end else if (parsed_offset_q < 54 || parsed_offset_q >= file_size) begin
                bmp_error <= ERR_OFFSET;
                decode_enabled <= 1'b0;
            end else if (required_end_q > file_size ||
                         header_file_size_q < required_end_q ||
                         header_file_size_q > file_size) begin
                bmp_error <= ERR_TRUNCATED;
                decode_enabled <= 1'b0;
            end else begin
                header_accepted <= 1'b1;
                decode_enabled <= 1'b1;
                top_down <= parsed_height_q[31];
                pixel_offset <= parsed_offset_q;
                row_stride <= parsed_stride_q;
                source_width3 <= parsed_width_q * 3;
                source_height <= absolute_height_q;
                // 只有恰好 1280x960 才走 2x2 平均，其余尺寸（含 640x480）走通用裁剪抽取
                source_is_2x <= (ALLOW_2X_SOURCE != 0 &&
                                 parsed_width_q == EXPECTED_WIDTH*2 &&
                                 absolute_height_q == EXPECTED_HEIGHT*2);
                // 通用路径的起始状态：第 0 行判定 + 列累加器初值
                row_keep <= row_step_first[14];
                acc_y    <= row_step_first[13:0];
                acc_x    <= {1'b0, crop_w} - 14'd640;
                out_x    <= 16'd0;
                out_y    <= 16'd0;
            end
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            header_accepted <= 1'b0;
            pixel_valid <= 1'b0;
            pixel_rgb <= 24'd0;
            pixel_x <= 16'd0;
            pixel_y <= 16'd0;
            frame_commit <= 1'b0;
            bmp_done <= 1'b0;
            bmp_error <= ERR_NONE;
            top_down <= 1'b0;
            pixel_offset <= 32'd0;
            row_stride <= 32'd0;
            decode_enabled <= 1'b0;
            byte_in_row <= 32'd0;
            physical_row <= 32'd0;
            pixels_received <= 32'd0;
            channel_phase <= 2'd0;
            blue_hold <= 8'd0;
            green_hold <= 8'd0;
            x_count <= 16'd0;
            source_width3 <= EXPECTED_WIDTH * 3;
            source_height <= EXPECTED_HEIGHT;
            source_is_2x <= 1'b0;
            pair_red <= 8'd0;
            pair_green <= 8'd0;
            pair_blue <= 8'd0;
            signature_ok_q <= 1'b0;
            parsed_height_q <= 32'sd0;
            absolute_height_q <= 32'd0;
            parsed_width_q <= 32'd0;
            parsed_offset_q <= 32'd0;
            parsed_stride_q <= 32'd0;
            required_bytes_q <= 32'd0;
            required_end_q <= 32'd0;
            dib_size_q <= 32'd0;
            header_file_size_q <= 32'd0;
            planes_q <= 16'd0;
            bpp_q <= 16'd0;
            compression_q <= 32'd0;
            crop_wide_q <= 1'b0;
            crop_w <= EXPECTED_WIDTH;
            crop_h <= EXPECTED_HEIGHT;
            crop_x0 <= 13'd0;
            crop_x1 <= EXPECTED_WIDTH;
            crop_y0 <= 13'd0;
            crop_y1 <= EXPECTED_HEIGHT;
            acc_x <= 14'd0;
            acc_y <= 14'd0;
            acc_x_plus <= 14'd0;
            col_hit <= 1'b0;
            col_in_crop <= 1'b0;
            row_keep <= 1'b0;
            out_x <= 16'd0;
            out_y <= 16'd0;
        end else begin
            pixel_valid <= 1'b0;
            frame_commit <= 1'b0;
            bmp_done <= 1'b0;

            if (file_start) begin
                header_accepted <= 1'b0;
                bmp_error <= ERR_NONE;
                top_down <= 1'b0;
                pixel_offset <= 32'd0;
                row_stride <= 32'd0;
                decode_enabled <= 1'b0;
                byte_in_row <= 32'd0;
                physical_row <= 32'd0;
                pixels_received <= 32'd0;
                channel_phase <= 2'd0;
                x_count <= 16'd0;
                source_width3 <= EXPECTED_WIDTH * 3;
                source_height <= EXPECTED_HEIGHT;
                source_is_2x <= 1'b0;
                pair_red <= 8'd0;
                pair_green <= 8'd0;
                pair_blue <= 8'd0;
                signature_ok_q <= 1'b0;
                parsed_height_q <= 32'sd0;
                absolute_height_q <= 32'd0;
                parsed_width_q <= 32'd0;
                parsed_offset_q <= 32'd0;
                parsed_stride_q <= 32'd0;
                required_bytes_q <= 32'd0;
                required_end_q <= 32'd0;
                dib_size_q <= 32'd0;
                header_file_size_q <= 32'd0;
                planes_q <= 16'd0;
                bpp_q <= 16'd0;
                compression_q <= 32'd0;
                row_keep <= 1'b0;
                out_x <= 16'd0;
                out_y <= 16'd0;
            end

            if (file_valid && file_byte_offset < 54)
                header[file_byte_offset] <= file_byte;

            if (file_valid && file_byte_offset == 2)
                signature_ok_q <= (header[0] == "B" && header[1] == "M");

            if (file_valid && file_byte_offset == 40) begin
                parsed_height_q <= le32(22);
                parsed_width_q <= le32(18);
                parsed_offset_q <= le32(10);
                dib_size_q <= le32(14);
                header_file_size_q <= le32(2);
                planes_q <= le16(26);
                bpp_q <= le16(28);
                compression_q <= le32(30);
            end

            if (file_valid && file_byte_offset == 41) begin
                absolute_height_q <= parsed_height_q[31] ?
                                     (~parsed_height_q + 1'b1) : parsed_height_q;
                // 行跨度 = 宽*3 向上取整到 4 字节
                parsed_stride_q <= ((parsed_width_q * 3) + 32'd3) & ~32'd3;
            end

            // 像素数据字节数 = 行跨度 * 行数。尺寸 <= 4096 时跨度 < 2^14、行数 < 2^13，
            // 16x16 乘法足够；超限的图会在 validate_header 被 ERR_DIMENSIONS 拒掉，
            // 截位的结果用不到。
            if (file_valid && file_byte_offset == 42) begin
                required_bytes_q <= parsed_stride_q[15:0] * absolute_height_q[15:0];
                crop_wide_q <= three_w > four_h;     // 3W > 4H：比 4:3 宽
            end

            if (file_valid && file_byte_offset == 43) begin
                required_end_q <= parsed_offset_q + required_bytes_q;
                if (crop_wide_q) begin
                    crop_w <= four_h_div3;           // floor(4H/3)
                    crop_h <= src_h13;
                end else begin
                    crop_w <= src_w13;
                    crop_h <= three_w[14:2];         // floor(3W/4)
                end
            end

            if (file_valid && file_byte_offset == 44) begin
                crop_x0 <= (src_w13 - crop_w) >> 1;
                crop_y0 <= (src_h13 - crop_h) >> 1;
            end

            if (file_valid && file_byte_offset == 45) begin
                crop_x1 <= {1'b0, crop_x0} + {1'b0, crop_w};
                crop_y1 <= {1'b0, crop_y0} + {1'b0, crop_h};
            end

            if (file_valid && file_byte_offset == 52)
                validate_header();

            if (file_valid && decode_enabled && file_byte_offset >= pixel_offset &&
                physical_row < source_height) begin
                if (byte_in_row < source_width3) begin
                    case (channel_phase)
                        2'd0: begin
                            blue_hold <= file_byte;
                            channel_phase <= 2'd1;
                        end
                        2'd1: begin
                            green_hold <= file_byte;
                            channel_phase <= 2'd2;
                            // 通用路径：这一拍先把列判定算好寄存，R 字节到来时直接用，
                            // 把加法+比较从像素输出那一拍的关键路径上拿掉
                            col_in_crop <= (x_count >= crop_x0) && (x_count < crop_x1);
                            acc_x_plus  <= acc_x + 14'd640;
                            col_hit     <= (acc_x + 14'd640) >= {1'b0, crop_w};
                        end
                        default: begin
                            if (!source_is_2x) begin
                                if (row_keep && col_in_crop) begin
                                    if (col_hit) begin
                                        pixel_valid <= 1'b1;
                                        pixel_rgb <= {file_byte, green_hold, blue_hold};
                                        pixel_x <= out_x;
                                        if (top_down)
                                            pixel_y <= out_y;
                                        else
                                            pixel_y <= EXPECTED_HEIGHT - 1 - out_y;
                                        pixels_received <= pixels_received + 1'b1;
                                        out_x <= out_x + 16'd1;
                                        acc_x <= acc_x_plus - {1'b0, crop_w};
                                    end else begin
                                        acc_x <= acc_x_plus;
                                    end
                                end
                            end else if (!x_count[0]) begin
                                pair_red <= file_byte;
                                pair_green <= green_hold;
                                pair_blue <= blue_hold;
                            end else if (physical_row[0]) begin
                                pixel_valid <= 1'b1;
                                pixel_rgb <= {
                                    average_four(row_pair_read_data[26:18], pair_red, file_byte),
                                    average_four(row_pair_read_data[17:9], pair_green, green_hold),
                                    average_four(row_pair_read_data[8:0], pair_blue, blue_hold)
                                };
                                pixel_x <= x_count >> 1;
                                if (top_down)
                                    pixel_y <= physical_row[15:1];
                                else
                                    pixel_y <= EXPECTED_HEIGHT - 1 - physical_row[15:1];
                                pixels_received <= pixels_received + 1'b1;
                            end
                            x_count <= x_count + 1'b1;
                            channel_phase <= 2'd0;
                        end
                    endcase
                end

                if (byte_in_row == row_stride - 1'b1) begin
                    byte_in_row <= 32'd0;
                    physical_row <= physical_row + 1'b1;
                    channel_phase <= 2'd0;
                    x_count <= 16'd0;
                    // 通用路径：换行时判定下一行是否输出，列累加器回到初值
                    if (row_keep)
                        out_y <= out_y + 16'd1;
                    row_keep <= row_step_next[14];
                    acc_y    <= row_step_next[13:0];
                    acc_x    <= {1'b0, crop_w} - 14'd640;
                    out_x    <= 16'd0;
                end else begin
                    byte_in_row <= byte_in_row + 1'b1;
                end
            end

            if (file_end) begin
                bmp_done <= 1'b1;
                decode_enabled <= 1'b0;
                if (upstream_error != 0) begin
                    bmp_error <= ERR_UPSTREAM;
                end else if (bmp_error == ERR_NONE && header_accepted &&
                             pixels_received == EXPECTED_WIDTH * EXPECTED_HEIGHT) begin
                    frame_commit <= 1'b1;
                end else if (bmp_error == ERR_NONE) begin
                    bmp_error <= ERR_TRUNCATED;
                end
            end
        end
    end
endmodule
