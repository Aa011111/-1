`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// ds3231_rtc：DS3231 实时时钟模块的 I2C 读写（ctrl = sd_card_clk 域）
//
// 模块资料：shizhong/资料/DS3231.pdf，Arduino 参考库 DS3231_TEST/DS3231.cpp。
// 器件地址 0x68（写 0xD0 / 读 0xD1），时间寄存器 0x00 秒 / 0x01 分 / 0x02 时，
// 全是 BCD。本模块只用这三个，日期 / 闹钟 / 温度都不碰。
//
// 两件事：
//   1) 每 POLL_MS 读一次 0x00~0x02：START D0 00 / reSTART D1 / 读 3 字节 / STOP
//   2) set_valid 来一拍，就把 set_bcd 一次写进 0x00~0x02：START D0 00 ss mm hh STOP
//      小时寄存器 bit6 写 0 = 24 小时制（等价于 Arduino 库 setClockMode(false)）。
//      写完立刻补读一次，屏幕上不用等下一个轮询周期。
//
// 【I2C 时序】SCL 约 I2C_HZ（默认 100kHz 标准模式），每位分 4 个 1/4 周期：
//   q0 SCL 低，改 SDA   q1 SCL 拉高   q2 SCL 高，采 SDA   q3 SCL 拉低
// DS3231 不做时钟拉伸，所以 SCL 只看自己，不回读。
// SCL / SDA 都是开漏：输出 0 或高阻，高电平靠模块板上的 4.7k 上拉（RP1）
// 和 pin.adc 里的内部上拉。
//
// 【总线恢复】FPGA 复位可能恰好打断一次读，DS3231 正在输出某一位 0，
// SDA 被它一直拉低，主机再发 START 也没用。所以上电和每次出现 NACK 后
// 先送 9 个 SCL（SDA 释放）再补一个 STOP，把从机的状态机推回空闲。
//
// 【time_valid】最近一次读成功，且读到的三个字节都是合法 BCD 时间时为 1。
// 模块没接 / 没上电 / 线接反都会 NACK，time_valid=0，OSD 显示 --:--:--。
// 模块若处在 12 小时制（Arduino 设过 setClockMode(true)），显示 01~12，
// 不带 AM/PM；用 TIM= 校一次时就切回 24 小时制。
// -----------------------------------------------------------------------------

module ds3231_rtc #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer I2C_HZ      = 100_000,
    parameter integer POLL_MS     = 100
) (
    input  wire        clk,
    input  wire        rst_n,

    inout  wire        scl,
    inout  wire        sda,

    // 校时：单拍，set_bcd = {时十, 时个, 分十, 分个, 秒十, 秒个} 各 4 位 BCD
    input  wire        set_valid,
    input  wire [23:0] set_bcd,

    // 当前时间，格式同 set_bcd
    output reg  [23:0] time_bcd,
    output reg         time_valid,
    output reg         read_ok_pulse
);
    localparam integer QDIV        = CLK_FREQ_HZ / (I2C_HZ * 4);   // 100MHz/400kHz = 250
    localparam integer POLL_CYCLES = (CLK_FREQ_HZ / 1000) * POLL_MS;

    localparam [7:0] ADDR_W = 8'hD0;
    localparam [7:0] ADDR_R = 8'hD1;

    // ---- 1/4 位节拍 ----
    reg  [15:0] q_cnt;
    wire        q_tick = (q_cnt == QDIV - 1);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            q_cnt <= 16'd0;
        else
            q_cnt <= q_tick ? 16'd0 : q_cnt + 16'd1;
    end

    // ---- 开漏输出 + SDA 输入同步 ----
    reg scl_o;      // 1 = 释放（高阻）
    reg sda_o;
    assign scl = scl_o ? 1'bz : 1'b0;
    assign sda = sda_o ? 1'bz : 1'b0;

    reg sda_s1, sda_s2;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sda_s1 <= 1'b1;
            sda_s2 <= 1'b1;
        end else begin
            sda_s1 <= sda;
            sda_s2 <= sda_s1;
        end
    end

    // ---- 事务程序表：按 txn + step 给出这一步做什么 ----
    localparam [2:0] OP_START   = 3'd0;
    localparam [2:0] OP_WR      = 3'd1;
    localparam [2:0] OP_RD_ACK  = 3'd2;
    localparam [2:0] OP_RD_NACK = 3'd3;
    localparam [2:0] OP_STOP    = 3'd4;

    localparam [1:0] TXN_RECOVER = 2'd0;
    localparam [1:0] TXN_READ    = 2'd1;
    localparam [1:0] TXN_WRITE   = 2'd2;

    reg  [1:0]  txn;
    reg  [3:0]  step;
    reg  [23:0] set_hold;      // 写事务进行中用的那份，不受新 set_valid 影响

    reg  [2:0]  op;
    reg  [7:0]  op_byte;
    always @* begin
        op      = OP_STOP;
        op_byte = 8'h00;
        if (txn == TXN_WRITE) begin
            case (step)
                4'd0: op = OP_START;
                4'd1: begin op = OP_WR; op_byte = ADDR_W; end
                4'd2: begin op = OP_WR; op_byte = 8'h00; end                     // 从 0x00 写起
                4'd3: begin op = OP_WR; op_byte = {1'b0, set_hold[6:0]};   end   // 秒
                4'd4: begin op = OP_WR; op_byte = {1'b0, set_hold[14:8]};  end   // 分
                4'd5: begin op = OP_WR; op_byte = {2'b00, set_hold[21:16]}; end  // 时，bit6=0 24h
                default: op = OP_STOP;
            endcase
        end else begin
            case (step)
                4'd0: op = OP_START;
                4'd1: begin op = OP_WR; op_byte = ADDR_W; end
                4'd2: begin op = OP_WR; op_byte = 8'h00; end                     // 寄存器指针 = 0x00
                4'd3: op = OP_START;                                             // reSTART
                4'd4: begin op = OP_WR; op_byte = ADDR_R; end
                4'd5: op = OP_RD_ACK;                                            // 秒
                4'd6: op = OP_RD_ACK;                                            // 分
                4'd7: op = OP_RD_NACK;                                           // 时，最后一个字节 NACK
                default: op = OP_STOP;
            endcase
        end
    end

    // ---- 读回数据合法性检查 ----
    reg  [7:0] rx_sec, rx_min, rx_hour;

    wire [3:0] s_t = {1'b0, rx_sec[6:4]};
    wire [3:0] s_o = rx_sec[3:0];
    wire [3:0] m_t = {1'b0, rx_min[6:4]};
    wire [3:0] m_o = rx_min[3:0];
    wire       h12 = rx_hour[6];
    wire [3:0] h_t = h12 ? {3'b000, rx_hour[4]} : {2'b00, rx_hour[5:4]};
    wire [3:0] h_o = rx_hour[3:0];

    wire rx_ok = (s_t <= 4'd5) && (s_o <= 4'd9) &&
                 (m_t <= 4'd5) && (m_o <= 4'd9) &&
                 (h_o <= 4'd9) && (h_t <= 4'd2) &&
                 !((h_t == 4'd2) && (h_o > 4'd3));

    // ---- 主状态机 ----
    localparam [2:0] ST_IDLE    = 3'd0;
    localparam [2:0] ST_NEXT    = 3'd1;
    localparam [2:0] ST_START   = 3'd2;
    localparam [2:0] ST_BYTE    = 3'd3;
    localparam [2:0] ST_STOP    = 3'd4;
    localparam [2:0] ST_RECOVER = 3'd5;

    reg [2:0]  state;
    reg [1:0]  q;
    reg [3:0]  bit_idx;        // 0~7 数据位，8 = 应答位
    reg [7:0]  shreg;
    reg        rd_mode;
    reg        ack_out;        // 读字节后主机发的应答：0 = ACK，1 = NACK
    reg        nack;           // 本次事务从机没应答

    reg        set_req;
    reg [23:0] set_req_bcd;
    reg [31:0] poll_cnt;
    reg        poll_due;
    reg        recover_req;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state         <= ST_IDLE;
            q             <= 2'd0;
            bit_idx       <= 4'd0;
            shreg         <= 8'h00;
            rd_mode       <= 1'b0;
            ack_out       <= 1'b0;
            nack          <= 1'b0;
            scl_o         <= 1'b1;
            sda_o         <= 1'b1;
            txn           <= TXN_RECOVER;
            step          <= 4'd0;
            set_hold      <= 24'd0;
            set_req       <= 1'b0;
            set_req_bcd   <= 24'd0;
            poll_cnt      <= 32'd0;
            poll_due      <= 1'b1;     // 上电恢复完马上读一次
            recover_req   <= 1'b1;
            rx_sec        <= 8'h00;
            rx_min        <= 8'h00;
            rx_hour       <= 8'h00;
            time_bcd      <= 24'd0;
            time_valid    <= 1'b0;
            read_ok_pulse <= 1'b0;
        end else begin
            read_ok_pulse <= 1'b0;

            // 轮询定时
            if (poll_cnt >= POLL_CYCLES - 1) begin
                poll_cnt <= 32'd0;
                poll_due <= 1'b1;
            end else begin
                poll_cnt <= poll_cnt + 32'd1;
            end

            case (state)
                ST_IDLE: begin
                    scl_o <= 1'b1;
                    sda_o <= 1'b1;
                    nack  <= 1'b0;
                    step  <= 4'd0;
                    q     <= 2'd0;
                    if (recover_req) begin
                        recover_req <= 1'b0;
                        txn         <= TXN_RECOVER;
                        bit_idx     <= 4'd0;
                        state       <= ST_RECOVER;
                    end else if (set_req) begin
                        set_req  <= 1'b0;
                        set_hold <= set_req_bcd;
                        txn      <= TXN_WRITE;
                        state    <= ST_NEXT;
                    end else if (poll_due) begin
                        poll_due <= 1'b0;
                        txn      <= TXN_READ;
                        state    <= ST_NEXT;
                    end
                end

                // 取程序表下一步，本拍就分派，不等节拍
                ST_NEXT: begin
                    q <= 2'd0;
                    case (op)
                        OP_START: state <= ST_START;
                        OP_WR: begin
                            shreg   <= op_byte;
                            rd_mode <= 1'b0;
                            bit_idx <= 4'd0;
                            state   <= ST_BYTE;
                        end
                        OP_RD_ACK, OP_RD_NACK: begin
                            shreg   <= 8'h00;
                            rd_mode <= 1'b1;
                            ack_out <= (op == OP_RD_NACK);
                            bit_idx <= 4'd0;
                            state   <= ST_BYTE;
                        end
                        default: state <= ST_STOP;
                    endcase
                end

                // START / reSTART：SDA 先回高，SCL 拉高，SCL 高期间 SDA 拉低
                ST_START: if (q_tick) begin
                    q <= q + 2'd1;
                    case (q)
                        2'd0: sda_o <= 1'b1;
                        2'd1: scl_o <= 1'b1;
                        2'd2: sda_o <= 1'b0;
                        2'd3: begin
                            scl_o <= 1'b0;
                            step  <= step + 4'd1;
                            state <= ST_NEXT;
                        end
                    endcase
                end

                ST_BYTE: if (q_tick) begin
                    q <= q + 2'd1;
                    case (q)
                        2'd0: begin
                            scl_o <= 1'b0;
                            if (bit_idx < 4'd8)
                                sda_o <= rd_mode ? 1'b1 : shreg[7];
                            else
                                sda_o <= rd_mode ? ack_out : 1'b1;   // 写：释放给从机应答
                        end
                        2'd1: scl_o <= 1'b1;
                        2'd2: begin
                            if (bit_idx < 4'd8)
                                shreg <= rd_mode ? {shreg[6:0], sda_s2} : {shreg[6:0], 1'b0};
                            else if (!rd_mode)
                                nack <= sda_s2;
                        end
                        2'd3: begin
                            scl_o <= 1'b0;
                            if (bit_idx < 4'd8) begin
                                bit_idx <= bit_idx + 4'd1;
                            end else if (!rd_mode && nack) begin
                                state <= ST_STOP;        // 从机不应答：直接收尾
                            end else begin
                                if (rd_mode) begin
                                    case (step)
                                        4'd5: rx_sec  <= shreg;
                                        4'd6: rx_min  <= shreg;
                                        default: rx_hour <= shreg;
                                    endcase
                                end
                                step  <= step + 4'd1;
                                state <= ST_NEXT;
                            end
                        end
                    endcase
                end

                // STOP：SCL 低时 SDA 拉低，SCL 拉高，SCL 高期间 SDA 释放
                ST_STOP: if (q_tick) begin
                    q <= q + 2'd1;
                    case (q)
                        2'd0: begin scl_o <= 1'b0; sda_o <= 1'b0; end
                        2'd1: scl_o <= 1'b1;
                        2'd2: sda_o <= 1'b1;
                        2'd3: begin
                            state <= ST_IDLE;
                            if (nack) begin
                                time_valid  <= 1'b0;
                                recover_req <= 1'b1;
                            end else if (txn == TXN_READ) begin
                                time_valid <= rx_ok;
                                if (rx_ok) begin
                                    time_bcd      <= {h_t, h_o, m_t, m_o, s_t, s_o};
                                    read_ok_pulse <= 1'b1;
                                end
                            end else if (txn == TXN_WRITE) begin
                                poll_due <= 1'b1;        // 写完马上读回
                            end
                        end
                    endcase
                end

                // 9 个空时钟，SDA 一直释放，然后 STOP
                ST_RECOVER: if (q_tick) begin
                    q <= q + 2'd1;
                    case (q)
                        2'd0: begin scl_o <= 1'b0; sda_o <= 1'b1; end
                        2'd1: scl_o <= 1'b1;
                        2'd2: ;
                        2'd3: begin
                            scl_o <= 1'b0;
                            if (bit_idx == 4'd8)
                                state <= ST_STOP;
                            else
                                bit_idx <= bit_idx + 4'd1;
                        end
                    endcase
                end

                default: state <= ST_IDLE;
            endcase

            // 校时请求放最后：和 ST_IDLE 里的清除同拍时，新请求不丢
            if (set_valid) begin
                set_req     <= 1'b1;
                set_req_bcd <= set_bcd;
            end
        end
    end
endmodule
