# rtc —— DS3231 实时时钟，HDMI 屏幕正中显示 HH:MM:SS

模块资料在 `shizhong/`（DS3231.pdf、Protel Schematic.pdf、Arduino 参考库）。模块上另有一片
AT24C32 EEPROM（地址 0x57），本工程不用。

**本工程的时间同时也是火灾检测板（src_zhu）的时间。** 那边资源紧、不接 DS3231，
本机每次回 RS-485 ACK 时把 `time_bcd` / `time_valid` 带过去（`u_rs485_alarm_slave`），
它只负责显示。所以这里 `TIM=` 校时后两块屏一起变；这里读不到 DS3231 时两块屏都显示
`--:--:--`。协议见 `rs485/README.md`。

## 硬件连接

| 模块脚 | 顶层端口 | J2 脚 | 丝印 | 排阻 | FPGA 网络 | 管脚 |
|---|---|---|---|---|---|---|
| SCL | `rtc_scl` | 24 | GPIOB_21 | RN34（6↔3） | GPIOB9 | **H3** |
| SDA | `rtc_sda` | 26 | GPIOB_23 | RN34（8↔1） | GPIOB11 | **F3** |
| VCC | — | 29 | 3V3 | | | |
| GND | — | 30 | GND | | | |

- 2026-11-02 从原来的 SCL = J2-26（F3）/ SDA = J2-28（J11）整体挪到 J2-24 / J2-26，J2-28 现在空闲。
  H3 是 IO_R14N_GCLKIOR_0_3（全局时钟复用脚），这里当普通 LVCMOS33 IO 用，没有影响。
- 按 4_GPIO 页排阻 → 2_FPGA 页核对过。排阻引脚对应关系（1↔8、2↔7、3↔6、4↔5）已经用
  `pin.adc` 里实测过的 GPIOB_0→P4、GPIOB_2→N3、GPIOB_27→K11 验证。
- **VCC 必须接 3V3，不能接 5V。** 模块上 SCL/SDA 用 4.7k（RP1）上拉到 VCC，
  接 5V 就会把 5V 灌进 FPGA 管脚。DS3231 在 2.3~5.5V 下都能工作。
- 模块上的 R5(200Ω)+D2 是给可充电电池（LIR2032）的充电电路。装普通 CR2032 时，
  在 3.3V 下充电电流很小，但严格说 CR2032 不该被充，长期使用建议拆掉 R5 或 D2。

## 结构

```
uart_rxd ─> media_uart_console ─TIM=HHMMSS─> ds3231_rtc ⇄ I2C ⇄ DS3231
                (sd_card_clk)                (sd_card_clk)
                                                  │ time_bcd + time_valid（25 位）
                                                  ├──> rs485_alarm_slave ─ACK─> 火灾检测板（src_zhu）
                                                  v
                                     cdc_bus_commit（sd -> video）
                                                  v
vout_data_param ─────────────────────> rtc_clock_osd ─> vout_data_rtc ─> emergency_screen ─> HDMI
```

| 文件 | 作用 |
|---|---|
| `ds3231_rtc.v` | I2C 主机，100kHz。每 100ms 读 0x00~0x02（秒/分/时）；收到校时请求就写 0x00~0x02 并立即读回。上电和每次 NACK 后先送 9 个 SCL + STOP 做总线恢复 |
| `rtc_clock_osd.v` | 4x6 数字字模放大 8 倍（字形 32x48），文字区 x 164~475 / y 216~263，外加 16 像素宽的半透明暗底 |

## 显示

- 正常：`HH:MM:SS`，24 小时制，白字。
- `--:--:--`：读不到时间——模块没接、没上电、SCL/SDA 接反、I2C 不应答，或者读到的不是合法 BCD。
  插好以后 100ms 内自动恢复，不用复位。
- 模块如果之前被 Arduino 设成了 12 小时制，会显示 01~12（不带 AM/PM）；用 `TIM=` 校一次就切回 24 小时制。
- 缩略图模式（`THUMB`）下不显示，免得压住中间那几格；ROM 逃生画面会整屏盖掉它。

## 校时

串口（115200 8N1，和其他命令一样以 CRLF 结尾）：

```
TIM=HHMMSS      例：TIM=083000 -> 08:30:00
```

- 6 位**十进制**，时 00~23、分秒 00~59，越界、位数不对、含非数字一律回 `ERR`，不写模块。
- 回 `OK` 后 FPGA 把时间写进 DS3231，掉电后靠模块上的纽扣电池继续走时。
- 只改时分秒，日期寄存器不动。

## 仿真

`sim/rtc/`：`vsim -c -do run.do` 跑 `tb_rtc`（串口 → I2C → 行为模型 `ds3231_model.v` 全链路，
8 项：上电读、跨天进位、TIM 写入与读回、4 种非法 TIM、拔插恢复、12 小时制），然后
`vsim -c tb_rtc_osd -do "run -all; quit -f"` 导出两帧画面，`python render.py` 与参考模型逐像素比对
并生成 `frame_2.png`（12:34:56）/ `frame_4.png`（--:--:--）。

## 夜间模式（2026-11-02）

右上角时钟的小时在 **19:00 ~ 次日 07:00**（含 19:00:00，不含 07:00:00）时：

- 画面亮度固定为 **128（最大亮度的一半）**，不再跟光敏 / SW4 / `BRT=` / KEY3；
- WAV 声音**静音**（音量送 0，播放器照常走，07:00 接着当前位置出声）。

例外：
- **火警优先**：主机发来报警（PIC12/13 或 ROM 逃生画面）期间不进夜间模式，亮度、报警音都恢复正常，报警解除后再回到夜间状态。
- 时间读不到（`--:--:--`）按白天处理。

顶层参数：`NIGHT_MODE_EN`（0 = 关掉）、`NIGHT_START_HOUR` / `NIGHT_END_HOUR`（BCD，`8'h19` = 19 点）、`NIGHT_BRIGHTNESS`。
判定在 sd 域（`night_sd`），亮度、音量随 `u_cfg_sd_to_video` 一起进 video 域，sdc 不用改。
串口 `STATUS` / 参数面板显示的仍是用户设的音量、亮度。备份：`top_tf_hdmi_audio.v.bak_before_night`。

上板验证：`TIM=185955` -> 5 秒后变半亮、静音；`TIM=065955` -> 5 秒后恢复；夜里让主机报警 -> 立刻全亮、报警音响。
