`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// uart_cmd_core：第10课原件的三层握手 wrapper，只做连线。
//
// 讲义原件的接口是"字节进、字节出"（对外露 tx_start/tx_data，自己驱动
// uart_tx）。本工程改成"字节进、reply 通道出"：发送器归第五讲的
// uart_status_reporter 管，本核只把回复字节交给它的 reply_* 口。
// 除此之外三层之间的握手连线与讲义逐根相同。
//
// 层次与责任（讲义第2节）：
//   uart_line_parser     CRLF 边界 + 16 字节缓冲 + 帧错清行 + drop-new 拥塞
//   uart_command_engine  命令码 -> 播放器动作 + 回复编号
//   uart_response_tx     回复编号 -> 固定字符串，逐字节按 reply 合同交付
// 每一级都是"数据 + 单拍有效 + 反压就绪"，下游 ready 为低时上游不得提交。
// -----------------------------------------------------------------------------

module uart_cmd_core #(
    parameter [7:0] DEFAULT_VOLUME     = 8'd255,
    parameter [7:0] DEFAULT_BRIGHTNESS = 8'd255,
    parameter [7:0] DEFAULT_CONTRAST   = 8'd128,    // 第十四讲
    parameter integer FOCUS_COUNT      = 16         // FOC=NN 上限
) (
    input  wire        clk,
    input  wire        rst_n,

    // 接收字节流（来自 uart_rx_byte）
    input  wire        rx_valid,
    input  wire [7:0]  rx_data,
    input  wire        line_abort,        // = uart_rx_byte 的 framing_error

    // 回复字节流（去 uart_status_reporter 的 reply 通道）
    output wire        reply_valid,
    output wire [7:0]  reply_data,
    output wire        reply_last,
    input  wire        reply_ready,

    // 播放器控制（ctrl = sd_card_clk 域）
    output wire        next_event,
    output wire        prev_event,
    output wire        auto_cfg_valid,
    output wire        auto_cfg_enabled,
    output wire        period_cfg_valid,
    output wire [31:0] period_cfg_cycles,
    output wire [7:0]  volume,
    output wire [7:0]  brightness,
    output wire        thumb_cfg_valid,    // 第十三讲：THUMB / FULL
    output wire        thumb_cfg_enabled,
    output wire        select_event,       // 第十五讲：SEL
    output wire        focus_cfg_valid,    // 触控屏：FOC=NN
    output wire [7:0]  focus_cfg_index,

    // 去 uart_status_reporter 的事件口
    output wire        status_event,
    output wire        menu_event,
    output wire [1:0]  menu_kind,
    output wire [31:0] period_ms,
    output wire        bright_event,
    output wire [7:0]  bright_value,

    // 第十四讲：对比度（CON=XX）
    output wire [7:0]  contrast,
    output wire        contrast_event,

    // 四边环绕频谱（VIS=XX）
    output wire [7:0]  vis_cfg,

    // DS3231 校时（TIM=HHMMSS）
    output wire        rtc_set_valid,
    output wire [23:0] rtc_set_bcd,

    // 诊断
    output wire        overflow           // 粘滞：行提交时下游忙，命令被丢弃
);
    wire        cmd_valid;
    wire [3:0]  cmd_code;
    wire [23:0] cmd_arg;
    wire        cmd_ready;
    wire        response_valid;
    wire [2:0]  response_id;
    wire        response_ready;

    uart_line_parser u_uart_line_parser (
        .clk       (clk),
        .rst_n     (rst_n),
        .rx_valid  (rx_valid),
        .rx_data   (rx_data),
        .line_abort(line_abort),
        .cmd_ready (cmd_ready),
        .cmd_valid (cmd_valid),
        .cmd_code  (cmd_code),
        .cmd_arg   (cmd_arg),
        .overflow  (overflow)
    );

    uart_command_engine #(
        .DEFAULT_VOLUME    (DEFAULT_VOLUME),
        .DEFAULT_BRIGHTNESS(DEFAULT_BRIGHTNESS),
        .DEFAULT_CONTRAST  (DEFAULT_CONTRAST),
        .FOCUS_COUNT       (FOCUS_COUNT)
    ) u_uart_command_engine (
        .clk              (clk),
        .rst_n            (rst_n),
        .cmd_valid        (cmd_valid),
        .cmd_code         (cmd_code),
        .cmd_arg          (cmd_arg),
        .cmd_ready        (cmd_ready),
        .response_ready   (response_ready),
        .response_valid   (response_valid),
        .response_id      (response_id),
        .next_event       (next_event),
        .prev_event       (prev_event),
        .auto_cfg_valid   (auto_cfg_valid),
        .auto_cfg_enabled (auto_cfg_enabled),
        .period_cfg_valid (period_cfg_valid),
        .period_cfg_cycles(period_cfg_cycles),
        .volume           (volume),
        .brightness       (brightness),
        .thumb_cfg_valid  (thumb_cfg_valid),
        .thumb_cfg_enabled(thumb_cfg_enabled),
        .select_event     (select_event),
        .focus_cfg_valid  (focus_cfg_valid),
        .focus_cfg_index  (focus_cfg_index),
        .status_event     (status_event),
        .menu_event       (menu_event),
        .menu_kind        (menu_kind),
        .period_ms        (period_ms),
        .bright_event     (bright_event),
        .bright_value     (bright_value),
        .contrast         (contrast),
        .contrast_event   (contrast_event),
        .vis_cfg          (vis_cfg),
        .rtc_set_valid    (rtc_set_valid),
        .rtc_set_bcd      (rtc_set_bcd)
    );

    uart_response_tx u_uart_response_tx (
        .clk           (clk),
        .rst_n         (rst_n),
        .response_valid(response_valid),
        .response_id   (response_id),
        .response_ready(response_ready),
        .reply_valid   (reply_valid),
        .reply_data    (reply_data),
        .reply_last    (reply_last),
        .reply_ready   (reply_ready)
    );
endmodule
