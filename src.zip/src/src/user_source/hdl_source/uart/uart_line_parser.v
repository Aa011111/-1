`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// uart_line_parser：第10课（11 UART环回与命令控制）原件结构 + 本工程命令集。
//
// 与讲义原件的差异，一共三处，行组装那套 saw_cr / command_overlong /
// command_length 的结构一行没动：
//
//  1) 命令集换掉。讲义是 LED ON / LED OFF / STATUS 三条，本工程是播放器，
//     命令集按第五讲 uart_status_reporter.v 的六类消息反推（K_PIC / K_VOL /
//     K_PRD / K_ERR / K_BRT + banner），这样每条命令都有对应的日志行，
//     不会出现"改了参数但串口上看不见"的哑动作：
//
//       NEXT        下一张           -> OK        （reporter 随后打 PIC n A/M）
//       PREV        上一张           -> OK        （同上）
//       AUTO ON     自动轮播开       -> OK
//       AUTO OFF    自动轮播关       -> OK
//       STATUS      重报当前状态     -> OK        （reporter 随后打 PIC n A/M）
//       VOL=XX      音量(2位hex)     -> OK        （reporter 随后打 VOL XX）
//       BRT=XX      亮度(2位hex)     -> OK        （reporter 随后打 BRT XX）
//       PRD=XXXX    轮播周期ms(4hex) -> OK        （reporter 随后打 PRD xxxxxms）
//       THUMB       2x2缩略图模式    -> OK        （第十三讲新增）
//       FULL        全屏模式         -> OK        （第十三讲新增）
//       CON=XX      对比度(2位hex)   -> OK        （第十四讲新增，reporter 随后打 CON XX）
//       SEL         缩略图下确认选择 -> OK        （第十五讲新增，全屏模式下无动作）
//       VIS=XX      四边频谱(2位hex) -> OK        （高4位非0=开，低4位=旋转像素/帧）
//       FOC=NN      缩略图焦点(2位十进制，01 起) -> OK  （触控屏直接设焦点）
//       TIM=HHMMSS  DS3231 校时(6位十进制，24h) -> OK  （时 00~23，分秒 00~59）
//       其余/空行/裸LF/重复CR/超长   -> ERR
//
//     取值一律十六进制，理由和 uart_status_reporter.v 文件头一样：回避除法器。
//     唯一例外是 FOC=NN：它是格子号，和 reporter 的 "PIC 01" 一样按十进制、
//     从 1 起数，触控屏那边不用做 hex 转换。十进制转二进制只要 d1*10+d0，
//     即 (d1<<3)+(d1<<1)+d0，没有除法。只收 0-9，00 判 ERR；上限由
//     uart_command_engine 按 FOCUS_COUNT 判。
//     TIM=HHMMSS 也是十进制，而且不做任何换算：DS3231 的寄存器本身就是
//     BCD，6 个 ASCII 数字的低 4 位直接拼成 24 位 BCD 放进 cmd_arg。
//     范围在这里判（时十位 0~2、为 2 时个位 0~3，分秒十位 0~5），越界回 ERR。
//     VOL/BRT 是 00~FF；PRD 是 0000~FFFF ms，超出 media_player_control 的
//     MIN/MAX 范围时不在这里拦——交给它回 control_error=0x51，reporter 自动
//     打一行 ERR 51，闭环在下游，本层不重复校验。
//
//  2) 新增 cmd_arg[23:0]。讲义的命令没有参数，本工程 VOL/BRT/PRD 要带值。
//     （原来 16 位，加 TIM=HHMMSS 时扩到 24 位，其余命令高位补 0。）
//     hex 字符非法（不在 0-9A-Fa-f）时整条按 CMD_ERROR 提交，不做部分接受。
//
//  3) CRLF 提交拆成两拍（match_pending）。讲义原件在收到 LF 的那一拍里
//     同时做完"匹配命令 + 给 cmd_valid"，它跑 50MHz(20ns)、只有 3 条命令。
//     本工程这一级在 sd_card_clk = 100MHz(10ns) 域，命令多到 8 条还要并行
//     解 4 个 hex nibble，一拍内的组合深度没有把握（本机没有 TD，时序结论
//     只能由综合器给）。所以第一拍只锁存"这一行结束了 + 长度 + overlong
//     快照"，第二拍才做匹配与提交，组合深度对半砍。
//     语义完全不变：cmd_ready 仍然在真正提交的那一拍检查，drop-new 拥塞
//     策略和 overflow 粘滞标志的行为与讲义一致。
//     两拍之间会不会又来一个字节？115200 波特下一个字节 = 868 拍，不会。
//     line_abort 若恰好落在这两拍之间，取消本次提交（比讲义更严，不会把
//     一条已经收全但紧跟帧错的行放过去）。
// -----------------------------------------------------------------------------

module uart_line_parser (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        rx_valid,
    input  wire [7:0]  rx_data,
    input  wire        line_abort,     // 接 uart_rx_byte 的 framing_error
    input  wire        cmd_ready,
    output reg         cmd_valid,
    output reg  [3:0]  cmd_code,
    output reg  [23:0] cmd_arg,
    output reg         overflow        // 粘滞：置1保持到复位
);
    localparam [3:0] CMD_NEXT     = 4'd0;
    localparam [3:0] CMD_PREV     = 4'd1;
    localparam [3:0] CMD_AUTO_ON  = 4'd2;
    localparam [3:0] CMD_AUTO_OFF = 4'd3;
    localparam [3:0] CMD_STATUS   = 4'd4;
    localparam [3:0] CMD_VOL      = 4'd5;
    localparam [3:0] CMD_BRT      = 4'd6;
    localparam [3:0] CMD_PRD      = 4'd7;
    localparam [3:0] CMD_THUMB    = 4'd8;    // 第十三讲
    localparam [3:0] CMD_FULL     = 4'd9;    // 第十三讲
    localparam [3:0] CMD_CON      = 4'd10;   // 第十四讲
    localparam [3:0] CMD_SEL      = 4'd11;   // 第十五讲
    localparam [3:0] CMD_VIS      = 4'd12;   // 四边环绕频谱
    localparam [3:0] CMD_FOC      = 4'd13;   // 触控屏：缩略图直接设焦点
    localparam [3:0] CMD_TIM      = 4'd14;   // DS3231 校时
    localparam [3:0] CMD_ERROR    = 4'd15;

    reg [7:0] command_buffer [0:15];
    reg [4:0] command_length;
    reg       command_overlong;
    reg       saw_cr;

    // 差异3：提交拆成两拍用的快照
    reg       match_pending;
    reg [4:0] match_length;
    reg       match_overlong;

    // ---- hex 字符解析（纯组合，只在 VOL/BRT/PRD 分支用到）----
    function is_hex;
        input [7:0] ch;
        begin
            is_hex = ((ch >= "0") && (ch <= "9")) ||
                     ((ch >= "A") && (ch <= "F")) ||
                     ((ch >= "a") && (ch <= "f"));
        end
    endfunction

    function [3:0] hex_val;
        input [7:0] ch;
        begin
            if ((ch >= "0") && (ch <= "9"))
                hex_val = ch[3:0];                 // '0'=0x30，低4位正好是数值
            else if ((ch >= "A") && (ch <= "F"))
                hex_val = ch[3:0] + 4'd9;          // 'A'=0x41 -> 1+9 = 10
            else
                hex_val = ch[3:0] + 4'd9;          // 'a'=0x61 -> 1+9 = 10
        end
    endfunction

    // 三条带参数的命令都是 "XXX=" 前缀，前缀判定共用
    wire prefix_eq3 = (command_buffer[3] == "=");
    wire arg2_hex   = is_hex(command_buffer[4]) && is_hex(command_buffer[5]);
    wire arg4_hex   = arg2_hex && is_hex(command_buffer[6]) && is_hex(command_buffer[7]);
    wire [15:0] arg2_value = {8'h00, hex_val(command_buffer[4]), hex_val(command_buffer[5])};
    wire [15:0] arg4_value = {hex_val(command_buffer[4]), hex_val(command_buffer[5]),
                              hex_val(command_buffer[6]), hex_val(command_buffer[7])};

    // FOC=NN 的十进制参数
    function is_dec;
        input [7:0] ch;
        begin
            is_dec = (ch >= "0") && (ch <= "9");
        end
    endfunction
    wire arg2_dec = is_dec(command_buffer[4]) && is_dec(command_buffer[5]);
    wire [6:0] dec_hi = {3'b000, command_buffer[4][3:0]};
    wire [15:0] arg2_dec_value = {9'd0, (dec_hi << 3) + (dec_hi << 1) +
                                        {3'b000, command_buffer[5][3:0]}};

    wire line_clean = !match_overlong;

    wire hit_next = line_clean && (match_length == 5'd4) &&
                    (command_buffer[0] == "N") && (command_buffer[1] == "E") &&
                    (command_buffer[2] == "X") && (command_buffer[3] == "T");

    wire hit_prev = line_clean && (match_length == 5'd4) &&
                    (command_buffer[0] == "P") && (command_buffer[1] == "R") &&
                    (command_buffer[2] == "E") && (command_buffer[3] == "V");

    wire auto_head = (command_buffer[0] == "A") && (command_buffer[1] == "U") &&
                     (command_buffer[2] == "T") && (command_buffer[3] == "O") &&
                     (command_buffer[4] == " ");

    wire hit_auto_on  = line_clean && (match_length == 5'd7) && auto_head &&
                        (command_buffer[5] == "O") && (command_buffer[6] == "N");

    wire hit_auto_off = line_clean && (match_length == 5'd8) && auto_head &&
                        (command_buffer[5] == "O") && (command_buffer[6] == "F") &&
                        (command_buffer[7] == "F");

    wire hit_status = line_clean && (match_length == 5'd6) &&
                      (command_buffer[0] == "S") && (command_buffer[1] == "T") &&
                      (command_buffer[2] == "A") && (command_buffer[3] == "T") &&
                      (command_buffer[4] == "U") && (command_buffer[5] == "S");

    wire hit_vol = line_clean && (match_length == 5'd6) && prefix_eq3 && arg2_hex &&
                   (command_buffer[0] == "V") && (command_buffer[1] == "O") &&
                   (command_buffer[2] == "L");

    wire hit_brt = line_clean && (match_length == 5'd6) && prefix_eq3 && arg2_hex &&
                   (command_buffer[0] == "B") && (command_buffer[1] == "R") &&
                   (command_buffer[2] == "T");

    wire hit_prd = line_clean && (match_length == 5'd8) && prefix_eq3 && arg4_hex &&
                   (command_buffer[0] == "P") && (command_buffer[1] == "R") &&
                   (command_buffer[2] == "D");

    // 第十三讲：缩略图 / 全屏
    wire hit_thumb = line_clean && (match_length == 5'd5) &&
                     (command_buffer[0] == "T") && (command_buffer[1] == "H") &&
                     (command_buffer[2] == "U") && (command_buffer[3] == "M") &&
                     (command_buffer[4] == "B");

    wire hit_full = line_clean && (match_length == 5'd4) &&
                    (command_buffer[0] == "F") && (command_buffer[1] == "U") &&
                    (command_buffer[2] == "L") && (command_buffer[3] == "L");

    // 第十四讲：对比度，格式与 BRT=XX 相同，80 = 原样
    wire hit_con = line_clean && (match_length == 5'd6) && prefix_eq3 && arg2_hex &&
                   (command_buffer[0] == "C") && (command_buffer[1] == "O") &&
                   (command_buffer[2] == "N");

    // 第十五讲：缩略图下确认选择焦点那张
    wire hit_sel = line_clean && (match_length == 5'd3) &&
                   (command_buffer[0] == "S") && (command_buffer[1] == "E") &&
                   (command_buffer[2] == "L");

    // 四边环绕频谱：格式与 BRT=XX 相同
    wire hit_vis = line_clean && (match_length == 5'd6) && prefix_eq3 && arg2_hex &&
                   (command_buffer[0] == "V") && (command_buffer[1] == "I") &&
                   (command_buffer[2] == "S");

    // 触控屏缩略图：焦点格子号，01 起；00 不算合法格子
    wire hit_foc = line_clean && (match_length == 5'd6) && prefix_eq3 && arg2_dec &&
                   (arg2_dec_value != 16'd0) &&
                   (command_buffer[0] == "F") && (command_buffer[1] == "O") &&
                   (command_buffer[2] == "C");

    // DS3231 校时：TIM=HHMMSS，6 位十进制直接当 BCD
    wire arg6_dec = arg2_dec && is_dec(command_buffer[6]) && is_dec(command_buffer[7]) &&
                    is_dec(command_buffer[8]) && is_dec(command_buffer[9]);
    wire [23:0] arg6_bcd = {command_buffer[4][3:0], command_buffer[5][3:0],
                            command_buffer[6][3:0], command_buffer[7][3:0],
                            command_buffer[8][3:0], command_buffer[9][3:0]};
    wire tim_range = (arg6_bcd[23:20] <= 4'd2) &&
                     !((arg6_bcd[23:20] == 4'd2) && (arg6_bcd[19:16] > 4'd3)) &&
                     (arg6_bcd[15:12] <= 4'd5) &&
                     (arg6_bcd[7:4]   <= 4'd5);
    wire hit_tim = line_clean && (match_length == 5'd10) && prefix_eq3 && arg6_dec &&
                   tim_range &&
                   (command_buffer[0] == "T") && (command_buffer[1] == "I") &&
                   (command_buffer[2] == "M");

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cmd_valid        <= 1'b0;
            cmd_code         <= CMD_ERROR;
            cmd_arg          <= 24'd0;
            overflow         <= 1'b0;
            command_length   <= 5'd0;
            command_overlong <= 1'b0;
            saw_cr           <= 1'b0;
            match_pending    <= 1'b0;
            match_length     <= 5'd0;
            match_overlong   <= 1'b0;
        end else begin
            cmd_valid <= 1'b0;

            // line_abort 优先于一切：讲义原件的"接收核心拒绝坏字节、解析器
            // 放弃坏行"两层责任。本工程额外把 match_pending 也撤掉。
            if (line_abort) begin
                command_length   <= 5'd0;
                command_overlong <= 1'b0;
                saw_cr           <= 1'b0;
                match_pending    <= 1'b0;
            end else if (match_pending) begin
                // ===== 第二拍：匹配并提交 =====
                match_pending <= 1'b0;
                if (!cmd_ready) begin
                    overflow <= 1'b1;            // drop-new，与讲义一致
                end else begin
                    cmd_valid <= 1'b1;
                    cmd_arg   <= 24'd0;
                    if      (hit_next)     cmd_code <= CMD_NEXT;
                    else if (hit_prev)     cmd_code <= CMD_PREV;
                    else if (hit_auto_on)  cmd_code <= CMD_AUTO_ON;
                    else if (hit_auto_off) cmd_code <= CMD_AUTO_OFF;
                    else if (hit_status)   cmd_code <= CMD_STATUS;
                    else if (hit_vol)    begin cmd_code <= CMD_VOL; cmd_arg <= arg2_value; end
                    else if (hit_brt)    begin cmd_code <= CMD_BRT; cmd_arg <= arg2_value; end
                    else if (hit_prd)    begin cmd_code <= CMD_PRD; cmd_arg <= arg4_value; end
                    else if (hit_thumb)    cmd_code <= CMD_THUMB;
                    else if (hit_full)     cmd_code <= CMD_FULL;
                    else if (hit_con)    begin cmd_code <= CMD_CON; cmd_arg <= arg2_value; end
                    else if (hit_sel)      cmd_code <= CMD_SEL;
                    else if (hit_vis)    begin cmd_code <= CMD_VIS; cmd_arg <= arg2_value; end
                    else if (hit_foc)    begin cmd_code <= CMD_FOC; cmd_arg <= arg2_dec_value; end
                    else if (hit_tim)    begin cmd_code <= CMD_TIM; cmd_arg <= arg6_bcd; end
                    else                  cmd_code <= CMD_ERROR;
                end
            end else if (rx_valid) begin
                if (rx_data == 8'h0D) begin
                    saw_cr <= 1'b1;
                    if (saw_cr)
                        command_overlong <= 1'b1;   // 重复 CR 判错误行
                end else if (rx_data == 8'h0A && saw_cr) begin
                    // ===== 第一拍：完整 CRLF，锁快照，下一拍再匹配 =====
                    saw_cr           <= 1'b0;
                    match_pending    <= 1'b1;
                    match_length     <= command_length;
                    match_overlong   <= command_overlong;
                    command_length   <= 5'd0;
                    command_overlong <= 1'b0;
                end else if (rx_data == 8'h0A) begin
                    // 裸 LF：完整的格式错误，立即按错误行走第二拍
                    saw_cr           <= 1'b0;
                    match_pending    <= 1'b1;
                    match_length     <= 5'd0;
                    match_overlong   <= 1'b1;       // 强制落到 CMD_ERROR
                    command_length   <= 5'd0;
                    command_overlong <= 1'b0;
                end else begin
                    if (saw_cr) begin
                        saw_cr           <= 1'b0;
                        command_overlong <= 1'b1;   // CR 后接普通字符
                    end
                    if (command_length < 16) begin
                        command_buffer[command_length] <= rx_data;
                        command_length <= command_length + 1'b1;
                    end else begin
                        command_overlong <= 1'b1;   // 第17个字符起只置标志
                    end
                end
            end
        end
    end
endmodule
