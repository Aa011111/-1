# uart —— 第五讲 系统稳定性：串口收发与命令控制

本目录是第五讲"可观测性层"的落地，加上 `11 UART环回与命令控制 等4项`
那四课的命令架构。与 `framebuf4bank/`、`fat32/`、`osd/`、`stable/` 解耦，
只通过顶层已有的控制口和状态线与它们相接。

## 这一讲补了什么

`osd/reference/说明.txt` 里记着三条硬缺口，第一条就是**本工程一个串口模块
都没有、`pin.adc` 里也没留串口引脚**。第五讲 3.2 的五层稳定性保障体系里，
第 5 层"可观测性"因此一直是空的——出故障只能看数码管那 6 位十六进制，
既看不到历史，也没法从外部干预。

| 第五讲 / 第10课要求 | 改造前 | 本讲后 |
|---|---|---|
| 错误码上报（UART 日志） | 无 | `uart_status_reporter` 打 `ERR xx` |
| 开机 banner | 无 | `MEDIA PLAYER READY` |
| 图片切换日志 | 无 | `PIC n A/M` |
| 参数变更日志 | 无 | `VOL xx` / `PRD xxxxxms` / `BRT xx` |
| 命令接收与执行 | 无 | 三层架构，8 条命令 |
| 命令应答 | 无 | `OK` / `ERR` |
| 帧错恢复 / 拥塞策略 | 无 | `line_abort` 清残行 + drop-new + 粘滞标志 |

## 文件清单

| 文件 | 来源 | 改动 |
|---|---|---|
| `uart_rx_byte.v` | 第五讲原件 | **无，逐字节相同** |
| `uart_tx_byte.v` | 第五讲原件 | **无，逐字节相同** |
| `uart_status_reporter.v` | 第五讲原件 | **无，逐字节相同** |
| `uart_line_parser.v` | 第10课原件结构 | 命令集换成播放器命令 + `cmd_arg` 参数 + 提交拆两拍 |
| `uart_command_engine.v` | 第10课原件结构 | 动作换成播放器控制 + PRD 的 ms→拍换算流水 |
| `uart_response_tx.v` | 第10课字符串表 | **改接 reporter 的 reply 通道，不再直连 uart_tx** |
| `uart_cmd_core.v` | 第10课原件 | 跟着换接口，连线逻辑不变 |
| `media_uart_console.v` | 新写 | 本工程的集成层 |
| `sim/tb_media_uart_console.v` | 新写 | 16 个场景的功能自检 |

`common/cdc_bus_commit.v` 也是这一讲新加的（多位慢变总线跨域），放在
`common/` 是因为它和 `sync_2ff.v` / `reset_sync.v` 同属通用同步器。

## 结构

```
uart_rxd ──> uart_rx_byte ──> uart_line_parser ──> uart_command_engine ──> uart_response_tx
            （第五讲原件）        （CRLF 边界）        （播放器动作）          │ reply_valid
                  │                                                          │ reply_data
                  │ framing_error                                            │ reply_last
                  └──> line_abort（清残行）                                   v reply_ready
                                                                   uart_status_reporter
                                                        （第五讲原件，内含唯一的 uart_tx_byte）
                                                                              │
                                                                              v uart_txd
```

**发送路只有一个 `uart_tx_byte`。** 板上只有一根 `uart_txd`（D12），
第五讲的 reporter 已经是这条路的唯一主人，而且它专门留了
`reply_valid / reply_data / reply_last / reply_ready` 四根口给命令回复共享。
所以 `uart_response_tx` 改成往这四根口交付字节，而不是第10课那样自己驱动
`uart_tx`——这样第五讲那三个原件一个字都不用改。

reporter 的 `ST_IDLE` 优先级是：

```
reply（命令回复） > banner > ERR > PIC > VOL/PRD > BRT
```

所以一条命令下去会看到**两行**：先 `OK`/`ERR`（reply 通道，"命令应答"），
再对应的事件日志行（reporter 自己那六类，"状态日志"）。这是第五讲定的
分工，不要把它们合成一条。

## 两路串口同时可用

触控屏（J2-1/J2-3，P4/N3）和板载 CH340（USB 口，D12/F12）**共用同一个控制台**：

- 接收：`uart_rx_merge.v` 把两路 RX 合成一路，任一路发的命令都执行。某一路持续低电平
  超过 20 个位时间（USB 没插、CH340 不上电）就判掉线并忽略，恢复空闲高 20 个位时间后自动接回。
- 发送：唯一的 `uart_txd` 同时送到 P4 和 D12，`OK` / `ERR` / 日志两边都收得到。
- 拔 USB 的那一下会留一次帧错（数码管 `72`，粘滞，复位清除），不影响使用。
- 两边恰好在同一个字节时间里一起发，这一行会回 `ERR`，重发即可。

## 命令集

全部以 CRLF 结尾，取值一律**十六进制**（理由和 `uart_status_reporter.v`
文件头一样：回避除法器/BCD 转换）。

| 命令 | 动作 | 应答 | 随后的日志行 |
|---|---|---|---|
| `NEXT` | 下一张 | `OK` | `PIC n A/M`（图真的换了才打） |
| `PREV` | 上一张 | `OK` | 同上 |
| `AUTO ON` | 自动轮播开 | `OK` | `PIC n A` |
| `AUTO OFF` | 自动轮播关 | `OK` | `PIC n M` |
| `STATUS` | 重报当前状态 | `OK` | `PIC n A/M` |
| `VOL=XX` | 音量 00~FF | `OK` | `VOL XX` |
| `BRT=XX` | 亮度 00~FF | `OK` | `BRT XX` |
| `PRD=XXXX` | 轮播周期 ms | `OK` | `PRD 0XXXXms` |
| `VIS=XX` | 四边环绕频谱：高 4 位非 0 = 开，低 4 位 = 每帧旋转像素（默认 `12`；`00` 关，`10` 开但不转） | `OK` | — |
| `THUMB` / `FULL` | 进缩略图 / 回全屏 | `OK` | — |
| `SEL` | 缩略图下全屏播放焦点那张 | `OK` | `PIC n M` |
| `FOC=NN` | 缩略图焦点直接设到第 NN 格（**十进制**，01~11） | `OK`；00、>11、非数字、位数不对回 `ERR` | — |
| `TIM=HHMMSS` | DS3231 校时（**十进制**，24 小时制），见 `rtc/README.md` | `OK`；时>23、分秒>59、非数字、位数不对回 `ERR` | — |
| 其他/空行/裸 LF/重复 CR/超长行/非法 hex | 无动作 | `ERR` | — |

`PRD` 的范围不在 UART 侧拦：越界交给 `media_player_control` 回
`control_error=0x51`，reporter 自动打一行 `ERR 51`，闭环在下游。
当前有效范围是 `MIN/MAX_PERIOD_CYCLES` = 500ms ~ 30000ms
（即 `PRD=01F4` ~ `PRD=7530`）。

## 接到顶层的哪几根

控制口全部是 `media_video_pipeline` / `media_player_control` **已经留好的**，
一根新信号都没往下游插：

| console 输出 | 顶层接法 |
|---|---|
| `next_event` / `prev_event` | 与 `key_next_event` / `key_prev_event` 或起来 |
| `auto_cfg_valid` / `auto_cfg_enabled` | 原来接死成 `1'b0`，现在由 `AUTO ON/OFF` 驱动 |
| `period_cfg_valid` / `period_cfg_cycles` | 原来接死成 `1'b0`/`32'd0` |
| `volume` | 原 `AUDIO_VOLUME` 常量，经 cdc 进 `pcm_media_tone` |
| `brightness` | 原 `8'd255` 常量，经 cdc 进 pipeline |
| `diag_code` | 进 `diag_secondary` 链，上数码管 |

`AUTO ON/OFF` 走 `auto_cfg_*` 而不是 `toggle_auto_event`：toggle 语义下
串口没法确定最终状态，命令式配置才能"说开就是开"。KEY2 的 toggle 保持原样。

## 时钟域

整块跑在 `sd_card_clk`（100MHz，= ctrl 域），和按键事件、fat32 摄入、
`media_player_control` 同域，所以上面那些控制口**不需要任何跨域**。

两条真的要跨域，都用 `common/cdc_bus_commit.v`：

| 信号 | 方向 | 为什么 |
|---|---|---|
| `{brightness, volume}` 16 位 | ctrl → video | 消费方 `pcm_media_tone` / pipeline 的 `brightness` 都在 `video_clk` |
| `player_video_error` 8 位 | video → ctrl | reporter 在 ctrl 域，要用它报 `ERR` |

两个都是多位 bundled data，**不能逐位 2FF**（见 `common/sync_2ff.v` 的合同
边界）。`cdc_bus_commit` 的目的侧第一级命名为 `commit_sync1`，已被
`media_player_promax_top.sdc` 第 6 节的 `*/commit_sync1` 通配覆盖，
**不需要往 sdc 里加新条目**。

## 三处容易踩的坑（都已处理，改动前先看这里）

### 1. `reply_valid` 必须组合门控，否则末尾字节发两遍

reporter 在 `tx_done` 那一拍把 `reply_ready` 寄成高、同时把 state 寄成
`ST_IDLE`，两者下一拍（N+1）才生效。上游也只能在 N+1 才看到 ready，
于是 `active` 要到 N+2 才落——N+1 期间 reporter 已在 `ST_IDLE` 而
`reply_valid` 还挂着高，它会把最后一个字节再抓一次。所以
`uart_response_tx` 里写成：

```verilog
assign reply_valid = active && !(reply_ready && reply_last);
```

不成环：reporter 的 `reply_ready` 是寄存器输出，不依赖 `reply_valid`。

### 2. `switch_event` 没有 pending 锁存，忙时会丢

reporter 的 `menu_event` / `bright_event` 进去会被锁成 pending 排队，
但 `switch_event` 是每拍无条件打拍（`reporter.v:176`）。**仿真里实测过**：
紧跟在一条 `ERR\r\n` 后面切图，`switch_q` 到达时 reporter 还在 `ST_REPLY`
收尾，那行 `PIC` 日志就没了。

修法不碰原件：`media_uart_console` 先把事件记成 `switch_pending`，等
`uart_txd` 已连续为高 11 个位时间（8N1 一帧 10 位 + 一位余量）且
`reply_valid` 为低，才打一拍。残余窗口只剩 1 拍，撞上也只是少一行日志，
下次 `media_id` 变化会重报。

### 3. `PRD` 的 ms→拍换算切了 3 拍

`cycles = ms * 100000`，100000 不是 2 的幂，直接写乘号会摊一个 16×17
乘法器直通 `period_cfg_cycles`。改成移位加法并切流水：

```
100000 = 2^16 + 2^15 + 2^10 + 2^9 + 2^7 + 2^5
```

六项拆两组各三项，每拍最多三个 32 位数相加。时间上不紧张：同一条命令的
`OK` 回复要发 4 个字节 ≈ 347us @115200，这 3 拍（30ns）早走完了。

**改时钟频率必须同时改那六个移位量**，不能只改 `CYCLES_PER_MS` 参数——
那个参数只记录意图，不参与运算。

## 触控屏（TJC8048X270）对接：`FOC=NN`

缩略图模式下触控屏的上下左右、点格子都由屏幕算好格子号，再发 `FOC=NN`，
FPGA 照着设焦点，两边不会走偏。确认发 `SEL`，返回发 `FULL`。

- NN 用十进制、从 01 起，和 `PIC 01` 日志同一套编号，屏幕端不用转 hex。
- 缩略图只显示、只可选 PIC1~11（顶层 `THUMB_COUNT = 11`）：PIC12/13 火警图那两格
  和网格末尾 3 格一样只画底色；方向键/`NEXT`/`PREV` 的焦点也只在 1~11 循环。
- 任何状态都收：紧跟在 `THUMB` 后面、转场还没走完时发来的 `FOC` 不会丢。
- 全屏下也回 `OK` 并照设，但进缩略图时焦点会重新落到当前图上，所以屏幕应在
  `THUMB` 之后再发一次 `FOC`。
- 自检：`sim/touch_foc/run.do`（17 项）。改动前的原文件都备份成了 `*.bak_before_foc`。

## 引脚与波特率

**当前（接触控屏）**：改到 J2 排针，`pin.adc` 改前备份为 `pin.adc.bak_before_j2uart`。

| 信号 | 引脚 | J2 | 接屏幕 |
|---|---|---|---|
| `uart_rxd` | N3（上拉） | J2-3 丝印 GPIOB_2 → RN29 → GPIOB17 | 屏幕 TX |
| `uart_txd` | P4（驱动 8mA） | J2-1 丝印 GPIOB_0 → RN29 → GPIOB20 | 屏幕 RX |

**原来（接板载 CH340 调试）**：想换回电脑串口助手，把 `pin.adc` 里两行改回下表即可。

| 信号 | 引脚 | 来源 |
|---|---|---|
| `uart_rxd` | F12（上拉） | 第10课 `code/constraints/top.adc` |
| `uart_txd` | D12（驱动 8mA） | 第09课 `code/constraints/top.adc` |

那套板级基线已在 CH340 COM4 上实测通过 `LED ON -> OK` / `STATUS -> ON`。
F12/D12 在本工程改造前都空闲：`seg_sel` 占的是 E12/E10/C13/F10/E11/D11，
注释掉的 `vga_data[11]` 是 E13，都不冲突。

RX 给上拉：串口空闲态是高，没插线时别悬空成随机电平，否则 `uart_rx_byte`
会把噪声当起始位、持续报 `framing_error`（数码管显示 0x72）。

波特率 **115200，8N1**：`CLKS_PER_BIT = 100_000_000 / 115_200 = 868`，
实际 `100e6/868 = 115207.4`，偏差 0.006%，8N1 十位帧累积远小于半位。

## 诊断码

串口自身的故障**不进** reporter 的 `error_code`，只走数码管——否则一次帧错
就会让 `error_code` 长期非 0，把 `PIC` 行全挡住（reporter `ST_IDLE` 里
`ERR` 优先于 `PIC`）。两个码接在工程现有诊断码之后：

| 码 | 含义 |
|---|---|
| `0x71` | 行提交时回复通道忙，该命令被丢弃（drop-new，粘滞到复位） |
| `0x72` | 接收停止位错，波特率或接线问题（粘滞到复位） |
| `0x70` | 顶层补的：摄入失败但 `ingest_diag_code` 恰好是 0 时的兜底码 |

`0x71` 优先于 `0x72`（"命令没执行"比"某个字节坏了"更要紧）。

## 怎么跑自检

```
vlib work
vlog common/cdc_bus_commit.v uart/uart_tx_byte.v uart/uart_rx_byte.v \
     uart/uart_status_reporter.v uart/uart_line_parser.v \
     uart/uart_command_engine.v uart/uart_response_tx.v \
     uart/uart_cmd_core.v uart/media_uart_console.v \
     uart/sim/tb_media_uart_console.v
vsim -c -do "run -all; quit -f" work.tb_media_uart_console
```

通过时打印：

```
TEST_PASS media_uart_console banner_commands_args_switchlog_boundaries_frameabort_overflow (126 bytes)
```

16 个场景：banner / 8 条命令的应答与日志 / 参数值断言（`volume`、
`brightness`、`period_cfg_cycles`）/ 图片切换日志 / 半行不执行 / 非法 hex /
重复 CR / 超长行 / 帧错清行 / drop-new 拥塞。

仿真里把 `CLKS_PER_BIT` 压到 16 只为缩短波特周期；对被测逻辑而言它只是
计数上限，握手时序与真实值无关。

**这只是功能闭环自检，不是时序验证。** 综合、资源占用、时序收敛的结论
必须由 TD 给——本机没有 TD 也没有板子。

## 还没做的

- **字幕下发**：`osd/reference/subtitle_uart_controller.v`（讲义的
  `SUB=xxx` 命令）仍未接入。串口和引脚这一层现在通了，剩下的缺口是它
  期望的"字幕落盘到 SD 卡"服务——`fat32/sd_media_service.v` 是只读的。
  接的时候按 `osd/reference/说明.txt` 的顺序走，`save_done/save_failed`
  至少要接成"立刻回失败"，不能悬空成 0（否则 `SUB=SAVE` 永远等不到回应，
  之后所有命令回 `ERR`）。
- **参数持久化**：第五讲的 `player_config_persistence.v` /
  `w25q64_record_store.v` 那条 Flash 固化链没接，所以 `VOL`/`BRT`/`PRD`
  掉电即丢。那是第五讲第 4 层"参数管理"的事，与本目录无关。
- **不丢命令**：拥塞策略是 drop-new。要不丢命令得在命令边界加 FIFO 或
  主机重试协议，并同步扩展测试用例（第10课讲义小结的原话）。
