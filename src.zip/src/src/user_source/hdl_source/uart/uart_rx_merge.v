`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// uart_rx_merge：两路 UART 接收线合成一路，给同一个 media_uart_console 用。
//
//   rx_a = 触控屏（J2-3，N3）     rx_b = 板载 CH340（F12）
//
// UART 空闲是高、起始位是低，所以两路直接"与"起来，谁发字节都能被收到。
// 发送方向不用合并：顶层把 uart_txd 同时接到两根输出管脚上。
//
// 【为什么不能只是一个与门】板载 CH340 靠 USB 供电。USB 没插时它的 TXD
// 可能被拉成低电平（芯片不上电，IO 经保护二极管钳位），电脑串口被拔掉时也一样。
// 这根线一直是低，与门的输出就一直是低，触控屏那一路也跟着被堵死，
// console 还会不停地报帧错（0x72）。
// 所以每一路都带一个"在不在线"的判定：
//   - 持续低电平超过 DEAD_BITS 个位时间 -> 判掉线，这一路按高电平处理（忽略）；
//     合法数据里最长的低电平是 0x00 字节：起始位 + 8 个 0 = 9 位，DEAD_BITS 取 20
//     远大于它，正常字节永远不会被误判；
//   - 掉线后（以及上电时）要先连续高 ALIVE_BITS 个位时间，才重新接进来。
//
// 【掉线瞬间的残字节】一路刚掉线的那 20 个位时间里，低电平还会传过去：
// uart_rx_byte 先报帧错，接着又起一帧，掉线判定一到线变高，这一帧就被当成
// 一个合法的乱码字节收进命令缓冲，下一条命令会因此回 ERR（仿真里实测到）。
// 所以掉线判定后先等 FLUSH_WAIT_BITS 个位时间（让那半截字节收完），再主动
// 拉低 9.75 个位时间：uart_rx_byte 在 9.5 位处采到停止位为低 -> 帧错 ->
// line_abort 把缓冲清掉；9.75 位就放开，它在 10 位处复核起始位时线已经是高，
// 不会再起一帧。
// 代价：数码管会留一个 72（串口帧错，粘滞），复位即清。
//
// 【两路同时发】两边恰好在同一个字节时间里一起发，字节会被搅坏，
// 这一行回 ERR，重发即可。人在电脑上敲命令和点触控屏，几乎不会撞上。
// -----------------------------------------------------------------------------

module uart_rx_merge #(
    parameter integer CLKS_PER_BIT = 868,
    parameter integer DEAD_BITS    = 20,
    parameter integer ALIVE_BITS   = 20
) (
    input  wire clk,
    input  wire rst_n,
    input  wire rx_a,
    input  wire rx_b,
    output reg  rx_out,
    output wire a_alive,
    output wire b_alive
);
    localparam integer DEAD_CYCLES  = DEAD_BITS  * CLKS_PER_BIT;
    localparam integer ALIVE_CYCLES = ALIVE_BITS * CLKS_PER_BIT;
    localparam integer FLUSH_WAIT   = 12 * CLKS_PER_BIT;
    localparam integer FLUSH_LOW    = (39 * CLKS_PER_BIT) / 4;   // 9.75 位

    wire a_ok, b_ok;

    uart_rx_presence #(.DEAD_CYCLES(DEAD_CYCLES), .ALIVE_CYCLES(ALIVE_CYCLES)) u_a (
        .clk(clk), .rst_n(rst_n), .rx(rx_a), .rx_masked(a_ok), .alive(a_alive)
    );
    uart_rx_presence #(.DEAD_CYCLES(DEAD_CYCLES), .ALIVE_CYCLES(ALIVE_CYCLES)) u_b (
        .clk(clk), .rst_n(rst_n), .rx(rx_b), .rx_masked(b_ok), .alive(b_alive)
    );

    // 掉线后清残字节：0 = 空闲，1 = 等半截字节收完，2 = 拉低制造一次帧错
    reg        a_alive_q, b_alive_q;
    reg [1:0]  flush_phase;
    reg [31:0] flush_cnt;
    wire       went_dead = (a_alive_q & ~a_alive) | (b_alive_q & ~b_alive);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            a_alive_q   <= 1'b0;
            b_alive_q   <= 1'b0;
            flush_phase <= 2'd0;
            flush_cnt   <= 32'd0;
            rx_out      <= 1'b1;
        end else begin
            a_alive_q <= a_alive;
            b_alive_q <= b_alive;

            if (went_dead) begin
                flush_phase <= 2'd1;
                flush_cnt   <= 32'd0;
            end else if (flush_phase == 2'd1) begin
                if (flush_cnt >= FLUSH_WAIT - 1) begin
                    flush_phase <= 2'd2;
                    flush_cnt   <= 32'd0;
                end else
                    flush_cnt <= flush_cnt + 32'd1;
            end else if (flush_phase == 2'd2) begin
                if (flush_cnt >= FLUSH_LOW - 1)
                    flush_phase <= 2'd0;
                else
                    flush_cnt <= flush_cnt + 32'd1;
            end

            rx_out <= (flush_phase == 2'd2) ? 1'b0 : (a_ok & b_ok);
        end
    end
endmodule

// 单路：2FF 同步 + 在线判定。rx_masked = 在线时的同步后电平，不在线时恒 1。
// 第一级叫 s1，被 media_player_promax_top.sdc 的 */s1 通配 false_path 覆盖。
module uart_rx_presence #(
    parameter integer DEAD_CYCLES  = 17360,
    parameter integer ALIVE_CYCLES = 17360
) (
    input  wire clk,
    input  wire rst_n,
    input  wire rx,
    output wire rx_masked,
    output reg  alive
);
    (* async_reg = "true" *) reg s1, s2;
    reg [31:0] run_cnt;     // 当前电平已经持续了多少拍

    assign rx_masked = s2 | ~alive;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1      <= 1'b1;
            s2      <= 1'b1;
            run_cnt <= 32'd0;
            alive   <= 1'b0;
        end else begin
            s1 <= rx;
            s2 <= s1;
            if (s2 != s1) begin
                run_cnt <= 32'd0;                  // 电平要变了，重新计时
            end else if (s2) begin
                if (run_cnt >= ALIVE_CYCLES - 1) alive <= 1'b1;
                else                             run_cnt <= run_cnt + 32'd1;
            end else begin
                if (run_cnt >= DEAD_CYCLES - 1)  alive <= 1'b0;
                else                             run_cnt <= run_cnt + 32'd1;
            end
        end
    end
endmodule
