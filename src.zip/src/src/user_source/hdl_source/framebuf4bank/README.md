# framebuf4bank —— 第八讲 四bank帧缓存架构

本目录是第八讲的全部新代码，与 `fat32/`、`stable/`、`SD/` 解耦。

## 这一讲解决了什么

改造前工程用的还是官方例程的 `frame_read_write` 二合一桥接：读写耦合在一个模块里、
单端口 SDRAM 靠 `O_wr_busy`/`O_rd_busy` 互看来协调、读侧没有 in-flight 流水、
没有 underflow 检测、切换图片直接改 `read_addr_index`（没有帧边界原子提交）。

第七讲已经把"4 张图各占一块固定 SDRAM 区、开机一次性摄入"做完了，所以**地址层面的
四bank本来就成立**。第八讲补上的是另一半：**loader/reader 分离 + FIFO/burst +
双时钟域异步FIFO + prefetch + 完整错误码 + 帧消隐期原子提交**。

## 文件清单

| 文件 | 来源 | 改动 |
|---|---|---|
| `media_frame_reader.v` | 讲义原件 | 无 |
| `video_timing_ctrl.v` | 讲义原件 | 无 |
| `rgb_video_adapter.v` | 讲义原件 | 无 |
| `fifo_prefetch_2.v` | 讲义原件 | 无 |
| `media_sdram_write_cdc.v` | 讲义原件 | **dst 侧判决重构**（含内置 `async_command_fifo`，未动） |
| `video_fade_transition.v` | 讲义原件 | 无（`FADE_FRAMES=0` 走 generate 旁路，一个门都不综合） |
| `media_frame_loader.v` | 讲义原件 | **+V_FLIP** |
| `media_player_control.v` | 讲义原件 | **+prev_event / +init_event** |
| `media_video_pipeline.v` | 讲义原件 | **+端口透传、+mem域同步器、de_in 去门控** |
| `media_key_events.v` | 新写 | 从 `fat32/media_playback_selector.v` 拆出按键部分 |

异步FIFO `rfifo_32_32_512` 和 `fifo_prefetch_2` 都是普通 RTL，**不需要在 TD 里新建 IP**。
`rfifo_32_32_512` 直接复用工程已有的 `IP/afifo_32_16_256.v`（参数和端口与 reader 的
例化完全匹配）；讲义文件夹里那份只是多了一条 `AL_MAP_LUT1` 写地址延迟链，工程这份在
`frame_read_write` 时代已经跑通，不动它。

## 对讲义原件做了哪些改动，为什么

### 1. `media_frame_loader.v` 加 `V_FLIP`

讲义原件的写地址是 `bank_base + pixels_written`，纯线性递增。但 BMP 文件是**自底向上**
存储的——改造前靠 `SD/frame_fifo_write.v` 的 `WRITE_V_FLIP=1` 在写地址上做翻转，换成
loader 后这层翻转会丢，**画面会上下颠倒**。

翻转按 `frame_fifo_write.v` 的同一套做法搬进来：一个随 pop 走的地址游标 + 行内列计数，
每写完一行往回跳两行再进一列，纯递增/递减，不引入除法器。
`V_FLIP=0`（默认）时与讲义原件逐字等价，顶层例化时传 `V_FLIP(1)`。

### 2. `media_player_control.v` 加 `prev_event` / `init_event`

- `prev_event`：本工程 KEY2 长按 = 上一张，讲义原件只有"下一张"。新增的
  `prev_available()` 与 `next_available()` 完全对称。
- `init_event`：讲义原件复位后 `active_index=0`，若 PIC1.BMP 缺失或解析失败，会去读
  bank0 的垃圾数据。改造前是靠 `media_playback_selector` 的 `first_valid_index()` 在
  `ingest_done` 时落位的，这个行为必须保住。**不能用 `next_event` 代替**——4 张图都在时
  从 index 0 发一次 next 会落到 1，而不是 0。

讲义的 `issue_next_request` 拆成带参数的 `issue_request(selected)`，三个事件共用同一套
busy/no-resource 判定，错误码语义不变。优先级：`init > next > prev > 自动轮播`。

### 3. `media_video_pipeline.v` 三处

- **端口透传** `prev_event` / `init_event` 到 `u_control`。
- **补 mem 域同步器**：讲义原件把 ctrl 域的 `player_enable` 裸接进 mem 域的
  `controller_init_done`（pix 域那一路是规规矩矩过了 `sync_2ff` 的，mem 域漏了）。
  本工程里这一路尤其要紧——`player_enable` 就是下面说的读写时间互斥开关，它一旦在
  mem 域亚稳，reader 可能在 loader 还在写的时候就发读指令，跟写指令在同一个单端口
  SDRAM 上撞车。补 `u_player_enable_mem`。
- **`de_in` 去掉 `player_enable_pix` 门控**：讲义原件是 `raw_de && player_enable_pix`。
  播放未使能时像素内容已经由 `selected_rgb` 黑掉了，再把 de 也拉掉会让 HDMI 彻底失去
  有效视频时序——显示器会报"无信号"而不是显示黑屏，摄入完成那一刻还要重新锁一次，
  画面闪一下。改造前 `video_timing_data` 是一直跑时序、只把 `vout_data` 黑掉的。

### 4. `media_sdram_write_cdc.v` 换掉 dst 侧的块指针判决

讲义原件的 dst 侧用一对跨域格雷码块指针决定何时搬运：src 每凑满 `BURST_SIZE`
个字推进一次块指针，dst 看到 `block_pending` 就固定搬 `BURST_SIZE` 个字。
**这套机制只在"写入总字数恰好是 BURST_SIZE 整数倍"时才闭合。**

正常情况下本工程是闭合的（307200 / 128 = 2400 整块）。但摄入状态机有单张图
watchdog，某张图中途 abort 时 loader 只写了非 128 倍数的字数，于是不足一块的
残余卡在 FIFO 里不搬，块边界从此**永久错位**——下一张图会先替它把这块凑满才
搬走，于是每张图结束时都留着一截同样大小的尾巴，`dst_idle` 永远为 0，
`ST_FLUSH` 等不到 `cdc_idle`，**后面每一张好图都会被 watchdog 误判为失败**。

试过在块指针上补一条排空路径，补不干净：dst 把残余排掉之后，src 侧的
`src_burst_word_count` 仍停在半块上，下一块只剩 `128-r` 个字就会置起
`block_pending`，dst 却按满 128 去搬，直接读空 FIFO。要修就得把"已排空"
反馈回 src 域，又是一条新的跨域握手。

**改法**：干脆不用块指针，dst 侧直接看 `async_command_fifo` 已经提供、但讲义
原例化里空着的 `rd_level`：

- `level >= BURST_SIZE` → 发一个满 128 字的 burst（与原行为一致）
- src 静默 255 拍且 `level != 0` → 按实际字数把残余搬走

没有"块"的概念，也就不存在错位；src 侧只剩溢出检测。

一个必须小心的点：`rd_level` 组合路径上有一条 10 级格雷码转二进制链，在
125MHz 上不该每拍都评估，所以寄存一拍再用。寄存值滞后 = 偏小，本身安全
（顶多晚发一个 burst）；但 **burst 刚结束的一两拍里它会偏大**（最后两拍的读还
在途中），偏大会导致按虚高的字数发 burst 而读空 FIFO、地址错位。所以 burst
之间插了 3 拍固定冷却等它稳定。代价是每 128 字 burst 多 3 拍间隔（约 2% 吞吐），
而写入只发生在开机摄入期、真正的瓶颈是 SD 卡读速度，完全无感。

### 5. `media_key_events.v`（新写）

原 `media_playback_selector` 把按键消抖裁决、`media_id` 选择、数码管状态码三件事写在
同一个 always 块里。第八讲把 index 管理连同帧消隐期原子提交一起交给
`media_player_control`（那是防撕裂的关键），所以这里只保留按键裁决，输出纯事件脉冲；
index 归 `media_player_control`，状态码回顶层。消抖器直接实例化那个文件里已有的
`fat32_key_press_debounce`，不复制。

按键裁决与 `media_playback_selector.v:117-191` 逐条对应，**包括它原有的两个门控**——
这两个容易在拆分时丢掉，丢了会有实际症状：

- `ready` 输入（= `display_valid`），对应原来的 `else if (display_valid)`。摄入还没出
  结果时按键一律不响应。**少了它**，摄入期按一下 KEY1，`media_player_control` 会报
  `ERR_NO_RESOURCE`(0x53) 把数码管点亮，是误报。
- `image_complete` 输入用来算 `valid_count > 1`，对应原来开自动轮播前的那个判断。
  **少了它**，只有一张图时也能开轮播，每 3s 触发一次切到自己的提交，没意义。

长按计时本身不门控（按住的时候 `ready` 可能刚好翻转），只门控最终发出的事件。

## 16 位色存储（RGB565，2026-10-21）

为了在 8MB SDRAM 里放更多张图（为火灾预警图腾名额），顶层新增参数
`PACK_RGB565`（默认 1），同时传给 loader 和 pipeline→reader，**两边必须一致**。

| | `PACK_RGB565=0`（原来） | `PACK_RGB565=1`（现在） |
|---|---|---|
| 每字 | 1 像素，`{8'h00, RGB888}` | 2 像素，`{右像素565, 左像素565}` |
| 每张图 | 307200 字 | 153600 字（8MB 理论可放 13 张） |
| 全屏读 | 128 字 burst | 128 字 burst，pix 侧每字拆两像素 |
| 缩略图读 | 每源行 5×128 字，丢奇数字 | 每源行 5×64 字（64 对齐，不跨 256 字 SDRAM 行），每字取低半字 |
| 色深 | 24 位 | 16 位（截位；回填高位，纯白仍是 FFFFFF） |

- 分辨率不变，仍是 640x480。`IMAGE_WORDS` 参数沿用旧名，含义始终是"每张图像素数"，
  模块内部用 `BANK_WORDS` 表示实际占用字数。
- `PACK_RGB565=0` 时 loader / reader 与改造前逐位等价（`sim/opt_equiv` 回归 + 
  `sim/rgb565` 里新旧 reader 逐拍比对）。
- 回归：`sim/rgb565/`，`vsim -c -do run.do`，期望 `RESULT: PASS`。
- 图片数量见下一节（已扩到 13 张）。
- reader 的 `DIAG_*` 诊断模式只按 24 位格式写，打开时须把 `PACK_RGB565` 设为 0。

TD 实跑（2026-10-21）：LUT 13896、BRAM 59/64（loader FIFO 24→32 位多 1 块）。
默认布局参数下 sd_card_clk 组 setup −174ps（失败路径全在 bmp24_decoder / fat32 扫描器 /
串口上报，不在本次改动的模块里；改造前该组余量也只有 +116ps）。
**Place 参数 `opt_timing` 设为 `high` 后收敛：setup +110ps、hold +23ps。**
（扩到 13 张后改回默认参数才收敛，见下一节。）

## 13 张图（2026-10-21）

顶层参数（`top_tf_hdmi_audio.v` 开头，只在这里改）：

| 参数 | 值 | 含义 |
|---|---|---|
| `IMAGE_COUNT` / `INDEX_W` | 13 / 4 | 图片数、编号位宽 |
| `NAV_MASK` | `13'b0_0111_1111_1111` | 参与 KEY1/KEY2/串口 NEXT PREV/自动轮播/开机首图的图：PIC1~11 |
| `THUMB_COLS` / `THUMB_ROWS` / `CELL_W` | 4 / 4 / 4 | 缩略图 4x4，每格 160x120，后 3 格空 |

TF 卡文件：`PIC1.BMP`~`PIC13.BMP`、`MUSIC1.WAV`~`MUSIC13.WAV`（一一对应，缺哪首那张静音）。
分配：PIC1 通知 / PIC2~11 展馆内容 / PIC12 火灾预警 / PIC13 火灾发生。
PIC12/13 平时不会被切到，缩略图里能看到、能选中（调试用），之后接传感器触发。

各模块默认参数（4 张 / 2x2 / 全部参与轮播）下行为与改造前相同。要点：

- **扫描器**：一位数、两位数序号都认（`PIC10   BMP` 这种 8.3 短名）；超过 `IMAGE_COUNT` 的忽略。
  音乐起始扇区改为扫目录时逐项算好，不再在结束时 N 路并行换算。
- **摄入**：扫描器改用 `rst_n`，不再被单张图 watchdog 局部复位，它的输出直接用，
  省掉一份 13x(32+32) 位的副本。13 选 1 的文件大小寄存一拍再给 bmp24_decoder。
- **播放控制**：next/prev 用"比当前大/小的位里找最低/最高的 1，找不到再全局找"，
  与原来的绕圈取模查找穷举等价（`sim/img13/tb_navfunc.v`），但路径浅得多；
  候选每拍预先算好寄存。
- **reader**：缩略图读地址改由计数器给出（格高 120 不是 2 的幂，原来那套比较+减法
  在 125MHz 下走不完）。4x4 下每格 4:1 抽取，一帧读 614400 字，与 24 位 2x2 时相同。
- **数码管**：正常显示时最右两位是两位十进制图号 01~13；诊断码四位整体左移一位。
  末位 0=摄入中、E=应急不变；"1/2 = 摄入失败"现在要看十位是否熄灭来区分。
- **状态条 OSD**：左上角 `[图号两位][A/E][错误码两位]`，宽 40 像素。
- **串口**：`PIC 01 A` 两位图号。
- **字幕**：`osd/osd_subtitle_source.v` 里 13 句英文占位，按实际内容改。

回归：`sim/img13/run.do`（13 张全屏 + 4x4 缩略图逐像素）、`sim/img13/run_nav.do`
（导航/轮播不进火灾图/焦点循环）、`sim/one_pic_one_wav/run.do`（扫描器含两位数文件名）、
`sim/rgb565/run.do`、`sim/opt_equiv/run.do`，全部 PASS。

TD 实跑：LUT 14226 (72.6%)、BRAM 59/64、DSP 15/29。**默认布局参数**收敛：
setup +100ps、hold +21ps（`opt_timing high` 这次反而在 hold 修复的增量布线上撞线失败）。
余量一直在 0.1ns 左右，每次改代码后都要看 `route_flow.status`。

## ⚠️ SDRAM 单端口读写仲裁 = 时间互斥

**这一条是整个改造最关键的约束，改代码之前必须读明白。**

官方 `frame_read_write` 内部靠 `frame_fifo_write.into_burst` 看 `~App_rd_busy`、
`frame_fifo_read` 看 `~App_wr_busy` 来协调写和读共用同一个 SDRAM 端口
（见 `SD/frame_read_write.v:87-88`）。换成 loader/reader 分离后，**两个模块各自直连
SDRAM 控制器、互不知晓，这层仲裁没有了**。

本工程用**时间互斥**替代，开关是顶层的 `ingest_finished`（= `player_enable`）：

```
摄入期  player_enable=0  ->  reader 的 controller_init_done 被门控为 0，
                             一条读指令都不发；只有 loader 在写
摄入完  player_enable=1  ->  loader 永久 idle，app_wr_en 恒 0；只有 reader 在读
```

顶层给它接的是 `display_valid`（= 摄入结束 **且** 至少有一张图加载成功），
不是光看 `ingest_finished`。一张图都没加载成功时 `ingest_finished` 照样是 1，
reader 会去读 bank0 未初始化的 SDRAM，屏幕显示雪花——改造前那种情况是黑屏。
时间互斥不受影响：第一张图加载完 `loader_image_complete` 就非 0 了，但那时
`ingest_finished` 还是 0，`display_valid` 仍为 0，reader 插不进来。

两者永不并发。**后续若要加"运行时重载单张图"（比如 SD 卡热插拔后重新摄入），
必须先补一个真正的仲裁器**，不能直接让 loader 在显示期间写。

`media_frame_loader` / `media_frame_reader` 的 `controller_busy` / `refresh_active`
两个输入在模块内部是**悬空的**（讲义注释说明：控制器自己处理 busy/refresh，这两根不是
逐字 ready，不能用来打断正在进行的写 burst），指望靠它们做仲裁是行不通的。

## 时钟域与跨域点

| 域 | 频率 | 谁在这个域 |
|---|---|---|
| `sd_card_clk` | 100MHz | fat32 摄入链、`bmp24_decoder`、`media_frame_loader`、`media_key_events`、`media_player_control` 的 ctrl 侧 |
| `ext_mem_clk` | 125MHz | `sdram U3`、`media_frame_reader` 的 mem 侧、写侧 CDC 的 dst 侧 |
| `video_clk` | 25MHz | `video_timing_ctrl`、`media_frame_reader` 的 pix 侧、`media_player_control` 的 pix 侧、OSD、HDMI 发射 |

跨域点清单（都在顶层或 pipeline 内部有显式同步器）：

1. **写数据 sd→mem**：`media_sdram_write_cdc`（异步FIFO + 格雷码块指针，按 128 字成块
   搬运，dst 侧输出仍是连续 128 拍的真 burst）。307200/128=2400 整除，整帧能搬干净不留尾巴。
2. **`dst_idle` mem→sd**：`u_wr_cdc_idle_sync`，`RESET_VAL=1`。摄入状态机 `ST_FLUSH`
   要等它——`load_done` 只管到 CDC 入口，管不到 CDC 里那 512 深 FIFO。
3. **`Sdr_init_done` mem→sd**：`u_sdr_init_done_sync`，给 loader 用。
4. **`player_enable` ctrl→pix / ctrl→mem**：pipeline 内的 `u_player_enable_pix` /
   `u_player_enable_mem`。
5. **读数据 mem→pix**：`rfifo_32_32_512` 异步FIFO + `fifo_prefetch_2` 两级预取。
6. **index ctrl→pix**：`media_player_control` 内部的 `request_toggle` + 2FF，
   在 `frame_start` 提交（防撕裂的关键）。
7. **`auto_enabled` ctrl→pix**：顶层 `u_auto_play_video_sync`，只给 OSD 用。

## 错误码汇总（都能在数码管上看到）

数码管第 1、2 位（从左数）= 读侧/控制错误，第 3、4 位 = 写侧/摄入错误，末位 = state_code。
正常显示时前四位熄灭，出故障才点亮。

| 码 | 来源 | 含义 |
|---|---|---|
| `0x00~0x0c` | `sd_spi_init.v` | SD 卡初始化各阶段失败 |
| `0x10/0x20/0x21/0x22` | `fat32_volume_scanner.v` | FAT32 扫描失败 |
| `0x31~0x38` | `bmp24_decoder.v` | BMP 头/尺寸/位深/压缩/截断 |
| `0x39` | `fat32_storage_ingest_top.v` | 单张图 watchdog 超时（本讲新增，见下） |
| `0x41` | loader | 未激活时收到像素 |
| `0x42` | loader | 写侧 FIFO 溢出 |
| `0x43` | loader | 像素计数超过 307200 |
| `0x44` | loader | 上游解码错误 |
| `0x45` | loader | 短帧（像素数不足） |
| `0x46` | loader | 写超时（SDRAM 一直忙） |
| `0x47` | **顶层** | 写侧跨时钟域 FIFO 溢出（loader 看不到，只能在顶层报） |
| `0x51~0x53` | `media_player_control` | 周期越界 / 请求忙 / 无可用资源 |
| `0x61` | reader | 帧溢出（上一帧没读完就来新请求） |
| `0x62` | reader | 读侧异步 FIFO 溢出 |
| `0x63` | reader | **显示下溢**（SDRAM 读速度跟不上显示） |
| `0x64` | reader | 短帧（返回数据不足） |

`0x39` 的由来：单张图 watchdog 超时（`sub_abort`）时，loader 既等不到 `frame_commit`
也等不到 `decode_error`，会一直停在 `active` 上，下一张的 `load_start` 因为
`load_start && !active` 被吞掉，整个摄入会卡死在第二张图。所以把 `sub_abort` 也当成
一种解码错误报给 loader，让它 `fail_load` 释放出来。

## 顶层改了什么

**删掉的实例**：`frame_read_write_m0`、`video_timing_data_m0`、`video_delay_m0`、
`media_playback_selector`、`frame_write_toggle_mem` 那个 always、
sd→video 的 `status_*` 整包 toggle 跨域块。

**新增的实例**：`u_media_frame_loader`、`u_media_sdram_write_cdc`、`u_media_key_events`、
`u_media_video_pipeline`、两个 `sync_2ff`。

**保持不动**：`sys_pll` / `video_pll` / `PLL_HDMI_AUDIO`、4 个 `reset_sync`、`sdram U3`、
`status_osd_overlay`、`pcm_media_tone`、`audio_arc_calculate`、
`video_rgb_to_axis_640x480`、`startup_pulse`、HDMI 发射核与 PHY。

**参数注意**：`media_video_pipeline` 的 `DEFAULT_PERIOD_CYCLES` 传的是 `300_000_000`
（3s @ ctrl_clk=100MHz），与改造前 `AUTO_PLAY_MS=3000` 一致。**讲义原件的默认值
250_000_000 是按 25MHz 像素时钟算的 10 秒，不能照抄**——本工程的 ctrl_clk 是 100MHz。

**保留但不再例化**：`fat32/media_playback_selector.v` 不删除。它里面的
`fat32_key_press_debounce` 还在被 `media_key_events` 使用，而且留着方便回退对照。
TD 清单里它仍是 active（同一个文件里两个 module，只有消抖器被引用，
另一个未被例化的顶层模块综合时会被丢弃）。

## TD 工程清单变更

`src/td_project/HDMI1.4b_Transmitter_v1.0.al`（改前已备份为 `.al.bak_before_lesson8`）：

- 新增 `framebuf4bank/` 下 10 个 `.v`，CompileOrder 60~69
- 以下 5 个标记为 `AutoExcluded=true`（文件保留在盘上，只是不再编译）：
  `SD/frame_read_write.v`、`SD/frame_fifo_read.v`、`SD/frame_fifo_write.v`、
  `SD/video_timing_data.v`、`SD/video_delay.v`
- IP 清单不动：`afifo_32_16_256.ipc` 生成的 `rfifo_32_32_512` 继续用；
  `frame_read_write` 用的 `wfifo_32_32_512`（来自 `afifo_16_32_256.ipc`）现在无人引用，
  IP 条目留着无害
- `include/global_def.v` 的 `SDR_CLK_PERIOD` 保持 125MHz 版本不动。讲义的
  `_IP核需在TD中生成.txt` 提到完赛工程 mem_clk 是 40MHz，**那是完赛工程的配置，
  本工程是 125MHz**，`SD/sdram.v` 里的 `REFRESH_INTERVAL_CYCLES=3200` 也是按 125MHz
  算出来的，两者要一起保持一致

## 上板验证

| # | 操作 | 预期 | 不对时看哪里 |
|---|---|---|---|
| 1 | TD 编译 | 无 undefined module / 无端口位宽警告 | TD 清单 |
| 2 | 上电，TF 卡插 PIC1~4.BMP | 摄入期数码管末位=0 且黑屏（**有信号的黑屏，不是"无信号"**），几秒后显示 PIC1，**图像正立不倒** | 倒立 → loader 的 `V_FLIP`；无信号 → pipeline 的 `de_in` 又被门控了 |
| 3 | 按 KEY1 | PIC2→3→4→1，**切换瞬间无加载延迟** | 有延迟 → loader 被误触发重载 |
| 4 | 快速连按 KEY1 | 画面无横向撕裂 | 撕裂 → `index_commit` 没落在 `frame_start` |
| 5 | 短按 KEY2 | 自动轮播 3s 一张；再短按停 | 周期不对 → `DEFAULT_PERIOD_CYCLES` |
| 6 | 长按 KEY2 ≥1s | 上一张 | → `prev_available()` |
| 7 | 拿掉 PIC2.BMP 重新上电 | 只在 1/3/4 之间轮转，不显示 bank1 垃圾 | → loader 的 `image_complete` 与 `init_event` |
| 8 | 塞一张残缺 BMP | 数码管出 `0x45`/`0x44`，系统不卡死、其余图正常显示 | → `decode_error` 接线与 `0x39` 那条 abort 路径 |
| 9 | 长时间显示纯白图 | 无雪花噪点 | → `SD/sdram.v` 的 `REFRESH_INTERVAL_CYCLES` |
| 10 | HDMI 音频 | 随图切换的旋律正常，无爆音 | → `pcm_media_tone.media_id` |

有 SignalTap/Debug Core 时额外抓：`App_wr_en` 应为连续 128 拍的 burst（不是单字）、
`App_rd_en` 同理、`reader_underflow` 恒 0、`wr_cdc_overflow` 恒 0。
