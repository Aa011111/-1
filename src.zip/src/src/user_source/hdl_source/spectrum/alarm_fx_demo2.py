# -*- coding: utf-8 -*-
"""
火灾图（PIC12 / PIC13）音频可视化 —— 第二批候选方案演示

和 alarm_fx_demo.py 一样：分析器用 spectrum_model.Analyzer（逐位和 RTL 一致），
画法按硬件思路（整数、移位加法、xorshift 噪声、无帧缓存）。只是演示。

  E_ember  余烬火星：火星从底部往上飘，哪一列频带响，哪一列火星就多、飘得高
  F_wave   冲击波纹：声音起音时从图标中心扩散出一圈圈波纹，越响越粗越亮
  G_line   声纹包络：底部一条上下镜像的发光声纹线，低频在中间
  H_scan   扫描光带：一条光带从上往下扫，拖尾长度逐列 = 该列频带柱高
  K_heat   热浪扭曲：画面像隔着热空气一样水平抖动，越往下、越响抖得越厉害

用法：python alarm_fx_demo2.py [起始秒] [帧数] [方案,逗号分隔] [12,13] [TF目录]
      输出到 preview/alarm_fx2/；两张图都出时另拼一张 sheet.png
"""
import os
import sys
from math import isqrt

from PIL import Image

import spectrum_model as sm
from alarm_fx_demo import xs16, blend_q, blend_16, bar_interp, fire_color, Siren, tri

W, H = sm.SCR_W, sm.SCR_H
N = sm.N_BANDS


def col_band(x):
    """列 → 频带插值高度所需的 (k0, k1, frac)，中间低频、两边高频（同 A_bottom）"""
    u = x - 320 if x >= 320 else 319 - x
    pos = u * 7                                             # u*35/320 ≈ u*7/64
    k0 = pos >> 6
    k1 = k0 + 1 if k0 + 1 < N else k0
    return k0, k1, (pos >> 2) & 15


def col_heights(bars):
    """每列一个插值柱高 0..40。RTL 里随 pixel_x 流水算，不用存"""
    return [bar_interp(bars, *col_band(x)) for x in range(W)]


# ----------------------------------------------------------------------------
# E：余烬火星
# ----------------------------------------------------------------------------
EMBER_LAYERS = ((3, 8, 3), (2, 4, 2))      # (cell 位宽, 上升速度 px/帧, 概率权重)


def render_embers(bg, bars, env, f):
    out = list(bg)
    ch = col_heights(bars)
    # 底部一条暗红余温，亮度随音量
    glow_h = 24
    for y in range(H - glow_h, H):
        a = ((y - (H - glow_h)) * (64 + (env >> 1))) >> 9          # 0..~8
        for x in range(W):
            i = y * W + x
            out[i] = blend_16(out[i], (200, 40, 0), a)
    for sh, speed, wgt in EMBER_LAYERS:
        cell = 1 << sh
        m = cell - 1
        for y in range(H - 8, 40, -1):
            life = H - 1 - y                                         # 离底部距离
            vy = y + f * speed
            cy = vy >> sh
            fy = vy & m
            sway = (tri(((y >> 2) + f) % 40) >> 6) - 2              # -2..1 左右摆
            for x in range(W):
                xx = x + sway
                cx = xx >> sh
                hgt = ch[x]
                h = xs16(cx, cy)
                h = xs16(h & 0x1FF, (h >> 9) ^ cy)                   # 两轮 xorshift，去掉竖向相关
                if life > 60 + hgt * 9 - ((h >> 4) & 63):            # 越响飘得越高，顶边参差
                    continue
                if (h & 0xFF) >= hgt * wgt + 3:                       # 越响越密
                    continue
                px = (h >> 8) & m
                py = (h >> 12) & m
                dx = (xx & m) - px
                dy = fy - py
                big = 2 if sh == 3 else 1                            # 大火星 3x3，小火星 2x2
                if dx < 0 or dy < 0 or dx > big or dy > big:
                    continue
                heat = 255 - (life >> 1) - (h >> 13)                 # 下白上红，略带随机
                if heat < 40:
                    heat = 40
                i = y * W + x
                out[i] = blend_q(out[i], fire_color(heat), 4 if sh == 3 else 3)
    return out


# ----------------------------------------------------------------------------
# F：冲击波纹
# ----------------------------------------------------------------------------
class Waves:
    """4 个波纹槽。起音检测：本帧电平比慢包络高出一截且冷却已过 → 发射一圈。
    RTL：4 组 (r,str) 寄存器 + 一个比较器"""

    def __init__(self):
        self.slow = 0
        self.cool = 0
        self.idle = 0
        self.rings = []

    def frame(self, bars):
        lvl = min(240, sum(bars) * 7 >> 5)
        fire = lvl > self.slow + 24 and self.cool == 0
        self.slow += (lvl - self.slow) >> 3
        self.cool = max(0, self.cool - 1)
        self.idle += 1
        if fire or self.idle > 45:                                   # 没起音也每 0.75s 发一圈
            if len(self.rings) == 4:
                self.rings.pop(0)
            self.rings.append([0, 96 + (lvl >> 1)])                  # 强度 96..216
            self.cool, self.idle = 8, 0
        for r in self.rings:
            r[0] += 7
        self.rings = [r for r in self.rings if r[1] - (r[0] >> 2) > 0]


def render_waves(bg, rings, center, color):
    if not rings:
        return bg
    out = list(bg)
    cx, cy = center
    for y in range(H):
        b = abs(y - cy)
        for x in range(W):
            a_ = abs(x - cx)
            d = isqrt(a_ * a_ + b * b)          # RTL：d² 两个 DSP，和每圈预算好的几个 r² 门限比较
            acc = 0
            for r, s in rings:
                s = s - (r >> 2)                                     # 越扩越淡
                w = 4 + (s >> 5)                                     # 越响越粗
                e = r - d
                if 0 <= e < w * 3:                                   # 外沿亮，向内拖尾
                    acc += (s * (w * 3 - e)) // (w * 3) if e >= 2 else s
            if acc:
                a = acc >> 4
                i = y * W + x
                out[i] = blend_16(bg[i], color, 16 if a > 16 else a)
    return out


# ----------------------------------------------------------------------------
# G：声纹包络线
# ----------------------------------------------------------------------------
LINE_Y = 400                     # 中线，避开文字区（<330）和字幕 OSD（440~463）
LINE_GLOW = (16, 11, 6, 3, 1)


def render_line(bg, bars, glow_col):
    out = list(bg)
    ch = col_heights(bars)
    for x in range(W):
        h = ch[x] - (ch[x] >> 3)                                     # 0..35
        top, bot = LINE_Y - h, LINE_Y + h
        for y in range(LINE_Y - 44, LINE_Y + 45):
            i = y * W + x
            dt, db = abs(y - top), abs(y - bot)
            d = dt if dt < db else db
            if d < len(LINE_GLOW):
                a = LINE_GLOW[d]
                out[i] = (255, 255, 230) if d == 0 else blend_16(bg[i], glow_col, a)
            elif top < y < bot:
                out[i] = blend_16(bg[i], glow_col, 3)                # 包络内淡淡填充
    return out


# ----------------------------------------------------------------------------
# H：扫描光带
# ----------------------------------------------------------------------------
SCAN_STEP = 5                     # px/帧，约 1.7s 扫一遍


def render_scan(bg, bars, env, f, color):
    out = list(bg)
    ch = col_heights(bars)
    period = H + 160
    ys = (f * SCAN_STEP) % period - 40                               # 光带前沿
    gain = 160 + (env >> 1) if env < 190 else 255
    for x in range(W):
        trail = 12 + ch[x] * 3                                       # 拖尾 12..132，逐列随频带
        for y in range(max(0, ys - trail), min(H, ys + 3)):
            d = ys - y
            if d < 0:
                a = 16                                               # 前沿 3px 实线
            else:
                a = ((trail - d) * gain) // (trail << 4)             # 0..15 线性衰减
            i = y * W + x
            out[i] = blend_16(bg[i], color, a)
    return out


# ----------------------------------------------------------------------------
# K：热浪扭曲
# ----------------------------------------------------------------------------
def render_heat(bg, env, f):
    """每行一个水平偏移，偶数像素对齐（RGB565 两像素一字，RTL 改 SDRAM 行读起始地址即可）"""
    out = list(bg)
    gain = 64 + env                                                  # 64..304
    for y in range(H):
        w = (y - 224) >> 4 if y >= 224 else 0                        # 只扭下半屏，文字区不动，0..15
        wave = tri(((y >> 1) + f * 2) % 40) + (tri(((y >> 2) + f * 3 + 13) % 40) >> 1) - 180
        off = (wave * w * gain) >> 16                                # 约 ±7（正常音量），最大 ±11
        off &= ~1
        row = y * W
        for x in range(W):
            sx = x + off
            if sx < 0:
                sx = 0
            elif sx >= W:
                sx = W - 1
            out[row + x] = bg[row + sx]
        if w >= 10:                                                  # 最下面一段加一点暖色
            a = ((w - 9) * gain) >> 8
            for x in range(W):
                out[row + x] = blend_16(out[row + x], (255, 90, 0), a)
    return out


# ----------------------------------------------------------------------------
def run(pic, wav, t0, n_frames, cfg, outdir, names):
    tag = os.path.splitext(os.path.basename(pic))[0].lower()
    an = sm.Analyzer()
    pcm = sm.load_wav(wav)
    bg = sm.load_bg(pic)
    siren = Siren()
    waves = Waves()

    start = max(0, int((t0 - 1.5) * sm.FS))
    first = int(t0 * sm.FS)
    pos, acc, f = start, 0.0, 0
    frames = {k: [] for k in names}
    while f < n_frames and pos < len(pcm):
        acc += sm.FRAME_SAMPLES
        n = int(acc)
        acc -= n
        for j, s in enumerate(pcm[pos:pos + n]):
            an.sample(s, frame_pass=(j == 0))
        pos += n
        siren.frame(an.bar)
        waves.frame(an.bar)
        if pos < first:
            continue
        f += 1
        if f % 2:                                                    # 隔帧出图，GIF 33ms ≈ 实时
            continue
        fx = {
            'E_ember': lambda: render_embers(bg, an.bar, siren.env, f),
            'F_wave': lambda: render_waves(bg, waves.rings, cfg['center'], cfg['color']),
            'G_line': lambda: render_line(bg, an.bar, cfg['glow']),
            'H_scan': lambda: render_scan(bg, an.bar, siren.env, f, cfg['color']),
            'K_heat': lambda: render_heat(bg, siren.env, f),
        }
        for k in names:
            im = Image.new('RGB', (W, H))
            im.putdata(fx[k]())
            frames[k].append(im)
        print('%s frame %d/%d' % (tag, f, n_frames), flush=True)

    stills = {}
    for k, fr in frames.items():
        fr[0].save(os.path.join(outdir, '%s_%s.gif' % (tag, k)), save_all=True,
                   append_images=fr[1:], duration=33, loop=0)
        stills[k] = fr[len(fr) // 2]
    return stills


ALL = ['E_ember', 'F_wave', 'G_line', 'H_scan', 'K_heat']

# 颜色要和底图反差：PIC12 底是黄橙 → 红；PIC13 底是红 → 白黄
# 波纹中心：PIC12 从警告三角发出，PIC13 从屏幕中心发出
CFG = {
    '12': {'color': (230, 0, 18), 'glow': (200, 0, 0), 'center': (150, 180)},
    '13': {'color': (255, 235, 140), 'glow': (255, 210, 40), 'center': (320, 240)},
}


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    t0 = float(sys.argv[1]) if len(sys.argv) > 1 else 4.0
    n_frames = int(sys.argv[2]) if len(sys.argv) > 2 else 120
    names = sys.argv[3].split(',') if len(sys.argv) > 3 else ALL
    pics = sys.argv[4].split(',') if len(sys.argv) > 4 else ['12', '13']
    tf = sys.argv[5] if len(sys.argv) > 5 else \
        os.path.normpath(os.path.join(here, '..', '..', '..', '..', '..', 'TF卡文件'))
    outdir = os.path.join(here, 'preview', 'alarm_fx2')
    os.makedirs(outdir, exist_ok=True)

    stills = {}
    for n in pics:
        st = run(os.path.join(tf, 'PIC%s.BMP' % n), os.path.join(tf, 'MUSIC%s.WAV' % n), t0, n_frames,
                 CFG[n], outdir, names)
        for k, im in st.items():
            im.save(os.path.join(outdir, 'pic%s_%s.png' % (n, k)))
        stills[n] = st

    if len(pics) > 1:
        sw, sh = W // 2, H // 2
        sheet = Image.new('RGB', (sw * len(names), sh * len(pics)), (0, 0, 0))
        for r, n in enumerate(pics):
            for c, k in enumerate(names):
                sheet.paste(stills[n][k].resize((sw, sh)), (c * sw, r * sh))
        sheet.save(os.path.join(outdir, 'sheet.png'))
    print('saved to', outdir)


if __name__ == '__main__':
    main()
