/************************************************************\
 **     Copyright (c) 2012-2024 Anlogic Inc.
 **  All Right Reserved.\
\************************************************************/
`timescale 1 ns / 100 fs

///////////////////////////////////////////////////////////////////////////////
//  单 PLL 五路输出，替代原来的 sys_pll + video_pll + PLL_HDMI_AUDIO 三 PLL 架构。
//  频率与三 PLL 方案逐路完全相同，SDRAM(125MHz) / 像素(25MHz) / TMDS(125MHz)
//  的时序假设全部不变。
//
//  Input frequency: 50.000000MHz   REFCLK_DIV=1  FBCLK_DIV=2  VCO=1000MHz
//      Clock name | Frequency   | Phase | 用途
//      C0         | 100.000MHz  |   0   | sd_card_clk     （反馈时钟）
//      C1         | 125.000MHz  |   0   | ext_mem_clk     （SDRAM 控制器）
//      C2         | 125.000MHz  | 180   | ext_mem_clk_sft （SDRAM 采样移相）
//      C3         |  25.000MHz  |   0   | video_clk       （640x480@60 像素）
//      C4         | 125.000MHz  |   0   | hdmi_5x_clk     （TMDS 5 倍频串行）
//
//  合并可行性：原 sys_pll 与 video_pll 的 VCO 同为 1000MHz，所以两者的
//  CLKCn_DIV / CPHASE 可以原样搬移到本文件——C0/C1/C2 取自 sys_pll，
//  C3/C4 取自 video_pll 的 C0/C1。模拟环路参数沿用 sys_pll 的一组，
//  因为本 PLL 的 PFD 参考频率(50MHz，REFCLK_DIV=1)与 sys_pll 一致；
//  video_pll 那组是按 25MHz 参考频率调的，不适用。
//
//  BUFG 拓扑（不要随意改动，两处都是为了保持成对时钟的延迟匹配）：
//    - C1/C2 都不加 BUFG：这对是 SDRAM 的 Clk / Clk_sft，180° 相位差是数据
//      采样窗口的硬性要求，与三 PLL 方案逐字一致（原来两路也都没有 BUFG）。
//    - C3/C4 都加 BUFG：这对是像素时钟与它的 5 倍频，后者进 4 个
//      lane_lvds_10_1 的 ODDR 做 10:1 串行化。反馈把 BUFG 后节点对齐到
//      refclk，所以裸 clkc 输出统一在 -t_BUFG 平面，两路同加 BUFG 后相对
//      偏斜为 0。原 video_pll 里 C0 的 BUFG 在反馈环内被补偿而 C1 无 BUFG，
//      本方案改为都加，相对关系比原来更干净。
///////////////////////////////////////////////////////////////////////////////

module sys_pll_single (
        refclk,
        reset,
        clk0_out,
        clk1_out,
        clk2_out,
        clk3_out,
        clk4_out,
        locked
    );

    input refclk;
    input reset;
    output clk0_out;
    output clk1_out;
    output clk2_out;
    output clk3_out;
    output clk4_out;
    output locked;

    wire clk0_buf;
    wire clk3_buf;
    wire clk4_buf;

    EG_LOGIC_BUFG bufg_feedback (
                      .i(clk0_buf),
                      .o(clk0_out)
                  );

    EG_LOGIC_BUFG bufg_pixel (
                      .i(clk3_buf),
                      .o(clk3_out)
                  );

    EG_LOGIC_BUFG bufg_serial (
                      .i(clk4_buf),
                      .o(clk4_out)
                  );

    EG_PHY_PLL #(
                   .DPHASE_SOURCE("DISABLE"),
                   .DYNCFG("DISABLE"),
                   .FIN("50.000000"),
                   .FEEDBK_MODE("NORMAL"),
                   .FEEDBK_PATH("CLKC0_EXT"),
                   .STDBY_ENABLE("DISABLE"),
                   .PLLRST_ENA("ENABLE"),
                   .SYNC_ENABLE("DISABLE"),
                   .GMC_GAIN(4),
                   .ICP_CURRENT(29),
                   .KVCO(4),
                   .LPF_CAPACITOR(1),
                   .LPF_RESISTOR(2),
                   .REFCLK_DIV(1),
                   .FBCLK_DIV(2),
                   .CLKC0_ENABLE("ENABLE"),
                   .CLKC0_DIV(10),
                   .CLKC0_CPHASE(9),
                   .CLKC0_FPHASE(0),
                   .CLKC1_ENABLE("ENABLE"),
                   .CLKC1_DIV(8),
                   .CLKC1_CPHASE(7),
                   .CLKC1_FPHASE(0),
                   .CLKC2_ENABLE("ENABLE"),
                   .CLKC2_DIV(8),
                   .CLKC2_CPHASE(3),
                   .CLKC2_FPHASE(0),
                   .CLKC3_ENABLE("ENABLE"),
                   .CLKC3_DIV(40),
                   .CLKC3_CPHASE(39),
                   .CLKC3_FPHASE(0),
                   .CLKC4_ENABLE("ENABLE"),
                   .CLKC4_DIV(8),
                   .CLKC4_CPHASE(7),
                   .CLKC4_FPHASE(0)
               ) pll_inst (
                   .refclk(refclk),
                   .reset(reset),
                   .stdby(1'b0),
                   .extlock(locked),
                   .load_reg(1'b0),
                   .psclk(1'b0),
                   .psdown(1'b0),
                   .psstep(1'b0),
                   .psclksel(3'b000),
                   .psdone(open),
                   .dclk(1'b0),
                   .dcs(1'b0),
                   .dwe(1'b0),
                   .di(8'b00000000),
                   .daddr(6'b000000),
                   .do({open, open, open, open, open, open, open, open}),
                   .fbclk(clk0_out),
                   .clkc({clk4_buf, clk3_buf, clk2_out, clk1_out, clk0_buf})
               );

endmodule
