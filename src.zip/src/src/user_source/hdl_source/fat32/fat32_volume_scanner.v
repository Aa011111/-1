`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 13 张图扩展（默认 IMAGE_COUNT=4 时识别范围与改造前相同）：
//  - 图片 PIC1~PICn.BMP、音乐 MUSIC1~MUSICn.WAV，n = IMAGE_COUNT（最多 19）。
//    两位数的 8.3 短名是 "PIC10   BMP" / "MUSIC10 WAV"，序号字段多占一位、
//    后面少一个空格；一位数和两位数两种写法都认。
//  - resourceN_cluster/size 四组端口合并成打包总线 resource_cluster/resource_size
//    （第 i 张在 [i*32 +: 32]），音乐同理。
//  - 音乐起始扇区不再在 ST_FINISH 里 N 路并行换算（13 路 32 位加法+移位太占
//    LUT），改成读到目录项第 28 字节时用一套加法器算好，第 31 字节随有效判定
//    一起落进 track_start_lba；扇区数 = 文件大小 >> 9 只是连线。
// -----------------------------------------------------------------------------

module fat32_volume_scanner #(
    parameter integer IMAGE_COUNT = 4,
    parameter integer INDEX_W = 2
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        scan_start,
    output wire        scan_busy,
    output reg         scan_done,
    output reg  [7:0]  fs_error,
    output reg  [31:0] partition_lba,
    output reg  [7:0]  sectors_per_cluster,
    output reg  [31:0] fat_start_lba,
    output reg  [31:0] data_start_lba,
    output reg  [31:0] max_cluster,
    output reg  [IMAGE_COUNT-1:0]    resource_valid,
    output reg  [IMAGE_COUNT*32-1:0] resource_cluster,
    output reg  [IMAGE_COUNT*32-1:0] resource_size,
    output reg         sector_req,
    output reg  [31:0] sector_lba,
    input  wire        sector_busy,
    input  wire        sector_valid,
    input  wire [7:0]  sector_byte,
    input  wire [8:0]  sector_byte_index,
    input  wire        sector_done,
    input  wire [7:0]  sector_error,
    // 一图一音：根目录里的 MUSIC1~n.WAV（8.3 名 "MUSICn  WAV"）分别对应
    // PIC1~n.BMP。（第十一讲的单个 MUSIC.WAV 已被它取代，不再识别。）
    // 只取首簇换算出的起始扇区，不跟 FAT 链——要求文件在卡上连续存放
    // （新格式化的卡上直接拷进去的文件都是连续的）。
    // track_sectors 取整扇区数（向下取整），不播文件末尾不满一扇区的残余，
    // 避免把簇尾的旧数据当声音播出来。
    // 打包顺序 {n-1,...,1,0}，每路 32 位。
    output reg  [IMAGE_COUNT-1:0]    track_valid,
    output reg  [IMAGE_COUNT*32-1:0] track_start_lba,
    output reg  [IMAGE_COUNT*32-1:0] track_sectors,
    // 调试用：整个根目录簇范围内，找"跟PICx.BMP模式匹配得最深的那一项"，
    // [7:4]=匹配深度(0=首字符就不是P/p，1~7=依次卡在I/C/序号/空格/B/M/扩展名P，
    //        8=文件名11字节全部匹配，只差属性字节判断)；
    // [3:0]=那一项的属性字节 attr[4:1]
    output reg  [7:0]  diag2_code
);

    localparam ERR_NONE            = 8'h00;
    localparam ERR_SECTOR          = 8'h10;
    localparam ERR_BOOT_SIGNATURE  = 8'h20;
    localparam ERR_UNSUPPORTED_BPB = 8'h21;
    localparam ERR_RESOURCE_MISSING= 8'h22;

    localparam ST_IDLE       = 4'd0;
    localparam ST_READ0_REQ  = 4'd1;
    localparam ST_READ0_WAIT = 4'd2;
    localparam ST_BOOT_PARSE = 4'd3;
    localparam ST_BOOT_REQ   = 4'd4;
    localparam ST_BOOT_WAIT  = 4'd5;
    localparam ST_ROOT_REQ   = 4'd6;
    localparam ST_ROOT_WAIT  = 4'd7;
    localparam ST_DIR_SCAN   = 4'd8;
    localparam ST_FINISH     = 4'd9;
    localparam ST_BOOT_LAYOUT= 4'd10;
    localparam ST_BOOT_ROOT  = 4'd11;

    reg [3:0] state;
    reg [7:0] sector_buffer [0:511];
    reg [4:0] directory_entry_index;
    reg [31:0] root_cluster;
    reg [31:0] total_sectors;
    reg [31:0] fat_sectors;
    reg [7:0] fat_count;
    reg [15:0] reserved_sectors;
    reg [31:0] root_lba;
    reg [7:0]  root_sector_idx;   // 根目录所在簇内，当前扫到第几个扇区（0~sectors_per_cluster-1）
    reg [31:0] data_sector_count;
    reg [31:0] fat_span;
    reg [2:0] sectors_per_cluster_shift;
    reg [7:0] dir_name0;
    reg [7:0] dir_name1;
    reg [7:0] dir_name2;
    reg [7:0] dir_name3;
    reg [7:0] dir_name4;
    reg [7:0] dir_name5;
    reg [7:0] dir_name6;
    reg [7:0] dir_name7;
    reg [7:0] dir_name8;
    reg [7:0] dir_name9;
    reg [7:0] dir_name10;
    reg       dir_entry_match;
    reg [INDEX_W-1:0] dir_resource_index;
    reg [15:0] dir_cluster_high;
    reg [15:0] dir_cluster_low;
    reg [31:0] dir_file_size;
    reg [3:0]  dbg_best_depth;   // 整簇范围内累积的最深匹配（不是单扇区，跨sector保留）
    reg        track_entry_match;
    reg [INDEX_W-1:0] track_entry_index;
    reg [31:0] dir_track_lba;    // 本目录项首簇换算出的起始扇区（第 28 字节算好）

    assign scan_busy = (state != ST_IDLE);

    // 调试：算这一项跟"PICx.BMP"模式匹配到第几步就断了（大小写不敏感），
    // 用于判断是"完全没有这类条目"还是"有条目但卡在某个具体字段"
    function [3:0] match_depth;
        input [7:0] n0, n1, n2, n3, n4, n5, n6, n7, n8, n9, n10;
        begin
            if ((n0 & 8'hDF) != "P")
                match_depth = 4'd0;
            else if ((n1 & 8'hDF) != "I")
                match_depth = 4'd1;
            else if ((n2 & 8'hDF) != "C")
                match_depth = 4'd2;
            else if (!name_ok(n3, n4, n5, n6, n7))
                match_depth = (n3 >= "1" && n3 <= "9") ? 4'd4 : 4'd3;
            else if ((n8 & 8'hDF) != "B")
                match_depth = 4'd5;
            else if ((n9 & 8'hDF) != "M")
                match_depth = 4'd6;
            else if ((n10 & 8'hDF) != "P")
                match_depth = 4'd7;
            else
                match_depth = 4'd8;
        end
    endfunction

    // 序号字段解析："d    "（1~9）或 "1d   "（10~19），d 为数字，后面全是空格。
    // 返回 {有效, 序号-1}；序号超过 IMAGE_COUNT 也算无效。
    // 图片名从第 3 个字符开始（PIC|n），音乐名从第 5 个字符开始（MUSIC|n），
    // 后者只剩 3 个字符位，第 4、5 个参数传空格。
    function [5:0] name_num;
        input [7:0] c0, c1, c2, c3, c4;
        reg [4:0] num;
        begin
            num = 5'd0;
            if (c0 >= "1" && c0 <= "9" && c1 == " " && c2 == " " && c3 == " " && c4 == " ")
                num = c0 - "0";
            else if (c0 == "1" && c1 >= "0" && c1 <= "9" && c2 == " " && c3 == " " && c4 == " ")
                num = 5'd10 + (c1 - "0");
            if (num != 0 && num <= IMAGE_COUNT)
                name_num = {1'b1, num - 5'd1};
            else
                name_num = 6'd0;
        end
    endfunction

    function name_ok;
        input [7:0] c0, c1, c2, c3, c4;
        reg [5:0] r;
        begin
            r = name_num(c0, c1, c2, c3, c4);
            name_ok = r[5];
        end
    endfunction

    wire [5:0] pic_num   = name_num(dir_name3, dir_name4, dir_name5, dir_name6, dir_name7);
    wire [5:0] music_num = name_num(dir_name5, dir_name6, dir_name7, " ", " ");

    function [15:0] le16;
        input integer offset;
        begin
            le16 = {sector_buffer[offset+1], sector_buffer[offset]};
        end
    endfunction

    function [31:0] le32;
        input integer offset;
        begin
            le32 = {sector_buffer[offset+3], sector_buffer[offset+2],
                    sector_buffer[offset+1], sector_buffer[offset]};
        end
    endfunction

    function valid_spc;
        input [7:0] value;
        begin
            valid_spc = value != 0 && ((value & (value - 1'b1)) == 0);
        end
    endfunction

    function [2:0] spc_shift;
        input [7:0] value;
        begin
            case (value)
                8'd2:   spc_shift = 3'd1;
                8'd4:   spc_shift = 3'd2;
                8'd8:   spc_shift = 3'd3;
                8'd16:  spc_shift = 3'd4;
                8'd32:  spc_shift = 3'd5;
                8'd64:  spc_shift = 3'd6;
                8'd128: spc_shift = 3'd7;
                default: spc_shift = 3'd0;
            endcase
        end
    endfunction

    task finish_with_error;
        input [7:0] code;
        begin
            fs_error <= code;
            state <= ST_FINISH;
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state <= ST_IDLE;
            scan_done <= 1'b0;
            fs_error <= ERR_NONE;
            partition_lba <= 32'd0;
            sectors_per_cluster <= 8'd0;
            fat_start_lba <= 32'd0;
            data_start_lba <= 32'd0;
            max_cluster <= 32'd0;
            resource_valid <= {IMAGE_COUNT{1'b0}};
            diag2_code <= 8'd0;
            dbg_best_depth <= 4'd0;
            resource_cluster <= {(IMAGE_COUNT*32){1'b0}};
            resource_size <= {(IMAGE_COUNT*32){1'b0}};
            sector_req <= 1'b0;
            sector_lba <= 32'd0;
            directory_entry_index <= 5'd0;
            root_cluster <= 32'd0;
            total_sectors <= 32'd0;
            fat_sectors <= 32'd0;
            fat_count <= 8'd0;
            reserved_sectors <= 16'd0;
            root_lba <= 32'd0;
            root_sector_idx <= 8'd0;
            data_sector_count <= 32'd0;
            fat_span <= 32'd0;
            sectors_per_cluster_shift <= 3'd0;
            dir_name0 <= 8'd0;
            dir_name1 <= 8'd0;
            dir_name2 <= 8'd0;
            dir_name3 <= 8'd0;
            dir_name4 <= 8'd0;
            dir_name5 <= 8'd0;
            dir_name6 <= 8'd0;
            dir_name7 <= 8'd0;
            dir_name8 <= 8'd0;
            dir_name9 <= 8'd0;
            dir_name10 <= 8'd0;
            dir_entry_match <= 1'b0;
            dir_resource_index <= {INDEX_W{1'b0}};
            dir_cluster_high <= 16'd0;
            dir_cluster_low <= 16'd0;
            dir_file_size <= 32'd0;
            track_entry_match <= 1'b0;
            track_entry_index <= {INDEX_W{1'b0}};
            dir_track_lba <= 32'd0;
            track_valid <= {IMAGE_COUNT{1'b0}};
            track_start_lba <= {(IMAGE_COUNT*32){1'b0}};
            track_sectors <= {(IMAGE_COUNT*32){1'b0}};
        end else begin
            scan_done <= 1'b0;
            sector_req <= 1'b0;
            if (sector_valid && state != ST_ROOT_WAIT)
                sector_buffer[sector_byte_index] <= sector_byte;

            if (sector_valid && state == ST_ROOT_WAIT) begin
                case (sector_byte_index[4:0])
                    5'd0: begin
                        dir_name0 <= sector_byte;
                        dir_entry_match <= 1'b0;
                        track_entry_match <= 1'b0;
                    end
                    5'd1:  dir_name1 <= sector_byte;
                    5'd2:  dir_name2 <= sector_byte;
                    5'd3:  dir_name3 <= sector_byte;
                    5'd4:  dir_name4 <= sector_byte;
                    5'd5:  dir_name5 <= sector_byte;
                    5'd6:  dir_name6 <= sector_byte;
                    5'd7:  dir_name7 <= sector_byte;
                    5'd8:  dir_name8 <= sector_byte;
                    5'd9:  dir_name9 <= sector_byte;
                    5'd10: dir_name10 <= sector_byte;
                    // 字母比较大小写不敏感：Windows一般把8.3短文件名字段存成大写，
                    // 但不是所有工具都遵循这个惯例（比如某些相机/非Windows系统/
                    // 拷卡软件会把小写字母原样写进短文件名字段），严格大写比较会
                    // 导致这类卡上的文件名一个都匹配不上。用 & 8'hDF 清掉字母的
                    // bit5（ASCII里小写转大写正好是清这一位，数字/空格没有这个位
                    // 也不受影响）把两种大小写都折算成大写再比较。
                    // 注意：sector_byte在这里是偏移11的属性字节，不是文件名字符，
                    // 不能做大小写折算；扩展名第3个字符"P"是dir_name10。
                    // 属性字节原来要求精确等于0x20（只有ARCHIVE位），但不是所有
                    // 工具/相机/非Windows系统写文件时都会置这个位——很多写出来是
                    // 0x00（什么标记都没有）。真正该拒绝的只是子目录(0x10)、
                    // 卷标(0x08)、长文件名条目(0x0F，其中就含0x08位)，其余
                    // 只读/隐藏/系统/存档的任意组合都应该当普通文件接受。
                    5'd11: begin
                        if ((sector_byte & 8'h18) == 8'h00 &&
                            (dir_name0 & 8'hDF) == "P" && (dir_name1 & 8'hDF) == "I" &&
                            (dir_name2 & 8'hDF) == "C" && pic_num[5] &&
                            (dir_name8 & 8'hDF) == "B" &&
                            (dir_name9 & 8'hDF) == "M" && (dir_name10 & 8'hDF) == "P") begin
                            dir_entry_match <= 1'b1;
                            dir_resource_index <= pic_num[INDEX_W-1:0];
                        end

                        // 一图一音：MUSIC1~n.WAV，第 6 个字符起是序号，
                        // 同样大小写不敏感、同样的属性过滤
                        if ((sector_byte & 8'h18) == 8'h00 &&
                            (dir_name0 & 8'hDF) == "M" && (dir_name1 & 8'hDF) == "U" &&
                            (dir_name2 & 8'hDF) == "S" && (dir_name3 & 8'hDF) == "I" &&
                            (dir_name4 & 8'hDF) == "C" && music_num[5] &&
                            (dir_name8 & 8'hDF) == "W" && (dir_name9 & 8'hDF) == "A" &&
                            (dir_name10 & 8'hDF) == "V") begin
                            track_entry_match <= 1'b1;
                            track_entry_index <= music_num[INDEX_W-1:0];
                        end

                        // 调试：整簇范围内累积"匹配得最深的条目"，不按扇区重置，
                        // 只在整个目录扫描开始时清零一次（见ST_ROOT_REQ）
                        if (match_depth(dir_name0, dir_name1, dir_name2, dir_name3,
                                         dir_name4, dir_name5, dir_name6, dir_name7,
                                         dir_name8, dir_name9, dir_name10) > dbg_best_depth) begin
                            dbg_best_depth <= match_depth(dir_name0, dir_name1, dir_name2, dir_name3,
                                                           dir_name4, dir_name5, dir_name6, dir_name7,
                                                           dir_name8, dir_name9, dir_name10);
                            diag2_code     <= {match_depth(dir_name0, dir_name1, dir_name2, dir_name3,
                                                            dir_name4, dir_name5, dir_name6, dir_name7,
                                                            dir_name8, dir_name9, dir_name10),
                                                sector_byte[4:1]};
                        end
                    end
                    5'd20: dir_cluster_high[7:0] <= sector_byte;
                    5'd21: dir_cluster_high[15:8] <= sector_byte;
                    5'd26: dir_cluster_low[7:0] <= sector_byte;
                    5'd27: dir_cluster_low[15:8] <= sector_byte;
                    5'd28: begin
                        dir_file_size[7:0] <= sector_byte;
                        // 首簇四个字节（20/21/26/27）此时都已到齐；簇号 <2 的项
                        // 在第 31 字节会被判无效，这里算出来的值用不上，不用管
                        dir_track_lba <= data_start_lba +
                            (({dir_cluster_high, dir_cluster_low} - 32'd2) << sectors_per_cluster_shift);
                    end
                    5'd29: dir_file_size[15:8] <= sector_byte;
                    5'd30: dir_file_size[23:16] <= sector_byte;
                    5'd31: begin
                        dir_file_size[31:24] <= sector_byte;
                        if (dir_entry_match) begin
                            resource_cluster[dir_resource_index*32 +: 32] <= {dir_cluster_high, dir_cluster_low};
                            resource_size[dir_resource_index*32 +: 32]    <= {sector_byte, dir_file_size[23:0]};
                            resource_valid[dir_resource_index]            <= 1'b1;
                        end
                        // 至少一整扇区、首簇合法才算有效音频文件；
                        // 扇区数 = 大小 >> 9（向下取整，不播末尾不满一扇区的残余）
                        if (track_entry_match && {dir_cluster_high, dir_cluster_low} >= 32'd2 &&
                            {sector_byte, dir_file_size[23:0]} >= 32'd512) begin
                            track_start_lba[track_entry_index*32 +: 32] <= dir_track_lba;
                            track_sectors[track_entry_index*32 +: 32]   <= {9'd0, sector_byte, dir_file_size[23:9]};
                            track_valid[track_entry_index]              <= 1'b1;
                        end
                    end
                    default: begin end
                endcase
            end

            case (state)
                ST_IDLE: if (scan_start) begin
                    fs_error <= ERR_NONE;
                    partition_lba <= 32'd0;
                    resource_valid <= {IMAGE_COUNT{1'b0}};
                    track_valid <= {IMAGE_COUNT{1'b0}};
                    state <= ST_READ0_REQ;
                end
                ST_READ0_REQ: if (!sector_busy) begin
                    sector_lba <= 32'd0;
                    sector_req <= 1'b1;
                    state <= ST_READ0_WAIT;
                end
                ST_READ0_WAIT: if (sector_done) begin
                    if (sector_error != 0)
                        finish_with_error(ERR_SECTOR);
                    else if (sector_buffer[510] != 8'h55 || sector_buffer[511] != 8'haa)
                        finish_with_error(ERR_BOOT_SIGNATURE);
                    else if (sector_buffer[0] == 8'heb || sector_buffer[0] == 8'he9) begin
                        partition_lba <= 32'd0;
                        state <= ST_BOOT_PARSE;
                    end else if (sector_buffer[450] == 8'h0b || sector_buffer[450] == 8'h0c) begin
                        partition_lba <= le32(454);
                        sector_lba <= le32(454);
                        state <= ST_BOOT_REQ;
                    end else begin
                        finish_with_error(ERR_UNSUPPORTED_BPB);
                    end
                end
                ST_BOOT_REQ: if (!sector_busy) begin
                    sector_req <= 1'b1;
                    state <= ST_BOOT_WAIT;
                end
                ST_BOOT_WAIT: if (sector_done) begin
                    if (sector_error != 0)
                        finish_with_error(ERR_SECTOR);
                    else if (sector_buffer[510] != 8'h55 || sector_buffer[511] != 8'haa)
                        finish_with_error(ERR_BOOT_SIGNATURE);
                    else
                        state <= ST_BOOT_PARSE;
                end
                ST_BOOT_PARSE: begin
                    if (le16(11) != 16'd512 || !valid_spc(sector_buffer[13]) ||
                        le16(14) == 0 || (sector_buffer[16] != 1 && sector_buffer[16] != 2) ||
                        le16(17) != 0 || le16(22) != 0 || le32(32) == 0 ||
                        le32(36) == 0 || le32(44) < 2) begin
                        finish_with_error(ERR_UNSUPPORTED_BPB);
                    end else begin
                        sectors_per_cluster <= sector_buffer[13];
                        reserved_sectors <= le16(14);
                        fat_count <= sector_buffer[16];
                        total_sectors <= le32(32);
                        fat_sectors <= le32(36);
                        root_cluster <= le32(44);
                        sectors_per_cluster_shift <= spc_shift(sector_buffer[13]);
                        fat_span <= sector_buffer[16] == 2 ? (le32(36) << 1) : le32(36);
                        fat_start_lba <= partition_lba + le16(14);
                        state <= ST_BOOT_LAYOUT;
                    end
                end
                ST_BOOT_LAYOUT: begin
                    data_start_lba <= partition_lba + reserved_sectors + fat_span;
                    data_sector_count <= total_sectors - reserved_sectors - fat_span;
                    state <= ST_BOOT_ROOT;
                end
                ST_BOOT_ROOT: begin
                    max_cluster <= (data_sector_count >> sectors_per_cluster_shift) + 1'b1;
                    root_lba <= data_start_lba
                                + ((root_cluster - 2) << sectors_per_cluster_shift);
                    sector_lba <= data_start_lba
                                  + ((root_cluster - 2) << sectors_per_cluster_shift);
                    root_sector_idx <= 8'd0;
                    state <= ST_ROOT_REQ;
                end
                // resource_valid只在整个根目录簇扫描开始时（root_sector_idx==0）清零，
                // 循环扫后面的扇区时要保留前面几个扇区已经找到的结果，不能每扇区清一次。
                // 真实TF卡用过一段时间后，根目录靠前的槙位常被之前删除文件的"墓碑"
                // 条目（首字节0xE5）占满，PIC1~4.BMP实际写在更靠后的位置——之前只读
                // 第1个扇区（16个目录项）就直接判定的做法，在这种卡上会一个都找不到。
                ST_ROOT_REQ: if (!sector_busy) begin
                    if (root_sector_idx == 8'd0) begin
                        resource_valid <= {IMAGE_COUNT{1'b0}};
                        track_valid    <= {IMAGE_COUNT{1'b0}};
                        dbg_best_depth <= 4'd0;
                        diag2_code     <= 8'd0;
                    end
                    dir_entry_match <= 1'b0;
                    track_entry_match <= 1'b0;
                    sector_req <= 1'b1;
                    state <= ST_ROOT_WAIT;
                end
                ST_ROOT_WAIT: if (sector_done) begin
                    if (sector_error != 0)
                        finish_with_error(ERR_SECTOR);
                    else begin
                        directory_entry_index <= 5'd0;
                        state <= ST_DIR_SCAN;
                    end
                end
                // 扫完一个扇区后：如果这一簇里还有没扫过的扇区，就继续读下一个扇区
                // （累计resource_valid，不提前判定），直到把整个簇扫完才做最终决定。
                // 放宽为部分匹配：resource_valid位图里只要有非0的一位就算扫描成功，
                // 缺哪张图直接由上层看resource_valid区分，不再要求四张齐全才算数
                // （硬错误只保留在resource_valid==0，即整簇扫完一张都没找到——用来
                //  区分"TF卡没有文件系统/没插卡"这类真故障 和 "只是少放了几张图"）。
                ST_DIR_SCAN: begin
                    if (root_sector_idx + 8'd1 < sectors_per_cluster) begin
                        root_sector_idx <= root_sector_idx + 8'd1;
                        sector_lba      <= root_lba + root_sector_idx + 8'd1;
                        state           <= ST_ROOT_REQ;
                    end else if (resource_valid != 0) begin
                        state <= ST_FINISH;
                    end else begin
                        finish_with_error(ERR_RESOURCE_MISSING);
                    end
                end
                ST_FINISH: begin
                    // 音乐起始扇区/扇区数在扫目录时已经逐项算好
                    scan_done <= 1'b1;
                    state <= ST_IDLE;
                end
                default: state <= ST_IDLE;
            endcase
        end
    end
endmodule
