`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 火灾判定 + 画面降级选择（ctrl = sd_card_clk 域）
//
// 本地烟雾 / 温度传感器已移除，火警等级只来自 RS-485 主机：
//   remote_level 是主机经 RS-485 发来的等级（rs485_alarm_slave，0 正常 / 1 预警 / 2 火灾），
//   已经是同域寄存器、主机侧消抖过，这里不再消抖。
//
// 判定：
//   remote=2          -> 火灾发生，目标图 PIC13（index FIRE_INDEX）
//   remote=1（或 3）  -> 火灾预警，目标图 PIC12（index WARN_INDEX）
//   remote=0          -> 正常播放
// 降级（安全冗余）：有报警时目标图能不能显示，只看它有没有真的进 SDRAM：
//   player_ready（= 顶层 display_valid：摄入结束且 reader 已放行）
//   且 image_complete[目标] = 1    -> alarm_pic=1，像素域把 reader 改读目标 bank
//   否则                           -> rom_screen=1，片内 ROM 逃生画面整屏覆盖
// "否则"覆盖了 TF 卡的所有坏法：没插卡 / 初始化失败 / 文件系统坏 / 只有
// PIC13.BMP 坏 / 摄入卡住一直不结束 / 掉电重启后读不出来。摄入没结束之前
// 一律走 ROM，所以不需要单独的超时——摄入一结束且图在，自动切回图片。
// 开机时卡是好的、运行中才坏的情况：图早已在 SDRAM 里，照样显示图片。
//
// 复位值 = 不报警。所有输出都是寄存器，下游跨域直接用 sync_2ff / cdc_bus_commit。
// -----------------------------------------------------------------------------
module fire_alarm_ctrl #(
    parameter integer IMAGE_COUNT  = 13,
    parameter integer INDEX_W      = 4,
    parameter integer WARN_INDEX   = 11,       // PIC12 火灾预警
    parameter integer FIRE_INDEX   = 12        // PIC13 火灾发生
) (
    input  wire                   clk,
    input  wire                   rst_n,
    input  wire [1:0]             remote_level, // rs485_alarm_slave：主机的火警等级
    input  wire                   player_ready,
    input  wire [IMAGE_COUNT-1:0] image_complete,

    output reg                    alarm,        // 任一报警（预警或火灾）
    output reg                    fire,         // 火灾
    output reg  [INDEX_W-1:0]     alarm_index,  // 当前该显示的火灾图
    output reg                    alarm_pic,    // 1 = 显示 SDRAM 里的 alarm_index
    output reg                    rom_screen    // 1 = 目标图不可用，显示 ROM 逃生画面
);
    wire               any_alarm  = (remote_level != 2'd0);
    wire               both_alarm = (remote_level == 2'd2);
    wire [INDEX_W-1:0] want_index = both_alarm ? FIRE_INDEX[INDEX_W-1:0] :
                                                 WARN_INDEX[INDEX_W-1:0];
    wire               want_ok    = player_ready &&
                                    (both_alarm ? image_complete[FIRE_INDEX] :
                                                  image_complete[WARN_INDEX]);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            alarm       <= 1'b0;
            fire        <= 1'b0;
            alarm_index <= WARN_INDEX[INDEX_W-1:0];
            alarm_pic   <= 1'b0;
            rom_screen  <= 1'b0;
        end else begin
            alarm       <= any_alarm;
            fire        <= both_alarm;
            alarm_index <= want_index;
            alarm_pic   <= any_alarm &&  want_ok;
            rom_screen  <= any_alarm && !want_ok;
        end
    end
endmodule
