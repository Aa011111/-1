`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 火灾图覆盖自检：vsim -c -do run_fire.do
//   fire_alarm_ctrl + 完整的 media_video_pipeline（control / 转场 / 缩略图 /
//   reader / 对比度级）+ SDRAM 读口模型。13 个 bank 各填一种纯色，
//   在 pipeline 的像素输出端逐帧检查：
//     - 整帧每个 de 像素都相同（不撕裂），记下这一帧是哪个 bank 的颜色
//     - 不报警 = 底下播放器那张；remote_level=1 预警 = PIC12；=2 火灾 = PIC13
//     - 报警期间缩略图被强制成全屏、按 NEXT 不淡变（画面保持满亮度）
//     - 报警解除后回到底下播放器的状态（报警期间按过的 NEXT 生效）
//     - 火灾图没加载 / 摄入没结束：alarm_pic=0、rom_screen=1，画面不被覆盖
// 帧高降到 16 行以缩短仿真。
// -----------------------------------------------------------------------------
module tb_fire_alarm;
    localparam integer W = 640, H = 16, PIX = W * H;
    localparam integer N = 13;
    localparam integer BANK = PIX / 2;
    localparam integer LAT = 24;
    localparam integer MEM_WORDS = N * BANK;

    reg ctrl_clk = 0, mem_clk = 0, pix_clk = 0;
    always #5  ctrl_clk = ~ctrl_clk;
    always #4  mem_clk  = ~mem_clk;
    always #20 pix_clk  = ~pix_clk;
    reg rst_n = 0;
    integer errors = 0;

    // 每个 bank 一种颜色，565 截位后互不相同
    function [23:0] color;
        input integer idx;
        begin
            color = {idx[3:0], 4'h8, 8'hF0 - {idx[3:0], 4'h0}, idx[4:0], 3'b100};
        end
    endfunction
    function [15:0] to565;
        input [23:0] c;
        begin
            to565 = {c[23:19], c[15:10], c[7:3]};
        end
    endfunction
    // pipeline 输出 = 565 展开 × 亮度 255 的 alpha（(255*256)>>8 = 255，再 c*255>>8）
    function [23:0] expect_rgb;
        input integer idx;
        reg [23:0] c; reg [7:0] r, g, b; reg [15:0] mr, mg, mb;
        begin
            c = color(idx);
            r = {c[23:19], c[23:21]}; g = {c[15:10], c[15:14]}; b = {c[7:3], c[7:5]};
            mr = r * 8'd255; mg = g * 8'd255; mb = b * 8'd255;
            expect_rgb = {mr[15:8], mg[15:8], mb[15:8]};
        end
    endfunction

    reg [31:0] mem [0:MEM_WORDS-1];
    integer i, j;
    initial begin
        for (i = 0; i < N; i = i + 1)
            for (j = 0; j < BANK; j = j + 1)
                mem[i * BANK + j] = {to565(color(i)), to565(color(i))};
    end

    // ---------------- 激励 ----------------
    reg [1:0] remote = 2'd0;          // 主机火警等级：0 正常 / 1 预警 / 2 火灾
    reg [N-1:0] complete = {N{1'b1}};
    reg ready = 0;
    reg next_ev = 0, init_ev = 0, thumb_cfg_v = 0, thumb_cfg_on = 0;

    wire alarm, fire, alarm_pic, rom_screen;
    wire [3:0] alarm_index;

    fire_alarm_ctrl #(
        .IMAGE_COUNT(N), .INDEX_W(4), .WARN_INDEX(11), .FIRE_INDEX(12)
    ) u_fire (
        .clk(ctrl_clk), .rst_n(rst_n),
        .remote_level(remote),
        .player_ready(ready), .image_complete(complete),
        .alarm(alarm), .fire(fire),
        .alarm_index(alarm_index), .alarm_pic(alarm_pic), .rom_screen(rom_screen)
    );

    // ---------------- SDRAM 读口模型 ----------------
    wire        rd_en;
    wire [20:0] rd_addr;
    reg  [LAT-1:0] vpipe = 0;
    reg  [20:0] apipe [0:LAT-1];
    wire        rd_valid = vpipe[LAT-1];
    wire [31:0] rd_data = mem[apipe[LAT-1]];
    integer k;
    always @(posedge mem_clk) begin
        vpipe <= {vpipe[LAT-2:0], rd_en};
        apipe[0] <= rd_addr;
        for (k = 1; k < LAT; k = k + 1) apipe[k] <= apipe[k-1];
        if (rd_en && rd_addr >= MEM_WORDS) begin
            errors = errors + 1; $display("ERR read addr %0d out of range", rd_addr);
        end
    end

    wire        v_de, v_hs, v_vs, thumb_mode, thumb_frame, frame_start;
    wire [23:0] v_rgb;
    wire [3:0]  act_idx, disp_idx, pend_idx;
    wire [7:0]  v_err, fade_alpha;
    wire        fade_active;

    media_video_pipeline #(
        .IMAGE_WORDS(PIX), .PACK_RGB565(1), .IMAGE_COUNT(N), .INDEX_W(4),
        .NAV_MASK(13'b0_0111_1111_1111),
        .THUMB_COLS(4), .THUMB_ROWS(4), .CELL_W(4),
        .FIFO_DEPTH(512), .FIFO_MARGIN(16),
        .H_ACT(640), .H_FP(16), .H_SYNC(96), .H_BP(48),
        .V_ACT(H), .V_FP(2), .V_SYNC(2), .V_BP(4),
        .DEFAULT_PERIOD_CYCLES(32'd300_000_000),
        .MIN_PERIOD_CYCLES(32'd50_000_000),
        .MAX_PERIOD_CYCLES(32'd3_000_000_000),
        .FADE_FRAMES(16)
    ) u_pipe (
        .ctrl_clk(ctrl_clk), .ctrl_rst_n(rst_n),
        .next_event(next_ev), .prev_event(1'b0), .init_event(init_ev),
        .toggle_auto_event(1'b0),
        .period_cfg_valid(1'b0), .period_cfg_cycles(32'd0),
        .auto_cfg_valid(1'b0), .auto_cfg_enabled(1'b0),
        .image_complete(complete), .player_enable(ready),
        .thumb_toggle_event(1'b0), .thumb_cfg_valid(thumb_cfg_v),
        .thumb_cfg_enabled(thumb_cfg_on), .confirm_event(1'b0),
        .focus_cfg_valid(1'b0), .focus_cfg_index(4'd0),
        .thumb_mode(thumb_mode), .thumb_frame_pix(thumb_frame),
        .alarm_show(alarm_pic), .alarm_index(alarm_index),
        .mem_clk(mem_clk), .mem_rst_n(rst_n),
        .controller_init_done(1'b1), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_rd_en(rd_en), .app_rd_addr(rd_addr),
        .sdram_rd_valid(rd_valid), .sdram_rd_data(rd_data),
        .brightness(8'd255), .contrast(8'd128),
        .pix_clk(pix_clk), .pix_rst_n(rst_n),
        .video_clk(), .video_hs(v_hs), .video_vs(v_vs), .video_de(v_de),
        .video_rgb(v_rgb), .video_x(),
        .active_index(act_idx), .display_index(disp_idx), .pending_index(pend_idx),
        .auto_enabled(), .frame_start(frame_start),
        .reader_busy(), .reader_underflow(), .video_error(v_err),
        .fade_alpha_pix(fade_alpha), .fade_active_pix(fade_active)
    );

    // ---------------- 输出端逐帧统计 ----------------
    // 一帧结束（vs 下降沿）时把这一帧的结果锁进 last_*：
    //   last_uniform = 整帧 de 像素全相同；last_bank = 与哪个 bank 的期望色相同（-1 = 都不是）
    reg        vs_q = 1;
    reg [23:0] first_px;
    reg        have_px = 0, uniform = 1;
    integer    frames = 0;
    reg        last_uniform = 0;
    integer    last_bank = -1;
    reg [23:0] last_px;
    integer    b;
    always @(posedge pix_clk) begin
        vs_q <= v_vs;
        if (vs_q && !v_vs) begin
            last_uniform = have_px && uniform;
            last_px      = first_px;
            last_bank    = -1;
            for (b = 0; b < N; b = b + 1)
                if (first_px == expect_rgb(b)) last_bank = b;
            frames  = frames + 1;
            have_px = 0;
            uniform = 1;
        end else if (v_de) begin
            if (!have_px) begin first_px = v_rgb; have_px = 1; end
            else if (v_rgb !== first_px) uniform = 0;
        end
    end

    task wait_frames;
        input integer n;
        integer f0;
        begin
            f0 = frames;
            while (frames < f0 + n) @(posedge pix_clk);
        end
    endtask

    // 等 n 帧让状态落定，再连续看 m 帧都必须是整帧 bank 色
    task expect_bank;
        input integer want;
        input integer settle;
        input integer m;
        input [8*40-1:0] what;
        integer f, e0;
        begin
            e0 = errors;
            wait_frames(settle);
            for (f = 0; f < m; f = f + 1) begin
                wait_frames(1);
                if (!last_uniform || last_bank != want) begin
                    errors = errors + 1;
                    $display("ERR %0s: frame uniform=%b bank=%0d px=%h (want bank %0d)",
                             what, last_uniform, last_bank, last_px, want);
                end
            end
            $display("%0s: bank %0d x%0d frames OK=%0d (alarm_pic=%b rom=%b disp=%0d act=%0d)",
                     what, want, m, (errors == e0), alarm_pic, rom_screen, disp_idx, act_idx);
        end
    endtask

    // 单拍事件（ctrl 域）。不用 output 参数的 task：Verilog 要到 task 返回才把
    // output 拷回实参，那样脉冲根本出不去
    task pulse_next;
        begin
            @(posedge ctrl_clk); next_ev <= 1;
            @(posedge ctrl_clk); next_ev <= 0;
        end
    endtask
    task pulse_init;
        begin
            @(posedge ctrl_clk); init_ev <= 1;
            @(posedge ctrl_clk); init_ev <= 0;
        end
    endtask

    task check_flags;
        input exp_pic, exp_rom;
        input [3:0] exp_idx;
        input [8*40-1:0] what;
        begin
            if (alarm_pic !== exp_pic || rom_screen !== exp_rom ||
                ((exp_pic || exp_rom) && alarm_index !== exp_idx)) begin
                errors = errors + 1;
                $display("ERR %0s: alarm_pic=%b rom=%b idx=%0d (want %b %b %0d)",
                         what, alarm_pic, rom_screen, alarm_index, exp_pic, exp_rom, exp_idx);
            end else
                $display("%0s: alarm_pic=%b rom=%b idx=%0d OK", what, alarm_pic, rom_screen, alarm_index);
        end
    endtask

    localparam integer DEB = 20;     // 等级变化后等几拍再查（输出只打一拍）

    initial begin
        repeat (10) @(posedge ctrl_clk);
        rst_n = 1;

        // ---- 摄入没结束（ready=0）时报警：只能 ROM 兜底 ----
        remote = 2'd2;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b0, 1'b1, 4'd12, "not ready, fire");
        remote = 2'd0;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b0, 1'b0, 4'd0, "not ready, clear");

        // ---- 摄入完成，首图落位 PIC1 ----
        ready = 1;
        repeat (20) @(posedge ctrl_clk);
        pulse_init;
        // 首图落位走自动切换路径，有 16 帧 Wipe 揭示，等它走完
        expect_bank(0, 20, 3, "normal PIC1");

        // ---- 主机预警 -> PIC12 ----
        remote = 2'd1;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b1, 1'b0, 4'd11, "warn");
        expect_bank(11, 2, 3, "warn -> PIC12");

        // ---- 主机火灾 -> PIC13 ----
        remote = 2'd2;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b1, 1'b0, 4'd12, "fire");
        expect_bank(12, 2, 3, "fire -> PIC13");

        // ---- 报警中进缩略图：仍然是全屏 PIC13 ----
        @(posedge ctrl_clk); thumb_cfg_on = 1; thumb_cfg_v = 1;
        @(posedge ctrl_clk); thumb_cfg_v = 0;
        expect_bank(12, 2, 40, "fire + THUMB");     // 覆盖住整个淡出淡入
        if (thumb_mode !== 1'b1) begin
            errors = errors + 1; $display("ERR underlying thumb_mode should be 1");
        end
        @(posedge ctrl_clk); thumb_cfg_on = 0; thumb_cfg_v = 1;
        @(posedge ctrl_clk); thumb_cfg_v = 0;
        expect_bank(12, 2, 40, "fire + FULL");

        // ---- 报警中按 NEXT：底下淡出切到 PIC2，屏幕上 PIC13 满亮度不动 ----
        pulse_next;
        expect_bank(12, 1, 45, "fire + NEXT");
        if (pend_idx !== 4'd1) begin
            errors = errors + 1; $display("ERR underlying pending_index=%0d want 1", pend_idx);
        end

        // ---- 降回预警 -> PIC12 ----
        remote = 2'd1;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b1, 1'b0, 4'd11, "back to warn");
        expect_bank(11, 2, 3, "warn -> PIC12");

        // ---- 全部解除：回到底下播放器的状态（PIC2）----
        remote = 2'd0;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b0, 1'b0, 4'd0, "clear");
        expect_bank(1, 2, 3, "clear -> PIC2");

        // ---- PIC13 没加载成功：火灾 -> ROM 兜底，画面不被 SDRAM 覆盖 ----
        complete[12] = 1'b0;
        remote = 2'd2;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b0, 1'b1, 4'd12, "PIC13 missing, fire");
        expect_bank(1, 2, 3, "PIC13 missing (pipeline untouched)");

        // ---- 同时 PIC12 在：预警 -> 显示 PIC12 ----
        remote = 2'd1;
        repeat (DEB) @(posedge ctrl_clk);
        check_flags(1'b1, 1'b0, 4'd11, "PIC13 missing, warn");
        expect_bank(11, 2, 3, "PIC13 missing, warn -> PIC12");

        // ---- PIC12 也没有 -> ROM ----
        complete[11] = 1'b0;
        repeat (20) @(posedge ctrl_clk);
        check_flags(1'b0, 1'b1, 4'd11, "PIC12 missing, warn");

        if (v_err !== 8'd0) begin
            errors = errors + 1; $display("ERR video_error = %h", v_err);
        end
        $display("frames simulated: %0d", frames);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL (%0d)", errors);
        $finish;
    end
endmodule
