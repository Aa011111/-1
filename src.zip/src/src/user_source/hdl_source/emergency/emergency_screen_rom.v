`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 应急逃生画面 ROM：320x240 x 2bit，4 像素打包成 1 字节，共 19200 字节。
// 内容由 make_emergency_screen.py 生成 emergency_screen.hex。
//
// 不用 IP 生成器的 EG_LOGIC_BRAM + INIT_FILE：那条路的相对路径基准没有文档，
// 本工程的 AUDIO_SAMPLE_ROM 用过一次也说不清是相对谁。这里用 TD 文档
// (SWUG106 2.1.3) 明确支持的 initial $readmemh 写法，初始化文件放在
// 【.v 源文件目录】或【.al 根目录】下即可——脚本两处各写一份。
// rom_style="bram" 强制落到 BRAM（SWUG106 4.2.7），19200x8 约 150Kbit。
// 同步读，读延迟 1 拍。
// -----------------------------------------------------------------------------
module emergency_screen_rom #(
    parameter         INIT_FILE  = "emergency_screen.hex",
    parameter integer DEPTH      = 19200,
    parameter integer ADDR_WIDTH = 15
) (
    input  wire                  clk,
    input  wire [ADDR_WIDTH-1:0] addr,
    output reg  [7:0]            q
);
    (* rom_style = "bram" *) reg [7:0] mem [0:DEPTH-1];

    initial $readmemh(INIT_FILE, mem);

    always @(posedge clk)
        q <= mem[addr];
endmodule
