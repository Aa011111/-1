# emergency —— 火灾检测 + 火灾图显示 + ROM 逃生画面兜底

本地烟雾（MQ-2）/ 温度（AM2302）传感器已移除（2026-11-01），火警等级只来自 RS-485 主机（见 `rs485/README.md`）。
原 `am2302_reader.v` 及其仿真移到了 `user_source/_unused/hdl_source/emergency/`。

| 主机等级 `remote_level` | 判定 | 显示 |
|---|---|---|
| 0 | 正常 | TF 卡图片正常播放 |
| 1 | 火灾预警 | **PIC12**（+ MUSIC12） |
| 2 | 火灾发生 | **PIC13**（+ MUSIC13） |

**安全冗余**：有报警时，目标图（PIC12 / PIC13）如果没有成功进 SDRAM，就改用片内 ROM 生成的逃生画面。
逃生画面完全由片内 ROM + 逻辑生成，不依赖 TF 卡、不依赖 SDRAM。

判断依据是"目标图在不在 SDRAM 里"（`display_valid && loader_image_complete[目标]`），不是"TF 卡坏没坏"：

| 情况 | 结果 |
|---|---|
| 开机时卡是好的，运行中才坏 | 图早已在 SDRAM 里 → 照样显示 PIC12/13（报警音会断，因为 WAV 是实时读卡的） |
| 没插卡 / 卡初始化失败 / FAT32 坏 | 摄入失败 → ROM 逃生画面 |
| 只是 PIC13.BMP 坏了 | `image_complete[12]=0` → 火灾时 ROM 逃生画面；只有一个报警时 PIC12 照常 |
| 开机摄入还没结束 / 卡在摄入里 | `display_valid=0` → ROM 逃生画面；摄入一完成且图在，自动切到图片（不需要单独超时） |
| 火灾中掉电重启，重启时卡已坏 | 同"没插卡" → ROM 逃生画面 |

![预览](emergency_screen_preview.png)

## 行为细节

- 复位值 = 不报警。`remote_level` 已是同域寄存器、主机侧消抖过，本模块不再消抖。
- 原来传感器占用的 J2 管脚 N4（MQ-2 DO）/ J3（AM2302 DATA）已释放，`pin.adc` 中对应约束已删除。
- **火灾图覆盖在像素域做**（`media_video_pipeline` 差异7）：报警时 reader 改读 PIC12/13 的 bank，强制全屏（缩略图模式也一样），不做淡变/Wipe，亮度/对比度仍然生效。
  播放器、转场、缩略图控制器一个都不碰，按键 / 串口 / 自动轮播照常作用于底下被盖住的播放器，**报警解除后回到它当时的状态**。
- 预警 ↔ 火灾、报警 ↔ 正常都在帧边界切换，不撕裂。
- 音频：有报警就放 MUSIC12/13（ROM 兜底时也会尝试，卡还能读就有声音），不跟转场淡入淡出。
- 数码管：火灾图覆盖时右两位显示 `12` / `13`；ROM 兜底时末位 `E`，同时照常显示 TF 卡诊断码，方便看是哪一步失败。
- 串口 / 字幕跟着屏幕上实际那张走（报警时打出 PIC 12/13）。
- 原来的"SW1 手动应急、不碰 TF 卡"模式已取消：现在开机无条件读卡，因为有报警时更需要把 PIC12/13 读进来。

## 画面组成

| 部分 | 实现 | 改哪里 |
|---|---|---|
| 标题（奔跑小人 + 安全出口 / EXIT）、平面图、提示语 | ROM，320x240 x 4 色，硬件 2x 放大 | `make_emergency_screen.py` 的 `render_default()` |
| "您在此处"红点闪烁（约 1Hz） | 调色板索引 2（红）按帧亮/灭 | `BLINK_FRAMES`；画图时只有要闪的东西用红色 |
| 流动箭头带（y 120~179） | 逻辑实时画 V 形箭头，每帧移 2 像素 | 顶层 `ARROW_SPEED` / `ARROW_DIR`（0 右 / 1 左） |

调色板：0 安全绿 `009A44`、1 白、2 红 `E60012`（闪）、3 深灰 `262626`。
脚本的 `PALETTE` 与 `emergency_screen.v` 的 `PAL_*` 参数要保持一致。

### 换成自己的画面

1. 用任意画图软件按上面 4 种颜色画一张图（建议 320x240 或 640x480，箭头带那一条留绿底）。
2. `python make_emergency_screen.py --image 我的图.png`，会按最近颜色映射到 4 色。
3. 看 `emergency_screen_preview.png` 确认，再到 TD 里重新综合。

脚本会同时写两份 `emergency_screen.hex`：本目录和 `td_project/`。
**两份都要有**——TD 文档（SWUG106 2.1.3）规定 `$readmemh` 的文件必须在 `.v` 源文件目录或 `.al` 根目录下，ModelSim 仿真用本目录这一份。

## 文件

| 文件 | 作用 |
|---|---|
| `fire_alarm_ctrl.v` | 按 RS-485 主机等级判定预警 / 火灾，按目标图是否在 SDRAM 里选 `alarm_pic` / `rom_screen`（sd_card_clk 域） |
| `emergency_mode_ctrl.v` | 旧的 SW1 手动应急消抖，**已不参与综合**，只给 `sim/run.do` 的旧仿真用 |
| `emergency_screen.v` | video_clk 域整屏叠加：ROM 取像素 + 调色板 + 闪烁 + 箭头；`frame_start` 锁存使能 |
| `emergency_screen_rom.v` | `$readmemh` 行为级 ROM，`rom_style="bram"`，19200x8 |
| `make_emergency_screen.py` | 生成 `emergency_screen.hex` 和预览图 |
| `sim/` | 逃生画面自检：`vsim -c -do run.do` 后 `python check_frames.py`；火灾图覆盖自检：`vsim -c -do run_fire.do` |

## 顶层改动（`top_tf_hdmi_audio.v`）

移除本地传感器（2026-11-01）：
- 删除端口 `smoke_do` / `dht_sda` 及 `pin.adc` 中的约束；删除 `u_am2302_reader`
- `fire_alarm_ctrl` 去掉 `smoke_in` / `temp_in` 输入、`smoke` / `temp` 输出和消抖，只按 `remote_level` 判定
- `rs485_alarm_slave.local_flags` 改接常 0
- `.al` 移除 `emergency/am2302_reader.v`

接入真传感器（2026-10-22，已被上一条撤销）：
- 端口 `sw1` / `sw2` 换成 `smoke_do`（N4）/ `dht_sda`（J3，inout），`pin.adc` 同步修改
- 新增 `u_am2302_reader`，其 `temp_alarm` 接 `u_fire_alarm_ctrl.temp_in`；`smoke_in` 接 `smoke_do`
- `fire_alarm_ctrl` 的 `ACTIVE_LEVEL` 拆成 `SMOKE_ACTIVE_LEVEL`(0) / `TEMP_ACTIVE_LEVEL`(1)
- `.al` 新增 `emergency/am2302_reader.v`（CompileOrder 77），原 `.al` 备份为 `.al.bak_before_sensor`
- sdc 不用改：`am2302_reader` 同步器第一级也叫 `s1`，被 `*/s1` 通配 false_path 覆盖

火灾检测改造（2026-10-22）：
- 新端口 `sw2`（C7）；`sw1` 改为烟雾输入
- `u_emergency_mode_ctrl` 换成 `u_fire_alarm_ctrl`；`.al` 里 `emergency_mode_ctrl.v` 换成 `fire_alarm_ctrl.v`（同一个 CompileOrder 73），原 `.al` 备份为 `.al.bak_before_fire_alarm`
- `ingest_start` 去掉门控，开机无条件摄入；`wav_ready_sd` 去掉门控
- `media_video_pipeline` 新增 `alarm_show` / `alarm_index` 输入、`display_index` 输出
- `shown_index_sd`（屏幕上实际那张）接数码管 / 串口 `media_id` / 字幕；`player_display_index` 接状态条
- `wav_want_index` 报警时取 `alarm_index_sd`；音频转场增益报警时固定 255
- `u_emergency_screen.enable` 改接 `rom_screen_video`
- sdc 不用改：新同步器第一级是 `s1`（sync_2ff / 消抖）和 `commit_sync1`（cdc_bus_commit），都已被通配 false_path 覆盖

最初的应急模式改动（2026-10-20）：OSD 链末端新增 `u_emergency_screen`：`vout_data_param → vout_data_final → AXIS`；`.al` 备份为 `.al.bak_before_emergency`。

## TD 实跑结果（2026-10-20，TD 6.2.168116）

| 项 | 改动前 | 改动后 |
|---|---|---|
| LUT | 13762 (70.2%) | 13936 (71.1%) |
| REG | 8017 | 8058 |
| BRAM9K | 36 / 64 | **58 / 64 (90.6%)**，ROM 占 22 块 |
| Setup WNS | +26ps | +116ps |
| Hold WNS | +4ps | +36ps（需要下面的 fix_hold） |

- 综合日志确认 `readmemh: reading from file 'emergency_screen.hex'`，ROM 推断进 BRAM。
  `net 'mem' does not have a driver` 告警是只读存储器没有写端口的正常提示。
- `sw1` 落在 C8，打成 IREG。
- **hold**：BRAM 到 91% 后布局变挤，原有模块里几条"触发器 → BRAM 输入"的单跳路径
  （SDRAM 写 FIFO、loader、HDMI 核内部 FIFO）hold 掉到 −70ps。只设 `route fix_hold`
  参数无效；**布线后再调一次 `fix_hold` 命令**才收敛。已加进
  `td_project/HDMI1.4b_Transmitter_v1.0_Runs/phy_1/HDMI1.4b_Transmitter_v1.0.tcl`
  的 opt_route 可编辑区（原脚本备份为 `.tcl.bak_before_emergency`）。
  如果 TD 重新生成了这个脚本把那一行冲掉，看 `route_flow.status` 的 Hold：
  若是负的，在 TD 的 Tcl 控制台里对 `_pr.db` 跑一次 `fix_hold` 再出 bit。
- BRAM 只剩 6 块，以后再加需要 BRAM 的功能，要先考虑腾空间（例如把这张图改成
  320x240 x 1bit + 局部彩色，或者干脆搬到 SPI Flash）。

## 仿真

```
cd emergency/sim
vsim -c -do run.do        # 逃生画面，期望 TB PASS
python check_frames.py    # 期望 CHECK PASS
vsim -c -do run_fire.do   # 火灾图覆盖，期望 RESULT: PASS
```

`run_fire.do`：`fire_alarm_ctrl` + 完整 `media_video_pipeline` + SDRAM 读口模型，13 个 bank 各一种纯色，
在像素输出端逐帧检查整帧一致、颜色属于哪张图。覆盖：摄入未完成报警 → ROM；预警 → PIC12；
火灾 → PIC13；报警中进缩略图 / 回全屏 / 按 NEXT 时屏幕保持 PIC13 满亮度；降回预警 → PIC12；
解除后回到底下播放器的状态（报警中按过的 NEXT 生效）；PIC13 未加载 → 火灾走 ROM、预警仍显示 PIC12；
PIC12 也未加载 → ROM。

覆盖：消抖（复位值、抖动不翻转、稳定后翻转）、帧中间拉 enable 当帧不生效、
第 3/4 帧共 614400 个像素与 Python 参考模型逐像素一致（含 ROM 放大寻址、
箭头相位、闪烁亮/灭两种状态）、未使能时像素逐位直通、输出无 X。

## 上板验证

| # | 操作 | 预期 | 不对时看哪里 |
|---|---|---|---|
| 1 | 接好 RS-485，主机正常，插卡上电 | 正常播放 | — |
| 2 | 主机发预警 | 整屏 PIC12，放 MUSIC12，数码管右两位 `12` | 不切图：见 `rs485/README.md` 上板验证 |
| 3 | 主机发火灾 | 整屏 PIC13，放 MUSIC13，数码管 `13` | — |
| 4 | 主机发正常 | 回到报警前的图 | — |
| 5 | 卡里删掉 PIC13.BMP（或改坏），主机发火灾 | ROM 逃生画面、箭头流动、红点闪烁，数码管末位 `E`；预警时仍是 PIC12 | — |
| 6 | **不插卡**上电，主机发预警或火灾 | 直接 ROM 逃生画面，显示器不报"无信号"，诊断码亮 | — |
| 7 | 画面全花 / 全绿无内容 | — | TD 没读到 hex：确认 `td_project/emergency_screen.hex` 存在，看综合日志里 `$readmemh` 的告警 |
