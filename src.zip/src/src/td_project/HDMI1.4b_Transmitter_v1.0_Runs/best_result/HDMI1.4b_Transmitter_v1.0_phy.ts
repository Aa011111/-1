SWNS: -0.683ns, STNS: -38.310ns.
HWNS: -0.070ns, HTNS: -0.433ns.
