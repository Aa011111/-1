`timescale 1ns / 1ps
// -----------------------------------------------------------------------------
// txs0108e_oe：TXS0108E 双向电平转换芯片的 OE 上电时序
//
// 芯片手册（ZHCSE13L）要点：
//   - OE 高 = 启用，OE 低 = 8 路 A/B 全部高阻、内部智能上拉 RPUA/RPUB 也断开；
//   - OE 输入以 VCCA 为参考：VIH >= 0.65*VCCA，VIL <= 0.35*VCCA。
//     FPGA 3.3V 输出驱动 OE，要求 VCCA <= 3.3V（芯片本来就要求 VCCA <= VCCB 且 <= 3.6V）；
//   - 8.3 节：上电/掉电期间 OE 必须保持低电平，直到 VCCA、VCCB 都斜升到位且稳定后才拉高，
//     并建议 OE 外接下拉电阻到 GND（FPGA 配置完成前管脚不受本逻辑控制）；
//   - ten（OE 拉高到 I/O 可用）最大 200ns，tdis（OE 拉低到 I/O 高阻）最大 400~410ns。
//
// 时序（本模块）：
//   复位中                 oe=0，ready=0
//   复位释放后 PWRUP_MS    oe=0，等两侧电源稳定（板上电源早在 FPGA 配置完成前就稳了，这里再留余量）
//   之后                   oe=1；再过 EN_US（> ten 200ns）ready=1，经转换芯片的信号从这时起才可信
//   rst_n 再次拉低（按复位键 / PLL 失锁）时 oe 异步回到 0，I/O 高阻，>=410ns 后对外完全断开
// -----------------------------------------------------------------------------
module txs0108e_oe #(
    parameter integer CLK_FREQ_HZ = 100_000_000,
    parameter integer PWRUP_MS    = 10,     // OE 拉高前等待
    parameter integer EN_US       = 1       // OE 拉高到 ready，须 > ten(200ns)
)(
    input  wire clk,
    input  wire rst_n,
    output reg  oe,         // 接 TXS0108E OE
    output reg  ready       // 1 = 转换通道可用
);
    localparam integer PWRUP_CYC = CLK_FREQ_HZ / 1000 * PWRUP_MS;
    localparam integer EN_CYC    = CLK_FREQ_HZ / 1000000 * EN_US;
    localparam integer CNT_W     = $clog2(PWRUP_CYC + 1);

    reg [CNT_W-1:0] cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cnt   <= {CNT_W{1'b0}};
            oe    <= 1'b0;
            ready <= 1'b0;
        end
        else if (!oe) begin
            if (cnt == PWRUP_CYC - 1) begin
                cnt <= {CNT_W{1'b0}};
                oe  <= 1'b1;
            end
            else
                cnt <= cnt + 1'b1;
        end
        else if (!ready) begin
            if (cnt == EN_CYC - 1)
                ready <= 1'b1;
            else
                cnt <= cnt + 1'b1;
        end
    end
endmodule
