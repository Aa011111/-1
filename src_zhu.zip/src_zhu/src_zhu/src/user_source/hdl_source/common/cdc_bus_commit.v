`timescale 1ns / 1ps
// -----------------------------------------------------------------------------
// cdc_bus_commit：多位慢变总线跨时钟域（bundled data + toggle 握手）
//
// 为什么不能用 sync_2ff：sync_2ff.v 的合同边界写得很清楚——"多位总线禁止
// 逐位2FF（各位到达拍数可能不同→撕裂）"。本工程原来没有这种需求，第五讲
// UART 接入后有了两条：
//   volume / brightness   sd_card_clk(ctrl) -> video_clk(pix)
//   player_error_video    video_clk(pix)    -> sd_card_clk(ctrl)
// 三个量都是"人下一条串口命令才变一次"的慢变电平，用不着异步 FIFO。
//
// 结构与 framebuf4bank/media_player_control.v 的 request_toggle/ack_toggle
// 同构，只是把 index 换成参数化宽度、并把"什么时候发起搬运"改成源侧自动
// 检测数值变化，调用方不需要额外给 commit 脉冲。
//
// 【隔离拍】osd/reference/说明.txt 那条警告说的就是这里：bundled data 的
// 数据和 toggle 绝不能同一拍变。本模块源侧分两步——先把新值锁进 src_hold
// （pending 置位），下一拍才翻 src_toggle，保证 toggle 翻转时 src_hold 已经
// 稳了至少一整拍；而且 busy 期间不接受新值，所以目的域 2FF 那两拍里
// src_hold 一定不动。
//
// 时序约束：目的侧第一级同步器命名为 commit_sync1，已被
// constraints_source/media_player_promax_top.sdc 第 6 节的
// `set_false_path -to [get_regs -hier {*/commit_sync1}]` 通配覆盖，
// 新增实例不需要再往 sdc 里加条目。
//
// 合同边界：
//   - 只适用于慢变总线。src_data 的变化间隔必须 > (两域各 3~4 拍)，否则
//     busy 期间的中间值会被吞掉（只保留最后一个值，不会撕裂，但会丢中间态）。
//   - 复位后 dst_data = RESET_VAL，dst_update 不会在复位释放时自发打一拍；
//     源侧第一次检测到 src_data != RESET_VAL 时才搬。所以调用方应让
//     RESET_VAL 等于源侧的默认值，上电即一致，不依赖第一次搬运。
// -----------------------------------------------------------------------------

module cdc_bus_commit #(
    parameter integer WIDTH = 8,
    parameter [WIDTH-1:0] RESET_VAL = {WIDTH{1'b0}}
)(
    input  wire             src_clk,
    input  wire             src_rst_n,
    input  wire [WIDTH-1:0] src_data,
    output wire             src_busy,      // 搬运中，此期间 src_data 的变化被暂缓

    input  wire             dst_clk,
    input  wire             dst_rst_n,
    output reg  [WIDTH-1:0] dst_data,
    output reg              dst_update     // 单拍：dst_data 刚被更新
);
    // 声明集中在前：ack_sync1 要用到目的域的 dst_ack_toggle，两域互相引用，
    // 放一起免得依赖"模块内可后声明"这种各家前端宽容度不一的写法。
    // ---------------- 源域 ----------------
    reg [WIDTH-1:0] src_hold;      // 交给目的域采样的 bundled data
    reg             src_pending;   // 隔离拍标志：值已锁存，toggle 还没翻
    reg             src_toggle;
    reg             ack_sync1, ack_sync2;
    // ---------------- 目的域 ----------------
    (* async_reg = "true" *) reg commit_sync1, commit_sync2;
    reg             dst_seen;
    reg             dst_ack_toggle;

    assign src_busy = (src_toggle != ack_sync2) || src_pending;

    always @(posedge src_clk or negedge src_rst_n) begin
        if (!src_rst_n) begin
            src_hold    <= RESET_VAL;
            src_pending <= 1'b0;
            src_toggle  <= 1'b0;
            ack_sync1   <= 1'b0;
            ack_sync2   <= 1'b0;
        end else begin
            ack_sync1 <= dst_ack_toggle;
            ack_sync2 <= ack_sync1;

            if (src_pending) begin
                // 隔离拍：src_hold 已稳一拍，现在才允许翻 toggle
                src_pending <= 1'b0;
                src_toggle  <= ~src_toggle;
            end else if (!src_busy && (src_data != src_hold)) begin
                src_hold    <= src_data;
                src_pending <= 1'b1;
            end
        end
    end

    // ---------------- 目的域时序 ----------------
    always @(posedge dst_clk or negedge dst_rst_n) begin
        if (!dst_rst_n) begin
            commit_sync1   <= 1'b0;
            commit_sync2   <= 1'b0;
            dst_seen       <= 1'b0;
            dst_ack_toggle <= 1'b0;
            dst_data       <= RESET_VAL;
            dst_update     <= 1'b0;
        end else begin
            commit_sync1 <= src_toggle;
            commit_sync2 <= commit_sync1;
            dst_update   <= 1'b0;

            if (commit_sync2 != dst_seen) begin
                dst_seen       <= commit_sync2;
                dst_data       <= src_hold;   // toggle 已翻过来，src_hold 早已静止
                dst_update     <= 1'b1;
                dst_ack_toggle <= commit_sync2;
            end
        end
    end
endmodule
