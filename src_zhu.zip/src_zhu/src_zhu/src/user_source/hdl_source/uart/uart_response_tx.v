`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// uart_response_tx：第10课原件的字符串表 + 换接第五讲 reporter 的 reply 通道。
//
// 【和讲义原件最大的差异：不再直连 uart_tx】
// 讲义原件自己按 start/data/busy/done 合同驱动 uart_tx。本工程不能这么接——
// 板上只有一根 uart_txd（D12），而第五讲的 uart_status_reporter.v 内部已经
// 例化了唯一那个 uart_tx_byte，并且专门留了四根口给命令回复共享这条发送路：
//     reply_valid / reply_data / reply_last -> reporter
//     reply_ready                           <- reporter
// 所以本模块改成往这四根口交付字节，reporter 的 ST_REPLY 状态负责实际驱动
// tx。第五讲那三个原件（uart_rx_byte / uart_tx_byte / uart_status_reporter）
// 一个字都没改。
//
// reply 通道的握手合同（读 uart_status_reporter.v:189-264 得到）：
//   - reply_valid 拉高并保持，reply_data/reply_last 同时稳定；
//   - reporter 在 ST_IDLE 看到 reply_valid 就把当前字节抓进 tx_data_r 起发，
//     抓的时候【不给】reply_ready；
//   - 每个字节发完（tx_done）给 reply_ready 一拍，意思是"这个字节完了，换下一个"；
//   - reply_last 为高的那个字节发完后 reporter 回 ST_IDLE。
//   - reporter 的 reply_wait 会在 ready 之后空一拍，所以上游有两拍时间把
//     reply_data 换成下一个字节，很宽松。
//
// 【reply_valid 为什么要组合门控，这是本文件唯一的取巧之处】
//   reporter 在 tx_done 那一拍把 reply_ready 寄成高、同时把 state 寄成
//   ST_IDLE，两者都在下一拍（记作 N+1）生效。本模块也只能在 N+1 的沿上
//   才看到 reply_ready=1，于是 active 要到 N+2 才落。这就意味着 N+1 期间
//   reporter 已经在 ST_IDLE 而 reply_valid 还挂着高——它会把最后一个字节
//   （byte_index 还没动）再抓一次，末尾的 LF 发两遍。
//   修法是把 reply_valid 做成组合、在"最后一个字节的 ready 拍"就主动落低：
//       assign reply_valid = active && !(reply_ready && reply_last);
//   不成环：reporter 的 reply_ready 是寄存器输出，不依赖 reply_valid 的组合值。
//   （这条是接线层的问题，不是 reporter 的 bug，所以修在本模块而不是动原件。）
//
// 字符串表本身沿用讲义：OK\r\n(4) / ERR\r\n(5)。本工程的命令只用这两条，
// 状态查询走 reporter 自己的 PIC/VOL/PRD/BRT 行，不再需要 ON/OFF 两条。
// RESP_ON/RESP_OFF 的表项保留着，加新命令时可以直接用。
// -----------------------------------------------------------------------------

module uart_response_tx (
    input  wire       clk,
    input  wire       rst_n,

    // 来自 uart_command_engine
    input  wire       response_valid,
    input  wire [2:0] response_id,
    output wire       response_ready,

    // 去 uart_status_reporter 的 reply 通道
    output wire       reply_valid,
    output wire [7:0] reply_data,
    output wire       reply_last,
    input  wire       reply_ready
);
    localparam [2:0] RESP_OK  = 3'd0;
    localparam [2:0] RESP_ERR = 3'd1;
    localparam [2:0] RESP_ON  = 3'd2;

    reg       active;
    reg [2:0] active_id;
    reg [2:0] byte_index;
    reg [2:0] byte_count;

    assign response_ready = !active;

    function [7:0] response_byte;
        input [2:0] kind;
        input [2:0] index;
        begin
            case (kind)
                RESP_OK: begin
                    case (index)
                        3'd0: response_byte = "O";
                        3'd1: response_byte = "K";
                        3'd2: response_byte = 8'h0D;
                        default: response_byte = 8'h0A;
                    endcase
                end
                RESP_ERR: begin
                    case (index)
                        3'd0: response_byte = "E";
                        3'd1: response_byte = "R";
                        3'd2: response_byte = "R";
                        3'd3: response_byte = 8'h0D;
                        default: response_byte = 8'h0A;
                    endcase
                end
                RESP_ON: begin
                    case (index)
                        3'd0: response_byte = "O";
                        3'd1: response_byte = "N";
                        3'd2: response_byte = 8'h0D;
                        default: response_byte = 8'h0A;
                    endcase
                end
                default: begin
                    case (index)
                        3'd0: response_byte = "O";
                        3'd1: response_byte = "F";
                        3'd2: response_byte = "F";
                        3'd3: response_byte = 8'h0D;
                        default: response_byte = 8'h0A;
                    endcase
                end
            endcase
        end
    endfunction

    assign reply_data  = response_byte(active_id, byte_index);
    assign reply_last  = (byte_index == byte_count - 1'b1);
    // 见文件头：最后一个字节的 ready 拍就要落 valid，否则 reporter 会重发它
    assign reply_valid = active && !(reply_ready && reply_last);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active     <= 1'b0;
            active_id  <= RESP_ERR;
            byte_index <= 3'd0;
            byte_count <= 3'd4;
        end else begin
            if (response_valid && response_ready) begin
                active     <= 1'b1;
                active_id  <= response_id;
                byte_index <= 3'd0;
                case (response_id)
                    RESP_OK, RESP_ON: byte_count <= 3'd4;   // OK\r\n / ON\r\n
                    default:          byte_count <= 3'd5;   // ERR\r\n / OFF\r\n
                endcase
            end else if (active && reply_ready) begin
                if (reply_last) begin
                    active     <= 1'b0;
                    byte_index <= 3'd0;
                end else begin
                    byte_index <= byte_index + 1'b1;
                end
            end
        end
    end
endmodule
