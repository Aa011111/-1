`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// media_uart_console：本工程的串口控制台，第五讲"可观测性层"的落地实例。
//
// 一个模块把三块拼齐，顶层只需要接两根管脚 + 几根已有的状态/控制线：
//
//   uart_rxd ──> uart_rx_byte ──> uart_cmd_core ──reply_*──┐
//   （第五讲原件）      │  framing_error = line_abort       │
//                       │                                   v
//                       └──> 诊断码            uart_status_reporter ──> uart_txd
//                                              （第五讲原件，内含唯一的 uart_tx_byte）
//
// 全部跑在 ctrl = sd_card_clk (100MHz) 域：和按键事件、fat32 摄入、
// media_player_control 同域，所以 next/prev/auto/period 这几个控制口
// 不需要任何跨时钟域。volume / brightness 要送到 video_clk 域消费，
// 那一段跨域在顶层用 common/cdc_bus_commit.v 做，不在本模块里。
//
// ---------------------------------------------------------------------------
// 【发送路只有一个 uart_tx_byte，两类输出在 reporter 内部排队】
// 板上只有一根 uart_txd。第五讲的 reporter 已经是这条路的唯一主人，它的
// ST_IDLE 优先级是：
//     reply（命令回复） > BAD > banner > ERR > PIC > VOL/PRD > BRT > CON
// 所以一条命令下去会看到两行：先 OK/ERR（reply 通道），再对应的事件日志行
// （reporter 自己的通道）。这是第五讲定的分工——reply 是"命令应答"，
// reporter 自己那六类是"状态日志"，不要把它们合成一条。
//
// 【switch_event 没有 pending 锁存，这点要当心】
// reporter 的 menu_event / bright_event 进去会被锁成 pending，忙完再发；
// 但 switch_event 是每拍无条件打拍（reporter:176 switch_q <= switch_event），
// reporter 忙时给过去就丢了。本模块的 switch_event 有两个来源：
//   a) media_id 变化：图片切换是秒级事件，reporter 不可能连续忙那么久；
//   b) STATUS 命令：由 uart_command_engine 延后到 OK 发完才打，见那边注释。
// 另外 reporter 的 ST_IDLE 里 ERR 优先于 PIC，且 error_code 非 0 期间
// switch_q 会被跳过——出故障时优先报错误码，这是原件的取舍，照留。
//
// 【error_code 只喂 sd 域看得见的那几个】
// 顶层传进来什么就报什么。UART 自己的故障（行溢出、帧错）【不】进这个口，
// 走下面的 diag_code 给数码管——否则 UART 一个帧错就会让 error_code 长期
// 非 0，把 PIC 行全挡住。
//
// 【坏图明细 BAD nn xx】
// 顶层的 bad_image_capture（本文件末尾）把 loader 的单张失败翻译成
// {图号, 失败原因码} 单拍事件送进来，这里记下来，reporter 空了逐条取。
// 单张图失败只走这条路，不进 error_code。串口命令 "1" 把记录从头再发一遍，
// 连同 banner 和当前 ERR（开机那几秒串口助手还没打开时用）。
//
// 本文件末尾还有 uart_dual_port：顶层用它把同一路串口同时接到 J2 排针和
// 板载 USB 串口两个物理口。
// ---------------------------------------------------------------------------

module media_uart_console #(
    // sd_card_clk = 100MHz，115200 波特 -> 868 拍/位
    // 实际波特率 100e6/868 = 115207.4Hz，偏差 0.006%，8N1 十位帧累积远小于半位
    parameter integer CLK_FREQ_HZ        = 100_000_000,
    parameter integer BAUD_RATE          = 115_200,
    parameter integer CLKS_PER_BIT       = CLK_FREQ_HZ / BAUD_RATE,
    parameter [7:0]   DEFAULT_VOLUME     = 8'd255,
    parameter [7:0]   DEFAULT_BRIGHTNESS = 8'd255,
    parameter [7:0]   DEFAULT_CONTRAST   = 8'd128,   // 第十四讲，128 = 原样
    // UART 自身故障码，接在本工程现有诊断码之后
    // （0x0x~0x2x fat32 / 0x41~0x47 写侧 / 0x51~0x53 控制 / 0x61~0x64 读侧）
    parameter [7:0]   DIAG_OVERFLOW      = 8'h71,   // 行提交时回复通道忙，命令被丢
    parameter [7:0]   DIAG_FRAMING       = 8'h72,   // 接收停止位错（波特率/接线问题）
    parameter integer INDEX_W            = 2,       // 13 张图扩展：图片 index 位宽
    parameter integer FOCUS_COUNT        = 16       // FOC=NN 上限（顶层 = THUMB_COUNT）
) (
    input  wire        clk,               // sd_card_clk
    input  wire        rst_n,             // rst_n_sd

    // 管脚
    input  wire        uart_rxd,
    output wire        uart_txd,

    // 播放器状态（ctrl 域电平）
    input  wire        report_enable,     // 上升沿触发 banner，接 display_valid
    input  wire [INDEX_W-1:0] media_id,   // 接 player_pending_index（与本模块同域）
    input  wire        auto_enabled,
    input  wire [7:0]  error_code,        // 顶层汇总的播放器故障码
    // 坏图明细（单拍）：一张图摄入失败的图号 + 失败原因码，来自 bad_image_capture
    input  wire        bad_valid,
    input  wire [INDEX_W-1:0] bad_index,
    input  wire [7:0]  bad_code,

    // 播放器控制（ctrl 域）
    output wire        next_event,
    output wire        prev_event,
    output wire        auto_cfg_valid,
    output wire        auto_cfg_enabled,
    output wire        period_cfg_valid,
    output wire [31:0] period_cfg_cycles,
    output wire [7:0]  volume,
    output wire [7:0]  brightness,
    output wire        thumb_cfg_valid,    // 第十三讲：THUMB / FULL
    output wire        thumb_cfg_enabled,
    output wire        select_event,       // 第十五讲：SEL，缩略图下确认选择
    output wire        focus_cfg_valid,    // 触控屏：FOC=NN，直接设缩略图焦点
    output wire [7:0]  focus_cfg_index,    // 0 起

    // 第十四讲：亮度/对比度设定脉冲（给 adjust/picture_param_ctrl）。
    // 脉冲那一拍 brightness / contrast 已经是新值。
    output wire [7:0]  contrast,
    output wire        bright_cfg_valid,
    output wire        contrast_cfg_valid,
    // 第十四讲：按键(KEY3/KEY4)改了参数时也要打日志，由 picture_param_ctrl 送进来。
    // 串口自己改的值走内部那一路，这两组只在按键改时有效，不会重复打。
    input  wire        key_bright_event,
    input  wire [7:0]  key_bright_value,
    input  wire        key_contrast_event,
    input  wire [7:0]  key_contrast_value,

    // 四边环绕频谱（VIS=XX），电平，消费方在 video 域
    output wire [7:0]  vis_cfg,

    // 诊断（给数码管，粘滞）
    output wire [7:0]  diag_code
);
    wire       rx_valid;
    wire [7:0] rx_data;
    wire       rx_framing_error;

    wire       reply_valid;
    wire [7:0] reply_data;
    wire       reply_last;
    wire       reply_ready;

    wire        cmd_overflow;
    wire        status_event;
    wire        replay_event;
    wire        menu_event;
    wire [1:0]  menu_kind;
    wire [31:0] period_ms;
    wire        bright_event;
    wire [7:0]  bright_value;
    wire        contrast_event;

    assign bright_cfg_valid   = bright_event;
    assign contrast_cfg_valid = contrast_event;

    // 日志来源合并：串口命令 or 按键。两者同拍撞上时按键那一行丢掉
    // （值已经被串口覆盖，报串口的值才是真实状态）。
    wire       log_bright_event   = bright_event   || key_bright_event;
    wire [7:0] log_bright_value   = bright_event   ? bright_value : key_bright_value;
    wire       log_contrast_event = contrast_event || key_contrast_event;
    wire [7:0] log_contrast_value = contrast_event ? contrast     : key_contrast_value;

    // ---- 图片切换检测：media_id 与本模块同域，直接比较 ----
    reg [INDEX_W-1:0] media_id_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            media_id_q <= {INDEX_W{1'b0}};
        else
            media_id_q <= media_id;
    end
    wire media_changed = (media_id != media_id_q);

    // ---- switch_event 的 pending + 发射时机（见文件头那条说明）----
    // reporter 的 switch_event 是每拍无条件打拍（reporter:176），它忙的时候
    // 给过去就丢。仿真里实测过：紧跟在一条 "ERR\r\n" 回复后面切图，switch_q
    // 到达时 reporter 还在 ST_REPLY 收尾，那行 PIC 日志就没了。
    //
    // 修法不碰第五讲原件：本模块先把事件记成 pending，等确认 reporter 真的
    // 空了再打一拍。"真的空了"用两个条件判定：
    //   1) uart_txd 已连续为高 11 个位时间 —— 8N1 一帧是 10 位，留一位余量，
    //      所以线上既没有正在发的字节，也没有刚起的起始位；
    //   2) reply_valid 为低 —— 回复通道优先级高于 switch（reporter ST_IDLE
    //      第一个分支就是 reply_valid），有回复待发时让它先走。
    //
    // 残余窗口只剩 1 拍：switch_event 打出去的下一拍如果 reply_valid 恰好
    // 抬起来，reporter 仍会优先回复。要在这一拍上撞，得让一条命令的回复
    // 正好在此刻成型；真撞上了也只是少一行日志，下次 media_id 变化会重报，
    // 播放器状态本身不受影响。
    localparam integer TX_IDLE_CYCLES = 11 * CLKS_PER_BIT;

    reg [31:0] tx_idle_cnt;      // 位宽照 uart_rx_byte/uart_tx_byte 原件取 32
    wire       tx_idle = (tx_idle_cnt >= TX_IDLE_CYCLES);
    reg        switch_pending;

    // reporter 在 switch_event 那一拍同时把 media_id 打进 switch_id_q
    // （reporter:176-177），两根必须同拍有效。延后发射不破坏这一点：
    // media_id 是电平，延后期间读到的仍是当前值；期间若又切了一次，
    // 报出来的是最新那张（两次切换合并成一行，符合"报当前状态"的语义）。
    wire switch_event = switch_pending && tx_idle && !reply_valid;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tx_idle_cnt    <= 32'd0;
            switch_pending <= 1'b0;
        end else begin
            if (!uart_txd)
                tx_idle_cnt <= 32'd0;
            else if (!tx_idle)
                tx_idle_cnt <= tx_idle_cnt + 1'b1;

            // 置位优先于清除：发射那一拍又来一次切换时不能把它吃掉
            if (media_changed || status_event)
                switch_pending <= 1'b1;
            else if (switch_event)
                switch_pending <= 1'b0;
        end
    end

    // ---- UART 自身故障：粘滞，与第10课板级 top 的 framing_error_latched 同构 ----
    reg framing_error_latched;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            framing_error_latched <= 1'b0;
        else if (rx_framing_error)
            framing_error_latched <= 1'b1;
    end

    // overflow 更靠近"命令没被执行"这个后果，优先报
    assign diag_code = cmd_overflow          ? DIAG_OVERFLOW :
                       framing_error_latched ? DIAG_FRAMING  : 8'h00;

    // ---- 串口命令 "1"：补发开机摄入结果 ----
    // BAD 行 / banner / ERR 都只在开机摄入时发一次，串口助手晚打开就看不到了。
    // 收到 "1" 先回 OK，再从头重发坏图记录，然后 banner（已在显示时）、当前 ERR（非 0 时）。
    // 和 STATUS 的 switch_event 一样，等 OK 发完、线路空闲（tx_idle）才动手：
    // replay_event 和 OK 回复同拍发出，reply_valid 与 replay_pending 同一个沿抬起来，
    // 所以 OK 一定先走（reporter ST_IDLE 里 reply 优先）。
    reg  replay_pending;
    wire replay_fire = replay_pending && tx_idle && !reply_valid;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            replay_pending <= 1'b0;
        else if (replay_event)
            replay_pending <= 1'b1;
        else if (replay_fire)
            replay_pending <= 1'b0;
    end

    // ---- 坏图明细记录 ----
    // 一行 "BAD nn xx\r\n" 11 字节，115200 下约 1ms；几张很小的坏文件可能每零点几
    // ms 就失败一张，reporter 里只锁一条会丢行，所以在这里记下来：还有没发的就给
    // reporter 挂着下一条，它在 ST_IDLE 取走时回 bad_ack，这边再出下一条。
    // 只追加、不覆盖：发过的也留着，命令 "1" 把读指针拨回 0 从头再发一遍。
    // 摄入只在上电跑一次，最多 IMAGE_COUNT（本工程 13）条，16 条装得下；
    // 万一满了丢新来的（同命令通道的 drop-new）。
    localparam integer BAD_DEPTH = 16;
    reg  [INDEX_W+7:0] bad_mem [0:BAD_DEPTH-1];
    reg  [4:0]         bad_wr_ptr;               // 已记录条数 0~16
    reg  [4:0]         bad_rd_ptr;               // 下一条要发的，0~bad_wr_ptr
    wire               bad_pending = (bad_rd_ptr != bad_wr_ptr);
    wire               bad_push    = bad_valid && (bad_wr_ptr != BAD_DEPTH);
    wire               bad_ack;
    wire [INDEX_W+7:0] bad_head    = bad_mem[bad_rd_ptr[3:0]];

    // 存储体放在无复位块里，让综合器推成分布式 RAM（同 media_frame_loader 的 fifo_mem）
    always @(posedge clk)
        if (bad_push)
            bad_mem[bad_wr_ptr[3:0]] <= {bad_index, bad_code};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            bad_wr_ptr <= 5'd0;
            bad_rd_ptr <= 5'd0;
        end else begin
            if (bad_push)
                bad_wr_ptr <= bad_wr_ptr + 1'b1;
            // 重发优先：和 bad_ack 同拍时那一条正在发，从头重发会再带上它
            if (replay_fire)
                bad_rd_ptr <= 5'd0;
            else if (bad_ack && bad_pending)
                bad_rd_ptr <= bad_rd_ptr + 1'b1;
        end
    end

    // ===================== 接收：第五讲原件 =====================
    uart_rx_byte #(
        .CLKS_PER_BIT(CLKS_PER_BIT)
    ) u_uart_rx_byte (
        .clk          (clk),
        .rst_n        (rst_n),
        .rx           (uart_rxd),
        .data         (rx_data),
        .valid        (rx_valid),
        .framing_error(rx_framing_error)
    );

    // ===================== 命令三层：第10课架构 =====================
    uart_cmd_core #(
        .DEFAULT_VOLUME    (DEFAULT_VOLUME),
        .DEFAULT_BRIGHTNESS(DEFAULT_BRIGHTNESS),
        .DEFAULT_CONTRAST  (DEFAULT_CONTRAST),
        .FOCUS_COUNT       (FOCUS_COUNT)
    ) u_uart_cmd_core (
        .clk              (clk),
        .rst_n            (rst_n),
        .rx_valid         (rx_valid),
        .rx_data          (rx_data),
        .line_abort       (rx_framing_error),
        .reply_valid      (reply_valid),
        .reply_data       (reply_data),
        .reply_last       (reply_last),
        .reply_ready      (reply_ready),
        .next_event       (next_event),
        .prev_event       (prev_event),
        .auto_cfg_valid   (auto_cfg_valid),
        .auto_cfg_enabled (auto_cfg_enabled),
        .period_cfg_valid (period_cfg_valid),
        .period_cfg_cycles(period_cfg_cycles),
        .volume           (volume),
        .brightness       (brightness),
        .thumb_cfg_valid  (thumb_cfg_valid),
        .thumb_cfg_enabled(thumb_cfg_enabled),
        .select_event     (select_event),
        .focus_cfg_valid  (focus_cfg_valid),
        .focus_cfg_index  (focus_cfg_index),
        .status_event     (status_event),
        .replay_event     (replay_event),
        .menu_event       (menu_event),
        .menu_kind        (menu_kind),
        .period_ms        (period_ms),
        .bright_event     (bright_event),
        .bright_value     (bright_value),
        .contrast         (contrast),
        .contrast_event   (contrast_event),
        .vis_cfg          (vis_cfg),
        .overflow         (cmd_overflow)
    );

    // ===================== 发送 + 状态日志：第五讲原件 =====================
    uart_status_reporter #(
        .INDEX_W(INDEX_W),
        .CLKS_PER_BIT(CLKS_PER_BIT)
    ) u_uart_status_reporter (
        .clk          (clk),
        .rst_n        (rst_n),
        .enable       (report_enable),
        .media_id     (media_id),
        .volume       (volume),
        .period_ms    (period_ms),
        .auto_enabled (auto_enabled),
        .switch_event (switch_event),
        .menu_event   (menu_event),
        .menu_kind    (menu_kind),
        .error_code   (error_code),
        .bright_event (log_bright_event),
        .bright_value (log_bright_value),
        .contrast_event(log_contrast_event),
        .contrast_value(log_contrast_value),
        .bad_valid    (bad_pending),
        .bad_index    (bad_head[INDEX_W+7:8]),
        .bad_code     (bad_head[7:0]),
        .bad_ack      (bad_ack),
        .replay       (replay_fire),
        .reply_valid  (reply_valid),
        .reply_data   (reply_data),
        .reply_last   (reply_last),
        .reply_ready  (reply_ready),
        .uart_tx      (uart_txd)
    );
endmodule

// -----------------------------------------------------------------------------
// bad_image_capture：把 media_frame_loader 的单张失败翻译成"哪张图、为什么"，
// 给 media_uart_console 打 BAD 行。顶层例化，跑在 sd_card_clk 域。
//
// loader 对所有解码类故障只给一个笼统的 ERR_DECODE(0x44)；具体是 BMP 头哪一项
// 不对（bmp24_decoder 的 0x31~0x38）还是单张 watchdog 超时（0x39），只出现在
// decode_error 上。loader 正是在 load_busy && decode_error != 0 那一拍
// fail_load 的，这里同拍把原始码抓下来；load_done 时 memory_error 非 0 就是
// 一张坏图：0x44 换成抓到的原始码，其余写侧故障（0x42/0x43/0x45/0x46）原样报。
//
// 图号在 load_start 时锁存（loader 也是这一拍锁 active_image），不能在 load_done
// 时取 image_index：watchdog 那条路上 load_done 到达时，fat32_storage_ingest_top
// 的 current_image 已经前进到下一张了。
// -----------------------------------------------------------------------------
module bad_image_capture #(
    parameter integer INDEX_W = 2
) (
    input  wire               clk,
    input  wire               rst_n,
    // fat32_storage_ingest_top -> loader 那几根
    input  wire               load_start,
    input  wire [INDEX_W-1:0] image_index,
    input  wire [7:0]         decode_error,
    // loader 的收尾结果
    input  wire               load_busy,
    input  wire               load_done,
    input  wire [7:0]         memory_error,
    // 给 media_uart_console（bad_valid 单拍，同拍 index/code 有效）
    output reg                bad_valid,
    output reg  [INDEX_W-1:0] bad_index,
    output reg  [7:0]         bad_code
);
    localparam [7:0] LOADER_ERR_DECODE = 8'h44;   // media_frame_loader 的 ERR_DECODE

    reg [INDEX_W-1:0] load_index;
    reg [7:0]         raw_code;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            load_index <= {INDEX_W{1'b0}};
            raw_code   <= 8'h00;
            bad_valid  <= 1'b0;
            bad_index  <= {INDEX_W{1'b0}};
            bad_code   <= 8'h00;
        end else begin
            if (load_start) begin
                load_index <= image_index;
                raw_code   <= 8'h00;
            end else if (load_busy && decode_error != 8'h00) begin
                raw_code   <= decode_error;
            end

            // load_done 那一拍 memory_error 就是这张的结果，raw_code 也已抓好
            bad_valid <= load_done && (memory_error != 8'h00);
            bad_index <= load_index;
            bad_code  <= (memory_error == LOADER_ERR_DECODE && raw_code != 8'h00) ?
                         raw_code : memory_error;
        end
    end
endmodule

// -----------------------------------------------------------------------------
// uart_dual_port：同一路串口同时接两个物理口，顶层例化，跑在 sd_card_clk 域。
//   口 A = J2 排针（N3 / P4），接触控屏或 USB-TTL 模块；
//   口 B = 板载 USB 串口（F12 / D12，11 UART 那 4 课的板级基线）。
// 原来只能二选一、要改 pin.adc 来回切；现在电脑插板子的 USB、触控屏插 J2，可以同时用。
//
//   TX：同一个信号同时驱动两个脚，两边收到的内容完全一样。
//   RX：两路线与（空闲为高，哪边拉低就是哪边在发）。两边恰好同时发会互相打坏，
//       表现为回 ERR 或数码管 0x72，调试时别和触控屏同时发命令。
//   线与的坑：一路被拉死在低电平（比如板载 USB 串口芯片没上电，ESD 二极管把
//   F12 钳住）会把另一路也堵死。所以每路先过 uart_rx_guard 判"接没接上"：
//   复位后要先见到连续 ARM_BITS 位时间的高电平才算接上，在那之前按高处理，
//   上电那一刻不会冒出假起始位；接上以后连续低超过 STUCK_BITS 位时间
//   （合法 8N1 帧最长连续低 9 位：起始位 + 8 个 0）就当掉线、屏蔽成高，
//   再见到高电平 ARM_BITS 位才恢复。
// -----------------------------------------------------------------------------
module uart_dual_port #(
    parameter integer CLKS_PER_BIT = 434,
    parameter integer ARM_BITS     = 2,
    parameter integer STUCK_BITS   = 20
) (
    input  wire clk,
    input  wire rst_n,
    input  wire rxd_a,          // 管脚，异步
    input  wire rxd_b,
    output wire rxd,            // 给 media_uart_console，已同步
    input  wire txd,            // 来自 media_uart_console
    output wire txd_a,
    output wire txd_b
);
    wire rx_a;
    wire rx_b;

    assign txd_a = txd;
    assign txd_b = txd;
    assign rxd   = rx_a & rx_b;

    uart_rx_guard #(
        .ARM_CYCLES  (ARM_BITS * CLKS_PER_BIT),
        .STUCK_CYCLES(STUCK_BITS * CLKS_PER_BIT)
    ) u_guard_a (
        .clk(clk), .rst_n(rst_n), .rx(rxd_a), .rx_out(rx_a)
    );

    uart_rx_guard #(
        .ARM_CYCLES  (ARM_BITS * CLKS_PER_BIT),
        .STUCK_CYCLES(STUCK_BITS * CLKS_PER_BIT)
    ) u_guard_b (
        .clk(clk), .rst_n(rst_n), .rx(rxd_b), .rx_out(rx_b)
    );
endmodule

// 一路 RX：2FF 同步 + "接没接上"判定，没接上时输出恒 1（见 uart_dual_port）
module uart_rx_guard #(
    parameter integer ARM_CYCLES   = 868,
    parameter integer STUCK_CYCLES = 8680
) (
    input  wire clk,
    input  wire rst_n,
    input  wire rx,
    output wire rx_out
);
    localparam integer CNT_W = $clog2(STUCK_CYCLES + 1);

    reg             rx_meta;
    reg             rx_sync;
    reg             live;
    reg [CNT_W-1:0] run;        // rx_sync 保持当前电平的拍数，封顶 STUCK_CYCLES

    assign rx_out = rx_sync | ~live;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rx_meta <= 1'b1;
            rx_sync <= 1'b1;
            live    <= 1'b0;
            run     <= {CNT_W{1'b0}};
        end else begin
            rx_meta <= rx;
            rx_sync <= rx_meta;
            // 下一拍 rx_sync 要变，计数从 0 重来
            if (rx_meta != rx_sync)
                run <= {CNT_W{1'b0}};
            else if (run != STUCK_CYCLES)
                run <= run + 1'b1;

            if (rx_sync && run >= ARM_CYCLES)
                live <= 1'b1;
            else if (!rx_sync && run >= STUCK_CYCLES)
                live <= 1'b0;
        end
    end
endmodule
