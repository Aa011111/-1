`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// uart_command_engine：第10课原件结构 + 本工程的播放器动作。
//
// 讲义原件把 cmd_code 变成 led 电平；本工程把它变成 media_video_pipeline /
// media_player_control 已经留好的那几个控制口，一根都不用新开：
//
//   NEXT / PREV     -> next_event / prev_event 单拍脉冲（顶层与按键事件 OR）
//   AUTO ON/OFF     -> auto_cfg_valid + auto_cfg_enabled
//   PRD=XXXX        -> period_cfg_valid + period_cfg_cycles
//   VOL=XX / BRT=XX -> volume / brightness 电平（顶层经 cdc_bus_commit 进 pix 域）
//   STATUS          -> status_event，喂给 uart_status_reporter 的 switch_event
//   THUMB / FULL    -> thumb_cfg_valid + thumb_cfg_enabled（第十三讲，缩略图/全屏）
//   CON=XX          -> contrast 电平 + contrast_event（第十四讲，对比度）
//   SEL             -> select_event 单拍脉冲（第十五讲，缩略图下确认选择）
//   VIS=XX          -> vis_cfg 电平（四边环绕频谱，顶层经 cdc_bus_commit 进 pix 域）
//   FOC=NN          -> focus_cfg_valid + focus_cfg_index（触控屏直接设缩略图焦点，
//                      NN 从 01 起，送出去的 index 从 0 起；NN > FOCUS_COUNT 回 ERR）
//   1               -> replay_event 单拍脉冲（media_uart_console 等 OK 发完后让 reporter
//                      补发开机摄入结果：BAD 行 / READY / 当前 ERR）
//   （没有 TIM=：本工程时间经 RS-485 从外部屏取，校时在外部屏上做）
//
// 第十四讲：亮度/对比度的"最终持有者"改成了 adjust/picture_param_ctrl
// （它还要接 KEY3/KEY4 的加减）。本层的 brightness / contrast 寄存器保留，
// 语义是"串口最后一次设定的值"；bright_event / contrast_event 同时兼作
// 给 picture_param_ctrl 的设定脉冲——事件那一拍寄存器已经是新值。
//
// 就绪窗口沿用讲义那条关键写法：
//   cmd_ready = response_ready && !response_valid && (prd_stage == 0)
// 前两项原因见讲义 3.1——response_valid 是寄存器输出，从执行命令到回复调度
// 层捕获之间有一拍窗口，这一拍不压低 cmd_ready 的话第二条命令会覆盖还没被
// 捕获的回复。第三项是本工程加的，见下面 PRD 那段。
//
// ---------------------------------------------------------------------------
// 【PRD 的 ms -> cycles 换算为什么要 3 拍】
// media_player_control 的 period_cfg_cycles 单位是 ctrl 域时钟拍
// （本工程 ctrl = sd_card_clk = 50MHz），而 uart_status_reporter 打印的
// period_ms 单位是毫秒。所以要算 cycles = ms * CYCLES_PER_MS = ms * 50000。
// 50000 不是 2 的幂，直接写乘号会让综合器摊一个 16x16 的乘法器直通
// period_cfg_cycles 寄存器；本机没有 TD 也没有板子，100MHz 下这条路径能不能
// 收敛我给不出结论，所以改成移位加法并切成流水：
//   50000 = 2^15 + 2^14 + 2^9 + 2^8 + 2^6 + 2^4
//   （32768 + 16384 + 512 + 256 + 64 + 16 = 50000，可以自己验）
//   （sd_card_clk 原来是 100MHz，当时是 100000 = 2^16+2^15+2^10+2^9+2^7+2^5，
//    降到 50MHz 后六个移位量整体减 1。）
// 六项拆两组各三项，stage1 算两个部分和，stage2 合并，stage3 才发 valid，
// 每一拍最多三个 32 位数相加。
// 时间上完全不紧张：同一条命令的 OK 回复要发 5 个字节 ≈ 434us @115200，
// 这 3 拍（60ns）早就走完了。cmd_ready 里带上 prd_stage==0 只是免费的保险。
//
// 换算常数做成 parameter CYCLES_PER_MS 只为了记录意图；真正参与运算的是
// 下面那六个写死的移位量，改时钟频率必须同时改这六项，不能只改 parameter。
// 目前 sd_card_clk = 50MHz -> 50000，与 parameter 一致。
// ---------------------------------------------------------------------------

module uart_command_engine #(
    parameter [7:0]  DEFAULT_VOLUME     = 8'd255,
    parameter [7:0]  DEFAULT_BRIGHTNESS = 8'd255,
    parameter [7:0]  DEFAULT_CONTRAST   = 8'd128,   // 第十四讲，128 = 原样
    parameter [7:0]  DEFAULT_VIS        = 8'h12,    // 频谱开，旋转 2 像素/帧
    // 只影响 period_ms 的复位值（reporter 打印用）。真正生效的默认周期是
    // media_video_pipeline 的 DEFAULT_PERIOD_CYCLES，两者必须对得上：
    // 顶层是 150_000_000 拍 @50MHz = 3000ms。
    parameter [15:0] DEFAULT_PERIOD_MS  = 16'd3000,
    parameter integer CYCLES_PER_MS     = 50000,   // 见上，仅记录意图
    // FOC=NN 的上限：缩略图里有几格可选（顶层 = THUMB_COUNT = 11）
    parameter integer FOCUS_COUNT       = 16
) (
    input  wire        clk,
    input  wire        rst_n,

    // 来自 uart_line_parser
    input  wire        cmd_valid,
    input  wire [4:0]  cmd_code,
    input  wire [15:0] cmd_arg,
    output wire        cmd_ready,

    // 去 uart_response_tx
    input  wire        response_ready,
    output reg         response_valid,
    output reg  [2:0]  response_id,

    // 播放器控制（ctrl = sd_card_clk 域）
    output reg         next_event,
    output reg         prev_event,
    output reg         auto_cfg_valid,
    output reg         auto_cfg_enabled,
    output reg         period_cfg_valid,
    output reg  [31:0] period_cfg_cycles,
    output reg  [7:0]  volume,
    output reg  [7:0]  brightness,
    output reg         thumb_cfg_valid,    // 第十三讲
    output reg         thumb_cfg_enabled,
    output reg         select_event,       // 第十五讲：SEL
    output reg         focus_cfg_valid,    // 触控屏：FOC=NN
    output reg  [7:0]  focus_cfg_index,    // 0 起

    // 去 uart_status_reporter 的事件口
    output reg         status_event,      // 接 reporter 的 switch_event（OR 进去）
    output reg         replay_event,      // "1"：补发开机摄入结果，console 负责等 OK 发完
    output reg         menu_event,
    output reg  [1:0]  menu_kind,         // 0 = VOL，1 = PRD（reporter 的约定）
    output reg  [31:0] period_ms,         // reporter 打印用，5 位 hex
    output reg         bright_event,
    output reg  [7:0]  bright_value,

    // 第十四讲：对比度
    output reg  [7:0]  contrast,
    output reg         contrast_event,

    // 四边环绕频谱
    output reg  [7:0]  vis_cfg
);
    localparam [4:0] CMD_NEXT     = 5'd0;
    localparam [4:0] CMD_PREV     = 5'd1;
    localparam [4:0] CMD_AUTO_ON  = 5'd2;
    localparam [4:0] CMD_AUTO_OFF = 5'd3;
    localparam [4:0] CMD_STATUS   = 5'd4;
    localparam [4:0] CMD_VOL      = 5'd5;
    localparam [4:0] CMD_BRT      = 5'd6;
    localparam [4:0] CMD_PRD      = 5'd7;
    localparam [4:0] CMD_THUMB    = 5'd8;
    localparam [4:0] CMD_FULL     = 5'd9;
    localparam [4:0] CMD_CON      = 5'd10;   // 第十四讲
    localparam [4:0] CMD_SEL      = 5'd11;   // 第十五讲
    localparam [4:0] CMD_VIS      = 5'd12;   // 四边环绕频谱
    localparam [4:0] CMD_FOC      = 5'd13;   // 触控屏：缩略图直接设焦点
    // 5'd14 原是 TIM（DS3231 校时），已去掉，parser 不会再发这个码
    localparam [4:0] CMD_REPLAY   = 5'd16;   // "1"：补发开机摄入结果

    // 回复编号与 uart_response_tx 的字符串表一致
    localparam [2:0] RESP_OK  = 3'd0;
    localparam [2:0] RESP_ERR = 3'd1;

    // PRD 换算流水
    reg [1:0]  prd_stage;
    reg [15:0] prd_ms_q;
    reg [31:0] prd_part_a;
    reg [31:0] prd_part_b;
    wire [31:0] prd_ms_ext = {16'h0000, prd_ms_q};

    // status_event 直接在命令执行那一拍打出去，不在本层等 reporter 空闲：
    // 这件事统一由 media_uart_console 的 switch_pending + tx_idle 门控负责
    // （reporter 的 switch_event 没有 pending 锁存，忙时会丢，理由见那边的
    // 注释）。本层只管"这条命令要求重报一次状态"这个意图。
    assign cmd_ready = response_ready && !response_valid && (prd_stage == 2'd0);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            response_valid    <= 1'b0;
            response_id       <= RESP_ERR;
            next_event        <= 1'b0;
            prev_event        <= 1'b0;
            auto_cfg_valid    <= 1'b0;
            auto_cfg_enabled  <= 1'b0;
            period_cfg_valid  <= 1'b0;
            period_cfg_cycles <= 32'd0;
            volume            <= DEFAULT_VOLUME;
            brightness        <= DEFAULT_BRIGHTNESS;
            thumb_cfg_valid   <= 1'b0;
            thumb_cfg_enabled <= 1'b0;
            select_event      <= 1'b0;
            focus_cfg_valid   <= 1'b0;
            focus_cfg_index   <= 8'd0;
            status_event      <= 1'b0;
            replay_event      <= 1'b0;
            menu_event        <= 1'b0;
            menu_kind         <= 2'd0;
            period_ms         <= {16'h0000, DEFAULT_PERIOD_MS};
            bright_event      <= 1'b0;
            bright_value      <= DEFAULT_BRIGHTNESS;
            contrast          <= DEFAULT_CONTRAST;
            contrast_event    <= 1'b0;
            vis_cfg           <= DEFAULT_VIS;
            prd_stage         <= 2'd0;
            prd_ms_q          <= 16'd0;
            prd_part_a        <= 32'd0;
            prd_part_b        <= 32'd0;
        end else begin
            // 所有单拍脉冲默认落低
            response_valid   <= 1'b0;
            next_event       <= 1'b0;
            prev_event       <= 1'b0;
            auto_cfg_valid   <= 1'b0;
            period_cfg_valid <= 1'b0;
            thumb_cfg_valid  <= 1'b0;
            select_event     <= 1'b0;
            focus_cfg_valid  <= 1'b0;
            status_event     <= 1'b0;
            replay_event     <= 1'b0;
            menu_event       <= 1'b0;
            bright_event     <= 1'b0;
            contrast_event   <= 1'b0;

            // ---- PRD 换算流水 ----
            case (prd_stage)
                2'd1: begin
                    prd_part_a <= (prd_ms_ext << 15) + (prd_ms_ext << 14) + (prd_ms_ext <<  9);
                    prd_part_b <= (prd_ms_ext <<  8) + (prd_ms_ext <<  6) + (prd_ms_ext <<  4);
                    prd_stage  <= 2'd2;
                end
                2'd2: begin
                    period_cfg_cycles <= prd_part_a + prd_part_b;
                    prd_stage         <= 2'd3;
                end
                2'd3: begin
                    // period_cfg_cycles 已在上一拍稳定，这一拍和 valid 同时有效
                    period_cfg_valid <= 1'b1;
                    period_ms        <= prd_ms_ext;
                    menu_event       <= 1'b1;
                    menu_kind        <= 2'd1;        // PRD
                    prd_stage        <= 2'd0;
                end
                default: ;   // 2'd0 = 空闲
            endcase

            // ---- 命令执行 ----
            if (cmd_valid && cmd_ready) begin
                response_valid <= 1'b1;
                case (cmd_code)
                    CMD_NEXT: begin
                        next_event  <= 1'b1;
                        response_id <= RESP_OK;
                        // 图片真的换了以后，reporter 自己会因 media_id 变化
                        // 打出 PIC 行，这里不用补 status_event
                    end
                    CMD_PREV: begin
                        prev_event  <= 1'b1;
                        response_id <= RESP_OK;
                    end
                    CMD_AUTO_ON: begin
                        auto_cfg_valid   <= 1'b1;
                        auto_cfg_enabled <= 1'b1;
                        response_id      <= RESP_OK;
                        status_event     <= 1'b1;    // 让 PIC 行把 A/M 标志报出来
                    end
                    CMD_AUTO_OFF: begin
                        auto_cfg_valid   <= 1'b1;
                        auto_cfg_enabled <= 1'b0;
                        response_id      <= RESP_OK;
                        status_event     <= 1'b1;
                    end
                    CMD_STATUS: begin
                        response_id  <= RESP_OK;
                        status_event <= 1'b1;
                    end
                    CMD_VOL: begin
                        volume      <= cmd_arg[7:0];
                        response_id <= RESP_OK;
                        menu_event  <= 1'b1;
                        menu_kind   <= 2'd0;         // VOL
                        // reporter 的 K_VOL 取的是它自己的 volume 输入口，
                        // 顶层接的就是本模块这根 volume，同拍已经是新值
                    end
                    CMD_BRT: begin
                        brightness   <= cmd_arg[7:0];
                        response_id  <= RESP_OK;
                        bright_event <= 1'b1;
                        bright_value <= cmd_arg[7:0];
                    end
                    CMD_PRD: begin
                        prd_ms_q    <= cmd_arg;
                        prd_stage   <= 2'd1;         // 启动 3 拍换算
                        response_id <= RESP_OK;
                    end
                    CMD_THUMB: begin
                        thumb_cfg_valid   <= 1'b1;
                        thumb_cfg_enabled <= 1'b1;
                        response_id       <= RESP_OK;
                    end
                    CMD_FULL: begin
                        thumb_cfg_valid   <= 1'b1;
                        thumb_cfg_enabled <= 1'b0;
                        response_id       <= RESP_OK;
                    end
                    CMD_CON: begin
                        contrast       <= cmd_arg[7:0];
                        contrast_event <= 1'b1;
                        response_id    <= RESP_OK;
                    end
                    CMD_SEL: begin
                        // 全屏模式下 thumbnail_controller 不理它，仍回 OK：
                        // 命令本身合法，和 FULL 在全屏下回 OK 是同一个取舍
                        select_event <= 1'b1;
                        response_id  <= RESP_OK;
                    end
                    CMD_VIS: begin
                        vis_cfg     <= cmd_arg[7:0];
                        response_id <= RESP_OK;
                    end
                    CMD_FOC: begin
                        // parser 已保证 1..99；这里只拦上限。全屏下也回 OK、
                        // 也照设，进缩略图时 thumbnail_controller 会重新落位
                        if (cmd_arg <= FOCUS_COUNT) begin
                            focus_cfg_valid <= 1'b1;
                            focus_cfg_index <= cmd_arg[7:0] - 8'd1;
                            response_id     <= RESP_OK;
                        end else begin
                            response_id     <= RESP_ERR;
                        end
                    end
                    CMD_REPLAY: begin
                        replay_event <= 1'b1;
                        response_id  <= RESP_OK;
                    end
                    default:
                        response_id <= RESP_ERR;     // CMD_ERROR 与未定义码
                endcase
            end
        end
    end
endmodule
