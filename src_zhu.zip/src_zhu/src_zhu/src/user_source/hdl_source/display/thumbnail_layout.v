`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十三讲（讲义第12课）图片缩放与缩略图
// thumbnail_layout：2x2 缩略图布局 + 最近邻缩放坐标映射，纯组合逻辑。
//
// 讲义原件 + 两处小修正（行为在默认参数下逐位相同）：
//  1) 缩放比例用 DISPLAY_WIDTH / DISPLAY_HEIGHT 算，不写死 640/480——讲义
//     Q1 让"先检查参数"，参数就应该真的参与运算。
//  2) window_x/window_y/local_x/local_y 在 always 块开头先给默认值。原件只在
//     if 分支里赋值，综合器会把这四个 integer 推成锁存器（TD 报 latch 警告）。
//
// 本工程例化时 THUMB_WIDTH/HEIGHT 传 H_ACT/2、V_ACT/2（320x240），四张缩略图
// 铺满整屏，缩放比 2:1；讲义默认的 160x120 只占左上 1/4 屏，其余留黑。
// 模块本身对两种参数都成立。
//
// 第十五讲（讲义第14课 2.4 加载状态显示）扩展，thumb_de/source_* 不变：
//  3) focus_border 不再要求 image_complete。焦点现在能停在未加载的格子上
//     （讲义要求焦点 0->1->2->3 全走，确认时再用 image_complete 拦），
//     原件那样只在已加载格子画框的话，焦点一走到空格子就"消失"了。
//  4) 新增 cell_edge：本像素在所在格子最外 2 像素的圈上（不管加载与否），
//     给 pipeline 画"当前正在播放那张"的白框用。
//  5) 新增 placeholder：未加载格子里两条对角线（约 3 像素宽的 X），
//     给 pipeline 画占位符。直线判据 |y*W - x*H| < 2*W（即纵向偏差 < 2 行），
//     常数乘法综合成移位加。
// media_frame_reader 里那一份例化 image_complete 接 4'b1111、这三根不接，
// 新增逻辑会被综合器整个剪掉，mem 域时序不受影响。
//
// 13 张图扩展：网格从写死的 2x2 改成 COLS x ROWS（默认仍是 2x2，行为逐位不变）。
//  6) 格子号 = 行 * COLS + 列，宽 CELL_W 位；列/行用"跨过了几条格线"算，不做除法。
//  7) 新增 cell_unused：格子号 >= USED_CELLS（比如 4x4 只放 13 张，后 3 格没有
//     对应图片），pipeline 给它画纯底色，不画"未加载"的 X。
// -----------------------------------------------------------------------------
module thumbnail_layout #(
    parameter integer DISPLAY_WIDTH = 640,
    parameter integer DISPLAY_HEIGHT = 480,
    parameter integer THUMB_WIDTH = 160,
    parameter integer THUMB_HEIGHT = 120,
    parameter integer COLS = 2,
    parameter integer ROWS = 2,
    parameter integer CELL_W = 2,                 // 格子号位宽，>= clog2(COLS*ROWS)
    parameter integer USED_CELLS = COLS * ROWS    // 前多少格有对应图片
) (
    input  wire                    in_de,
    input  wire [11:0]             pixel_x,
    input  wire [11:0]             pixel_y,
    input  wire [CELL_W-1:0]       focus_index,
    input  wire [COLS*ROWS-1:0]    image_complete,
    output reg                     thumb_de,
    output reg  [CELL_W-1:0]       source_index,
    output reg  [9:0]              source_x,
    output reg  [9:0]              source_y,
    output reg                     focus_border,
    output reg                     cell_edge,       // 第十五讲
    output reg                     placeholder,     // 第十五讲
    output reg                     cell_unused      // 13 张图扩展
);
    integer window_x;
    integer window_y;
    integer local_x;
    integer local_y;
    integer diag_main;   // 第十五讲：主对角线偏差 y*W - x*H
    integer diag_anti;   // 第十五讲：副对角线偏差 y*W - (W-1-x)*H
    integer col;
    integer row;
    integer k;
    always @* begin
        thumb_de = 1'b0;
        source_index = {CELL_W{1'b0}};
        source_x = 10'd0;
        source_y = 10'd0;
        focus_border = 1'b0;
        cell_edge = 1'b0;
        placeholder = 1'b0;
        cell_unused = 1'b0;
        col = 0;
        row = 0;
        window_x = 0;
        window_y = 0;
        local_x = 0;
        local_y = 0;
        diag_main = 0;
        diag_anti = 0;
        if (in_de && pixel_x < DISPLAY_WIDTH && pixel_y < DISPLAY_HEIGHT) begin
            for (k = 1; k < COLS; k = k + 1)
                if (pixel_x >= k * THUMB_WIDTH)
                    col = k;
            for (k = 1; k < ROWS; k = k + 1)
                if (pixel_y >= k * THUMB_HEIGHT)
                    row = k;
            source_index = row * COLS + col;
            window_x = col * THUMB_WIDTH;
            window_y = row * THUMB_HEIGHT;
            local_x = pixel_x - window_x;
            local_y = pixel_y - window_y;
            cell_unused = (row * COLS + col) >= USED_CELLS;
            if (local_x < THUMB_WIDTH && local_y < THUMB_HEIGHT) begin
                cell_edge = (local_x < 2 || local_y < 2 ||
                             local_x >= THUMB_WIDTH-2 || local_y >= THUMB_HEIGHT-2);
                focus_border = (source_index == focus_index) && cell_edge;
                if (image_complete[source_index]) begin
                    thumb_de = 1'b1;
                    source_x = local_x * (DISPLAY_WIDTH / THUMB_WIDTH);
                    source_y = local_y * (DISPLAY_HEIGHT / THUMB_HEIGHT);
                end else begin
                    diag_main = local_y * THUMB_WIDTH - local_x * THUMB_HEIGHT;
                    diag_anti = local_y * THUMB_WIDTH - (THUMB_WIDTH - 1 - local_x) * THUMB_HEIGHT;
                    placeholder = (diag_main < 2 * THUMB_WIDTH && diag_main > -2 * THUMB_WIDTH) ||
                                  (diag_anti < 2 * THUMB_WIDTH && diag_anti > -2 * THUMB_WIDTH);
                end
            end
        end
    end
endmodule
