# 第十三讲 —— 图片缩放与缩略图（讲义第12课）

## 讲义要求 vs 本工程补齐情况

| 讲义内容 | 本工程改造前 | 补齐后 |
|---|---|---|
| `thumbnail_layout.v`：2x2 布局 + 最近邻坐标映射 | 无 | `display/thumbnail_layout.v`（讲义原件，修了锁存器推断） |
| reader 按 source_index/x/y 读像素 | reader 只会整帧顺序读 | `framebuf4bank/media_frame_reader.v` 加缩略图读模式 |
| 控制层：缩略图/全屏切换 + 焦点 | 无 | `media_player_control` 持有 `thumb_mode`；焦点 = `active_index` |
| 焦点边框、未加载图涂黑 | 无 | `media_video_pipeline` 的 pix 侧遮罩 |
| 支持不同分辨率 BMP | 只收 640x480 | 另收 1280x960，解码时 2x2 求平均缩到 640x480 |
| 双线性插值（选做，完赛未实现） | 无 | `display/bilinear_8q8.v` 补齐 G/B，**不接入链路**，附 `sim/tb_bilinear_8q8.v` |

## 操作方式

| 操作 | 全屏模式 | 缩略图模式 |
|---|---|---|
| KEY1 短按 / 串口 `NEXT` | 下一张（淡出淡入） | 黄框移到下一格（无转场） |
| **KEY1 长按 ≥1s** | 进入缩略图 | 回到全屏，显示黄框那张 |
| KEY2 长按 / 串口 `PREV` | 上一张（Wipe） | 黄框移到上一格 |
| KEY2 短按 / `AUTO ON/OFF` | 自动轮播 | 自动轮播 = 黄框每 3s 走一格 |
| 串口 `THUMB` / `FULL` | 明确进入缩略图 / 全屏，回 `OK` | 同左 |

注意：KEY1 的"下一张"从按下沿改成了松开沿触发（长短按要在松开时才能区分）。

## 缩略图模式怎么实现的

```
屏幕 640x480 = 2x2，每格 320x240，2:1 最近邻
 ┌─────────┬─────────┐
 │ PIC1(0) │ PIC2(1) │   source_x = local_x*2
 ├─────────┼─────────┤   source_y = local_y*2
 │ PIC3(2) │ PIC4(3) │
 └─────────┴─────────┘
```

- **没有用讲义默认的 160x120**：那样只占左上 1/4 屏。模块参数化没变，例化时传 320x240。
- **reader 不按像素跳着读**：`sdr_as_ram` 是加密 IP，原件的读 burst 永远 128 字对齐、
  不跨 SDRAM 行，逐像素跳读会跨行，没法验证 IP 支不支持。所以每条屏幕行照常读两条
  整源行（左图、右图各 5 个 128 字 burst），**只把偶数列写进 FIFO**——这就是水平
  2:1 抽取；源行号取 `(y mod 240)*2`——这就是垂直 2:1 抽取。读量翻倍（每行 1280 字），
  约占读带宽的 35%。写进 FIFO 的仍是每帧 307200 字，pix 侧节奏/underflow 判据不变。
- 地址映射和 pix 侧遮罩用的是**同一个** `thumbnail_layout`（mem 域一份、pix 域一份），
  两边映射天然一致。
- 模式在 `frame_start` 锁定（pix 侧 `thumb_frame_q` 和 reader 的 `request_thumb_pix`
  同一拍锁同一个值），不会半帧切换撕裂（讲义 Q3）。
- 缩略图帧不参与转场 alpha / Wipe，`BRT=` 亮度仍然生效；音频波形在缩略图帧关闭
  （否则压住下排两格）。

## 不同分辨率

`fat32_storage_ingest_top` 新增 `ALLOW_2X_SOURCE`，顶层设 1：`bmp24_decoder` 已有的
1280x960 路径被打开，解码时 2x2 求平均（box filter，比最近邻抗锯齿）。其它尺寸仍报
`0x32`（ERR_DIMENSIONS），和改造前一样跳过该图、其余正常。1280x960 文件 ~3.7MB，
单图 watchdog 从 2s 放宽到 8s。

### 任意尺寸自适应（裁剪铺满）

顶层再打开 `ALLOW_SCALE_SOURCE=1`：640x480 ~ 4096x4096 的任意 24 位 BMP 都能显示。
`bmp24_decoder` 先在源图中间裁出最大的 4:3 区域（宽图裁左右、高图裁上下），
再最近邻缩到 640x480，画面铺满、不变形、没有黑边。没有新增 BRAM、没有行缓存，
输出仍是每帧 307200 个像素，下游不变。

| 源图 | 处理 |
|---|---|
| 640x480 | 直通（与改造前逐位相同） |
| 1280x960 | 2x2 平均（与改造前逐位相同，画质最好） |
| 其它 >= 640x480、<= 4096x4096 | 居中裁 4:3 + 最近邻缩小 |
| 宽 < 640 或 高 < 480 或任一边 > 4096 | 拒收，`0x32` |

注意：只缩小不放大；读卡约 1MB/s，单张 watchdog 20s，约 20MB 以上（如 4000x3000 = 36MB）
会超时（`0x39`）跳过。手机原图建议先缩到 1920 宽以内，开机也快。
回归仿真：`sim/opt_equiv/run_bmp.do`。

## TD 工程变更

- `.al` 已备份为 `.al.bak_before_lesson13`，新增 `display/thumbnail_layout.v`（CompileOrder 90）
- `bilinear_8q8.v` 不进清单（未例化）
- `media_player_promax_top.sdc` 第 6 节加一条 `*/thumb_sync1_mem` false_path

## 上板验证

| # | 操作 | 预期 | 不对时看哪里 |
|---|---|---|---|
| 1 | TD 编译 | 无 undefined module、无 latch 警告来自 thumbnail_layout | `.al` 清单 |
| 2 | 上电全屏看图 | 与第十二讲完全相同 | thumb_mode=0 路径应逐拍不变 |
| 3 | KEY1 长按 1s 松开 | 4 张图 2x2 铺满，当前那张有 2 像素黄框 | 花屏/错位 → reader 的 `t_*` 游标、`keep_word` |
| 4 | 缩略图下 KEY1 短按 | 黄框按 index 0→1→2→3 走（左上→右上→左下→右下→回左上） | 框不动 → `active_index` 没提交 |
| 5 | 拿掉 PIC2.BMP | 右上格黑，黄框跳过它 | `image_complete_pix` |
| 6 | 缩略图下 KEY1 长按 | 回全屏，显示黄框那张，无撕裂 | 撕裂 → 模式没在 frame_start 锁定 |
| 7 | 串口 `THUMB` / `FULL` | 回 `OK`，模式切换 | parser 的 `hit_thumb`/`hit_full` |
| 8 | 放一张 1280x960 BMP | 正常显示（缩到 640x480），数码管无 `0x32` | `ALLOW_2X_SOURCE`；超时 `0x39` → watchdog |
| 9 | 缩略图模式放 10 分钟 | 数码管无 `0x61/0x62/0x63` | 带宽不够 → 看 `reader_underflow` |
