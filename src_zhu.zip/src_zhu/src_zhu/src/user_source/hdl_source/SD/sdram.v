`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: anlgoic
// Author: 	xg 
// description:  top module
//////////////////////////////////////////////////////////////////////////////////

`define DEBUG

`include "../user_source/hdl_source/include/global_def.v"

module sdram(
    `ifdef SIMULATION
	output					SDRAM_CLK,
	output					SDR_CKE,
	output					SDR_RAS,
	output					SDR_CAS,
	output					SDR_WE,
	output	[`BA_WIDTH-1:0]	SDR_BA,
	output	[`ROW_WIDTH-1:0]SDR_ADDR,
	output	[`DM_WIDTH-1:0]	SDR_DM,
	inout	[`DATA_WIDTH-1:0]	SDR_DQ,	
	`endif
    input   					Clk,
    input						Clk_sft,
    input						Rst,
    
    output 						Sdr_init_done,
    output						Sdr_init_ref_vld,
    output						Sdr_busy,
    
    input						App_wr_en,
	input [`ADDR_WIDTH-1:0]		App_wr_addr,  	
	input [`DM_WIDTH-1:0]		App_wr_dm,
	input [`DATA_WIDTH-1:0]		App_wr_din,	//synthesis keep
    
    input 						App_rd_en,
	input [`ADDR_WIDTH-1:0]		App_rd_addr,
	output 						Sdr_rd_en,
	output [`DATA_WIDTH-1:0]	Sdr_rd_dout	//synthesis keep
    
    
    
);
`ifndef SIMULATION
wire  			SDRAM_CLK;
wire 			SDR_RAS;
wire  			SDR_CAS;
wire  			SDR_WE;
wire  [`BA_WIDTH-1:0]	SDR_BA;
wire  [`ROW_WIDTH-1:0]	SDR_ADDR;
wire  [`DATA_WIDTH-1:0]	SDR_DQ ;
wire  [`DM_WIDTH-1:0]	SDR_DM;
`endif

// 显式周期性刷新请求：sdr_as_ram是加密IP（sdr_as_ram.enc.v），内部刷新逻辑不可见，
// 只能通过它暴露出来的App_ref_req输入主动请求一次刷新。之前这里硬编码1'b0，
// 完全靠self_refresh_open=1'b1让IP内部自己找空档插入刷新——第七讲FAT32升级把
// 图片改成开机一次性写入SDRAM、之后只读不写，暴露出"长时间只读不写"这个新的
// 访问模式下画面逐渐出现雪花噪点（白色背景最明显，因为0xFFFFFF全1电荷衰减
// 后翻成随机值最扎眼），是典型DRAM未及时刷新的表现。这里按SDRAM规范"64ms内
// 刷完全部行"换算出周期（2^ROW_WIDTH行，Sdr_clk周期用125MHz算），留了安全余量，
// 主动定时请求一次刷新，不再完全依赖加密IP内部黑盒的刷新调度。
localparam REFRESH_INTERVAL_CYCLES = 13'd3200; // 64ms/2^11行/8ns(125MHz)≈3906拍，留余量取3200
reg [12:0] refresh_cnt;
reg        refresh_pending;
reg        app_ref_req_r;

always @(posedge Clk or posedge Rst) begin
    if (Rst) begin
        refresh_cnt     <= 13'd0;
        refresh_pending <= 1'b0;
        app_ref_req_r   <= 1'b0;
    end else begin
        app_ref_req_r <= 1'b0;
        if (refresh_pending) begin
            // 等一个IP不忙的空档才发请求，不跟正在进行的读写指令抢
            if (!Sdr_busy) begin
                app_ref_req_r   <= 1'b1;
                refresh_pending <= 1'b0;
                refresh_cnt     <= 13'd0;
            end
        end else if (refresh_cnt >= REFRESH_INTERVAL_CYCLES) begin
            refresh_pending <= 1'b1;
        end else begin
            refresh_cnt <= refresh_cnt + 13'd1;
        end
    end
end

sdr_as_ram  #( .self_refresh_open(1'b1))
	u2_ram( 
		.Sdr_clk(Clk),
		.Sdr_clk_sft(Clk_sft),
		.Rst(Rst),
			  			  
		.Sdr_init_done(Sdr_init_done),
		.Sdr_init_ref_vld(Sdr_init_ref_vld),
		.Sdr_busy(Sdr_busy),
		
		.App_ref_req(app_ref_req_r),
		
        .App_wr_en(App_wr_en), 
        .App_wr_addr(App_wr_addr),  	
		.App_wr_dm(App_wr_dm),
		.App_wr_din(App_wr_din),

		.App_rd_en(App_rd_en),
		.App_rd_addr(App_rd_addr),
		.Sdr_rd_en	(Sdr_rd_en),
		.Sdr_rd_dout(Sdr_rd_dout),
	
		.SDRAM_CLK(SDRAM_CLK),
		.SDR_RAS(SDR_RAS),
		.SDR_CAS(SDR_CAS),
		.SDR_WE(SDR_WE),
		.SDR_BA(SDR_BA),
		.SDR_ADDR(SDR_ADDR),
		.SDR_DM(SDR_DM),
		.SDR_DQ(SDR_DQ)	
	);


assign SDR_CKE=1'b1;

//`ifndef SIMULATION
	EG_PHY_SDRAM_2M_32 sdram(
		.clk(SDRAM_CLK),
		.ras_n(SDR_RAS),
		.cas_n(SDR_CAS),
		.we_n(SDR_WE),
		.addr(SDR_ADDR[10:0]),
		.ba(SDR_BA),
		.dq(SDR_DQ),
		.cs_n(1'b0),
		.dm0(SDR_DM[0]),
		.dm1(SDR_DM[1]),
		.dm2(SDR_DM[2]),
		.dm3(SDR_DM[3]),
		.cke(1'b1)
		);
//`endif

endmodule 