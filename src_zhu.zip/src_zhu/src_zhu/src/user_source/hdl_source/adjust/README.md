# 第十四讲 —— 亮度对比度调节（讲义第13课）

## 讲义要求 vs 本工程补齐情况

| 讲义内容 | 本工程改造前 | 补齐后 |
|---|---|---|
| 亮度调节（2.1，折进转场 alpha） | 已有，串口 `BRT=XX` | 保留原做法；改成 **frame_start 锁存** 后再用 |
| 对比度调节（2.2，完赛未实现，练习） | 无 | `adjust/brightness_contrast_adjust.v`：TODO 补齐 + 四舍五入，插在 pipeline 转场之后 |
| 参数帧边界生效（2.5） | 亮度直接进乘法器，帧中间变会上下半屏不一致 | `media_video_pipeline` 里 `brightness_frame / contrast_frame` 在 frame_start 锁存 |
| 按键调节（2.4 / 3.3） | KEY1/KEY2 已被翻页/轮播/缩略图占满 | `adjust/picture_param_ctrl.v`：KEY3 亮度、KEY4 对比度，短按 +16，长按 1s 后每 200ms −16。**默认关闭**，见下 |
| 串口调节 | `BRT=XX` | 新增 `CON=XX`，回 `OK` + 日志行 `CON XX` |
| OSD 参数显示（2.6） | 无 | `adjust/picture_param_osd.v`：左上角 `B:255` / `C:128` + 进度条，调节后显示约 3 秒 |
| param_menu_controller（2.7，音量/周期） | 音量/周期已由串口 `VOL=`/`PRD=` 管 | 不重复引入；按键裁决写法照它的"松开沿判定"搬进 `picture_key_stepper` |

## 数据通路

```
ctrl(sd_card_clk)                                     pix(video_clk)
 串口 BRT=/CON= ─┐                                     ┌─ media_video_pipeline
 KEY3 / KEY4 ────┴─> picture_param_ctrl ─> cdc_bus_commit(24位) ─┤   frame_start 锁存
                        │ (key_*_event)                         │   亮度: eff_alpha
                        └─> 串口 reporter 打 BRT/CON 日志        │   对比度: brightness_contrast_adjust
                                                                └─ picture_param_osd（OSD 链末端）
```

## 公式

- 亮度（沿用第五讲）：`out = in × (alpha × (B+1) >> 8) >> 8`，B=255 逐位原样
- 对比度：`out = sat(((in − 128) × C + 64) >>> 7 + 128)`，C=128 逐位原样
- 默认 B=255、C=128，上电画面与第十三讲逐位相同（整条视频输出晚 1 个像素时钟，hs/vs/de/rgb 一起晚）

## 启用 KEY3 / KEY4

本工程 `pin.adc` 只有 key1(B2)/key2(C1)/rst_n(A2)，KEY3/KEY4 引脚未核实，所以默认关闭（关闭时只有串口能调）。

1. 查原理图，在 `constraints_source/pin.adc` 末尾把 `key3`/`key4` 两行取消注释，`??` 改成真实管脚
2. 在 `top_tf_hdmi_audio.v` 顶部去掉 `` // `define LESSON14_KEY34 `` 的注释

两处必须同时开/关。

## TD 工程变更

- `.al` 已备份为 `.al.bak_before_lesson14`，新增 `adjust/` 下 3 个 `.v`（CompileOrder 91~93）
- sdc 不用改：新增跨域只有 `cdc_bus_commit` 加宽，第一级 `commit_sync1` 已被通配覆盖
- 资源：对比度 3 个 9×9 有符号乘法（亮度不新增乘法器）

## 上板验证

| # | 操作 | 预期 | 不对时看哪里 |
|---|---|---|---|
| 1 | TD 编译 | 无 undefined module | `.al` 清单 |
| 2 | 上电看图 | 与第十三讲相同，左上角没有面板 | C 默认值不是 128 → `VIDEO_CONTRAST` |
| 3 | 串口 `CON=00` | 回 `OK`、`CON 00`；整屏变成中灰；面板 C 行黄色，`C:000`，进度条空 | parser `hit_con` |
| 4 | 串口 `CON=FF` | 明暗对比明显加强，亮处发白、暗处发黑；`C:255` 进度条满 | 颜色异常 → `>>>` 与位宽 |
| 5 | 串口 `CON=80` | 画面恢复原样；进度条到中间刻度 | — |
| 6 | 串口 `BRT=40` | 画面变暗到约 1/4；B 行黄色 `B:064` | — |
| 7 | 连续发 `BRT=` 调节 | 画面没有上下半屏分界线 | 帧边界锁存 |
| 8 | 停止调节 3 秒 | 面板自动消失 | `SHOW_FRAMES` |
| 9 | 转场中调亮度 | 淡入淡出正常、亮度一起缩放 | eff_alpha |
| 10 | （启用按键后）KEY3 短按 / 长按 | 亮度 +16 / 每 200ms −16，串口打 `BRT xx` | `picture_key_stepper` |
