`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十四讲 亮度对比度调节（讲义第13课）
// picture_param_osd：讲义 2.6 的"OSD 参数显示"。屏幕左上角一块半透明面板：
//
//      B:255 [################]      <- 亮度，十进制 + 64 像素进度条
//      C:128 [########        ]      <- 对比度，进度条中点刻度 = 128(原样)
//
// 讲义 4.1 写的是"在 status_osd_overlay 基础上扩展"。本工程没有去改那个
// 模块：它是第八讲留下的纯组合 5x7 字模状态条（8,8 处 "1A00"），而这里要
// 的是 8x16 大字 + 进度条 + 半透明底，写法跟第九讲 timestamp_osd 同一套
// （4x6 字模横纵各放大 2 倍、字模预取一拍），单独成模块更清楚，挂在 OSD
// 链末端即可，和状态条不相交（状态条 y=8~15，本面板 y=20~63）。
//
// 显示时机（讲义 2.6 "调节时显示，调节完成后几秒自动隐藏"）：
//   每个 frame_start 把 brightness/contrast 锁存一次（讲义 2.5 帧边界生效，
//   面板上的数字和画面效果同帧变化）；锁存时发现值变了，就把倒计时装满
//   SHOW_FRAMES（默认 180 帧 ≈ 3s @59.5Hz），并记下是哪一项变了，那一行
//   高亮成黄色。倒计时到 0 面板消失。ALWAYS_SHOW=1 则常驻。
//   变化检测放在 pix 域做，所以不需要从 ctrl 域另外跨一根"事件"过来——
//   串口改的、按键改的都一样能触发。
//
// 十进制显示：8 位二进制 -> 3 位 BCD 用比较链（>=200/>=100、>=90...>=10），
//   只有比较和减常数，没有除法器；而且只在 frame_start 那一拍算一次、
//   结果寄存，不在像素路径上。
// -----------------------------------------------------------------------------

module picture_param_osd #(
    parameter integer OSD_X       = 8,        // 面板第一个字符的左上角
    parameter integer OSD_Y       = 24,
    parameter integer SHOW_FRAMES = 180,      // 调节后显示多少帧
    parameter integer ALWAYS_SHOW = 0,        // 1 = 常驻不隐藏
    parameter [23:0]  TEXT_COLOR  = 24'hE0E0E0,
    parameter [23:0]  HOT_COLOR   = 24'hFFFF00,   // 刚被调节的那一行
    parameter [23:0]  BAR_COLOR   = 24'h60A0FF,
    parameter [23:0]  FRAME_COLOR = 24'hFFFFFF
) (
    input  wire        clk,              // video_clk
    input  wire        rst_n,
    input  wire        de,
    input  wire        frame_start,
    input  wire [11:0] pixel_x,
    input  wire [11:0] pixel_y,
    input  wire [7:0]  brightness,       // pix 域（cdc_bus_commit 之后）
    input  wire [7:0]  contrast,
    input  wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire        osd_active
);
    // ---------------- 布局常数 ----------------
    // 每行：字符 5 格 x 8 像素 = 40，空 8，进度条 66（1 像素边框 + 64 填充）
    localparam integer CHAR_W   = 8;
    localparam integer CHAR_H   = 16;
    localparam integer ROW_PITCH = 20;              // 两行间距（16 + 4 空隙）
    localparam integer BAR_X0   = 48;              // 进度条左边框相对 OSD_X
    localparam integer BAR_X1   = BAR_X0 + 65;     // 右边框
    localparam integer PANEL_W  = BAR_X1 + 1;      // 114
    localparam integer PANEL_H  = ROW_PITCH + CHAR_H;  // 36
    localparam integer PAD      = 4;               // 半透明底比内容四周各大 4

    localparam [3:0] G_B     = 4'd10;
    localparam [3:0] G_C     = 4'd11;
    localparam [3:0] G_COLON = 4'd12;

    // ---------------- 帧边界锁存 + 显示倒计时 ----------------
    reg [7:0]  b_q, c_q;
    reg [11:0] b_bcd, c_bcd;
    reg        hot_row;          // 0 = 亮度行高亮，1 = 对比度行高亮
    reg [8:0]  show_cnt;

    function [11:0] to_bcd;
        input [7:0] v;
        reg   [7:0] r;
        reg   [3:0] h, t;
        begin
            if (v >= 8'd200)      begin h = 4'd2; r = v - 8'd200; end
            else if (v >= 8'd100) begin h = 4'd1; r = v - 8'd100; end
            else                  begin h = 4'd0; r = v;          end
            if      (r >= 8'd90) begin t = 4'd9; r = r - 8'd90; end
            else if (r >= 8'd80) begin t = 4'd8; r = r - 8'd80; end
            else if (r >= 8'd70) begin t = 4'd7; r = r - 8'd70; end
            else if (r >= 8'd60) begin t = 4'd6; r = r - 8'd60; end
            else if (r >= 8'd50) begin t = 4'd5; r = r - 8'd50; end
            else if (r >= 8'd40) begin t = 4'd4; r = r - 8'd40; end
            else if (r >= 8'd30) begin t = 4'd3; r = r - 8'd30; end
            else if (r >= 8'd20) begin t = 4'd2; r = r - 8'd20; end
            else if (r >= 8'd10) begin t = 4'd1; r = r - 8'd10; end
            else                 begin t = 4'd0;                end
            to_bcd = {h, t, r[3:0]};
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            b_q      <= 8'd255;
            c_q      <= 8'd128;
            b_bcd    <= 12'h255;
            c_bcd    <= 12'h128;
            hot_row  <= 1'b0;
            show_cnt <= 9'd0;
        end else if (frame_start) begin
            b_q   <= brightness;
            c_q   <= contrast;
            b_bcd <= to_bcd(brightness);
            c_bcd <= to_bcd(contrast);
            if (brightness != b_q) begin
                hot_row  <= 1'b0;
                show_cnt <= SHOW_FRAMES;
            end else if (contrast != c_q) begin
                hot_row  <= 1'b1;
                show_cnt <= SHOW_FRAMES;
            end else if (show_cnt != 9'd0) begin
                show_cnt <= show_cnt - 9'd1;
            end
        end
    end

    wire visible = (ALWAYS_SHOW != 0) || (show_cnt != 9'd0);

    // ---------------- 4x6 字模，返回一行 4 位，bit3 = 最左列 ----------------
    // 数字点阵与 osd/timestamp_osd.v 相同；B / C / 冒号是本模块新增的。
    function [3:0] glyph_row;
        input [3:0] g;
        input [2:0] row;
        begin
            case (g)
                4'd0: case (row) 0: glyph_row=4'b0110; 1,2,3,4: glyph_row=4'b1001; default: glyph_row=4'b0110; endcase
                4'd1: case (row) 0: glyph_row=4'b0110; 5: glyph_row=4'b0111; default: glyph_row=4'b0010; endcase
                4'd2: case (row) 0: glyph_row=4'b0110; 1: glyph_row=4'b0001; 2: glyph_row=4'b0110;
                                 3: glyph_row=4'b0100; 4: glyph_row=4'b1000; default: glyph_row=4'b0111; endcase
                4'd3: case (row) 0,2,5: glyph_row=4'b0110; default: glyph_row=4'b0001; endcase
                4'd4: case (row) 0,1: glyph_row=4'b1001; 2: glyph_row=4'b1111; default: glyph_row=4'b0001; endcase
                4'd5: case (row) 0: glyph_row=4'b1111; 1: glyph_row=4'b1000; 2: glyph_row=4'b1110;
                                 5: glyph_row=4'b0110; default: glyph_row=4'b0001; endcase
                4'd6: case (row) 0,5: glyph_row=4'b0110; 1: glyph_row=4'b1000; 2: glyph_row=4'b1110;
                                 default: glyph_row=4'b1001; endcase
                4'd7: case (row) 0: glyph_row=4'b1111; 1: glyph_row=4'b0001; default: glyph_row=4'b0010; endcase
                4'd8: case (row) 0,2,5: glyph_row=4'b0110; default: glyph_row=4'b1001; endcase
                4'd9: case (row) 0,5: glyph_row=4'b0110; 1: glyph_row=4'b1001; 2: glyph_row=4'b0111;
                                 default: glyph_row=4'b0001; endcase
                G_B:  case (row) 0,2,5: glyph_row=4'b1110; default: glyph_row=4'b1001; endcase
                G_C:  case (row) 0,5: glyph_row=4'b0111; default: glyph_row=4'b1000; endcase
                G_COLON: case (row) 1,4: glyph_row=4'b0110; default: glyph_row=4'b0000; endcase
                default: glyph_row = 4'b0000;
            endcase
        end
    endfunction

    // ---------------- 下一个像素的分类（预取一拍，规则同 timestamp_osd）----------------
    wire [11:0] next_x = de ? (pixel_x + 12'd1) : 12'd0;
    wire [11:0] dx = next_x  - OSD_X;
    wire [11:0] dy = pixel_y - OSD_Y;

    // 半透明底：内容区四周各扩 PAD
    wire in_panel = visible &&
                    (next_x  + PAD >= OSD_X) && (next_x  < OSD_X + PANEL_W + PAD) &&
                    (pixel_y + PAD >= OSD_Y) && (pixel_y < OSD_Y + PANEL_H + PAD);

    wire in_row0 = (pixel_y >= OSD_Y) && (pixel_y < OSD_Y + CHAR_H);
    wire in_row1 = (pixel_y >= OSD_Y + ROW_PITCH) && (pixel_y < OSD_Y + ROW_PITCH + CHAR_H);
    wire in_cols = (next_x >= OSD_X) && (next_x < OSD_X + PANEL_W);
    wire row_sel = in_row1;                                  // 0 = 亮度，1 = 对比度
    wire [11:0] ly = row_sel ? (dy - ROW_PITCH) : dy;        // 行内 y，0~15

    wire [7:0]  row_value = row_sel ? c_q   : b_q;
    wire [11:0] row_bcd   = row_sel ? c_bcd : b_bcd;

    wire [2:0] slot = dx[5:3];          // 字符格 0~4（dx < 40 时有效）
    wire [1:0] gcol = dx[2:1];          // 格内列 /2 -> 字模列 0~3
    wire [2:0] grow = ly[3:1];          // 格内行 /2 -> 字模行 0~7（用 0~5）

    reg [3:0] glyph;
    always @* begin
        case (slot)
            3'd0:    glyph = row_sel ? G_C : G_B;
            3'd1:    glyph = G_COLON;
            3'd2:    glyph = row_bcd[11:8];
            3'd3:    glyph = row_bcd[7:4];
            default: glyph = row_bcd[3:0];
        endcase
    end
    wire [3:0] glyph_bits = glyph_row(glyph, grow);

    wire in_row   = visible && in_cols && (in_row0 || in_row1);
    wire in_text  = in_row && (dx < 12'd40) && (grow < 3'd6) && glyph_bits[3 - gcol];

    // 进度条：竖向占行内 2~13，边框 1 像素，填充 64 像素 = value/4
    wire bar_rows   = (ly >= 12'd2) && (ly <= 12'd13);
    wire bar_cols   = (dx >= BAR_X0) && (dx <= BAR_X1);
    wire bar_frame  = in_row && bar_rows && bar_cols &&
                      ((dx == BAR_X0) || (dx == BAR_X1) || (ly == 12'd2) || (ly == 12'd13));
    wire [11:0] fill_pos = dx - (BAR_X0 + 1);                // 0~63
    wire bar_fill   = in_row && bar_rows && (dx > BAR_X0) && (dx < BAR_X1) &&
                      ({fill_pos[9:0], 2'b00} < {4'd0, row_value});
    // 对比度行在 128（原样）处画一道刻度，填充越过刻度=增强，没到=减弱
    wire bar_tick   = in_row && row_sel && bar_rows && (fill_pos == 12'd32) &&
                      (dx > BAR_X0) && (dx < BAR_X1);

    reg panel_q, text_q, frame_q, fill_q, tick_q, hot_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            panel_q <= 1'b0; text_q <= 1'b0; frame_q <= 1'b0;
            fill_q  <= 1'b0; tick_q <= 1'b0; hot_q   <= 1'b0;
        end else begin
            panel_q <= in_panel;
            text_q  <= in_text;
            frame_q <= bar_frame;
            fill_q  <= bar_fill;
            tick_q  <= bar_tick;
            hot_q   <= (row_sel == hot_row);
        end
    end

    // 半透明底 = 原像素每通道减半（移位，不占乘法器）
    wire [23:0] dim_rgb = {1'b0, rgb_in[23:17], 1'b0, rgb_in[15:9], 1'b0, rgb_in[7:1]};
    wire [23:0] ink     = hot_q ? HOT_COLOR : TEXT_COLOR;

    assign rgb_out = !de      ? rgb_in :
                     text_q   ? ink :
                     frame_q  ? FRAME_COLOR :
                     tick_q   ? FRAME_COLOR :
                     fill_q   ? (hot_q ? HOT_COLOR : BAR_COLOR) :
                     panel_q  ? dim_rgb :
                                rgb_in;
    assign osd_active = de && panel_q;
endmodule
