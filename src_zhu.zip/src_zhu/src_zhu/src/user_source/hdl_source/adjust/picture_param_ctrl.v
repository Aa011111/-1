`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十四讲 亮度对比度调节（讲义第13课）
// picture_param_ctrl：画面参数（亮度/对比度）的唯一持有者，ctrl 域。
//
// 讲义 2.7 的 param_menu_controller 管的是音量/轮播周期（本工程这两项
// 早就由串口 VOL= / PRD= 管），讲义 3.3 给的扩展建议是：
//     KEY3 短按增加亮度，长按减少亮度
//     KEY4 短按增加对比度，长按减少对比度
// 本模块按这条建议实现，按键裁决沿用 param_menu_controller 和本工程
// media_key_events 的共同写法——按住期间只计时，短按在【松开沿】判定，
// 所以一次按压不会同时触发加和减。长按在讲义基础上多了连发：
//     按住满 LONG_PRESS_MS  -> 减一档
//     之后每 REPEAT_MS       -> 再减一档（按住不放可以一路降到底）
//     长按后松开            -> 不再加，避免"降完又加回一档"
//
// 两个来源并存：
//   串口 BRT=XX / CON=XX  -> uart_*_valid + 值，直接设定（绝对值）
//   KEY3 / KEY4           -> 按 STEP 增减，0 和 255 处饱和
// 同一拍撞上时串口优先（人手敲命令和按键同拍到达的概率可以不考虑，
// 优先级只是为了语义确定）。
//
// 输出：
//   brightness / contrast   电平，顶层经 cdc_bus_commit 搬进 pix 域
//   key_*_event             单拍，只在【按键】改了参数时打，给串口 reporter
//                           打日志用。串口命令自己改的值 reporter 已经会报，
//                           这里不重复打，否则一条 BRT= 会出两行 BRT。
// key_*_event 和新值由同一个时钟沿写入，所以事件那一拍 brightness/contrast
// 已经是新值，reporter 直接采电平即可。
//
// 按键没有接（没有 KEY3/KEY4 引脚）时顶层把 key_*_n 接 1'b1，
// 消抖器看到的恒为"松开"，本模块就只剩串口一路。
// -----------------------------------------------------------------------------

module picture_param_ctrl #(
        parameter integer CLK_FREQ_HZ        = 100_000_000,
        parameter integer DEBOUNCE_MS        = 20,
        parameter integer LONG_PRESS_MS      = 1000,
        parameter integer REPEAT_MS          = 200,
        parameter [7:0]   DEFAULT_BRIGHTNESS = 8'd255,
        parameter [7:0]   DEFAULT_CONTRAST   = 8'd128,
        parameter [7:0]   BRIGHT_STEP        = 8'd16,
        parameter [7:0]   CONTRAST_STEP      = 8'd16
    ) (
        input  wire       clk,                 // sd_card_clk
        input  wire       rst_n,
        input  wire       ready,               // 有图可显示了才响应按键（=display_valid）

        input  wire       key_bright_n,        // KEY3，低有效
        input  wire       key_contrast_n,      // KEY4，低有效

        input  wire       uart_bright_valid,   // 串口 BRT=XX
        input  wire [7:0] uart_bright_value,
        input  wire       uart_contrast_valid, // 串口 CON=XX
        input  wire [7:0] uart_contrast_value,

        output reg  [7:0] brightness,
        output reg  [7:0] contrast,
        output reg        key_bright_event,
        output reg        key_contrast_event
    );
    wire bright_inc, bright_dec;
    wire contrast_inc, contrast_dec;

    picture_key_stepper #(
                            .CLK_FREQ_HZ  (CLK_FREQ_HZ),
                            .DEBOUNCE_MS  (DEBOUNCE_MS),
                            .LONG_PRESS_MS(LONG_PRESS_MS),
                            .REPEAT_MS    (REPEAT_MS)
                        ) u_key_bright (
                            .clk      (clk),
                            .rst_n    (rst_n),
                            .ready    (ready),
                            .key_n    (key_bright_n),
                            .inc_pulse(bright_inc),
                            .dec_pulse(bright_dec)
                        );

    picture_key_stepper #(
                            .CLK_FREQ_HZ  (CLK_FREQ_HZ),
                            .DEBOUNCE_MS  (DEBOUNCE_MS),
                            .LONG_PRESS_MS(LONG_PRESS_MS),
                            .REPEAT_MS    (REPEAT_MS)
                        ) u_key_contrast (
                            .clk      (clk),
                            .rst_n    (rst_n),
                            .ready    (ready),
                            .key_n    (key_contrast_n),
                            .inc_pulse(contrast_inc),
                            .dec_pulse(contrast_dec)
                        );

    // 饱和加减：不回绕，255 再加还是 255，0 再减还是 0
    function [7:0] sat_add;
        input [7:0] value;
        input [7:0] step;
        reg   [8:0] sum;
        begin
            sum = {1'b0, value} + {1'b0, step};
            sat_add = sum[8] ? 8'd255 : sum[7:0];
        end
    endfunction

    function [7:0] sat_sub;
        input [7:0] value;
        input [7:0] step;
        begin
            sat_sub = (value < step) ? 8'd0 : value - step;
        end
    endfunction

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            brightness         <= DEFAULT_BRIGHTNESS;
            contrast           <= DEFAULT_CONTRAST;
            key_bright_event   <= 1'b0;
            key_contrast_event <= 1'b0;
        end
        else begin
            key_bright_event   <= 1'b0;
            key_contrast_event <= 1'b0;

            if (uart_bright_valid) begin
                brightness <= uart_bright_value;
            end
            else if (bright_inc) begin
                brightness       <= sat_add(brightness, BRIGHT_STEP);
                key_bright_event <= 1'b1;
            end
            else if (bright_dec) begin
                brightness       <= sat_sub(brightness, BRIGHT_STEP);
                key_bright_event <= 1'b1;
            end

            if (uart_contrast_valid) begin
                contrast <= uart_contrast_value;
            end
            else if (contrast_inc) begin
                contrast           <= sat_add(contrast, CONTRAST_STEP);
                key_contrast_event <= 1'b1;
            end
            else if (contrast_dec) begin
                contrast           <= sat_sub(contrast, CONTRAST_STEP);
                key_contrast_event <= 1'b1;
            end
        end
    end
endmodule

// -----------------------------------------------------------------------------
// picture_key_stepper：单个按键 -> 加/减单拍脉冲。
// 消抖直接复用 fat32/media_playback_selector.v 里的 fat32_key_press_debounce
// （media_key_events 也是这么做的），不另写一份。
// -----------------------------------------------------------------------------
module picture_key_stepper #(
        parameter integer CLK_FREQ_HZ   = 100_000_000,
        parameter integer DEBOUNCE_MS   = 20,
        parameter integer LONG_PRESS_MS = 1000,
        parameter integer REPEAT_MS     = 200
    ) (
        input  wire clk,
        input  wire rst_n,
        input  wire ready,
        input  wire key_n,          // 低有效
        output reg  inc_pulse,      // 短按松开
        output reg  dec_pulse       // 长按到点 + 之后每 REPEAT_MS 一次
    );
    localparam [31:0] LONG_PRESS_CYCLES = (CLK_FREQ_HZ / 1000) * LONG_PRESS_MS;
    localparam [31:0] REPEAT_CYCLES     = (CLK_FREQ_HZ / 1000) * REPEAT_MS;

    wire key_stable;            // 1 = 松开，0 = 按下
    reg  key_stable_d;
    wire key_release = key_stable & ~key_stable_d;

    reg [31:0] hold_cnt;
    reg        long_marked;

    fat32_key_press_debounce #(
                                 .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(DEBOUNCE_MS)
                             ) u_debounce (
                                 .clk(clk), .rst(~rst_n), .button_in(key_n),
                                 .press_pulse(), .button_stable_out(key_stable)
                             );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key_stable_d <= 1'b1;
            hold_cnt     <= 32'd0;
            long_marked  <= 1'b0;
            inc_pulse    <= 1'b0;
            dec_pulse    <= 1'b0;
        end
        else begin
            inc_pulse    <= 1'b0;
            dec_pulse    <= 1'b0;
            key_stable_d <= key_stable;

            if (key_stable == 1'b0) begin
                // 按住：第一次到 LONG_PRESS 减一档，之后每 REPEAT 再减一档
                if (!long_marked) begin
                    if (hold_cnt >= LONG_PRESS_CYCLES - 1) begin
                        long_marked <= 1'b1;
                        hold_cnt    <= 32'd0;
                        dec_pulse   <= ready;
                    end
                    else begin
                        hold_cnt <= hold_cnt + 32'd1;
                    end
                end
                else begin
                    if (hold_cnt >= REPEAT_CYCLES - 1) begin
                        hold_cnt  <= 32'd0;
                        dec_pulse <= ready;
                    end
                    else begin
                        hold_cnt <= hold_cnt + 32'd1;
                    end
                end
            end
            else begin
                // 松开沿裁决：没到长按门限才算短按
                if (key_release && ready && !long_marked)
                    inc_pulse <= 1'b1;
                hold_cnt    <= 32'd0;
                long_marked <= 1'b0;
            end
        end
    end
endmodule
