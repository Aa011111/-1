`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十四讲 亮度对比度调节（讲义第13课）
// brightness_contrast_adjust：讲义 3.2.1 练习骨架 + 3.2.2 参考答案补齐版。
//
// 相对讲义骨架的三处改动：
//
//  改动1（TODO 补齐）：对比度 + 饱和截断按讲义 2.2 的公式实现
//      y = saturate((x - 128) * contrast / 128 + 128)
//    /128 用算术右移 >>>7；中间量全部 signed 并给足位宽。
//    右移前先加 64 做四舍五入（讲义参考答案是直接截断，负数会系统性
//    偏暗 1 LSB）。contrast=128 时 (c*128+64)>>>7 == c，旁路仍逐位不变。
//
//  改动2（亮度旁路逐位不变）：讲义骨架是 x*brightness>>8，brightness=255
//    时 255*255>>8=254，达不到讲义 3.2.3 第1条"输出和输入完全一致"。
//    这里改用 media_video_pipeline 同一套 (brightness+1)>>8 写法：
//    brightness=255 时 x*256>>8 = x，逐位不变。
//
//  改动3（BRIGHTNESS_EN 参数）：本工程的亮度早在第五讲就折进了转场 alpha
//    （media_video_pipeline 的 eff_alpha，讲义 2.1 说的"完赛做法"），
//    这里再乘一次就重复了。所以 pipeline 里例化时 BRIGHTNESS_EN=0，
//    亮度三个乘法器整段不生成，只剩对比度三个 9x9 有符号乘法。
//    单独拿本模块做练习/仿真时保持默认 1，就是讲义的"先亮度后对比度"级联。
//
// 时序：纯组合算完打一拍输出（讲义的流水线寄存器），out_de 同拍跟着打。
// 调用方负责把 hs/vs 也延一拍，保持整组对齐。
// 参数 brightness/contrast 由调用方在 frame_start 锁存后给进来（讲义 2.5），
// 本模块不再锁一次。
// -----------------------------------------------------------------------------

module brightness_contrast_adjust #(
    parameter integer BRIGHTNESS_EN = 1
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        in_de,
    input  wire [23:0] rgb_in,
    input  wire [7:0]  brightness,   // 帧边界锁存后的亮度，255 = 原样
    input  wire [7:0]  contrast,     // 帧边界锁存后的对比度，128 = 原样
    output reg         out_de,
    output reg  [23:0] rgb_out
);
    wire [23:0] final_rgb;

    genvar ch;
    generate
        for (ch = 0; ch < 3; ch = ch + 1) begin : g_ch
            wire [7:0] x = rgb_in[ch*8 +: 8];

            // ---- 亮度：x * (brightness+1) / 256 ----
            wire [7:0] bright;
            if (BRIGHTNESS_EN != 0) begin : g_bright
                wire [16:0] mul = {9'd0, x} * ({9'd0, brightness} + 17'd1);
                assign bright = mul[15:8];
            end else begin : g_bright_bypass
                assign bright = x;
            end

            // ---- 对比度：以 128 为中心拉伸/压缩 ----
            // ctr   : -128 ~ 127
            // prod  : -128*255 = -32640 ~ 127*255 = 32385，18 位有符号够用
            // scaled: -255 ~ 253
            // sum   : -127 ~ 381，出了 0~255 就截断
            wire signed [8:0]  ctr    = $signed({1'b0, bright}) - 9'sd128;
            wire signed [17:0] prod   = ctr * $signed({1'b0, contrast});
            wire signed [17:0] scaled = (prod + 18'sd64) >>> 7;   // 必须 >>>，不能 >>
            wire signed [17:0] sum    = scaled + 18'sd128;

            assign final_rgb[ch*8 +: 8] = (sum < 18'sd0)   ? 8'd0   :
                                          (sum > 18'sd255) ? 8'd255 : sum[7:0];
        end
    endgenerate

    // 打一拍输出（流水线寄存器），DE 跟着打拍
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            out_de  <= 1'b0;
            rgb_out <= 24'h000000;
        end else begin
            out_de  <= in_de;
            rgb_out <= final_rgb;
        end
    end
endmodule
