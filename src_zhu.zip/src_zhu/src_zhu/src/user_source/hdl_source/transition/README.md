# 第十讲 图片转场特效

讲义原件：`D:\code\anlu\第十讲：图片转场特效\第十课_图片转场特效.md`

## 作用

硬切改为有过渡的切换（对应赛题扩展要求第 2 点）：

| 触发来源 | 转场方式 | 过程 |
|---|---|---|
| 手动 next（KEY1 短按 / 串口 `NEXT`） | 淡入淡出 | 淡出 16 帧 → 全黑时放行切换请求 → 帧边界切 index → 淡入 16 帧 |
| 自动轮播 / prev / 首图落位 | Wipe 揭示 | 切换已由 control 内部完成，新图按 index 选 左→右 / 右→左 / 百叶窗 / 棋盘百叶窗 揭示 |

为什么手动切换要先淡到全黑：SDRAM 是单读端口，没法同时读两张图做交叉淡化，
所以走 "旧图→黑→新图"，一次只需要读一路。

## 文件位置

本讲核心模块在第八讲时就随 `media_video_pipeline` 一起进了工程，只是被
`FADE_FRAMES=0` 旁路掉了。**本讲的集成就是把顶层参数改成 16**，没有新增工程文件。

| 文件 | 是否在工程(.al)里 | 说明 |
|---|---|---|
| `../framebuf4bank/video_fade_transition.v` | 是 | 转场控制器：IDLE/OUT/HOLD/IN 四状态机 + 三组 toggle/2FF 跨域（与讲义原件相同，只修了第 74 行零宽拼接，见下） |
| `../framebuf4bank/media_video_pipeline.v` | 是 | 例化转场模块；`g_fade_mul` 分支做像素级 alpha 乘法 + Wipe 选择 |
| `../top_tf_hdmi_audio.v` | 是 | `FADE_FRAMES(16)` |
| `reference/frame_blend.v` | **否** | 两帧交叉混合（12 位 RGB），需要双读端口，本工程单端口用不上，仅供参考。别加进工程 |
| `sim/tb_video_fade_transition.v` | 否 | 仿真：转场模块 + media_player_control 联合 |

## 相对讲义原件的改动

`video_fade_transition.v` 第 74 行：讲义原件是
`assign ramp_out = {{(5-CNT_W){1'b0}}, ramp};`。FADE_FRAMES=16 时 CNT_W=5，
这会变成 `{0{1'b0}}` 零宽复制。ModelSim 只报 warning，但有些综合器会直接报错。
改成 `assign ramp_out = ramp;`，由赋值自动补零扩展，行为不变。

## 参数

`FADE_FRAMES` 取值要能整除 256，而且不能超过 16，因为 ramp_out 只有 5 位：

| FADE_FRAMES | 单程时长@60fps | 说明 |
|---|---|---|
| 0 | — | 旁路，硬切，像素和改造前逐位相同 |
| 8 | 0.13 s | 快 |
| 16 | 0.27 s | 当前取值 |

## 仿真

ModelSim（在任意空目录下）：

```
vlib work
vlog <hdl_source>/framebuf4bank/video_fade_transition.v <hdl_source>/framebuf4bank/media_player_control.v <hdl_source>/transition/sim/tb_video_fade_transition.v
vsim -c tb_video_fade_transition -do "run -all; quit -f"
```

期望输出：

```
case1 manual fade      : min_alpha=0 commits=1 index 0->1
case2 busy drop        : commits=1 index 1->2
case3 auto wipe        : commits=1 wipe_frames=16 max_ramp=15 kind=3
case4 single image     : commits=1 index 3->3 min_alpha=0
TB PASS
```

case4 验证的是只有一张图时按 next 不会卡在全黑：control 选回同一张图，照样发出 index_commit。

## 上板排查

- 还是硬切：先确认 `FADE_FRAMES` 不是 0，再确认 bit 是重新综合过的
- 按键连按没反应：这是正常行为，转场进行中的 next 会被丢弃
- 画面整体略暗 1 LSB：alpha=255 时乘完再右移 8 位，255→254，肉眼看不出
