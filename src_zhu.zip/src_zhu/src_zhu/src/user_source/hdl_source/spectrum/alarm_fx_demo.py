# -*- coding: utf-8 -*-
"""
火灾图（PIC12 / PIC13）频谱特效 —— 候选方案演示

分析器直接用 spectrum_model.Analyzer（逐位和 RTL 一致），只换"怎么画"：
  now      现在的四边彩虹 LED 旋转环（对照）
  A_ring   火焰边框：四边向内烧，火焰高度 = 频带柱高，越响越高越"热"
  A_bottom 火焰边框：只在底边，从下往上烧，低频在中间
  B        警灯呼吸：边框内发光，左右半屏反相交替，约 1.5Hz，亮度随音量
  C        报警配色 LED：几何同现在，不旋转，按段号用 橙→黄→白 热度色

画法全部按硬件思路写：整数、移位加法、xorshift 噪声（纯异或），不用除法，
不需要额外的帧缓存 / BRAM。只是演示，还不是 RTL 金标准。

  A_haze   A_ring + 底下一层红色晕染（边缘最红、平方衰减，随呼吸和音量变深）

用法：python alarm_fx_demo.py [起始秒] [帧数] [方案,逗号分隔] [12,13]
      输出到 preview/alarm_fx/；两张图都出时另拼一张 sheet.png
"""
import os
import sys

from PIL import Image

import spectrum_model as sm

W, H = sm.SCR_W, sm.SCR_H
N = sm.N_BANDS


# ----------------------------------------------------------------------------
# 公共小件
# ----------------------------------------------------------------------------
def xs16(a, b):
    """两个坐标 → 16 位伪随机。xorshift，只有移位和异或，LUT 里很便宜"""
    v = ((a & 0x1FF) | ((b & 0x7F) << 9)) ^ 0xACE1
    v ^= (v << 7) & 0xFFFF
    v ^= v >> 9
    v ^= (v << 8) & 0xFFFF
    return v


def blend_q(bg, col, a):
    """a = 0..4（四分之几），只用移位加法"""
    if a >= 4:
        return col
    if a <= 0:
        return bg
    if a == 2:
        return tuple((b >> 1) + (c >> 1) for b, c in zip(bg, col))
    if a == 1:
        return tuple((b >> 1) + (b >> 2) + (c >> 2) for b, c in zip(bg, col))
    return tuple((b >> 2) + (c >> 1) + (c >> 2) for b, c in zip(bg, col))


def blend_16(bg, col, a):
    """a = 0..16（十六分之几）。RTL：4 个移位项相加，或 3 个小乘法"""
    return tuple((b * (16 - a) + c * a) >> 4 for b, c in zip(bg, col))


def bar_interp(bars, k0, k1, frac16):
    """相邻两个频带柱高线性插值，frac 0..15（6bit x 4bit 小乘法）"""
    h0, h1 = bars[k0], bars[k1]
    return h0 + (((h1 - h0) * frac16) >> 4)


def fire_color(heat):
    """heat 0..255 → 火焰调色板（暗红→红→橙→黄→白），按高 2 位分段线性"""
    seg, t = heat >> 6, (heat & 63) << 2
    if seg == 0:
        return (96 + (t >> 1) + (t >> 2), 0, 0)              # 96..252 暗红→红
    if seg == 1:
        return (255, t >> 1, 0)                              # 红→橙
    if seg == 2:
        return (255, 128 + (t >> 1), t >> 3)                 # 橙→黄
    return (255, 255, 32 + t - (t >> 3))                     # 黄→白


# ----------------------------------------------------------------------------
# A：火焰
# ----------------------------------------------------------------------------
def tongue_noise(col, f):
    """沿边平滑的值噪声 0..31：每 16 列一个随机点，中间线性插值；
    随时间横向漂移 + 每 4 帧换一组点，火舌就会左右摆、此起彼伏"""
    c = col + (f >> 1)
    g, t = c >> 4, c & 15
    s = f >> 2
    n0 = xs16(g, s) & 31
    n1 = xs16(g + 1, s) & 31
    return n0 + (((n1 - n0) * t) >> 4)


def flame_pixel(bg, d, col, hgt, heat_k, f):
    """d=离火焰根部距离，col=沿边的列坐标，hgt=该列火焰高度"""
    hgt = hgt - ((tongue_noise(col, f) * hgt) >> 6)          # 火舌：高度按噪声削掉 0~50%
    if d >= hgt:
        # 火舌上方偶尔飘一点火星
        if d < hgt + 12:
            s = xs16(col, (d + f * 3) >> 1)
            if (s & 0x3FF) < 6:
                return (255, 200, 60)
        return bg
    lick = xs16(col >> 2, (d + f * 2) >> 2) & 15            # 小块，向内"涌"
    spark = xs16(col, d + f * 3) & 15                       # 细碎抖动
    heat = (hgt - d) * heat_k + lick + spark - 16
    if heat <= 0:
        return bg
    if heat > 255:
        heat = 255
    a = 1 if heat < 40 else 2 if heat < 80 else 3 if heat < 120 else 4
    return blend_q(bg, fire_color(heat), a)


def render_fire_ring(bg, bars, f):
    out = list(bg)
    depth = 64
    for y in range(H):
        xs = range(W) if (y < depth or y >= H - depth) else list(range(depth)) + list(range(W - depth, W))
        for x in xs:
            d, p = sm.pixel_geom(x, y)
            if d >= depth:
                continue
            bar = p >> 4
            k0 = sm.bar_to_band(bar)
            k1 = sm.bar_to_band(bar + 1 if bar + 1 < sm.N_BARS else 0)
            h = bar_interp(bars, k0, k1, p & 15)
            hgt = 6 + h + (h >> 2)                           # 6..56
            i = y * W + x
            out[i] = flame_pixel(bg[i], d, p, hgt, 5, f)
    return out


HAZE = 128           # 红色晕染从边缘往里的深度
HAZE_COLOR = (200, 0, 0)
BAYER4 = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def render_red_haze(bg, env, f):
    """火焰底下的红色晕染：离边越近越红（平方衰减，过渡柔和），
    整体随 BREATH 呼吸、随音量加深。返回新的底图，火焰再画在上面。
    RTL：(HAZE-d)^2 一个 7x7 小乘法，再乘强度，16 级混合 + 4x4 Bayer 抖动"""
    out = list(bg)
    gain = 128 + (env >> 1)                                 # 128..248
    inten = 112 + (tri(f % BREATH) * gain >> 9)             # 112..228，最暗时也有一层红
    for y in range(H):
        xs = range(W) if (y < HAZE or y >= H - HAZE) else list(range(HAZE)) + list(range(W - HAZE, W))
        for x in xs:
            d, _ = sm.pixel_geom(x, y)
            if d >= HAZE:
                continue
            r = HAZE - d
            a = ((r * r * inten) >> 14) + BAYER4[y & 3][x & 3]  # 16 级 + 有序抖动，消色阶
            a >>= 4
            if a:
                i = y * W + x
                out[i] = blend_16(bg[i], HAZE_COLOR, a)
    return out


def render_fire_bottom(bg, bars, f):
    out = list(bg)
    depth = 104
    for y in range(H - depth, H):
        d = H - 1 - y
        for x in range(W):
            u = x - 320 if x >= 320 else 319 - x               # 0..319，中间低频
            pos = u * 7                                        # u*35/320 ≈ u*7/64
            k0 = pos >> 6
            k1 = k0 + 1 if k0 + 1 < N else k0
            h = bar_interp(bars, k0, k1, (pos >> 2) & 15)
            hgt = 10 + h * 2                                   # 10..90
            i = y * W + x
            out[i] = flame_pixel(bg[i], d, x, hgt, 4, f)
    return out


# ----------------------------------------------------------------------------
# B：警灯呼吸
# ----------------------------------------------------------------------------
BREATH = 40          # 帧，≈1.5Hz，低于 WCAG 每秒 3 次的闪烁上限
GLOW = 64            # 发光带宽度


class Siren:
    def __init__(self):
        self.env = 0

    def frame(self, bars):
        lvl = sum(bars) * 7 >> 5                             # ≈ 平均柱高*7.5 → 0..300
        lvl = min(lvl, 240)
        self.env = lvl if lvl > self.env else max(0, self.env - 4)


def tri(phase):
    """0..BREATH-1 → 0..240 三角波（RTL 里是计数器 + 取反）"""
    v = phase if phase < BREATH // 2 else BREATH - 1 - phase
    return v * 12


def render_siren(bg, env, f, color):
    out = list(bg)
    gain = 128 + (env >> 1)                                 # 静音也能看到呼吸，越响越亮
    i_l = tri(f % BREATH) * gain >> 8
    i_r = tri((f + BREATH // 2) % BREATH) * gain >> 8
    for y in range(H):
        xs = range(W) if (y < GLOW or y >= H - GLOW) else list(range(GLOW)) + list(range(W - GLOW, W))
        for x in xs:
            d, _ = sm.pixel_geom(x, y)
            if d >= GLOW:
                continue
            inten = i_l if x < W // 2 else i_r
            if d < 4:
                a = inten >> 4                               # 最外 4 像素实线
            else:
                a = (inten * (GLOW - d)) >> 10               # 向内线性衰减，0..15
            if a > 16:
                a = 16
            i = y * W + x
            out[i] = blend_16(bg[i], color, a)
    return out


# ----------------------------------------------------------------------------
# C：报警配色 LED（不旋转）
# ----------------------------------------------------------------------------
SEG_HEAT = [(200, 40, 0), (220, 70, 0), (240, 100, 0), (255, 130, 0), (255, 160, 0),
            (255, 190, 10), (255, 215, 40), (255, 235, 90), (255, 248, 160), (255, 255, 230)]


def render_heat_led(bg, disp):
    out = list(bg)
    D = sm.DEPTH
    for y in range(H):
        xs = range(W) if (y < D or y >= H - D) else list(range(D)) + list(range(W - D, W))
        for x in xs:
            d, q = sm.pixel_geom(x, y)
            if d >= D:
                continue
            i = y * W + x
            b = bg[i]
            pos = q & 15
            if pos < 2 or pos > 13 or (d & 3) == 3:
                out[i] = tuple(c >> 1 for c in b)              # 缝也压暗，形成深色底轨
                continue
            band = sm.bar_to_band(q >> 4)
            seg = d >> 2
            col = SEG_HEAT[seg]
            hseg, pvalid, pseg = disp[band]
            if pvalid and seg == pseg and seg >= hseg:
                out[i] = (255, 255, 255)
            elif seg < hseg:
                out[i] = tuple((c >> 3) + v - (v >> 3) for c, v in zip(b, col))
            else:
                out[i] = tuple((c >> 2) + (v >> 4) for c, v in zip(b, col))
    return out


# ----------------------------------------------------------------------------
def run(pic, wav, t0, n_frames, siren_color, outdir, names):
    tag = os.path.splitext(os.path.basename(pic))[0].lower()
    an = sm.Analyzer()
    pcm = sm.load_wav(wav)
    bg = sm.load_bg(pic)
    siren = Siren()

    start = max(0, int((t0 - 1.5) * sm.FS))
    first = int(t0 * sm.FS)
    pos, acc, rot, f = start, 0.0, 0, 0
    frames = {k: [] for k in names}
    while f < n_frames and pos < len(pcm):
        acc += sm.FRAME_SAMPLES
        n = int(acc)
        acc -= n
        for j, s in enumerate(pcm[pos:pos + n]):
            an.sample(s, frame_pass=(j == 0))
        pos += n
        rot = rot + sm.SPIN_STEP - (sm.PERIM if rot + sm.SPIN_STEP >= sm.PERIM else 0)
        siren.frame(an.bar)
        if pos < first:
            continue
        f += 1
        if f % 2:                                           # 隔帧出图，GIF 33ms ≈ 实时
            continue
        fx = {
            'now': lambda: sm.render(bg, an.disp, rot),
            'A_ring': lambda: render_fire_ring(bg, an.bar, f),
            'A_haze': lambda: render_fire_ring(render_red_haze(bg, siren.env, f), an.bar, f),
            'A_bottom': lambda: render_fire_bottom(bg, an.bar, f),
            'B': lambda: render_siren(bg, siren.env, f, siren_color),
            'C': lambda: render_heat_led(bg, an.disp),
        }
        for k in names:
            px = fx[k]()
            im = Image.new('RGB', (W, H))
            im.putdata(px)
            frames[k].append(im)
        print('%s frame %d/%d' % (tag, f, n_frames), flush=True)

    stills = {}
    for k, fr in frames.items():
        fr[0].save(os.path.join(outdir, '%s_%s.gif' % (tag, k)), save_all=True,
                   append_images=fr[1:], duration=33, loop=0)
        stills[k] = fr[len(fr) // 2]
    return stills


ALL = ['now', 'A_ring', 'A_haze', 'A_bottom', 'B', 'C']


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    t0 = float(sys.argv[1]) if len(sys.argv) > 1 else 4.0
    n_frames = int(sys.argv[2]) if len(sys.argv) > 2 else 120
    names = sys.argv[3].split(',') if len(sys.argv) > 3 else ALL
    pics = sys.argv[4].split(',') if len(sys.argv) > 4 else ['12', '13']
    tf = os.path.normpath(os.path.join(here, '..', '..', '..', '..', '..', 'TF卡文件'))
    outdir = os.path.join(here, 'preview', 'alarm_fx')
    os.makedirs(outdir, exist_ok=True)

    # 警灯颜色要和底图反差：PIC12 底是黄橙 → 红光；PIC13 底是红 → 白黄光
    siren_color = {'12': (230, 0, 18), '13': (255, 235, 140)}
    stills = {}
    for n in pics:
        st = run(os.path.join(tf, 'PIC%s.BMP' % n), os.path.join(tf, 'MUSIC%s.WAV' % n), t0, n_frames,
                 siren_color[n], outdir, names)
        for k, im in st.items():
            im.save(os.path.join(outdir, 'pic%s_%s.png' % (n, k)))
        stills[n] = st

    # 拼版：每行一张图 x 每列一个方案，半尺寸
    if len(pics) > 1:
        sw, sh = W // 2, H // 2
        sheet = Image.new('RGB', (sw * len(names), sh * len(pics)), (0, 0, 0))
        for r, n in enumerate(pics):
            for c, k in enumerate(names):
                sheet.paste(stills[n][k].resize((sw, sh)), (c * sw, r * sh))
        sheet.save(os.path.join(outdir, 'sheet.png'))
    print('saved to', outdir)


if __name__ == '__main__':
    main()
