`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// spectrum_border_overlay：四边环绕音频频谱（video_clk 域，640x480）
//
// 效果参考 audioMotion-analyzer 的 radial + LED + prism 预设，把圆环改成沿屏幕
// 四条边的矩形环：每条边上的柱子从屏幕边缘向里长，频带沿边框排布，每帧整体
// 沿顺时针挪 spin 个像素 = "旋转"。效果预览和逐位模型见 spectrum_model.py。
//
// 【放在 OSD 链最前面，整条视频延迟 LAT=5 拍】
//   本工程其它 OSD 都是零延迟模块（当拍 pixel_x 当拍出 rgb），靠"字模预取一拍"
//   把组合深度压住。这里每个像素要做 最近边判定 → 周长坐标 → 加旋转取模 →
//   柱号/镜像 → 查表比较 → 混合，一拍塞不下。所以本模块接在
//   media_video_pipeline 输出之后、所有 OSD 之前，hs/vs/de/rgb 一起延迟 5 拍：
//   下游看到的仍是一套自洽的时序（osd_pixel_x/y 也是从延迟后的 de/vs 反推的），
//   一个下游模块都不用改。关掉频谱时延迟不变，只是像素直通。
//
// 【几何】d = 离最近边的距离（优先级 上>右>下>左，四角按对角线斜接）
//   周长坐标 p（顺时针，周长 2240）：上 x ；右 640+y ；下 1759-x ；左 2239-y
//   q = (p + rot) mod 2240 ； 柱号 = q>>4（140 根），柱内 2..13 点亮
//   频带 = 柱号镜像：0..34,34..0 重复两遍（低→高→低，绕两圈）
//   d < 40 才画，段号 seg = d>>2（10 段 LED），d%4==3 是段间缝
//
// 【配色/混合】prism 彩虹按频带着色，全部移位加法，不占 DSP：
//   点亮段  bg/8 + col*7/8      峰值段  col/2 + 128      暗格  bg*3/4 + col/16
//
// 【火警特效】alarm=1（显示 PIC12 预警 / PIC13 火灾）时 LED 环换成
//   alarm_fx_demo.py 的 A_haze 方案（模型 spectrum_model.fire_pixel，逐位一致）：
//   红色晕染  d<128：a = ((128-d)^2 * inten >> 14 + Bayer4x4) >> 4，16 级混合 (200,0,0)；
//             inten 随 40 帧呼吸（≈1.5Hz，低于 3Hz 闪烁上限）和音量包络变深
//   火焰      d<64：不旋转。火焰高 = 相邻两根柱的频带柱高插值 6..56，
//             沿边值噪声削火舌，xorshift 噪声（纯异或）做翻涌、细碎抖动和火星；
//             heat → 暗红/红/橙/黄/白 调色板，按 heat 分 4 级移位混合
//   帧状态（frame_start 更新）：fcnt 14 位帧计数、呼吸相位 0..39、音量包络 env
//   （上一遍 frame pass 的柱高和 *7/32，快攻、每帧 -4 慢放）。
//   用到 7 个乘法（最大 15x8），都在 25MHz 的单拍里，不需要额外 RAM。
//
// 【控制】cfg[7:4] != 0 打开，cfg[3:0] = 每帧旋转像素（UART VIS=XX，默认 12）
//   cfg / thumb / alarm 在 frame_start 锁存，帧内恒定。
// -----------------------------------------------------------------------------
module spectrum_border_overlay #(
    parameter COEF_FILE = "spectrum_coef.hex"
) (
    input  wire               clk,
    input  wire               rst_n,
    input  wire [7:0]         cfg,
    input  wire               thumb,          // 缩略图模式下关闭
    input  wire               alarm,          // 1 = 火警特效（已同步到 video 域的电平）
    // 音频（video_clk 域）
    input  wire               sample_valid,
    input  wire signed [15:0] sample,
    // 视频输入
    input  wire               hs_in,
    input  wire               vs_in,
    input  wire               de_in,
    input  wire [23:0]        rgb_in,
    // 视频输出（整体延迟 5 拍）
    output wire               hs_out,
    output wire               vs_out,
    output wire               de_out,
    output reg  [23:0]        rgb_out,
    output wire               overrun
);
    localparam integer LAT    = 5;
    localparam integer W      = 640;
    localparam integer H      = 480;
    localparam integer PERIM  = 2240;
    localparam integer DEPTH  = 40;
    localparam integer NB     = 35;
    localparam integer HAZE   = 128;
    localparam integer BREATH = 40;

    // ================= 输入侧坐标（和顶层 osd_pixel_x/y 同一写法）=================
    reg  [9:0] cx, cy;
    reg        de_d, vs_d;
    wire       frame_start = vs_in & ~vs_d;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            cx <= 10'd0; cy <= 10'd0; de_d <= 1'b0; vs_d <= 1'b0;
        end
        else begin
            de_d <= de_in;
            vs_d <= vs_in;
            if (de_in)
                cx <= cx + 10'd1;
            else begin
                cx <= 10'd0;
                if (de_d)
                    cy <= cy + 10'd1;
            end
            if (frame_start)
                cy <= 10'd0;
        end
    end

    // ================= 分析器 =================
    wire [5:0]  s3_band_w;
    wire [8:0]  disp;
    wire [5:0]  fx_k0_w, fx_k1_w;
    wire [5:0]  fx_h0, fx_h1;
    wire [10:0] bar_sum;

    spectrum_analyzer #(
        .COEF_FILE (COEF_FILE)
    ) u_spectrum_analyzer (
        .clk          (clk),
        .rst_n        (rst_n),
        .sample_valid (sample_valid),
        .sample       (sample),
        .frame_start  (frame_start),
        .rd_band      (s3_band_w),
        .rd_data      (disp),
        .rd_band_a    (fx_k0_w),
        .rd_h_a       (fx_h0),
        .rd_band_b    (fx_k1_w),
        .rd_h_b       (fx_h1),
        .bar_sum      (bar_sum),
        .overrun      (overrun)
    );

    // ================= 帧参数 =================
    reg  [11:0] rot;
    reg         en_f;
    reg         fire_f;
    reg  [13:0] fcnt;           // 帧计数（噪声只用低 14 位）
    reg  [7:0]  f3x;            // 3*fcnt mod 256，每帧 +3 递推，省一个像素级加法
    reg  [5:0]  ph;             // 呼吸相位 0..BREATH-1
    reg  [7:0]  env;            // 音量包络 0..240
    reg  [7:0]  inten;          // 晕染强度 112..222，帧内恒定
    wire [3:0]  spin = cfg[3:0];
    wire [12:0] rot_sum = {1'b0, rot} + spin;

    wire [13:0] lvl7    = {bar_sum, 3'b000} - bar_sum;            // *7，最大 9800
    wire [7:0]  lvl     = (lvl7[13:5] > 9'd240) ? 8'd240 : lvl7[12:5];
    wire [7:0]  env_dec = (env > 8'd4) ? env - 8'd4 : 8'd0;
    wire [4:0]  tri_v   = (ph < BREATH / 2) ? ph[4:0] : (BREATH - 1) - ph;   // 0..19
    wire [7:0]  tri12   = {tri_v, 3'b000} + {1'b0, tri_v, 2'b00};             // *12，0..228
    wire [7:0]  gain    = 8'd128 + {1'b0, env[7:1]};                          // 128..248
    wire [15:0] br_prod = tri12 * gain;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            rot    <= 12'd0;
            en_f   <= 1'b0;
            fire_f <= 1'b0;
            fcnt   <= 14'd0;
            f3x    <= 8'd0;
            ph     <= 6'd0;
            env    <= 8'd0;
            inten  <= 8'd112;
        end
        else begin
            if (frame_start) begin
                rot    <= (rot_sum >= PERIM) ? rot_sum - PERIM : rot_sum[11:0];
                en_f   <= (cfg[7:4] != 4'd0) && !thumb;
                fire_f <= alarm;
                fcnt   <= fcnt + 14'd1;
                f3x    <= f3x + 8'd3;
                ph     <= (ph == BREATH - 1) ? 6'd0 : ph + 6'd1;
                env    <= (lvl > env) ? lvl : env_dec;
            end
            inten <= 8'd112 + {1'b0, br_prod[15:9]};
        end
    end

    // ================= 视频延迟线 =================
    // rgb 只延 3 拍：S4 的 s4_bg（晕染后的底色，非火警时 = 原像素）顶替第 4 拍
    reg [LAT-1:0] hs_dl, vs_dl, de_dl;
    reg [23:0]    rgb_d1, rgb_d2, rgb_d3;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hs_dl <= {LAT{1'b0}}; vs_dl <= {LAT{1'b0}}; de_dl <= {LAT{1'b0}};
            rgb_d1 <= 24'd0; rgb_d2 <= 24'd0; rgb_d3 <= 24'd0;
        end
        else begin
            hs_dl  <= {hs_dl[LAT-2:0], hs_in};
            vs_dl  <= {vs_dl[LAT-2:0], vs_in};
            de_dl  <= {de_dl[LAT-2:0], de_in};
            rgb_d1 <= rgb_in;
            rgb_d2 <= rgb_d1;
            rgb_d3 <= rgb_d2;
        end
    end
    assign hs_out = hs_dl[LAT-1];
    assign vs_out = vs_dl[LAT-1];
    assign de_out = de_dl[LAT-1];

    // ================= 公共函数 =================
    // 柱号 0..139 → 频带，镜像（低→高→低）绕两圈
    function [5:0] bar_band;
        input [7:0] bar;
        reg   [7:0] bi;
        begin
            bi       = (bar >= 2 * NB) ? bar - 2 * NB : bar;
            bar_band = (bi < NB) ? bi[5:0] : (2 * NB - 1) - bi;
        end
    endfunction

    // 两个坐标 → 16 位伪随机（xorshift，只有异或），spectrum_model.xs16
    function [15:0] xs16;
        input [8:0] a;
        input [6:0] b;
        reg   [15:0] v;
        begin
            v    = {b, a} ^ 16'hACE1;
            v    = v ^ {v[8:0], 7'd0};
            v    = v ^ {9'd0, v[15:9]};
            xs16 = v ^ {v[7:0], 8'd0};
        end
    endfunction

    // ================= S1：最近边 / 距离 / 周长坐标 =================
    wire [9:0] dt = cy;
    wire [9:0] db = (H - 1) - cy;
    wire [9:0] dl = cx;
    wire [9:0] dr = (W - 1) - cx;
    wire       e_top   = (dt <= db) && (dt <= dl) && (dt <= dr);
    wire       e_right = (dr <= db) && (dr <= dl);
    wire       e_bot   = (db <= dl);

    reg  [9:0]  d_w;
    reg  [11:0] p_w;
    always @(*) begin
        if (e_top)        begin d_w = dt; p_w = {2'b00, cx}; end
        else if (e_right) begin d_w = dr; p_w = W + cy; end
        else if (e_bot)   begin d_w = db; p_w = (2 * W + H - 1) - cx; end
        else              begin d_w = dl; p_w = (PERIM - 1) - cy; end
    end

    reg        s1_ring;         // LED 环（非火警）
    reg        s1_fx;           // 火警晕染区 d<128
    reg [6:0]  s1_d;
    reg [11:0] s1_p;
    reg [3:0]  s1_bay;          // {y[1:0], x[1:0]}

    // ================= S2：加旋转取模（LED）/ 噪声与平方（火警）=================
    wire [12:0] q_sum = {1'b0, s1_p} + rot;
    reg        s2_ring;
    reg [6:0]  s2_d;
    reg [11:0] s2_q;

    // 下一根柱的频带 = 本柱频带 ±1；镜像拐点（bi=34）和绕回点（bi=69，下一根是 0 号柱）不变
    wire [7:0]  fx_bar  = s1_p[11:4];
    wire [7:0]  fx_bi   = (fx_bar >= 2 * NB) ? fx_bar - 2 * NB : fx_bar;      // 0..69
    wire [5:0]  fx_k0   = (fx_bi < NB) ? fx_bi[5:0] : (2 * NB - 1) - fx_bi;
    wire        fx_inc  = (fx_bi < NB - 1);
    wire        fx_dec  = (fx_bi > NB - 1) && (fx_bi != 2 * NB - 1);
    wire [5:0]  fx_k1   = fx_k0 + {{5{fx_dec}}, fx_inc | fx_dec};
    wire [12:0] fx_c    = {1'b0, s1_p} + fcnt[13:1];               // (p + f/2) mod 8192
    wire [8:0]  fx_g    = fx_c[12:4];
    wire [6:0]  fx_s    = fcnt[8:2];
    wire [15:0] fx_n0   = xs16(fx_g, fx_s);
    wire [15:0] fx_n1   = xs16(fx_g + 9'd1, fx_s);
    wire [8:0]  fx_d2   = {2'b00, s1_d} + {fcnt[7:0], 1'b0};       // (d + 2f) mod 512
    wire [7:0]  fx_d3   = {1'b0, s1_d} + f3x;                       // (d + 3f) mod 256
    wire [15:0] fx_lk   = xs16(s1_p[10:2], fx_d2[8:2]);
    wire [15:0] fx_sp   = xs16(s1_p[8:0], fx_d3[6:0]);
    wire [15:0] fx_em   = xs16(s1_p[8:0], fx_d3[7:1]);
    wire [7:0]  fx_r    = 8'd128 - s1_d;                            // 1..128

    reg         s2_fx, s2_fl;   // 晕染区 / 火焰区 d<64
    reg  [5:0]  s2_k0, s2_k1;
    reg  [3:0]  s2_frac, s2_t;
    reg  [4:0]  s2_n0, s2_n1;
    reg  [3:0]  s2_lick, s2_spk;
    reg         s2_emb;
    reg  [14:0] s2_rr;
    reg  [3:0]  s2_bay;
    assign fx_k0_w = s2_k0;
    assign fx_k1_w = s2_k1;

    // ================= S3：柱号镜像 → 频带；缝判定（LED）/ 火焰高与晕染系数（火警）=================
    wire [5:0] bnd  = bar_band(s2_q[11:4]);
    wire       on3  = s2_ring && (s2_q[3:0] >= 4'd2) && (s2_q[3:0] <= 4'd13) &&
                      (s2_d[1:0] != 2'd3);
    reg        s3_on;
    reg [5:0]  s3_band;
    reg [3:0]  s3_seg;
    assign s3_band_w = s3_band;

    // 相邻两带柱高插值：h0 + ((h1-h0)*frac >>> 4)，向下取整
    wire signed [6:0]  fx_dh  = $signed({1'b0, fx_h1}) - $signed({1'b0, fx_h0});
    wire signed [11:0] fx_dhm = fx_dh * $signed({1'b0, s2_frac});
    wire        [5:0]  fx_h   = fx_h0 + fx_dhm[9:4];                // 低 6 位补码相加
    wire        [5:0]  fx_hgt = 6'd6 + fx_h + {2'b00, fx_h[5:2]};   // 6..56
    // 火舌值噪声插值 0..31
    wire signed [5:0]  fx_dn  = $signed({1'b0, s2_n1}) - $signed({1'b0, s2_n0});
    wire signed [10:0] fx_dnm = fx_dn * $signed({1'b0, s2_t});
    wire        [4:0]  fx_tn  = s2_n0 + fx_dnm[8:4];
    // 晕染：(128-d)^2 * inten >> 14，加 Bayer 抖动后取高 4 位
    wire        [22:0] fx_hzp = s2_rr * inten;
    reg         [3:0]  bayer;
    always @(*) begin
        case (s2_bay)
            4'h0: bayer = 4'd0;  4'h1: bayer = 4'd8;  4'h2: bayer = 4'd2;  4'h3: bayer = 4'd10;
            4'h4: bayer = 4'd12; 4'h5: bayer = 4'd4;  4'h6: bayer = 4'd14; 4'h7: bayer = 4'd6;
            4'h8: bayer = 4'd3;  4'h9: bayer = 4'd11; 4'ha: bayer = 4'd1;  4'hb: bayer = 4'd9;
            4'hc: bayer = 4'd15; 4'hd: bayer = 4'd7;  4'he: bayer = 4'd13; default: bayer = 4'd5;
        endcase
    end
    wire        [8:0]  fx_hz  = fx_hzp[22:14] + bayer;              // 最大 243

    reg         s3_fl;
    reg  [6:0]  s3_d;
    reg  [5:0]  s3_hgt;
    reg  [4:0]  s3_tn;
    reg  [3:0]  s3_lick, s3_spk;
    reg         s3_emb;
    reg  [3:0]  s3_ahz;

    // ================= S4：查显示表 / 颜色，定模式（LED）/ 火焰判定、晕染混合（火警）=================
    localparam [1:0] M_NONE = 2'd0, M_DIM = 2'd1, M_LIT = 2'd2, M_PEAK = 2'd3;
    wire [3:0] hseg   = disp[8:5];
    wire       pvalid = disp[4];
    wire [3:0] pseg   = disp[3:0];
    reg  [1:0] mode_w;
    always @(*) begin
        if (!s3_on)
            mode_w = M_NONE;
        else if (pvalid && (s3_seg == pseg) && (s3_seg >= hseg))
            mode_w = M_PEAK;
        else if (s3_seg < hseg)
            mode_w = M_LIT;
        else
            mode_w = M_DIM;
    end

    // 火舌削高：hgt - (tn*hgt >> 6)
    wire [10:0] fx_cut  = s3_tn * s3_hgt;
    wire [5:0]  fx_hg2  = s3_hgt - fx_cut[10:6];
    wire        fx_in   = (s3_d < {1'b0, fx_hg2});
    wire [5:0]  fx_gap  = fx_hg2 - s3_d[5:0];                        // 火焰内 1..56
    wire [8:0]  fx_h5   = {1'b0, fx_gap, 2'b00} + fx_gap;            // *5
    wire [9:0]  fx_hs   = fx_h5 + s3_lick + s3_spk;                  // heat + 16
    wire [9:0]  fx_heat = fx_hs - 10'd16;
    wire        fx_burn = s3_fl && fx_in && (fx_hs > 10'd16);
    wire        fx_spark = s3_fl && !fx_in && (s3_d < {1'b0, fx_hg2} + 7'd12) && s3_emb;

    // 晕染 16 级混合：(bg*(16-a) + (200,0,0)*a) >> 4，a=0 时就是原像素
    wire [4:0]  fx_ia   = 5'd16 - s3_ahz;
    wire [11:0] fx_mr   = rgb_d3[23:16] * fx_ia + {s3_ahz, 7'd0} + {s3_ahz, 6'd0} + {s3_ahz, 3'd0};
    wire [11:0] fx_mg   = rgb_d3[15:8]  * fx_ia;
    wire [11:0] fx_mb   = rgb_d3[7:0]   * fx_ia;

    localparam [1:0] F_NONE = 2'd0, F_SPARK = 2'd1, F_BURN = 2'd2;
    reg  [1:0]  s4_mode;
    reg  [23:0] s4_col;
    reg  [23:0] s4_bg;
    reg  [1:0]  s4_fm;
    reg  [7:0]  s4_heat;

    // prism 彩虹 35 色（spectrum_model.py BAND_COLOR）
    function [23:0] band_color;
        input [5:0] b;
        case (b)
            6'd0:  band_color = 24'haa3355;  6'd1:  band_color = 24'hb23f59;
            6'd2:  band_color = 24'hbb4c5d;  6'd3:  band_color = 24'hc35961;
            6'd4:  band_color = 24'hcc6666;  6'd5:  band_color = 24'hd6755b;
            6'd6:  band_color = 24'hdf8252;  6'd7:  band_color = 24'he78f4a;
            6'd8:  band_color = 24'hee9d3f;  6'd9:  band_color = 24'heeb22a;
            6'd10: band_color = 24'heec319;  6'd11: band_color = 24'heed408;
            6'd12: band_color = 24'he3dd0a;  6'd13: band_color = 24'hc8dd25;
            6'd14: band_color = 24'hb3dd3a;  6'd15: band_color = 24'h9edd4f;
            6'd16: band_color = 24'h89dd5e;  6'd17: band_color = 24'h6edd6e;
            6'd18: band_color = 24'h59dd7b;  6'd19: band_color = 24'h44dd88;
            6'd20: band_color = 24'h3bd894;  6'd21: band_color = 24'h33d4a1;
            6'd22: band_color = 24'h28cfb1;  6'd23: band_color = 24'h1fcabc;
            6'd24: band_color = 24'h17c6c0;  6'd25: band_color = 24'h0ec2c4;
            6'd26: band_color = 24'h04bdc9;  6'd27: band_color = 24'h00b6cc;
            6'd28: band_color = 24'h00aecc;  6'd29: band_color = 24'h00a5cc;
            6'd30: band_color = 24'h009bcc;  6'd31: band_color = 24'h098fc8;
            6'd32: band_color = 24'h1682c4;  6'd33: band_color = 24'h2375c0;
            default: band_color = 24'h3366bb;
        endcase
    endfunction

    // ================= S5：混合 =================
    // LED 三种和火焰四级共用一个"两个底色项 + 两个颜色项"的四输入加法，结果饱和到 255：
    //   B_BG    bg                        B_LIT   bg/8 + c - c/8
    //   B_PEAK  c/2 + 128                 B_DIM   bg/2 + bg/4 + c/16
    //   B_F1    bg/2 + bg/4 + c/4         B_F2    bg/2 + c/2
    //   B_F3    bg/4 + c/2 + c/4          B_COL   c
    // c 9 位（火焰调色板暗红段 R 最高 285）。LED 三种本来就不会超过 255。
    localparam [2:0] B_BG = 3'd0, B_LIT = 3'd1, B_PEAK = 3'd2, B_DIM = 3'd3,
                     B_F1 = 3'd4, B_F2  = 3'd5, B_F3   = 3'd6, B_COL = 3'd7;
    function [7:0] blend;
        input [2:0] m;
        input [7:0] bg;
        input [8:0] c;
        reg   [8:0] tb1, tb2, tc1;
        reg   [9:0] tc2;
        reg   [10:0] v;
        begin
            case (m)
                B_BG:            tb1 = {1'b0, bg};
                B_LIT:           tb1 = {4'd0, bg[7:3]};
                B_DIM, B_F1, B_F2: tb1 = {2'd0, bg[7:1]};
                B_F3:            tb1 = {3'd0, bg[7:2]};
                default:         tb1 = 9'd0;
            endcase
            tb2 = (m == B_DIM || m == B_F1) ? {3'd0, bg[7:2]} : 9'd0;
            case (m)
                B_LIT, B_COL:    tc1 = c;
                B_PEAK, B_F2, B_F3: tc1 = {1'b0, c[8:1]};
                B_DIM:           tc1 = {4'd0, c[8:4]};
                B_F1:            tc1 = {2'd0, c[8:2]};
                default:         tc1 = 9'd0;
            endcase
            case (m)
                B_LIT:   tc2 = -{4'd0, c[8:3]};
                B_PEAK:  tc2 = 10'd128;
                B_F3:    tc2 = {3'd0, c[8:2]};
                default: tc2 = 10'd0;
            endcase
            v     = {2'b00, tb1} + {2'b00, tb2} + {2'b00, tc1} + {tc2[9], tc2};
            blend = (v[10:8] != 3'd0) ? 8'hff : v[7:0];
        end
    endfunction

    // heat → 暗红→红→橙→黄→白，按高 2 位分段线性
    wire [1:0] fc_seg = s4_heat[7:6];
    wire [7:0] fc_t   = {s4_heat[5:0], 2'b00};
    reg  [8:0] fc_r;
    reg  [7:0] fc_g, fc_b;
    always @(*) begin
        case (fc_seg)
            2'd0:    begin fc_r = 9'd96 + fc_t[7:1] + fc_t[7:2]; fc_g = 8'd0;               fc_b = 8'd0; end
            2'd1:    begin fc_r = 9'd255; fc_g = {1'b0, fc_t[7:1]};                          fc_b = 8'd0; end
            2'd2:    begin fc_r = 9'd255; fc_g = 8'd128 + fc_t[7:1];                         fc_b = {3'b000, fc_t[7:3]}; end
            default: begin fc_r = 9'd255; fc_g = 8'd255; fc_b = 8'd32 + fc_t - {3'b000, fc_t[7:3]}; end
        endcase
    end
    wire [2:0] fc_m = (s4_heat < 8'd40) ? B_F1 : (s4_heat < 8'd80) ? B_F2 :
                      (s4_heat < 8'd120) ? B_F3 : B_COL;

    reg  [2:0]  bm;
    reg  [26:0] bc;             // 三个 9 位颜色
    always @(*) begin
        case (s4_fm)
            F_BURN:  begin bm = fc_m;  bc = {fc_r, 1'b0, fc_g, 1'b0, fc_b}; end
            F_SPARK: begin bm = B_COL; bc = {9'hff, 9'hc8, 9'h3c}; end
            default: begin
                case (s4_mode)
                    M_LIT:   bm = B_LIT;
                    M_PEAK:  bm = B_PEAK;
                    M_DIM:   bm = B_DIM;
                    default: bm = B_BG;
                endcase
                bc = {1'b0, s4_col[23:16], 1'b0, s4_col[15:8], 1'b0, s4_col[7:0]};
            end
        endcase
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_ring <= 1'b0; s1_fx <= 1'b0; s1_d <= 7'd0; s1_p <= 12'd0; s1_bay <= 4'd0;
            s2_ring <= 1'b0; s2_d <= 7'd0; s2_q <= 12'd0;
            s2_fx <= 1'b0; s2_fl <= 1'b0; s2_k0 <= 6'd0; s2_k1 <= 6'd0;
            s2_frac <= 4'd0; s2_t <= 4'd0; s2_n0 <= 5'd0; s2_n1 <= 5'd0;
            s2_lick <= 4'd0; s2_spk <= 4'd0; s2_emb <= 1'b0; s2_rr <= 15'd0; s2_bay <= 4'd0;
            s3_on   <= 1'b0; s3_band <= 6'd0; s3_seg <= 4'd0;
            s3_fl <= 1'b0; s3_d <= 7'd0; s3_hgt <= 6'd0; s3_tn <= 5'd0;
            s3_lick <= 4'd0; s3_spk <= 4'd0; s3_emb <= 1'b0; s3_ahz <= 4'd0;
            s4_mode <= M_NONE; s4_col <= 24'd0;
            s4_bg <= 24'd0; s4_fm <= F_NONE; s4_heat <= 8'd0;
            rgb_out <= 24'd0;
        end
        else begin
            // S1
            s1_ring <= en_f && !fire_f && de_in && (d_w < DEPTH);
            s1_fx   <= en_f &&  fire_f && de_in && (d_w < HAZE);
            s1_d    <= d_w[6:0];
            s1_p    <= p_w;
            s1_bay  <= {cy[1:0], cx[1:0]};
            // S2
            s2_ring <= s1_ring;
            s2_d    <= s1_d;
            s2_q    <= (q_sum >= PERIM) ? q_sum - PERIM : q_sum[11:0];
            s2_fx   <= s1_fx;
            s2_fl   <= s1_fx && !s1_d[6];
            s2_k0   <= fx_k0;
            s2_k1   <= fx_k1;
            s2_frac <= s1_p[3:0];
            s2_t    <= fx_c[3:0];
            s2_n0   <= fx_n0[4:0];
            s2_n1   <= fx_n1[4:0];
            s2_lick <= fx_lk[3:0];
            s2_spk  <= fx_sp[3:0];
            s2_emb  <= (fx_em[9:0] < 10'd6);
            s2_rr   <= fx_r * fx_r;
            s2_bay  <= s1_bay;
            // S3
            s3_on   <= on3;
            s3_band <= bnd;
            s3_seg  <= s2_d[5:2];
            s3_fl   <= s2_fl;
            s3_d    <= s2_d;
            s3_hgt  <= fx_hgt;
            s3_tn   <= fx_tn;
            s3_lick <= s2_lick;
            s3_spk  <= s2_spk;
            s3_emb  <= s2_emb;
            s3_ahz  <= s2_fx ? fx_hz[7:4] : 4'd0;
            // S4
            s4_mode <= mode_w;
            s4_col  <= band_color(s3_band);
            s4_bg   <= {fx_mr[11:4], fx_mg[11:4], fx_mb[11:4]};
            s4_fm   <= fx_burn ? F_BURN : fx_spark ? F_SPARK : F_NONE;
            s4_heat <= (fx_heat > 10'd255) ? 8'd255 : fx_heat[7:0];
            // S5
            rgb_out <= {blend(bm, s4_bg[23:16], bc[26:18]),
                        blend(bm, s4_bg[15:8],  bc[17:9]),
                        blend(bm, s4_bg[7:0],   bc[8:0])};
        end
    end
endmodule
