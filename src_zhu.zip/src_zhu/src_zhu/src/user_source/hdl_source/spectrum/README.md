# spectrum —— 四边环绕音频频谱

参考 audioMotion-analyzer 的 radial + LED + prism 效果，把圆环改成沿 640x480
屏幕四条边的矩形环，替代第十二讲的波形条（`promax_audio_waveform` 已移到 `_unused/`）。

## 文件

| 文件 | 作用 |
|---|---|
| `spectrum_border_overlay.v` | 顶层：坐标、旋转、5 级渲染流水线；例化分析器。hs/vs/de/rgb 整体延迟 5 拍 |
| `spectrum_analyzer.v` | 35 频带 IIR 滤波器组 + 包络 + 每帧柱高/峰值，输出显示表 |
| `spectrum_coef.hex` | 滤波器系数 ROM（`$readmemh`），`td_project/` 下有同一份 |
| `spectrum_model.py` | 逐位精确的 Python 模型：出预览、生成 hex、作仿真金标准（含火警特效 `fire_pixel`） |
| `alarm_fx_demo.py` | 火警特效候选方案演示（选定 `A_haze`，已落到 RTL） |
| `preview/` | 模型出的效果图（`anim.gif` / `still_2x.png`）；`alarm_fx/` 下是火警特效 |

仿真：`user_source/sim/spectrum/`，`python gen_vectors.py` → `vsim -c -do run.do` →
`python check_spectrum.py`（逐帧比显示表 + 4 帧整帧逐像素比对：前 2 帧 LED 环，
第 20 帧后 tb 拉高 alarm，后 2 帧比火警特效）。

## 接法

```
media_video_pipeline ──*_raw──> spectrum_border_overlay ──hs/vs/de/vout_data──> 状态条 → 字幕 → 时间戳 → 参数面板 → 应急 → AXIS
                                    ↑ audio_valid / audio_sample_left（音量缩放后）
```

放在 OSD 链最前面，所有文字压在频谱上面。延迟对下游透明（下游坐标从延迟后的 de/vs 反推）。
缩略图模式下关闭；应急模式由 emergency_screen 整屏盖掉。
`alarm` 接顶层 `alarm_video`（`fire_alarm_ctrl.alarm` 打两拍）：显示 PIC12 预警 / PIC13 火灾时切成火警特效。

## 火警特效（alarm=1）

`alarm_fx_demo.py` 的 `A_haze` 方案，替换 LED 环（帧起点切换，帧内不撕裂）。
预览：`python spectrum_model.py --fire` → `preview/alarm_fx/pic12_fire_rtl.gif`、`pic13_fire_rtl.gif`
（RTL 逐位模型出的，对照 demo 出的 `pic12_A_haze.gif`）。

| 项 | 值 |
|---|---|
| 红色晕染 | 离边 d<128，a = ((128-d)²·inten>>14 + Bayer4x4)>>4，16 级混合 (200,0,0) |
| 呼吸 | 40 帧三角波（≈1.5Hz，低于 3Hz 闪烁上限），inten 112..222 随音量包络变深 |
| 音量包络 | 上一遍 frame pass 的 35 带柱高和 ·7/32，封顶 240，快攻、每帧 -4 慢放 |
| 火焰 | 离边 d<64，不旋转；火焰高 = 相邻两柱频带柱高插值 → 6..56 |
| 火舌/火星 | 沿边值噪声削高 0~50%，xorshift（纯异或）做翻涌和抖动；火舌上方 12 像素偶发火星 |
| 调色 | heat → 暗红/红/橙/黄/白，heat 分 4 级移位混合；暗红段 R 到 285，混合后饱和 |

和 demo 只差帧状态的写法（14 位帧计数、呼吸相位单独计、包络用上一帧柱高和），观感一致。

## 参数

| 项 | 值 |
|---|---|
| 频带 | 35 个，40Hz~16kHz 对数分布，每带两级同系数 RBJ 带通（4 阶） |
| 柱 | 柱距 16（亮 12 + 缝 4），周长 2240 → 140 根，频带镜像低→高→低绕两圈 |
| 高度 | 0~40 像素 = 10 段 LED（段距 4），显示动态范围约 40dB |
| 峰值 | 保持 30 帧（0.5s）后以 1/16 像素/帧² 加速下落 |
| 旋转 | `VIS=XX` 低 4 位，默认 2 像素/帧（约 19s 一圈） |
| 混合 | 点亮 bg/8+col·7/8，峰值 col/2+128，暗格 bg·3/4+col/16，纯移位加法 |

改参数时 `spectrum_model.py` 和 RTL 要一起改，改完重跑模型预览和仿真比对。
改 `F_LO/F_HI/N_BANDS` 等系数相关参数后要 `python spectrum_model.py --gen` 重新生成 hex。

## 资源与时序要点

- 1 个 24x27 乘法器分时复用（每带 6 次）；样本间隔 520 拍，一遍 35 带 = 490 拍（tb 实测）。
- 状态 RAM 512x26（含每带峰值状态字）、系数 ROM 256x24，TD 实际各拆成 2 块 BRAM9K（共 4 块）；
  只有 35 项显示表是分布式 RAM。整个频谱约 1525 LE。
- 低频带极点贴近单位圆，截断会留极限环（静音后柱子不归零），所以两级都做了误差反馈。
- 加火警特效后（整片综合）：频谱 1641 LUT / 8 DSP / BRAM 不变（4 块）。柱高表是两份
  64x6 分布式 RAM，必须 `ram_style="dram"`，否则 TD 推成 BRAM，整片 65/64 放不下。
- 显示表只在帧起点后第一个样本那一遍更新（~1000 拍），远早于第一行有效像素（33 行之后），不撕裂。

## 编译（TD 6.2）

加入频谱后芯片很满：LUT 78.7%，BRAM9K 63/64，DSP 18/29。默认布局策略下 setup 违例
（sd_card_clk 约 -0.14ns，在 FAT32/BMP 解码那几条老路径上），需要用下面这组布局参数：

```
place relaxation      0.9
place hfn_opt_effort  high
```

GUI 里在 phy_1 的策略/用户参数里设这两项；命令行可以直接复跑
`td_project/HDMI1.4b_Transmitter_v1.0_Runs/spec_syn`（综合）→ `spec_phy_s4`（布局布线，
settings.cfg 里的 phyWildParams 就是这两项），结果：SWNS +0.106ns，HWNS +0.021ns，布线无失败。

同一次修改里给 `framebuf4bank/media_video_pipeline.v` 在转场乘法后插了一级寄存（差异6），
把 video_clk 上 26 级的 坐标→缩略图占位符→乘法→对比度 长路径切开，视频输出整体晚 1 拍。
改动前的原文件留在 `media_video_pipeline.v.bak_before_spectrum`。
