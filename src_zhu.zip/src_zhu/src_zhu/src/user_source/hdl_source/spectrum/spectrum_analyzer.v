`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// spectrum_analyzer：35 频带音频频谱分析（video_clk 域，25MHz）
//
// 参考 audioMotion-analyzer 的效果（对数频带柱 + 峰值保持 + 重力下落），
// FFT 换成 IIR 带通滤波器组，资源才放得进 EG4S20 剩下的那点空间。
// 算法、位宽、截断方式和 spectrum_model.py 逐位一致，tb 拿模型输出逐帧比对。
//
// 【每个样本做什么】48kHz 一拍的 sample_valid 到来后，对 35 个频带依次：
//   第一级  acc = B*(x-x2) + (-A1)*y1 + (-A2)*y2 + ey ; y = sat26(acc>>>22) ; ey = acc[21:0]
//   第二级  acc = B*(y-y2) + (-A1)*z1 + (-A2)*z2 + ez ; z = sat26(acc>>>22) ; ez = acc[21:0]
//   包络    a=|z|;  a>env ? env += (a-env)>>2  :  env -= env>>10
//   - 两级同系数级联 = 4 阶带通，比单个二阶的裙边陡一倍，单音不会点亮一大片柱。
//   - ey/ez 是误差反馈（把上次截掉的低 22 位加回来）。不加的话 40Hz 这种极点
//     贴着单位圆的低频带会在静音后留一个停不下来的极限环，柱子永远不归零。
//   - 第二级的输入历史就是第一级的输出历史 y1/y2，不另存。
//   - ROM 里 A1/A2 预先取了负，累加器只有"加"一种操作（acc 或 e 加乘积）。
//
// 【面积优先的写法】EG4S20 的 LUT 已经 70%+，这里尽量让数据直通：
//   - 乘法器（24x27，1 个，分时复用 6 次/带）的 A 口直接接系数 ROM 输出，
//     B 口只在"状态 RAM 输出"和一个差分寄存器 d_reg 之间二选一；
//   - y1/y2、z1/z2 用乒乓槽位：每个样本翻一次 par，新值写进"旧 y2"那一格，
//     它自动变成下一拍的 y1，原来的 y1 自动变成 y2，不用搬数据；
//   - 峰值状态也放进状态 RAM（每带第 8 个字），不另占分布式 RAM。
//
// 【时间预算】样本间隔 520~521 拍；每带固定 14 拍，35 带 = 490 拍。
//   单拍最长组合路径 = RAM/ROM 输出寄存器 → 乘法器 → prod 寄存器，25MHz 下宽裕。
//
// 【存储】
//   状态 RAM 512x26（简单双口，同步读；地址 {band, idx}）：
//     idx 0/1 = y 两个槽，2/3 = z 两个槽，4 = ey，5 = ez，6 = env，
//     7 = 峰值 {pk[9:0], hold[4:0], vel[5:0]}
//     复位后先清 280 拍，不依赖 BRAM 初值（TD 的 eram_init 默认关，RAM 初值会被丢掉）。
//   系数 ROM 256x24（$readmemh spectrum_coef.hex）：每带 4 字 B, -A1, -A2, 0。
//   显示表 35 项（分布式 RAM），渲染侧组合读。
//
// 【每帧做什么】frame_start（vs 上升沿，有效区之前 33 行）置 frame_req，
//   之后第一个样本那一遍 = frame pass：每个频带算完新包络就把它送进 4 级
//   小流水线：log2(Q4) + 两端补偿 → 柱高 0..40 → 峰值保持/下落 → 写显示表。
//   frame pass 在 frame_start 之后 ~1000 拍内结束，远早于第一行有效像素
//   （33 行 = 26400 拍），所以显示表在一帧有效区内恒定，不会撕裂。
//
// 【显示表格式】disp[band] = {hseg[3:0], pvalid, pseg[3:0]}
//   hseg  = 点亮的 LED 段数 = (h+3)>>2，0..10
//   pvalid/pseg = 峰值所在段号（峰值 > 0 时有效）
// 另有柱高表 bar_mem_a/b[band] = h（0..40，两个读口）和 bar_sum（一遍 frame pass
// 35 带柱高之和，最后一带写完时锁存），给火警特效用。
//
// 【一带 14 拍的排程】Ek = 第 k 拍结束的时钟沿；RAM/ROM 在第 k 拍给地址，k+1 拍出数
//   拍  RAM读  ROM读  乘法(本拍操作数)   累加(Ek)            写(Ek)      其它(Ek)
//   0   ey     B
//   1   y1     -A1    B*d_reg(dx)                                         e  <= ey
//   2   y2     -A2    -A1*y1            acc = e + p
//   3   ez                -A2*y2         acc += p                         d_reg <= y2
//   4                                    acc += p                         e  <= ez
//   5          B                                             y            d_reg <= y - y2
//   6   z1     -A1    B*d_reg(y-y2)                          ey
//   7   z2     -A2    -A1*z1            acc = e + p
//   8                 -A2*z2            acc += p
//   9   env                             acc += p
//   10                                                       z            zabs, env_old
//   11  pk                                                   ez           env_new
//   12                                                       env          → 帧流水线
//   13                                                                    d_reg <= dx，下一带
// -----------------------------------------------------------------------------
module spectrum_analyzer #(
    parameter COEF_FILE = "spectrum_coef.hex"
) (
    input  wire               clk,            // video_clk
    input  wire               rst_n,
    input  wire               sample_valid,   // 48kHz 一拍脉冲
    input  wire signed [15:0] sample,
    input  wire               frame_start,    // 一拍脉冲
    input  wire [5:0]         rd_band,
    output wire [8:0]         rd_data,
    input  wire [5:0]         rd_band_a,      // 柱高表两个读口（火警特效）
    output wire [5:0]         rd_h_a,
    input  wire [5:0]         rd_band_b,
    output wire [5:0]         rd_h_b,
    output reg  [10:0]        bar_sum,        // 上一遍 frame pass 的柱高和 0..1400
    output reg                overrun         // 粘滞：一遍没算完又来了两个样本（不该出现）
);
    localparam integer NB      = 35;
    localparam integer LOG_MIN = 200;
    localparam integer DEPTH   = 40;
    localparam integer HOLD_FR = 30;

    localparam [2:0] I_Y0 = 3'd0, I_Z0 = 3'd2, I_EY = 3'd4, I_EZ = 3'd5,
                     I_ENV = 3'd6, I_PK = 3'd7;

    // ================= 控制寄存器 =================
    reg               busy;
    reg               clearing;
    reg  [8:0]        clr_cnt;
    reg               frame_req;
    reg               frame_pass;
    reg               pend;
    reg  signed [15:0] pend_sample;
    reg               par;               // 乒乓槽位
    reg  signed [23:0] x1, x2;
    reg  signed [24:0] dx;
    reg  [5:0]        band;
    reg  [3:0]        step;

    // ================= 存储 =================
    reg  [25:0] smem [0:511];
    reg  [25:0] q;
    reg  [8:0]  raddr;
    reg         we;
    reg  [8:0]  waddr;
    reg  [25:0] wdata;

    always @(posedge clk) begin
        if (we)
            smem[waddr] <= wdata;
        q <= smem[raddr];
    end

    (* rom_style = "bram" *) reg [23:0] cmem [0:255];
    initial $readmemh(COEF_FILE, cmem);
    reg  [1:0]  csel;
    reg  signed [23:0] cq;
    always @(posedge clk)
        cq <= cmem[{band, csel}];

    reg  [8:0] disp_mem [0:63];
    assign rd_data = disp_mem[rd_band];
    // 柱高表两份一样的分布式 RAM，各一个读口：一个数组带两个读口会被 TD 推成
    // 2 块 BRAM9K（芯片只剩 1 块），平铺成寄存器则要 ~750 LUT
    (* ram_style = "dram" *) reg [5:0] bar_mem_a [0:63];
    (* ram_style = "dram" *) reg [5:0] bar_mem_b [0:63];
    assign rd_h_a = bar_mem_a[rd_band_a];
    assign rd_h_b = bar_mem_b[rd_band_b];

    // ================= 定点辅助 =================
    // acc>>>22 饱和到 26 位：右移后的高 5 位全同号才没溢出
    function signed [25:0] sat26;
        input signed [51:0] a;
        begin
            if (a[51:47] == 5'h00 || a[51:47] == 5'h1f)
                sat26 = a[47:22];
            else
                sat26 = a[51] ? 26'sh2000000 : 26'sh1ffffff;
        end
    endfunction

    // 两端频带补偿（Q4）：spectrum_model.py BAND_TILT
    function [6:0] band_tilt;
        input [5:0] b;
        begin
            if (b < 6'd6)       band_tilt = (7'd6 - b[2:0]) * 7'd6;
            else if (b > 6'd22) band_tilt = {1'b0, b - 6'd22} << 3;
            else                band_tilt = 7'd0;
        end
    endfunction

    // ================= 数据通路 =================
    reg  signed [26:0] d_reg;
    reg  [21:0]        e_reg;
    reg  signed [50:0] prod;
    reg  signed [51:0] acc;
    reg  [25:0]        zabs_r;
    reg  [25:0]        env_old;
    reg  [25:0]        env_r;

    wire signed [26:0] q_s     = {q[25], q};
    wire               use_d   = (step == 4'd1) || (step == 4'd6);
    wire signed [26:0] m_b     = use_d ? d_reg : q_s;
    wire signed [25:0] acc_sat = sat26(acc);
    wire        [25:0] acc_abs = acc_sat[25] ? (~acc_sat + 26'd1) : acc_sat;
    wire               acc_first = (step == 4'd2) || (step == 4'd7);
    wire               acc_en    = (step == 4'd2) || (step == 4'd3) || (step == 4'd4) ||
                                   (step == 4'd7) || (step == 4'd8) || (step == 4'd9);
    wire signed [51:0] acc_in  = acc_first ? $signed({30'd0, e_reg}) : acc;
    wire        [25:0] env_new = (zabs_r > env_old) ? env_old + ((zabs_r - env_old) >> 2)
                                                    : env_old - (env_old >> 10);

    wire               start_now = !busy && !clearing && (sample_valid || pend);
    wire signed [15:0] start_smp = pend ? pend_sample : sample;
    wire signed [23:0] start_xs  = {start_smp, 8'h00};

    // 帧流水线（声明提前：写口要用）
    reg         f1_v, f2_v, f3_v;
    reg  [5:0]  f1_b, f2_b, f3_b;
    reg  [25:0] f1_env;
    reg  [4:0]  f1_msb;
    reg  [20:0] f1_pk, f2_pk, f3_pk;
    reg  signed [10:0] f2_lv;
    reg  [5:0]  f3_h;

    // ---- RAM 读地址 / ROM 选择（组合，按拍号）----
    always @(*) begin
        raddr = {band, I_EY};
        csel  = 2'd0;
        case (step)
            4'd0:  begin raddr = {band, I_EY};               csel = 2'd0; end
            4'd1:  begin raddr = {band, I_Y0[2:1], par};     csel = 2'd1; end
            4'd2:  begin raddr = {band, I_Y0[2:1], ~par};    csel = 2'd2; end
            4'd3:  begin raddr = {band, I_EZ};               csel = 2'd2; end
            4'd5:  begin                                     csel = 2'd0; end
            4'd6:  begin raddr = {band, I_Z0[2:1], par};     csel = 2'd1; end
            4'd7:  begin raddr = {band, I_Z0[2:1], ~par};    csel = 2'd2; end
            4'd9:  begin raddr = {band, I_ENV}; end
            4'd11: begin raddr = {band, I_PK}; end
            default: ;
        endcase
        // 空闲时预先给第 0 带第 0 拍的 ROM 地址无所谓：start 那拍 band=0、step=0
    end

    // ---- 峰值更新（帧流水线第 4 拍，组合）----
    wire [9:0] pk_old   = f3_pk[20:11];
    wire [4:0] hold_old = f3_pk[10:6];
    wire [5:0] vel_old  = f3_pk[5:0];
    wire [9:0] hq       = {f3_h, 4'd0};
    wire [5:0] vel_inc  = vel_old + 6'd1;
    reg  [9:0] pk_n;
    reg  [4:0] hold_n;
    reg  [5:0] vel_n;
    always @(*) begin
        pk_n = pk_old; hold_n = hold_old; vel_n = vel_old;
        if (hq >= pk_old) begin
            pk_n = hq; hold_n = HOLD_FR; vel_n = 6'd0;
        end
        else if (hold_old != 5'd0) begin
            hold_n = hold_old - 5'd1;
        end
        else begin
            vel_n = vel_inc;
            pk_n  = (pk_old > {4'd0, vel_inc}) ? pk_old - vel_inc : 10'd0;
        end
    end
    wire [5:0] pk_px  = pk_n[9:4];
    wire [5:0] pk_m1  = pk_px - 6'd1;
    wire [5:0] h_p3   = f3_h + 6'd3;
    wire [8:0] disp_n = {h_p3[5:2], (pk_px != 6'd0), (pk_px != 6'd0) ? pk_m1[5:2] : 4'd0};

    // ---- RAM 写口（组合，按拍号；帧流水线和清零各占空闲拍）----
    always @(*) begin
        we    = 1'b0;
        waddr = {band, I_EY};
        wdata = acc_sat;
        if (clearing) begin
            we    = 1'b1;
            waddr = clr_cnt;
            wdata = 26'd0;
        end
        else if (f3_v) begin
            // 只会落在下一带的第 0 拍或一遍结束后的空闲拍，和下面几项不冲突
            we    = 1'b1;
            waddr = {f3_b, I_PK};
            wdata = {5'd0, pk_n, hold_n, vel_n};
        end
        else if (busy) begin
            case (step)
                4'd5:  begin we = 1'b1; waddr = {band, I_Y0[2:1], ~par}; wdata = acc_sat; end
                4'd6:  begin we = 1'b1; waddr = {band, I_EY};  wdata = {4'd0, acc[21:0]}; end
                4'd10: begin we = 1'b1; waddr = {band, I_Z0[2:1], ~par}; wdata = acc_sat; end
                4'd11: begin we = 1'b1; waddr = {band, I_EZ};  wdata = {4'd0, acc[21:0]}; end
                4'd12: begin we = 1'b1; waddr = {band, I_ENV}; wdata = env_r; end
                default: ;
            endcase
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            busy        <= 1'b0;
            clearing    <= 1'b1;
            clr_cnt     <= 9'd0;
            frame_req   <= 1'b0;
            frame_pass  <= 1'b0;
            pend        <= 1'b0;
            pend_sample <= 16'sd0;
            overrun     <= 1'b0;
            par         <= 1'b0;
            x1 <= 24'sd0; x2 <= 24'sd0; dx <= 25'sd0;
            band <= 6'd0; step <= 4'd0;
            d_reg <= 27'sd0; e_reg <= 22'd0;
            prod <= 51'sd0; acc <= 52'sd0;
            zabs_r <= 26'd0; env_old <= 26'd0; env_r <= 26'd0;
        end
        else begin
            prod <= cq * m_b;

            if (frame_start)
                frame_req <= 1'b1;

            if (clearing) begin
                clr_cnt <= clr_cnt + 9'd1;
                if (clr_cnt == NB * 8 - 1)
                    clearing <= 1'b0;
            end
            else if (start_now) begin
                busy        <= 1'b1;
                // 补算挂起样本的同一拍又来一个新样本：新的接着挂起
                pend        <= pend & sample_valid;
                pend_sample <= sample;
                // 和 frame_start 同拍到的样本算"帧起点之后"（模型同一约定）
                frame_pass  <= frame_req | frame_start;
                frame_req   <= 1'b0;
                par         <= ~par;
                dx          <= start_xs - x2;
                d_reg       <= start_xs - x2;
                x2          <= x1;
                x1          <= start_xs;
                band        <= 6'd0;
                step        <= 4'd0;
            end
            else if (busy) begin
                // 忙时来样本：挂起一个，这一遍算完立刻补上（正常情况下不会发生）
                if (sample_valid) begin
                    if (pend) overrun <= 1'b1;
                    pend        <= 1'b1;
                    pend_sample <= sample;
                end

                if (acc_en)
                    acc <= acc_in + prod;

                case (step)
                    4'd1:  e_reg <= q[21:0];                    // ey
                    4'd3:  d_reg <= q_s;                        // y2
                    4'd4:  e_reg <= q[21:0];                    // ez
                    4'd5:  d_reg <= {acc_sat[25], acc_sat} - d_reg;   // y - y2
                    4'd10: begin zabs_r <= acc_abs; env_old <= q; end
                    4'd11: env_r <= env_new;
                    default: ;
                endcase

                if (step == 4'd13) begin
                    step  <= 4'd0;
                    d_reg <= dx;
                    if (band == NB - 1)
                        busy <= 1'b0;
                    else
                        band <= band + 6'd1;
                end
                else
                    step <= step + 4'd1;
            end
        end
    end

    // ================= 帧流水线：包络 -> 柱高 -> 峰值 -> 显示表 =================
    //   F1(E12)  锁 env / 峰值字 / 最高位位置
    //   F2(E13)  log2 小数位 + 补偿 - LOG_MIN
    //   F3       柱高 = clamp(lv*3>>3, 0, 40)
    //   F4       峰值更新，写回状态 RAM 和显示表（组合写口，见上）
    reg  [4:0] msb_w;
    integer    mi;
    always @(*) begin
        msb_w = 5'd0;
        for (mi = 0; mi < 26; mi = mi + 1)
            if (env_r[mi]) msb_w = mi[4:0];
    end
    wire [29:0] f1_sh   = {f1_env, 4'b0000} >> f1_msb;
    wire [8:0]  f1_log  = (f1_env == 26'd0) ? 9'd0 : {f1_msb, f1_sh[3:0]};
    wire signed [10:0] lv_calc = $signed({2'b00, f1_log}) + $signed({4'b0000, band_tilt(f1_b)}) - LOG_MIN;
    wire [12:0] lv3   = {f2_lv[9:0], 1'b0} + f2_lv[9:0];   // lv*3（lv>0 时）
    wire [9:0]  h_raw = lv3[12:3];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            f1_v <= 1'b0; f2_v <= 1'b0; f3_v <= 1'b0;
            f1_b <= 6'd0; f2_b <= 6'd0; f3_b <= 6'd0;
            f1_env <= 26'd0; f1_msb <= 5'd0;
            f1_pk <= 21'd0; f2_pk <= 21'd0; f3_pk <= 21'd0;
            f2_lv <= 11'sd0; f3_h <= 6'd0;
        end
        else begin
            f1_v   <= busy && (step == 4'd12) && frame_pass;
            f1_b   <= band;
            f1_env <= env_r;
            f1_msb <= msb_w;
            f1_pk  <= q[20:0];
            f2_v   <= f1_v;  f2_b <= f1_b;  f2_pk <= f1_pk;
            f2_lv  <= lv_calc;
            f3_v   <= f2_v;  f3_b <= f2_b;  f3_pk <= f2_pk;
            f3_h   <= (f2_lv <= 0) ? 6'd0 : (h_raw > DEPTH) ? DEPTH[5:0] : h_raw[5:0];
        end
    end

    always @(posedge clk) begin
        if (clearing && clr_cnt < 9'd64) begin
            disp_mem[clr_cnt[5:0]]  <= 9'd0;
            bar_mem_a[clr_cnt[5:0]] <= 6'd0;
            bar_mem_b[clr_cnt[5:0]] <= 6'd0;
        end
        else if (f3_v) begin
            disp_mem[f3_b]  <= disp_n;
            bar_mem_a[f3_b] <= f3_h;
            bar_mem_b[f3_b] <= f3_h;
        end
    end

    // 柱高和：第 0 带重新开始累加，第 34 带写完时锁存
    reg  [10:0] sum_acc;
    wire [10:0] sum_nxt = ((f3_b == 6'd0) ? 11'd0 : sum_acc) + f3_h;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sum_acc <= 11'd0;
            bar_sum <= 11'd0;
        end
        else if (f3_v) begin
            sum_acc <= sum_nxt;
            if (f3_b == NB - 1)
                bar_sum <= sum_nxt;
        end
    end
endmodule
