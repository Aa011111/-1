# -*- coding: utf-8 -*-
"""
四边环绕音频频谱 —— 逐位精确的 Python 参考模型

用途：
  1. 出效果预览图（PNG 静帧 + GIF 动图）；
  2. RTL 仿真的金标准：所有运算都是整数，位宽/截断/饱和/时序约定和
     spectrum_analyzer.v / spectrum_border_overlay.v 一一对应；
  3. 生成 RTL 要用的常量：spectrum_coef.hex（滤波器系数 ROM）。

思路来自 audioMotion-analyzer（FFT → dB → 对数频带 → 峰值保持/重力下落 → 画柱），
按 EG4S20 的资源改成：
  - 分析：35 个频带，每带两级同系数 RBJ 带通级联（4 阶），误差反馈消极限环，
          分时复用 1 个 24x27 乘法器；|z| 快攻慢放包络；
  - 每帧：包络 → log2(Q4) → 柱高 0..40；峰值保持 30 帧后加速下落；
  - 显示：640x480 四条边各向内长柱，按"离哪条边最近"分区（四角斜接），
          沿边框顺时针坐标 p（周长 2240），柱宽 16 → 140 根柱，
          35 个频带镜像排布（低→高→低）绕两圈，每帧 p 加偏移 = 旋转；
          prism 彩虹按频带着色。

用法：
  python spectrum_model.py [WAV] [BMP] [起始秒] [帧数]   出预览到 preview/
  python spectrum_model.py --gen                          只重新生成 hex 常量
  python spectrum_model.py --fire                         火警特效预览到 preview/alarm_fx/
"""
import math
import os
import sys
import wave

# ----------------------------------------------------------------------------
# 参数（和 RTL parameter 保持一致）
# ----------------------------------------------------------------------------
FS = 48000
PIX_CLK = 25_000_000
H_TOTAL, V_TOTAL = 800, 525
SCR_W, SCR_H = 640, 480
FRAME_SAMPLES = FS * H_TOTAL * V_TOTAL / PIX_CLK      # ≈ 806.4 样本/帧

N_BANDS = 35
F_LO, F_HI = 40.0, 16000.0
COEF_FRAC = 22                  # 系数 Q2.22，24 位有符号
COEF_BITS = 24
X_SHIFT = 8                     # 输入 16bit 左移 8 位进滤波器，给低频带留精度
Y_BITS = 26                     # 滤波器状态位宽（饱和）
ENV_ATTACK = 2                  # 包络上升 env += (a-env)>>2
ENV_RELEASE = 10                # 包络下降 env -= env>>10   (≈21ms)

BAR_PITCH = 16                  # 柱距（2 的幂，RTL 只用移位）
BAR_LIT_LO, BAR_LIT_HI = 2, 13  # 柱内 2..13 点亮，两侧共 4 像素缝
DEPTH = 40                      # 柱最大高度（像素，向屏内）
LED_PITCH = 4                   # LED 段距：3 亮 + 1 缝
N_SEG = DEPTH // LED_PITCH      # 10 段
PERIM = 2 * (SCR_W + SCR_H)     # 2240
N_BARS = PERIM // BAR_PITCH     # 140

LOG_MIN_Q4 = 200                # log2(env)(Q4) 低于此值柱高为 0；用 MUSIC1/5/9 标定：
                                #   中位数 ≈ 260 → 柱高 ≈ 22，p99 ≈ 305 以上满格
# 柱高 = (lv*3)>>3：40 像素对应 107 个 Q4 单位 ≈ 40dB 显示动态范围
# 两端频带补偿（Q4，1 单位 ≈ 0.38dB）：低于 6 号每带 +6，高于 22 号每带 +8
BAND_TILT = [max(0, 6 - k) * 6 + max(0, k - 22) * 8 for k in range(N_BANDS)]
PEAK_HOLD = 30                  # 峰值保持帧数（≈0.5s，同 audioMotion peakHoldTime）
PEAK_ACC_Q4 = 1                 # 峰值下落加速度 1/16 像素/帧²
SPIN_STEP = 2                   # 每帧旋转像素（UART VIS=1x 的低半字节）

# audioMotion 'prism' 色标，35 个频带由低到高插值
PRISM = ['#a35', '#c66', '#e94', '#ed0', '#9d5', '#4d8', '#2cb', '#0bc', '#09c', '#36b']


def _hex3(s):
    s = s.lstrip('#')
    return tuple(int(c, 16) * 17 for c in s)


def _band_colors():
    stops = [_hex3(c) for c in PRISM]
    out = []
    for k in range(N_BANDS):
        pos = k * (len(stops) - 1) * 16 // (N_BANDS - 1)    # Q4
        i, t = pos >> 4, pos & 15
        if i >= len(stops) - 1:
            out.append(stops[-1])
        else:
            c0, c1 = stops[i], stops[i + 1]
            out.append(tuple((c0[j] * (16 - t) + c1[j] * t) // 16 for j in range(3)))
    return out


BAND_COLOR = _band_colors()


# ----------------------------------------------------------------------------
# 频带系数
# ----------------------------------------------------------------------------
def band_centers():
    r = (F_HI / F_LO) ** (1.0 / (N_BANDS - 1))
    return [F_LO * r ** i for i in range(N_BANDS)]


def band_coefs():
    """RBJ 带通（constant 0 dB peak gain），返回 [(B0, A1, A2)] 整数 Q2.22。
    y = B0*(x - x2) - A1*y1 - A2*y2
    每个频带两级同系数级联（4 阶），单级 Q 乘 sqrt(sqrt2-1)，
    使级联后 -3dB 带宽仍等于频带间距（相邻频带在 -3dB 处交叉）。"""
    fc = band_centers()
    bw_oct = math.log2(F_HI / F_LO) / (N_BANDS - 1)
    q = 1.0 / (2 ** (bw_oct / 2) - 2 ** (-bw_oct / 2)) * math.sqrt(math.sqrt(2) - 1)
    out = []
    lim = 1 << (COEF_BITS - 1)
    for f in fc:
        w0 = 2 * math.pi * f / FS
        alpha = math.sin(w0) / (2 * q)
        a0 = 1 + alpha
        s = 1 << COEF_FRAC
        c = (round(alpha / a0 * s), round(-2 * math.cos(w0) / a0 * s), round((1 - alpha) / a0 * s))
        assert all(-lim <= v < lim for v in c) and -lim <= -c[1] < lim and -lim <= -c[2] < lim
        out.append(c)
    return out, q


def sat(v, bits):
    hi = (1 << (bits - 1)) - 1
    lo = -(1 << (bits - 1))
    return hi if v > hi else lo if v < lo else v


def log2_q4(v):
    """log2 定点近似：整数部分 = 最高位位置，小数 4 位 = 最高位后面 4 位（线性插值）。
    v<=0 返回 0。RTL：优先编码器 + 移位取 4 位。"""
    if v <= 0:
        return 0
    msb = v.bit_length() - 1
    if msb >= 4:
        frac = (v >> (msb - 4)) & 0xF
    else:
        frac = (v << (4 - msb)) & 0xF
    return msb * 16 + frac


# ----------------------------------------------------------------------------
# 分析器
#   sample(x, frame_pass)：处理一个样本。frame_pass=1 时（帧起点后的第一个样本，
#   和 RTL 的 frame_req 约定相同），每个频带在算完新包络后紧接着做柱高/峰值更新。
#   disp[k] = (hseg, pvalid, pseg) 就是 RTL 显示寄存器的内容。
# ----------------------------------------------------------------------------
class Analyzer:
    def __init__(self):
        self.coefs, self.q = band_coefs()
        self.x1 = self.x2 = 0
        z = [0] * N_BANDS
        self.y1, self.y2, self.z1, self.z2 = list(z), list(z), list(z), list(z)
        self.ey, self.ez = list(z), list(z)         # 误差反馈：上次截掉的低 COEF_FRAC 位
        self.env = list(z)
        self.peak, self.hold, self.vel = list(z), list(z), list(z)   # peak/vel 为 Q4
        self.bar = list(z)
        self.bar_sum = 0                            # 上一遍 frame pass 的柱高和（火警特效用）
        self.disp = [(0, 0, 0)] * N_BANDS

    def sample(self, x16, frame_pass=False):
        xs = x16 << X_SHIFT
        dx = xs - self.x2
        mask = (1 << COEF_FRAC) - 1
        for k in range(N_BANDS):
            b0, a1, a2 = self.coefs[k]
            y1, y2 = self.y1[k], self.y2[k]
            # 第一级：输入 x
            acc = b0 * dx - a1 * y1 - a2 * y2 + self.ey[k]
            self.ey[k] = acc & mask
            y = sat(acc >> COEF_FRAC, Y_BITS)
            # 第二级：输入 = 第一级输出，其输入历史正好就是 y1/y2（共用，不另存）
            acc = b0 * (y - y2) - a1 * self.z1[k] - a2 * self.z2[k] + self.ez[k]
            self.ez[k] = acc & mask
            z = sat(acc >> COEF_FRAC, Y_BITS)
            self.y2[k], self.y1[k] = y1, y
            self.z2[k], self.z1[k] = self.z1[k], z
            a = abs(z)
            e = self.env[k]
            if a > e:
                e = e + ((a - e) >> ENV_ATTACK)
            else:
                e = e - (e >> ENV_RELEASE)
            self.env[k] = e
            if frame_pass:
                self._frame_band(k)
        self.x2 = self.x1
        self.x1 = xs

    def _frame_band(self, k):
        lv = log2_q4(self.env[k]) + BAND_TILT[k] - LOG_MIN_Q4
        h = (lv * 3) >> 3 if lv > 0 else 0
        if h > DEPTH:
            h = DEPTH
        self.bar[k] = h
        hq = h << 4
        if hq >= self.peak[k]:
            self.peak[k] = hq
            self.hold[k] = PEAK_HOLD
            self.vel[k] = 0
        elif self.hold[k]:
            self.hold[k] -= 1
        else:
            self.vel[k] += PEAK_ACC_Q4
            p = self.peak[k] - self.vel[k]
            self.peak[k] = p if p > 0 else 0
        pk = self.peak[k] >> 4
        self.disp[k] = ((h + 3) >> 2, 1 if pk > 0 else 0, ((pk - 1) >> 2) if pk > 0 else 0)
        if k == N_BANDS - 1:
            self.bar_sum = sum(self.bar)


# ----------------------------------------------------------------------------
# 显示（逐像素，和 spectrum_border_overlay.v 的流水线算的是同一个函数）
# ----------------------------------------------------------------------------
def pixel_geom(x, y):
    """返回 (d, p)：离最近边的距离、沿边框顺时针坐标。优先级 上 > 右 > 下 > 左"""
    dt, db, dl, dr = y, SCR_H - 1 - y, x, SCR_W - 1 - x
    if dt <= db and dt <= dl and dt <= dr:
        return dt, x
    if dr <= db and dr <= dl:
        return dr, SCR_W + y
    if db <= dl:
        return db, SCR_W + SCR_H + (SCR_W - 1 - x)
    return dl, 2 * SCR_W + SCR_H + (SCR_H - 1 - y)


def bar_to_band(idx):
    """140 根柱 → 35 频带，镜像（低→高→低）绕两圈"""
    i = idx - 2 * N_BANDS if idx >= 2 * N_BANDS else idx
    return i if i < N_BANDS else 2 * N_BANDS - 1 - i


def pixel_out(x, y, bg, disp, rot):
    d, p = pixel_geom(x, y)
    if d >= DEPTH:
        return bg
    q = p + rot
    if q >= PERIM:
        q -= PERIM
    pos = q & (BAR_PITCH - 1)
    if pos < BAR_LIT_LO or pos > BAR_LIT_HI:
        return bg                                 # 柱间缝
    if (d & (LED_PITCH - 1)) == LED_PITCH - 1:
        return bg                                 # LED 段间缝
    band = bar_to_band(q >> 4)
    seg = d >> 2
    col = BAND_COLOR[band]
    hseg, pvalid, pseg = disp[band]
    if pvalid and seg == pseg and seg >= hseg:
        return tuple((c >> 1) + 128 for c in col)                         # 峰值段
    if seg < hseg:
        return tuple((b >> 3) + c - (c >> 3) for b, c in zip(bg, col))     # 点亮
    return tuple((b >> 1) + (b >> 2) + (c >> 4) for b, c in zip(bg, col))  # 暗格


def render(bg, disp, rot):
    out = list(bg)
    for y in range(SCR_H):
        if DEPTH <= y < SCR_H - DEPTH:
            xs = list(range(DEPTH)) + list(range(SCR_W - DEPTH, SCR_W))
        else:
            xs = range(SCR_W)
        for x in xs:
            i = y * SCR_W + x
            out[i] = pixel_out(x, y, bg[i], disp, rot)
    return out


# ----------------------------------------------------------------------------
# 火警特效（报警时替换 LED 环，alarm_fx_demo.py 的 A_haze 方案）
#   红色晕染：离边 128 像素内，(128-d)^2 平方衰减，强度随 40 帧呼吸 + 音量
#   火焰边框：离边 64 像素内，四边向内烧，火焰高度 = 相邻频带柱高插值；
#             值噪声削火舌、xorshift 噪声做翻涌和火星。不旋转。
# 和 spectrum_border_overlay.v 的 fx 通路逐位一致。与 demo 的差别只在帧状态：
#   帧计数 f 14 位回绕（噪声只用到低 14 位，效果相同）；呼吸相位单独计 0..39；
#   音量包络在帧起点用"上一遍 frame pass"的柱高和（RTL 里显示表这时还没更新）。
# ----------------------------------------------------------------------------
FX_HAZE = 128                   # 晕染深度
FX_FLAME = 64                   # 火焰区深度
FX_BREATH = 40                  # 呼吸周期（帧），≈1.5Hz
FX_HAZE_R = 200                 # 晕染颜色 (200,0,0)
FX_BAYER4 = [[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]


def xs16(a, b):
    """两个坐标 → 16 位伪随机。xorshift，只有移位和异或"""
    v = ((a & 0x1FF) | ((b & 0x7F) << 9)) ^ 0xACE1
    v ^= (v << 7) & 0xFFFF
    v ^= v >> 9
    v ^= (v << 8) & 0xFFFF
    return v


class FireFx:
    """帧级状态，每个 frame_start 调一次 frame()"""

    def __init__(self):
        self.f = 0              # 14 位帧计数
        self.ph = 0             # 呼吸相位 0..39
        self.env = 0            # 音量包络 0..240

    def frame(self, bar_sum):
        self.f = (self.f + 1) & 0x3FFF
        self.ph = 0 if self.ph == FX_BREATH - 1 else self.ph + 1
        lvl = min((bar_sum * 7) >> 5, 240)
        self.env = lvl if lvl > self.env else max(0, self.env - 4)

    def inten(self):
        """晕染强度 112..222：三角波 * 增益（静音也有呼吸，越响越深）"""
        v = self.ph if self.ph < FX_BREATH // 2 else FX_BREATH - 1 - self.ph
        return 112 + ((v * 12 * (128 + (self.env >> 1))) >> 9)


def fire_color(heat):
    """heat 0..255 → 暗红→红→橙→黄→白。第 0 段 R 最高 285（9 位，混合后才饱和）"""
    seg, t = heat >> 6, (heat & 63) << 2
    if seg == 0:
        return (96 + (t >> 1) + (t >> 2), 0, 0)
    if seg == 1:
        return (255, t >> 1, 0)
    if seg == 2:
        return (255, 128 + (t >> 1), t >> 3)
    return (255, 255, 32 + t - (t >> 3))


def fire_pixel(x, y, bg, bars, f, inten):
    d, p = pixel_geom(x, y)
    if d >= FX_HAZE:
        return bg
    # 晕染（16 级混合 + 4x4 Bayer 抖动）
    r = FX_HAZE - d
    a = (((r * r * inten) >> 14) + FX_BAYER4[y & 3][x & 3]) >> 4
    bg = ((bg[0] * (16 - a) + FX_HAZE_R * a) >> 4, (bg[1] * (16 - a)) >> 4, (bg[2] * (16 - a)) >> 4)
    if d >= FX_FLAME:
        return bg
    # 火焰高度：相邻两根柱对应频带的柱高插值
    bar = p >> 4
    h0 = bars[bar_to_band(bar)]
    h1 = bars[bar_to_band(bar + 1 if bar + 1 < N_BARS else 0)]
    h = h0 + (((h1 - h0) * (p & 15)) >> 4)
    hgt = 6 + h + (h >> 2)                                   # 6..56
    # 火舌：沿边平滑值噪声（每 16 列一个点，横向漂移，每 4 帧换一组）削掉 0~50%
    c = (p + (f >> 1)) & 0x1FFF
    g, t, s = c >> 4, c & 15, f >> 2
    n0 = xs16(g, s) & 31
    n1 = xs16(g + 1, s) & 31
    tn = n0 + (((n1 - n0) * t) >> 4)
    hgt -= (tn * hgt) >> 6
    if d >= hgt:
        # 火舌上方 12 像素内偶尔飘一点火星
        if d < hgt + 12 and (xs16(p, (d + f * 3) >> 1) & 0x3FF) < 6:
            return (255, 200, 60)
        return bg
    lick = xs16(p >> 2, (d + f * 2) >> 2) & 15
    spark = xs16(p, d + f * 3) & 15
    heat = (hgt - d) * 5 + lick + spark - 16
    if heat <= 0:
        return bg
    heat = min(heat, 255)
    col = fire_color(heat)
    if heat >= 120:
        return col
    if heat >= 80:
        o = tuple((b >> 2) + (c >> 1) + (c >> 2) for b, c in zip(bg, col))
    elif heat >= 40:
        o = tuple((b >> 1) + (c >> 1) for b, c in zip(bg, col))
    else:
        o = tuple((b >> 1) + (b >> 2) + (c >> 2) for b, c in zip(bg, col))
    return tuple(min(v, 255) for v in o)


def render_fire(bg, bars, fx):
    out = list(bg)
    f, inten = fx.f, fx.inten()
    for y in range(SCR_H):
        if FX_HAZE <= y < SCR_H - FX_HAZE:
            xs = list(range(FX_HAZE)) + list(range(SCR_W - FX_HAZE, SCR_W))
        else:
            xs = range(SCR_W)
        for x in xs:
            i = y * SCR_W + x
            out[i] = fire_pixel(x, y, bg[i], bars, f, inten)
    return out


# ----------------------------------------------------------------------------
# 常量生成
# ----------------------------------------------------------------------------
def gen_files(here):
    coefs, _ = band_coefs()
    m = (1 << COEF_BITS) - 1
    lines = []
    # 每带 4 个字：B  -A1  -A2  0。A1/A2 预先取负，RTL 的累加器只做加法
    for b0, a1, a2 in coefs:
        lines += ['%06x' % (b0 & m), '%06x' % (-a1 & m), '%06x' % (-a2 & m), '000000']
    lines += ['000000'] * (256 - len(lines))
    txt = '\n'.join(lines) + '\n'
    # 和 emergency_screen.hex 一样，.v 目录和 .al 根目录各放一份
    for d in (here, os.path.normpath(os.path.join(here, '..', '..', '..', 'td_project'))):
        with open(os.path.join(d, 'spectrum_coef.hex'), 'w') as f:
            f.write(txt)
    print('spectrum_coef.hex written')
    print('// BAND_TILT', BAND_TILT)
    print('// BAND_COLOR', ['%02x%02x%02x' % c for c in BAND_COLOR])


# ----------------------------------------------------------------------------
def load_wav(path):
    w = wave.open(path)
    assert w.getsampwidth() == 2 and w.getframerate() == FS
    n, ch = w.getnframes(), w.getnchannels()
    raw = w.readframes(n)
    s = [int.from_bytes(raw[i:i + 2], 'little', signed=True)
         for i in range(0, len(raw), 2)]
    if ch == 2:
        s = [(s[i] + s[i + 1]) >> 1 for i in range(0, len(s), 2)]
    return s


def load_bg(path):
    from PIL import Image
    im = Image.open(path).convert('RGB').resize((SCR_W, SCR_H))
    # 模拟 SDRAM 里 RGB565 存储 + 高位回填
    px = []
    for r, g, b in zip(*[iter(im.tobytes())] * 3):
        r5, g6, b5 = r >> 3, g >> 2, b >> 3
        px.append(((r5 << 3) | (r5 >> 2), (g6 << 2) | (g6 >> 4), (b5 << 3) | (b5 >> 2)))
    return px


def fire_preview(here, tf, t0=4.0, n_frames=120):
    """火警特效预览：PIC12+MUSIC12（预警）、PIC13+MUSIC13（火灾），按 RTL 的帧时序跑"""
    from PIL import Image
    outdir = os.path.join(here, 'preview', 'alarm_fx')
    os.makedirs(outdir, exist_ok=True)
    for n in ('12', '13'):
        an, fx = Analyzer(), FireFx()
        pcm = load_wav(os.path.join(tf, 'MUSIC%s.WAV' % n))
        bg = load_bg(os.path.join(tf, 'PIC%s.BMP' % n))
        pos, acc, k = max(0, int((t0 - 1.5) * FS)), 0.0, 0
        first = int(t0 * FS)
        frames = []
        while k < n_frames and pos < len(pcm):
            acc += FRAME_SAMPLES
            m = int(acc)
            acc -= m
            fx.frame(an.bar_sum)                    # frame_start：先更新帧状态
            for j, s in enumerate(pcm[pos:pos + m]):
                an.sample(s, frame_pass=(j == 0))
            pos += m
            if pos < first:
                continue
            k += 1
            if k % 2 == 0:
                im = Image.new('RGB', (SCR_W, SCR_H))
                im.putdata(render_fire(bg, an.bar, fx))
                frames.append(im)
        frames[0].save(os.path.join(outdir, 'pic%s_fire_rtl.gif' % n), save_all=True,
                       append_images=frames[1:], duration=33, loop=0)
        frames[len(frames) // 2].save(os.path.join(outdir, 'pic%s_fire_rtl.png' % n))
        print('pic%s: %d frames' % (n, len(frames)))
    print('saved to', outdir)


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    if '--gen' in sys.argv:
        gen_files(here)
        return
    if '--fire' in sys.argv:
        tf = os.path.normpath(os.path.join(here, '..', '..', '..', '..', '..', 'TF卡文件'))
        fire_preview(here, tf)
        return
    from PIL import Image
    tf = os.path.normpath(os.path.join(here, '..', '..', '..', '..', '..', 'TF卡文件'))
    wav = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] else os.path.join(tf, 'MUSIC1.WAV')
    bmp = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else os.path.join(tf, 'PIC5.BMP')
    t0 = float(sys.argv[3]) if len(sys.argv) > 3 else 6.0
    n_frames = int(sys.argv[4]) if len(sys.argv) > 4 else 120
    outdir = os.path.join(here, 'preview')
    os.makedirs(outdir, exist_ok=True)

    an = Analyzer()
    print('Q = %.2f, bands = %s' % (an.q, ', '.join('%.0f' % f for f in band_centers())))
    pcm = load_wav(wav)
    bg = load_bg(bmp)

    # 预热：从 t0 前 2s 开始跑，让起始瞬态和它留下的峰值点落完
    start = max(0, int((t0 - 2.0) * FS))
    first_show = int(t0 * FS)
    pos, acc, rot = start, 0.0, 0
    frames, rows = [], []
    while len(frames) < n_frames and pos < len(pcm):
        acc += FRAME_SAMPLES
        n = int(acc)
        acc -= n
        for i, s in enumerate(pcm[pos:pos + n]):
            an.sample(s, frame_pass=(i == 0))
        pos += n
        rot = rot + SPIN_STEP - (PERIM if rot + SPIN_STEP >= PERIM else 0)
        if pos < first_show:
            continue
        rows.append(list(an.bar))
        if len(frames) % 2 == 0:
            img = Image.new('RGB', (SCR_W, SCR_H))
            img.putdata(render(bg, an.disp, rot))
            frames.append(img)
        else:
            frames.append(None)
    shown = [f for f in frames if f is not None]
    mid = shown[len(shown) // 2]
    mid.save(os.path.join(outdir, 'still.png'))
    mid.resize((SCR_W * 2, SCR_H * 2), Image.NEAREST).save(os.path.join(outdir, 'still_2x.png'))
    shown[0].save(os.path.join(outdir, 'anim.gif'), save_all=True,
                  append_images=shown[1:], duration=33, loop=0)
    with open(os.path.join(outdir, 'bars.csv'), 'w') as f:
        for r in rows:
            f.write(','.join(map(str, r)) + '\n')
    print('saved to', outdir)


if __name__ == '__main__':
    main()
