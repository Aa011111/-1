`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 双屏协同 · 主机（火灾检测板，src_zhu 工程）
//
// 每 POLL_MS 发一帧 STATUS 给外部屏（从机），把本机火警等级带过去；等级一变
// 不等轮询周期，空闲就立刻补发一帧（预警来了外部屏几十 ms 内就切图）。
// 每帧都要等从机回 ACK（SEQ 必须对上），连续 MISS_LIMIT 帧没回 -> link_lost。
//
//   主机 -> 从机  STATUS：ADDR=SLAVE_ADDR CMD=0x01 SEQ=n DATA0=等级 DATA1=传感器位 时分秒=0
//   从机 -> 主机  ACK   ：ADDR=SLAVE_ADDR CMD=0x81 SEQ=n DATA0=从机屏幕状态
//                         DATA1=bit7 时间有效 + 从机标志  时分秒=从机 DS3231 时间（BCD）
//   等级：0 正常 / 1 火灾预警（PIC12）/ 2 火灾发生（PIC13）
//   DATA1：bit0 烟雾  bit1 温度（只是告诉对方原因，从机不用它判定）
//
// 【实时时钟】本机不接 DS3231，时间取自从机 ACK。轮询 200ms，对 1Hz 走的秒
// 采样 5 次，屏上不会跳秒/停秒（1s 轮询会）。连续 TIME_MISS_LIMIT 帧没应答
// 就清 time_valid，屏幕显示 --:--:--，不拿旧时间冒充。
// time_bcd / time_valid 是寄存器输出，最快每 POLL_MS 变一次。
//
// 每次回到 IDLE 后至少静默 TURN_CLKS（3.5 个字符，同 Modbus 帧间隔）才发下一帧：
// 判出 ACK 有效是在从机最后一个停止位的中间，从机还要再过半位 + 1 位才放 DE，
// 等级恰好在这时变化、立刻补发的话两边会同时驱动总线（仿真里撞到过）。
// 只在 WAIT_ACK 时打开接收：本机在发的时候 SP3485 接收器是关的，平时总线上
// 也只有从机会回话，这样任何不是"应答本帧"的东西都进不来。
// 全部在 sd_card_clk 域；level / sensor_flags 是同域寄存器输出（fire_alarm_ctrl）。
// -----------------------------------------------------------------------------
module rs485_alarm_master #(
    parameter integer CLK_FREQ_HZ     = 100_000_000,
    parameter integer BAUD            = 9600,
    parameter integer POLL_MS         = 200,
    parameter integer ACK_TIMEOUT_MS  = 50,
    parameter integer MISS_LIMIT      = 15,    // x POLL_MS = 3s 报 0x74
    parameter integer TIME_MISS_LIMIT = 3,     // x POLL_MS ≈ 0.6s 时间作废
    parameter [7:0]   SLAVE_ADDR      = 8'h01,
    // 仿真时直接给拍数缩短时间；0 = 按上面的毫秒数算
    parameter integer POLL_CLKS_OVR   = 0,
    parameter integer ACK_CLKS_OVR    = 0
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [1:0] level,           // 0 正常 / 1 预警 / 2 火灾
    input  wire [7:0] sensor_flags,

    input  wire       rs485_rxd,
    output wire       rs485_txd,
    output wire       rs485_de,

    output reg        link_ok,         // 最近一帧有应答
    output reg        link_lost,       // 连续 MISS_LIMIT 帧没应答；收到一次应答就清
    output reg  [7:0] slave_state,     // 从机最近一次 ACK 的 DATA0
    output reg  [7:0] slave_flags,     // 从机 DATA1[6:0]（bit7 是时间有效，单独给出）
    output reg [23:0] time_bcd,        // {时十, 时个, 分十, 分个, 秒十, 秒个}
    output reg        time_valid,
    output wire [7:0] diag_code        // 0x74 = 外部屏不应答，其余 0
);
    localparam integer CLKS_PER_BIT = (CLK_FREQ_HZ + BAUD / 2) / BAUD;
    localparam integer POLL_CLKS = (POLL_CLKS_OVR != 0) ? POLL_CLKS_OVR :
                                   (CLK_FREQ_HZ / 1000) * POLL_MS;
    localparam integer ACK_CLKS  = (ACK_CLKS_OVR != 0) ? ACK_CLKS_OVR :
                                   (CLK_FREQ_HZ / 1000) * ACK_TIMEOUT_MS;
    localparam integer TURN_CLKS = 35 * CLKS_PER_BIT;

    // 计数器按实际上限取位宽（原来一律 32 位）
    localparam integer PW = $clog2(POLL_CLKS + 1);
    localparam integer AW = $clog2(ACK_CLKS + 1);
    localparam integer QW = $clog2(TURN_CLKS + 1);

    localparam [7:0] CMD_STATUS = 8'h01;
    localparam [7:0] CMD_ACK    = 8'h81;

    localparam [1:0] ST_IDLE = 2'd0;
    localparam [1:0] ST_TX   = 2'd1;
    localparam [1:0] ST_WAIT = 2'd2;

    reg  [1:0]    state;
    reg  [PW-1:0] poll_cnt;
    reg  [AW-1:0] ack_cnt;
    reg  [QW-1:0] quiet_cnt;
    reg  [7:0]    seq;
    reg  [1:0]    sent_level;
    reg  [7:0]    sent_flags;
    reg  [7:0]    miss_cnt;
    reg           tx_start;

    wire          tx_busy;
    wire          rx_valid;
    wire [63:0]   rx_payload;

    // 发送内容全部来自只在 IDLE 里更新的寄存器，ST_TX 期间不变，满足 frame_tx
    // "busy 期间 payload 不变"的要求，不用再锁存一份
    wire [63:0]   tx_payload = {SLAVE_ADDR, CMD_STATUS, seq,
                                6'd0, sent_level, sent_flags, 24'd0};

    wire          poll_due    = (poll_cnt >= POLL_CLKS - 1);
    wire          bus_quiet   = (quiet_cnt >= TURN_CLKS - 1);
    wire          level_moved = (level != sent_level);
    wire          ack_match   = rx_valid &&
                                rx_payload[63:56] == SLAVE_ADDR &&
                                rx_payload[55:48] == CMD_ACK &&
                                rx_payload[47:40] == seq;

    assign diag_code = link_lost ? 8'h74 : 8'h00;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state       <= ST_IDLE;
            poll_cnt    <= {PW{1'b0}};
            ack_cnt     <= {AW{1'b0}};
            quiet_cnt   <= {QW{1'b0}};
            seq         <= 8'd0;
            sent_level  <= 2'd0;
            sent_flags  <= 8'd0;
            miss_cnt    <= 8'd0;
            tx_start    <= 1'b0;
            link_ok     <= 1'b0;
            link_lost   <= 1'b0;
            slave_state <= 8'd0;
            slave_flags <= 8'd0;
            time_bcd    <= 24'd0;
            time_valid  <= 1'b0;
        end else begin
            tx_start <= 1'b0;
            if (!poll_due)
                poll_cnt <= poll_cnt + 1'b1;

            case (state)
                ST_IDLE: begin
                    if (!bus_quiet)
                        quiet_cnt <= quiet_cnt + 1'b1;
                    if (bus_quiet && (poll_due || level_moved)) begin
                        quiet_cnt  <= {QW{1'b0}};
                        poll_cnt   <= {PW{1'b0}};
                        seq        <= seq + 8'd1;
                        sent_level <= level;
                        sent_flags <= sensor_flags;
                        tx_start   <= 1'b1;
                        state      <= ST_TX;
                    end
                end
                ST_TX: begin
                    // tx_start 打出去的那一拍 busy 还没起来，多等一拍再看
                    if (!tx_start && !tx_busy) begin
                        ack_cnt <= {AW{1'b0}};
                        state   <= ST_WAIT;
                    end
                end
                ST_WAIT: begin
                    if (ack_match) begin
                        miss_cnt    <= 8'd0;
                        link_ok     <= 1'b1;
                        link_lost   <= 1'b0;
                        slave_state <= rx_payload[39:32];
                        slave_flags <= {1'b0, rx_payload[30:24]};
                        time_valid  <= rx_payload[31];
                        time_bcd    <= rx_payload[23:0];
                        state       <= ST_IDLE;
                    end else if (ack_cnt >= ACK_CLKS - 1) begin
                        link_ok <= 1'b0;
                        if (miss_cnt != 8'hFF)
                            miss_cnt <= miss_cnt + 8'd1;
                        if (miss_cnt + 8'd1 >= MISS_LIMIT)
                            link_lost <= 1'b1;
                        if (miss_cnt + 8'd1 >= TIME_MISS_LIMIT)
                            time_valid <= 1'b0;
                        state <= ST_IDLE;
                    end else begin
                        ack_cnt <= ack_cnt + 1'b1;
                    end
                end
                default: state <= ST_IDLE;
            endcase
        end
    end

    rs485_frame_tx #(
        .CLKS_PER_BIT (CLKS_PER_BIT)
    ) u_frame_tx (
        .clk     (clk),
        .rst_n   (rst_n),
        .start   (tx_start),
        .payload (tx_payload),
        .txd     (rs485_txd),
        .de      (rs485_de),
        .busy    (tx_busy)
    );

    rs485_frame_rx #(
        .CLKS_PER_BIT (CLKS_PER_BIT),
        .GAP_CLKS     (35 * CLKS_PER_BIT)
    ) u_frame_rx (
        .clk           (clk),
        .rst_n         (rst_n),
        .rxd           (rs485_rxd),
        .enable        (state == ST_WAIT),
        .frame_valid   (rx_valid),
        .payload       (rx_payload),
        .crc_error     (),
        .framing_error ()
    );
endmodule
