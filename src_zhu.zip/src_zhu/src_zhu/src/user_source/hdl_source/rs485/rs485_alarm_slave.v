`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 双屏协同 · 从机（外部疏散显示屏，src 工程）
//
// 收主机的 STATUS 帧（帧格式 / 字段含义见 rs485_alarm_master.v 文件头），
// 把 DATA0 的火警等级交给 fire_alarm_ctrl 的 remote_level，再回一帧 ACK：
//   ADDR=MY_ADDR CMD=0x81 SEQ=原样 DATA0=shown_state
//   DATA1={time_valid, local_flags[6:0]} 时分秒=time_bcd
// 时间来自本机 DS3231（ds3231_rtc），主机没有时钟模块，靠这个显示 HH:MM:SS。
// ADDR=0xFF 是广播：照收不回（以后接多块外部屏时，主机可以一帧通知全部）。
//
// 回 ACK 前先等 REPLY_DELAY_MS：本机判出帧有效是在主机最后一个停止位的中间，
// 主机还要再过半位 + 1 位才放掉 DE，立刻回话会和它撞在总线上。
//
// 掉线（LINK_TIMEOUT_MS 内没收到发给自己的 STATUS）时 remote_level【保持】
// 最后一次的值：主机板在火场里烧坏 / 断电，外部屏要继续指示疏散，不能自己
// 回到正常画面。报警只能由主机一帧明确的"等级 0"解除。上电后从没收到过
// 帧时是 0，不误报。掉线只通过 link_lost / diag_code 0x75 告知。
// -----------------------------------------------------------------------------
module rs485_alarm_slave #(
    parameter integer CLK_FREQ_HZ     = 100_000_000,
    parameter integer BAUD            = 9600,
    parameter integer REPLY_DELAY_MS  = 2,
    parameter integer LINK_TIMEOUT_MS = 3500,
    parameter [7:0]   MY_ADDR         = 8'h01,
    // 仿真时直接给拍数缩短时间；0 = 按上面的毫秒数算
    parameter integer REPLY_CLKS_OVR  = 0,
    parameter integer LINK_CLKS_OVR   = 0
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire [7:0] shown_state,     // 0 正常 / 1 PIC12 / 2 PIC13 / 3 ROM 逃生画面
    input  wire [7:0] local_flags,     // 只发 bit6~0，bit7 让给 time_valid
    input  wire [23:0] time_bcd,       // 本机 DS3231，{时十, 时个, 分十, 分个, 秒十, 秒个}
    input  wire       time_valid,

    input  wire       rs485_rxd,
    output wire       rs485_txd,
    output wire       rs485_de,

    output reg  [1:0] remote_level,    // 0 正常 / 1 预警 / 2 火灾
    output reg  [7:0] remote_flags,    // 主机 DATA1：bit0 烟雾 bit1 温度
    output reg        link_lost,
    output wire [7:0] diag_code        // 0x75 = 收不到主机，其余 0
);
    localparam integer CLKS_PER_BIT = (CLK_FREQ_HZ + BAUD / 2) / BAUD;
    localparam integer REPLY_CLKS = (REPLY_CLKS_OVR != 0) ? REPLY_CLKS_OVR :
                                    (CLK_FREQ_HZ / 1000) * REPLY_DELAY_MS;
    localparam integer LINK_CLKS  = (LINK_CLKS_OVR != 0) ? LINK_CLKS_OVR :
                                    (CLK_FREQ_HZ / 1000) * LINK_TIMEOUT_MS;
    localparam integer DW = $clog2(REPLY_CLKS + 1);
    localparam integer LW = $clog2(LINK_CLKS + 1);

    localparam [7:0] CMD_STATUS = 8'h01;
    localparam [7:0] CMD_ACK    = 8'h81;
    localparam [7:0] ADDR_BCAST = 8'hFF;

    localparam [1:0] ST_IDLE  = 2'd0;
    localparam [1:0] ST_DELAY = 2'd1;
    localparam [1:0] ST_TX    = 2'd2;

    reg  [1:0]    state;
    reg  [DW-1:0] delay_cnt;
    reg  [LW-1:0] link_cnt;
    reg  [7:0]    rx_seq;
    reg           tx_start;
    reg  [63:0]   tx_payload;      // 只在 ST_DELAY 末尾装，ST_TX 期间不变

    wire          tx_busy;
    wire          rx_valid;
    wire [63:0]   rx_payload;

    wire [7:0]    rx_addr   = rx_payload[63:56];
    wire          status_rx = rx_valid &&
                              rx_payload[55:48] == CMD_STATUS &&
                              (rx_addr == MY_ADDR || rx_addr == ADDR_BCAST);
    // 协议只定义了 0~2；CRC 对但值越界说明两边版本不一致，按"火灾"处理宁可多疏散
    wire [1:0]    rx_level  = (rx_payload[39:32] > 8'd2) ? 2'd2 : rx_payload[33:32];

    assign diag_code = link_lost ? 8'h75 : 8'h00;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= ST_IDLE;
            delay_cnt    <= {DW{1'b0}};
            link_cnt     <= {LW{1'b0}};
            rx_seq       <= 8'd0;
            tx_start     <= 1'b0;
            tx_payload   <= 64'd0;
            remote_level <= 2'd0;
            remote_flags <= 8'd0;
            link_lost    <= 1'b0;
        end else begin
            tx_start <= 1'b0;

            if (status_rx) begin
                link_cnt  <= {LW{1'b0}};
                link_lost <= 1'b0;
            end else if (link_cnt >= LINK_CLKS - 1) begin
                link_lost <= 1'b1;
            end else begin
                link_cnt <= link_cnt + 1'b1;
            end

            case (state)
                ST_IDLE: begin
                    if (status_rx) begin
                        remote_level <= rx_level;
                        remote_flags <= rx_payload[31:24];
                        rx_seq       <= rx_payload[47:40];
                        delay_cnt    <= {DW{1'b0}};
                        if (rx_addr == MY_ADDR)
                            state <= ST_DELAY;
                    end
                end
                ST_DELAY: begin
                    if (delay_cnt >= REPLY_CLKS - 1) begin
                        // shown_state / 时间在发的这一拍取，回给主机的是"此刻"的值
                        tx_payload <= {MY_ADDR, CMD_ACK, rx_seq, shown_state,
                                       time_valid, local_flags[6:0], time_bcd};
                        tx_start   <= 1'b1;
                        state      <= ST_TX;
                    end else begin
                        delay_cnt <= delay_cnt + 1'b1;
                    end
                end
                ST_TX: begin
                    if (!tx_start && !tx_busy)
                        state <= ST_IDLE;
                end
                default: state <= ST_IDLE;
            endcase
        end
    end

    rs485_frame_tx #(
        .CLKS_PER_BIT (CLKS_PER_BIT)
    ) u_frame_tx (
        .clk     (clk),
        .rst_n   (rst_n),
        .start   (tx_start),
        .payload (tx_payload),
        .txd     (rs485_txd),
        .de      (rs485_de),
        .busy    (tx_busy)
    );

    rs485_frame_rx #(
        .CLKS_PER_BIT (CLKS_PER_BIT),
        .GAP_CLKS     (35 * CLKS_PER_BIT)
    ) u_frame_rx (
        .clk           (clk),
        .rst_n         (rst_n),
        .rxd           (rs485_rxd),
        .enable        (state == ST_IDLE),
        .frame_valid   (rx_valid),
        .payload       (rx_payload),
        .crc_error     (),
        .framing_error ()
    );
endmodule
