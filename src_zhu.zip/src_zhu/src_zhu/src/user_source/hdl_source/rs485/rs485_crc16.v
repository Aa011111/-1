`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// CRC-16/MODBUS 单字节更新（纯组合）
//   多项式 0x8005（反射形式 0xA001），初值 0xFFFF，LSB 先算，无最终异或。
//   发送时低字节在前。和 Modbus-RTU 完全一样，电脑上用 USB-485 + 任何
//   "Modbus CRC 计算器"都能手算核对一帧，调试时不用自己写工具。
// 发送侧（rs485_frame_tx）和接收侧（rs485_frame_rx）共用这一份。
// -----------------------------------------------------------------------------
module rs485_crc16 (
    input  wire [15:0] crc_in,
    input  wire [7:0]  data,
    output reg  [15:0] crc_out
);
    integer i;
    always @(*) begin
        crc_out = crc_in ^ {8'h00, data};
        for (i = 0; i < 8; i = i + 1)
            crc_out = crc_out[0] ? ((crc_out >> 1) ^ 16'hA001) : (crc_out >> 1);
    end
endmodule
