`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 双屏协同 485 链路自检：rs485_alarm_master + rs485_alarm_slave 挂同一条总线
//
// 总线模型：谁的 DE 高谁驱动；都不驱动时 = 1（SP3485 fail-safe 空闲态）。
// 本机 DE 高时自己的 RO 高阻、FPGA 上拉 -> 读到 1。bus_cut=1 模拟断线，
// bus_flip=1 模拟总线上一段干扰（把主机发的位取反）。
// 为缩短仿真，波特率提到 1Mbps（CLKS_PER_BIT=100），各定时用 *_OVR 直接给拍数；
// 对被测逻辑而言它们只是计数上限，握手顺序与真实值无关。
// 比例按真实参数取：轮询 1 份（真实 200ms）、主机 15 帧报 74、3 帧时间作废、
// 从机 17.5 份（真实 3.5s）报 75、"1 秒" = 5 份轮询。
// -----------------------------------------------------------------------------
module tb_rs485_link;
    reg clk = 1'b0;
    always #5 clk = ~clk;          // 100MHz
    reg rst_n = 1'b0;

    reg  [1:0] level = 2'd0;
    reg        bus_cut  = 1'b0;
    reg        bus_flip = 1'b0;

    // 从机侧 DS3231 的输出（顶层里来自 ds3231_rtc）
    reg [23:0] s_time_bcd   = 24'h123456;
    reg        s_time_valid = 1'b1;

    wire m_txd, m_de, s_txd, s_de;
    wire bus = m_de ? (m_txd ^ bus_flip) : s_de ? s_txd : 1'b1;
    wire m_rxd = m_de ? 1'b1 : (bus_cut ? 1'b1 : bus);
    wire s_rxd = s_de ? 1'b1 : (bus_cut ? 1'b1 : bus);

    wire        m_link_ok, m_link_lost;
    wire [7:0]  m_slave_state, m_slave_flags, m_diag;
    wire [23:0] m_time_bcd;
    wire        m_time_valid;
    wire [1:0]  s_level;
    wire [7:0]  s_flags, s_diag;
    wire        s_link_lost;

    localparam integer POLL = 200_000;     // 2ms，代表 200ms
    localparam integer LINK = 3_500_000;   // 17.5 个轮询周期，代表 3.5s
    localparam integer SEC  = POLL * 5;    // 代表 1s

    rs485_alarm_master #(
        .CLK_FREQ_HZ     (100_000_000),
        .BAUD            (1_000_000),
        .MISS_LIMIT      (15),
        .TIME_MISS_LIMIT (3),
        .POLL_CLKS_OVR   (POLL),
        .ACK_CLKS_OVR    (20_000)
    ) u_master (
        .clk          (clk),
        .rst_n        (rst_n),
        .level        (level),
        .sensor_flags ({6'd0, level == 2'd2, level != 2'd0}),
        .rs485_rxd    (m_rxd),
        .rs485_txd    (m_txd),
        .rs485_de     (m_de),
        .link_ok      (m_link_ok),
        .link_lost    (m_link_lost),
        .slave_state  (m_slave_state),
        .slave_flags  (m_slave_flags),
        .time_bcd     (m_time_bcd),
        .time_valid   (m_time_valid),
        .diag_code    (m_diag)
    );

    // 从机"屏上显示的"就是它收到的等级（顶层里实际来自 fire_alarm_ctrl）
    // local_flags 给 0xDA：bit7 必须被 time_valid 顶掉，主机应收到 0x5A
    rs485_alarm_slave #(
        .CLK_FREQ_HZ    (100_000_000),
        .BAUD           (1_000_000),
        .REPLY_CLKS_OVR (500),
        .LINK_CLKS_OVR  (LINK)
    ) u_slave (
        .clk          (clk),
        .rst_n        (rst_n),
        .shown_state  ({6'd0, s_level}),
        .local_flags  (8'hDA),
        .time_bcd     (s_time_bcd),
        .time_valid   (s_time_valid),
        .rs485_rxd    (s_rxd),
        .rs485_txd    (s_txd),
        .rs485_de     (s_de),
        .remote_level (s_level),
        .remote_flags (s_flags),
        .link_lost    (s_link_lost),
        .diag_code    (s_diag)
    );

    // ---- CRC 自身对标准校验值：CRC-16/MODBUS("123456789") = 0x4B37 ----
    reg  [15:0] crc_acc;
    wire [15:0] crc_nxt;
    reg  [7:0]  crc_byte;
    rs485_crc16 u_crc_chk (.crc_in(crc_acc), .data(crc_byte), .crc_out(crc_nxt));

    integer errors = 0;
    integer i;
    integer frames_m = 0;
    integer t0;

    always @(posedge m_de) frames_m = frames_m + 1;

    // 主从同时驱动总线 = 协议时序错误
    always @(posedge clk) if (m_de && s_de) begin
        $display("FAIL bus contention at %0t", $time);
        errors = errors + 1;
    end

    // ---- 走时监视：tick_on 期间主机看到的秒只能不变或 +1，不能跳也不能倒退 ----
    reg        tick_on = 1'b0;
    reg  [7:0] last_sec;
    integer    sec_steps = 0;
    integer    sec_bad   = 0;
    function [7:0] bcd_inc;        // 00~59 BCD 加 1，59 -> 00
        input [7:0] b;
        begin
            if (b == 8'h59)          bcd_inc = 8'h00;
            else if (b[3:0] == 4'd9) bcd_inc = {b[7:4] + 4'd1, 4'd0};
            else                     bcd_inc = b + 8'd1;
        end
    endfunction
    always @(m_time_bcd) if (tick_on && m_time_valid) begin
        if (m_time_bcd[7:0] == bcd_inc(last_sec))
            sec_steps = sec_steps + 1;
        else if (m_time_bcd[7:0] != last_sec) begin
            $display("FAIL second jumped %h -> %h at %0t", last_sec, m_time_bcd[7:0], $time);
            sec_bad = sec_bad + 1;
        end
        last_sec = m_time_bcd[7:0];
    end

    task check(input cond, input [8*64-1:0] msg);
        begin
            if (!cond) begin
                $display("FAIL %0s  (t=%0t lvl=%0d s_lvl=%0d m_ok=%0d m_lost=%0d s_lost=%0d m_time=%h/%0d)",
                         msg, $time, level, s_level, m_link_ok, m_link_lost, s_link_lost,
                         m_time_bcd, m_time_valid);
                errors = errors + 1;
            end else
                $display("ok   %0s", msg);
        end
    endtask

    task wait_clks(input integer n);
        begin repeat (n) @(posedge clk); end
    endtask

    initial begin
        crc_acc = 16'hFFFF;
        for (i = 0; i < 9; i = i + 1) begin
            crc_byte = "1" + i;
            #1 crc_acc = crc_nxt;
        end
        check(crc_acc == 16'h4B37, "crc16 modbus check value 0x4B37");

        wait_clks(10);
        rst_n = 1'b1;

        // 1. 上电正常轮询
        wait_clks(POLL * 3);
        check(m_link_ok && !m_link_lost && !s_link_lost, "link up after power-on");
        check(s_level == 2'd0 && m_diag == 8'h00 && s_diag == 8'h00, "normal level, no diag");
        check(m_slave_flags == 8'h5A, "master got slave flags via ACK (bit7 masked)");
        check(frames_m >= 2 && frames_m <= 4, "poll period ~POLL");
        check(m_time_valid && m_time_bcd == 24'h123456, "master got slave time 12:34:56");

        // 2. 预警：不等轮询周期，立刻补发
        level = 2'd1;
        t0 = $time;
        wait (s_level == 2'd1);
        // 最坏：正好赶上一来一回（帧+回复延时+ACK帧）+ 静默 3.5 字符 + 本帧
        //   = 11.2k + 0.5k + 11.2k + 3.5k + 11.2k ≈ 37.6k 拍 = 376us（$time 单位 ns）
        // 轮询周期是 2000us，远小于它就说明是"变化即发"而不是等轮询
        $display("     warn latency = %0d ns", $time - t0);
        check(($time - t0) < 400_000, "warn reaches slave without waiting for poll");
        wait_clks(30_000);
        check(m_slave_state == 8'd1, "slave reports PIC12 shown");
        check(s_flags == 8'h01, "sensor flags forwarded");

        // 3. 火灾
        level = 2'd2;
        wait_clks(30_000);
        check(s_level == 2'd2 && m_slave_state == 8'd2, "fire reaches slave, ack PIC13");

        // 4. 干扰：一帧被破坏 -> CRC 不过，不能误更新；下一帧恢复
        level = 2'd0;
        @(posedge m_de); wait_clks(1500); bus_flip = 1'b1; wait_clks(300); bus_flip = 1'b0;
        wait_clks(15_000);
        check(s_level == 2'd2, "corrupted frame rejected (level held)");
        check(m_time_valid, "one lost frame does not blank the clock");
        wait_clks(POLL + 20_000);
        check(s_level == 2'd0 && m_link_ok, "next poll recovers to normal");

        // 5. 校时：从机时间一变，下一次轮询主机就跟上
        s_time_bcd = 24'h083000;
        wait_clks(POLL + 30_000);
        check(m_time_valid && m_time_bcd == 24'h083000, "master follows slave time change");

        // 6. 从机自己读不到 DS3231 -> 主机显示 --:--:--；恢复后跟回来
        s_time_valid = 1'b0;
        wait_clks(POLL + 30_000);
        check(!m_time_valid && m_link_ok, "slave time invalid -> master invalid, link ok");
        s_time_valid = 1'b1;
        wait_clks(POLL + 30_000);
        check(m_time_valid, "slave time valid again -> master valid");

        // 7. 走时：从机按"1 秒"走 8 秒，主机看到的秒逐个 +1，不跳不停
        last_sec = m_time_bcd[7:0];
        tick_on  = 1'b1;
        for (i = 0; i < 8; i = i + 1) begin
            wait_clks(SEC);
            s_time_bcd[7:0] = bcd_inc(s_time_bcd[7:0]);
        end
        wait_clks(POLL + 30_000);
        tick_on = 1'b0;
        check(sec_bad == 0 && sec_steps == 8, "8 seconds ticked, every second shown once");

        // 8. 断线：火灾中拔线
        level = 2'd2;
        wait_clks(30_000);
        bus_cut = 1'b1;
        level = 2'd0;              // 主机侧解除了，但从机收不到
        wait_clks(POLL * 4);
        check(!m_time_valid, "master clock blanks after 3 misses");
        check(!m_link_lost && m_diag == 8'h00, "master not yet link_lost before 15 misses");
        wait_clks(POLL * 15);
        check(m_link_lost && m_diag == 8'h74, "master: link_lost + diag 74 after 15 misses");
        check(s_link_lost && s_diag == 8'h75, "slave: link_lost + diag 75 after timeout");
        check(s_level == 2'd2, "slave HOLDS fire level while link lost");

        // 9. 重新接上：主机一帧"正常"把从机解除，时间恢复
        bus_cut = 1'b0;
        wait_clks(POLL + 30_000);
        check(!m_link_lost && !s_link_lost && m_diag == 8'h00 && s_diag == 8'h00,
              "both recover after reconnect");
        check(s_level == 2'd0, "slave cleared by explicit normal frame");
        check(m_time_valid && m_time_bcd == s_time_bcd, "master clock back after reconnect");

        if (errors == 0) $display("TEST_PASS tb_rs485_link");
        else             $display("TEST_FAIL tb_rs485_link errors=%0d", errors);
        $finish;
    end

    initial begin
        #400_000_000;
        $display("TEST_FAIL timeout");
        $finish;
    end
endmodule
