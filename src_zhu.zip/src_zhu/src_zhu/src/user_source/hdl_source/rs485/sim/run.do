vlib work
vlog ../../uart/uart_tx_byte.v ../../uart/uart_rx_byte.v \
     ../rs485_crc16.v ../rs485_frame_tx.v ../rs485_frame_rx.v \
     ../rs485_alarm_master.v ../rs485_alarm_slave.v tb_rs485_link.v
vsim -c work.tb_rs485_link
run -all
quit -f
