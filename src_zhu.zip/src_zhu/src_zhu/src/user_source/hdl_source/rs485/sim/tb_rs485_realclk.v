`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 上板等效链路检查：主机 50MHz（src_zhu 的 sd_card_clk）、从机 100MHz（src），
// 两边都是真实 9600 波特、真实 2ms 回复延时 / 50ms ACK 超时。只把轮询缩到 40ms，
// 从机掉线超时缩到 700ms，省仿真时间。tb_rs485_link 两边同时钟、1Mbps，测不到
// 两块板时钟不同、CLKS_PER_BIT 不同（5208 / 10417）的情况，这里补上。
// -----------------------------------------------------------------------------
module tb_rs485_realclk;
    reg clk_m = 1'b0;  always #10 clk_m = ~clk_m;     // 50MHz
    reg clk_s = 1'b0;  always #5  clk_s = ~clk_s;     // 100MHz
    reg rst_n = 1'b0;

    reg [23:0] s_time = 24'h123456;
    reg        s_time_valid = 1'b1;

    wire m_txd, m_de, s_txd, s_de;
    wire bus   = m_de ? m_txd : s_de ? s_txd : 1'b1;
    wire m_rxd = m_de ? 1'b1 : bus;
    wire s_rxd = s_de ? 1'b1 : bus;

    wire        m_link_ok, m_link_lost, m_time_valid;
    wire [23:0] m_time;
    wire [7:0]  m_diag, s_diag;
    wire [1:0]  s_level;

    rs485_alarm_master #(
        .CLK_FREQ_HZ     (50_000_000),
        .BAUD            (9600),
        .ACK_TIMEOUT_MS  (50),
        .MISS_LIMIT      (15),
        .TIME_MISS_LIMIT (3),
        .POLL_CLKS_OVR   (2_000_000)       // 40ms @50MHz
    ) u_master (
        .clk(clk_m), .rst_n(rst_n), .level(2'd0), .sensor_flags(8'd0),
        .rs485_rxd(m_rxd), .rs485_txd(m_txd), .rs485_de(m_de),
        .link_ok(m_link_ok), .link_lost(m_link_lost), .slave_state(), .slave_flags(),
        .time_bcd(m_time), .time_valid(m_time_valid), .diag_code(m_diag)
    );

    rs485_alarm_slave #(
        .CLK_FREQ_HZ    (100_000_000),
        .BAUD           (9600),
        .REPLY_DELAY_MS (2),
        .LINK_CLKS_OVR  (70_000_000)       // 700ms @100MHz
    ) u_slave (
        .clk(clk_s), .rst_n(rst_n), .shown_state(8'd0), .local_flags(8'd0),
        .time_bcd(s_time), .time_valid(s_time_valid),
        .rs485_rxd(s_rxd), .rs485_txd(s_txd), .rs485_de(s_de),
        .remote_level(s_level), .remote_flags(), .link_lost(), .diag_code(s_diag)
    );

    integer errors = 0;
    integer acks = 0;
    always @(posedge u_master.rx_valid) acks = acks + 1;
    always @(posedge clk_m) if (m_de && s_de) begin
        $display("FAIL bus contention at %0t", $time); errors = errors + 1;
    end

    task check(input cond, input [8*64-1:0] msg);
        begin
            if (!cond) begin
                $display("FAIL %0s (t=%0t ok=%0d lost=%0d tv=%0d t=%h acks=%0d sdiag=%h)",
                         msg, $time, m_link_ok, m_link_lost, m_time_valid, m_time, acks, s_diag);
                errors = errors + 1;
            end else $display("ok   %0s", msg);
        end
    endtask

    initial begin
        #1000 rst_n = 1'b1;
        #120_000_000;                       // 120ms ≈ 3 次轮询
        check(acks >= 2, "master received ACK frames (50MHz <-> 100MHz)");
        check(m_link_ok && !m_link_lost && m_diag == 8'h00, "link ok, no 74");
        check(s_diag == 8'h00, "slave no 75");
        check(m_time_valid && m_time == 24'h123456, "master shows slave time 12:34:56");
        s_time = 24'h083000;
        #60_000_000;
        check(m_time_valid && m_time == 24'h083000, "master follows TIM=083000 on slave");
        if (errors == 0) $display("TEST_PASS tb_rs485_realclk");
        else             $display("TEST_FAIL tb_rs485_realclk errors=%0d", errors);
        $finish;
    end
endmodule
