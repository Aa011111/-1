`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// RS-485 发一帧（半双工，SP3485 的 DE 与 /RE 接在一起由 de 驱动）
//
// 帧格式（固定 11 字节，两个方向一样，见 rs485/README.md）：
//   [0] 0xA5  帧头
//   [1] ADDR  [2] CMD  [3] SEQ  [4] DATA0  [5] DATA1        <- payload[63:24]，ADDR 在最高字节
//   [6] 时 BCD  [7] 分 BCD  [8] 秒 BCD                       <- payload[23:0]
//   [9] CRC16 低字节  [10] CRC16 高字节                       <- CRC-16/MODBUS 覆盖 [0]~[8]
//
// 时序：start -> de 拉高 -> 等 1 位（让 SP3485 驱动器先建立，总线从"空闲偏置"
// 过渡到确定的高电平）-> 连发 11 字节 -> 最后一个停止位发完再等 1 位 -> de 拉低。
// 尾部这 1 位不能省：uart_tx_byte 的 done 在停止位结束那一拍出来，这时立刻
// 放掉 de，停止位尾巴会被截断，对端偶尔判成帧错。
//
// 【payload 不在本模块锁存】从 start 到 busy 落低，上游必须保持 payload 不变
// （master / slave 都只在空闲时改它）。省掉一份 64 位副本，src_zhu 资源紧。
// -----------------------------------------------------------------------------
module rs485_frame_tx #(
    parameter integer CLKS_PER_BIT = 10417       // 100MHz / 9600
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        start,          // 单拍；busy 时忽略
    input  wire [63:0] payload,        // {ADDR, CMD, SEQ, DATA0, DATA1, 时, 分, 秒}
    output wire        txd,
    output reg         de,             // 1 = 发送（同时关掉本机接收器）
    output wire        busy
);
    localparam [7:0] SOF = 8'hA5;
    localparam integer CW = $clog2(CLKS_PER_BIT + 1);

    localparam [2:0] ST_IDLE  = 3'd0;
    localparam [2:0] ST_LEAD  = 3'd1;
    localparam [2:0] ST_ISSUE = 3'd2;
    localparam [2:0] ST_WAIT  = 3'd3;
    localparam [2:0] ST_TAIL  = 3'd4;

    reg  [2:0]    state;
    reg  [CW-1:0] cnt;
    reg  [3:0]    idx;          // 正在发第几个字节，0~10
    reg  [15:0]   crc;
    reg           byte_start;

    wire          byte_busy;
    wire          byte_done;

    reg  [7:0]  cur_byte;
    always @(*) begin
        case (idx)
            4'd0:    cur_byte = SOF;
            4'd1:    cur_byte = payload[63:56];
            4'd2:    cur_byte = payload[55:48];
            4'd3:    cur_byte = payload[47:40];
            4'd4:    cur_byte = payload[39:32];
            4'd5:    cur_byte = payload[31:24];
            4'd6:    cur_byte = payload[23:16];
            4'd7:    cur_byte = payload[15:8];
            4'd8:    cur_byte = payload[7:0];
            4'd9:    cur_byte = crc[7:0];
            default: cur_byte = crc[15:8];
        endcase
    end

    wire [15:0] crc_next;
    rs485_crc16 u_crc (
        .crc_in  (crc),
        .data    (cur_byte),
        .crc_out (crc_next)
    );

    assign busy = (state != ST_IDLE);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state      <= ST_IDLE;
            cnt        <= {CW{1'b0}};
            idx        <= 4'd0;
            crc        <= 16'hFFFF;
            de         <= 1'b0;
            byte_start <= 1'b0;
        end else begin
            byte_start <= 1'b0;
            case (state)
                ST_IDLE: begin
                    de <= 1'b0;
                    if (start) begin
                        crc   <= 16'hFFFF;
                        idx   <= 4'd0;
                        cnt   <= {CW{1'b0}};
                        de    <= 1'b1;
                        state <= ST_LEAD;
                    end
                end
                ST_LEAD: begin
                    if (cnt >= CLKS_PER_BIT - 1) begin
                        cnt   <= {CW{1'b0}};
                        state <= ST_ISSUE;
                    end else begin
                        cnt <= cnt + 1'b1;
                    end
                end
                ST_ISSUE: begin
                    // 第 0~8 字节边发边算 CRC；发到第 9 字节时 crc 已是最终值
                    if (!byte_busy) begin
                        byte_start <= 1'b1;
                        if (idx <= 4'd8)
                            crc <= crc_next;
                        state <= ST_WAIT;
                    end
                end
                ST_WAIT: begin
                    if (byte_done) begin
                        if (idx == 4'd10) begin
                            cnt   <= {CW{1'b0}};
                            state <= ST_TAIL;
                        end else begin
                            idx   <= idx + 4'd1;
                            state <= ST_ISSUE;
                        end
                    end
                end
                ST_TAIL: begin
                    if (cnt >= CLKS_PER_BIT - 1) begin
                        cnt   <= {CW{1'b0}};
                        de    <= 1'b0;
                        state <= ST_IDLE;
                    end else begin
                        cnt <= cnt + 1'b1;
                    end
                end
                default: state <= ST_IDLE;
            endcase
        end
    end

    // byte_start 比 cur_byte 晚一拍有效，但 ST_WAIT 期间 idx 不变，数据仍稳定
    uart_tx_byte #(
        .CLKS_PER_BIT (CLKS_PER_BIT)
    ) u_tx (
        .clk   (clk),
        .rst_n (rst_n),
        .start (byte_start),
        .data  (cur_byte),
        .tx    (txd),
        .busy  (byte_busy),
        .done  (byte_done)
    );
endmodule
