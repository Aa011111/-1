`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// RS-485 收一帧：uart_rx_byte + 找帧头 + 字节间超时 + CRC 校验
//
// 帧格式见 rs485_frame_tx.v 文件头。本模块不看 ADDR/CMD 的含义，只保证交出去的
// 8 字节 payload 通过了 CRC；地址/命令过滤由上层（master / slave）做。
//
// 同步规则（借 Modbus-RTU 的"3.5 字符静默"思路）：
//   - 空闲时只认 0xA5，其余字节丢弃；
//   - 帧内两个字节之间超过 GAP_CLKS 没来新字节，当前残帧作废，重新找帧头；
//   - enable=0 时（本机在发，或者不在等应答）丢弃一切并清掉残帧。
// 这样某一字节坏了 / 有人插线拔线制造了毛刺，最多丢当前这一帧，
// 下一帧（200ms 后）一定能重新对齐，不会一直错位。
//
// 【payload 直接引出移位寄存器】不另存一份：frame_valid 那一拍有效，并一直
// 保持到下一帧的第 1 个 payload 字节进来。上层只在 frame_valid 那一拍取用。
//
// SP3485 的 /RE 拉高（本机在发）时 RO 是高阻，FPGA 端必须开内部上拉
// （pin.adc 里 PULLTYPE = PULLUP），否则悬空的 RO 会被当成起始位。
// -----------------------------------------------------------------------------
module rs485_frame_rx #(
    parameter integer CLKS_PER_BIT = 10417,           // 100MHz / 9600
    parameter integer GAP_CLKS     = 35 * 10417       // 3.5 个字符时间
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        rxd,
    input  wire        enable,
    output reg         frame_valid,      // 单拍，payload 同拍有效
    output wire [63:0] payload,          // {ADDR, CMD, SEQ, DATA0, DATA1, 时, 分, 秒}
    output reg         crc_error,        // 单拍：凑够 11 字节但 CRC 不对
    output wire        framing_error     // 单拍：停止位错（透传 uart_rx_byte）
);
    localparam [7:0] SOF = 8'hA5;
    localparam integer GW = $clog2(GAP_CLKS + 1);

    wire [7:0] rx_data;
    wire       rx_valid;

    uart_rx_byte #(
        .CLKS_PER_BIT (CLKS_PER_BIT)
    ) u_rx (
        .clk           (clk),
        .rst_n         (rst_n),
        .rx            (rxd),
        .data          (rx_data),
        .valid         (rx_valid),
        .framing_error (framing_error)
    );

    reg  [3:0]    idx;          // 下一个收到的字节是第几个；0 = 在找帧头
    reg  [15:0]   crc;
    reg  [63:0]   shift;
    reg  [7:0]    crc_lo;
    reg  [GW-1:0] gap_cnt;

    assign payload = shift;

    wire [15:0] crc_next;
    rs485_crc16 u_crc (
        .crc_in  (idx == 4'd0 ? 16'hFFFF : crc),
        .data    (rx_data),
        .crc_out (crc_next)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            idx         <= 4'd0;
            crc         <= 16'hFFFF;
            shift       <= 64'd0;
            crc_lo      <= 8'd0;
            gap_cnt     <= {GW{1'b0}};
            frame_valid <= 1'b0;
            crc_error   <= 1'b0;
        end else begin
            frame_valid <= 1'b0;
            crc_error   <= 1'b0;

            if (!enable) begin
                idx     <= 4'd0;
                gap_cnt <= {GW{1'b0}};
            end else if (rx_valid) begin
                gap_cnt <= {GW{1'b0}};
                case (idx)
                    4'd0: if (rx_data == SOF) begin
                        crc <= crc_next;
                        idx <= 4'd1;
                    end
                    4'd1, 4'd2, 4'd3, 4'd4, 4'd5, 4'd6, 4'd7, 4'd8: begin
                        crc   <= crc_next;
                        shift <= {shift[55:0], rx_data};
                        idx   <= idx + 4'd1;
                    end
                    4'd9: begin
                        crc_lo <= rx_data;
                        idx    <= 4'd10;
                    end
                    default: begin
                        idx <= 4'd0;
                        if ({rx_data, crc_lo} == crc)
                            frame_valid <= 1'b1;
                        else
                            crc_error <= 1'b1;
                    end
                endcase
            end else if (idx != 4'd0) begin
                if (gap_cnt >= GAP_CLKS - 1) begin
                    gap_cnt <= {GW{1'b0}};
                    idx     <= 4'd0;
                end else begin
                    gap_cnt <= gap_cnt + 1'b1;
                end
            end
        end
    end
endmodule
