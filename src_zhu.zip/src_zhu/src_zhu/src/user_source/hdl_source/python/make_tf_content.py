#!/usr/bin/env python3
"""生成 13 张图 + 13 段音频，可直接拷进 TF 卡根目录。

    python make_tf_content.py <输出目录>

图片：PIC1~13.BMP，640x480 24 位 BMP（不压缩）。
  PIC1 参观须知 / PIC2~11 十个展区 / PIC12 火灾预警 / PIC13 火灾警报
  FPGA 按 RGB565 存储，这里先用 Floyd-Steinberg 抖动到 565 色阶，
  渐变背景上不会出现色带；FPGA 截位后得到的正好是抖动后的值。
  版面避开 OSD 叠加区：左上状态条 / 右上时间戳（y 8~15）、
  音频波形（y 368~431）、底部滚动字幕（y 440~463）。

音频：MUSIC1~13.WAV，48kHz / 16 位 / 单声道，标准 44 字节头。
  中文语音讲解（Windows 自带 Huihui 语音，经 PowerShell System.Speech 合成）
  + 合成的背景音乐 / 提示音 / 警报声。只用 Pillow 和标准库。

额外在输出目录旁边写一张 13 图拼版预览（不要拷进卡里）。
"""
import math
import os
import random
import struct
import subprocess
import sys
import tempfile
import wave

from PIL import Image, ImageDraw, ImageFont

W, H = 640, 480
RATE = 48000
FONT_DIR = "C:/Windows/Fonts/"
F_BOLD = FONT_DIR + "msyhbd.ttc"
F_REG = FONT_DIR + "msyh.ttc"

# ---------------------------------------------------------------- 内容
NOTICE = {
    "title": "参观须知",
    "lines": [
        "开放时间  周二至周日 9:00-17:00，周一闭馆",
        "请勿触摸标有“禁止触摸”的展品",
        "馆内禁止吸烟，禁止携带易燃易爆物品",
        "遇紧急情况请听从工作人员指挥",
        "沿绿色疏散指示有序撤离",
    ],
    "voice": "欢迎来到科技馆。参观前请阅读入馆须知。馆内禁止吸烟，遇到紧急情况，请听从工作人员指挥，沿绿色疏散指示有序撤离。",
}

EXHIBITS = [
    # (标题, 副标题, 两行说明, 图标, 主色(上), 主色(下), 语音)
    ("宇宙探索", "SPACE", ["认识太阳系八大行星", "探寻恒星的诞生与演化"], "planet",
     (10, 14, 48), (40, 20, 90),
     "宇宙探索展区。在这里，你可以认识太阳系的八大行星，了解恒星的诞生与演化。"),
    ("机器人世界", "ROBOTICS", ["感知环境  规划动作", "与人类协作的智能伙伴"], "robot",
     (8, 40, 60), (20, 90, 110),
     "机器人世界展区。看看机器人如何感知环境、规划动作，并与人类协作。"),
    ("人工智能", "ARTIFICIAL INTELLIGENCE", ["机器如何从数据中学习", "学会看、听、说和思考"], "neural",
     (30, 10, 60), (80, 30, 120),
     "人工智能展区。了解机器如何从数据中学习，学会看、听、说和思考。"),
    ("航空航天", "AEROSPACE", ["从第一架飞机到载人航天", "探索飞向蓝天与太空的历程"], "rocket",
     (5, 25, 70), (30, 90, 160),
     "航空航天展区。从第一架飞机到载人航天，一起探索人类飞向蓝天和太空的历程。"),
    ("生命科学", "LIFE SCIENCE", ["走进细胞与基因的微观世界", "认识生命的奥秘"], "dna",
     (5, 50, 45), (20, 110, 90),
     "生命科学展区。走进细胞与基因的微观世界，认识生命的奥秘。"),
    ("能源与环境", "ENERGY", ["太阳能、风能等清洁能源", "共同守护绿色地球"], "energy",
     (20, 70, 30), (90, 150, 50),
     "能源与环境展区。了解太阳能、风能等清洁能源，共同守护绿色地球。"),
    ("电与磁", "ELECTROMAGNETISM", ["体验电流与磁场的神奇互动", "感受电磁的力量"], "magnet",
     (40, 20, 10), (120, 60, 20),
     "电与磁展区。亲手体验电流与磁场的神奇互动，感受电磁的力量。"),
    ("光学奇观", "OPTICS", ["观察光的反射、折射与色散", "揭开彩虹的秘密"], "prism",
     (15, 15, 25), (50, 50, 80),
     "光学奇观展区。观察光的反射、折射与色散，揭开彩虹的秘密。"),
    ("数学之美", "MATHEMATICS", ["从黄金分割到分形图案", "发现自然中的数学规律"], "spiral",
     (60, 40, 10), (140, 100, 30),
     "数学之美展区。从黄金分割到分形图案，发现隐藏在自然中的数学规律。"),
    ("芯片与集成电路", "INTEGRATED CIRCUITS", ["一颗芯片里的亿万个晶体管", "现代电子技术的核心"], "chip",
     (10, 30, 40), (20, 80, 90),
     "芯片与集成电路展区。认识一颗小小芯片里的亿万个晶体管，了解现代电子技术的核心。"),
]

FIRE_WARN_VOICE = "注意！系统检测到烟雾或温度异常。请停止参观，保持冷静，留意广播，听从工作人员指引。"
FIRE_ALARM_VOICE = "火灾警报！请立即沿绿色疏散指示有序撤离。不要乘坐电梯。用湿毛巾捂住口鼻，弯腰低姿前进。"


# ---------------------------------------------------------------- 绘图工具
def font(path, size):
    return ImageFont.truetype(path, size)


def gradient(top, bottom):
    img = Image.new("RGB", (W, H))
    px = img.load()
    for y in range(H):
        t = y / (H - 1)
        c = tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(3))
        for x in range(W):
            px[x, y] = c
    return img


def text_center(d, cx, y, s, f, fill):
    b = d.textbbox((0, 0), s, font=f)
    d.text((cx - (b[2] - b[0]) // 2 - b[0], y), s, font=f, fill=fill)


def stars(d, seed, n, area=(0, 20, W, 360)):
    rnd = random.Random(seed)
    for _ in range(n):
        x = rnd.randint(area[0], area[2] - 1)
        y = rnd.randint(area[1], area[3] - 1)
        v = rnd.randint(120, 255)
        r = rnd.choice([0, 0, 0, 1])
        d.ellipse((x - r, y - r, x + r, y + r), fill=(v, v, v))


def dither565(img):
    """Floyd-Steinberg 抖动到 R5 G6 B5，输出仍是 888（低位按高位回填，与 FPGA 一致）。"""
    src = list(img.get_flattened_data()) if hasattr(img, "get_flattened_data") else list(img.getdata())
    bits = (5, 6, 5)
    out = [[0, 0, 0] for _ in range(W * H)]
    for ch in range(3):
        sh = 8 - bits[ch]
        buf = [float(p[ch]) for p in src]
        for y in range(H):
            row = y * W
            for x in range(W):
                i = row + x
                old = buf[i]
                q = int(old + 0.5)
                q = 0 if q < 0 else 255 if q > 255 else q
                hi = q >> sh
                # 取最近的 565 色阶（低位按高位回填）
                up = min(hi + 1, (1 << bits[ch]) - 1)
                up_v = (up << sh) | (up >> (bits[ch] - sh))
                lo_v = (hi << sh) | (hi >> (bits[ch] - sh))
                v = up_v if abs(up_v - old) < abs(lo_v - old) else lo_v
                out[i][ch] = v
                e = old - v
                if x + 1 < W:
                    buf[i + 1] += e * 7 / 16
                if y + 1 < H:
                    if x > 0:
                        buf[i + W - 1] += e * 3 / 16
                    buf[i + W] += e * 5 / 16
                    if x + 1 < W:
                        buf[i + W + 1] += e * 1 / 16
    res = Image.new("RGB", (W, H))
    res.putdata([tuple(p) for p in out])
    return res


# ---------------------------------------------------------------- 图标
def icon(d, kind, cx, cy, r):
    white = (240, 245, 255)
    if kind == "planet":
        d.ellipse((cx - r * .62, cy - r * .62, cx + r * .62, cy + r * .62), fill=(230, 150, 70))
        for k in range(5):
            yy = cy - r * .45 + k * r * .22
            d.line((cx - r * .55, yy, cx + r * .55, yy + 4), fill=(200, 110, 50), width=4)
        d.arc((cx - r * 1.05, cy - r * .32, cx + r * 1.05, cy + r * .32), 200, 340, fill=(250, 220, 160), width=7)
        d.arc((cx - r * 1.05, cy - r * .32, cx + r * 1.05, cy + r * .32), -20, 160, fill=(250, 220, 160), width=7)
        d.ellipse((cx + r * .7, cy - r * .95, cx + r * .92, cy - r * .73), fill=(180, 200, 255))
    elif kind == "robot":
        d.rounded_rectangle((cx - r * .7, cy - r * .55, cx + r * .7, cy + r * .45), r * .2, fill=(200, 215, 230))
        d.line((cx, cy - r * .55, cx, cy - r * .85), fill=white, width=6)
        d.ellipse((cx - 12, cy - r * .85 - 12, cx + 12, cy - r * .85 + 12), fill=(255, 90, 90))
        for s in (-1, 1):
            ex = cx + s * r * .33
            d.ellipse((ex - r * .17, cy - r * .3, ex + r * .17, cy + r * .04), fill=(20, 40, 60))
            d.ellipse((ex - r * .08, cy - r * .21, ex + r * .08, cy - r * .05), fill=(80, 220, 255))
        d.rounded_rectangle((cx - r * .35, cy + r * .16, cx + r * .35, cy + r * .28), 6, fill=(20, 40, 60))
        d.rectangle((cx - r * .85, cy - r * .2, cx - r * .7, cy + r * .1), fill=(150, 170, 190))
        d.rectangle((cx + r * .7, cy - r * .2, cx + r * .85, cy + r * .1), fill=(150, 170, 190))
    elif kind == "neural":
        layers = [3, 5, 5, 2]
        pts = []
        for li, n in enumerate(layers):
            x = cx - r + li * (2 * r / (len(layers) - 1))
            col = [(x, cy - (n - 1) * r * .22 + k * r * .44) for k in range(n)]
            pts.append(col)
        for a, b in zip(pts, pts[1:]):
            for p in a:
                for q in b:
                    d.line((p, q), fill=(150, 120, 220), width=2)
        for li, col in enumerate(pts):
            for (x, y) in col:
                c = (255, 200, 80) if li in (0, len(pts) - 1) else (120, 220, 255)
                d.ellipse((x - 11, y - 11, x + 11, y + 11), fill=c, outline=white, width=2)
    elif kind == "rocket":
        d.polygon([(cx, cy - r), (cx + r * .28, cy - r * .45), (cx + r * .28, cy + r * .45),
                   (cx - r * .28, cy + r * .45), (cx - r * .28, cy - r * .45)], fill=(235, 240, 250))
        d.polygon([(cx - r * .28, cy + r * .05), (cx - r * .6, cy + r * .55), (cx - r * .28, cy + r * .45)], fill=(220, 60, 60))
        d.polygon([(cx + r * .28, cy + r * .05), (cx + r * .6, cy + r * .55), (cx + r * .28, cy + r * .45)], fill=(220, 60, 60))
        d.ellipse((cx - r * .14, cy - r * .4, cx + r * .14, cy - r * .12), fill=(60, 140, 220), outline=(40, 60, 90), width=4)
        d.polygon([(cx - r * .2, cy + r * .45), (cx + r * .2, cy + r * .45), (cx, cy + r * 1.0)], fill=(255, 170, 40))
        d.polygon([(cx - r * .1, cy + r * .45), (cx + r * .1, cy + r * .45), (cx, cy + r * .78)], fill=(255, 240, 120))
    elif kind == "dna":
        n = 14
        for k in range(n + 1):
            t = k / n
            y = cy - r + 2 * r * t
            ph = t * math.pi * 2.2
            x1 = cx + math.sin(ph) * r * .5
            x2 = cx - math.sin(ph) * r * .5
            d.line((x1, y, x2, y), fill=(200, 230, 220), width=3)
            d.ellipse((x1 - 9, y - 9, x1 + 9, y + 9), fill=(90, 230, 170))
            d.ellipse((x2 - 9, y - 9, x2 + 9, y + 9), fill=(250, 140, 180))
    elif kind == "energy":
        sx, sy = cx - r * .45, cy - r * .45
        for a in range(0, 360, 30):
            ra = math.radians(a)
            d.line((sx + math.cos(ra) * r * .32, sy + math.sin(ra) * r * .32,
                    sx + math.cos(ra) * r * .48, sy + math.sin(ra) * r * .48), fill=(255, 220, 80), width=5)
        d.ellipse((sx - r * .25, sy - r * .25, sx + r * .25, sy + r * .25), fill=(255, 200, 40))
        tx, ty = cx + r * .35, cy - r * .1
        d.polygon([(tx - 6, ty), (tx + 6, ty), (tx + 12, cy + r), (tx - 12, cy + r)], fill=(240, 245, 250))
        for a in (90, 210, 330):
            ra = math.radians(a)
            d.polygon([(tx, ty), (tx + math.cos(ra) * r * .6, ty - math.sin(ra) * r * .6),
                       (tx + math.cos(ra + .25) * r * .5, ty - math.sin(ra + .25) * r * .5)], fill=(240, 245, 250))
        d.ellipse((tx - 9, ty - 9, tx + 9, ty + 9), fill=(180, 190, 200))
    elif kind == "magnet":
        for k in range(1, 4):
            rr = r * (.55 + k * .15)
            d.arc((cx - rr, cy - rr * .8, cx + rr, cy + rr * .8), 200, 340, fill=(150, 200, 255), width=2)
        w = r * .22
        d.arc((cx - r * .6, cy - r * .55, cx + r * .6, cy + r * .65), 180, 360, fill=(220, 50, 50), width=int(w))
        d.rectangle((cx - r * .6, cy + r * .05, cx - r * .6 + w, cy + r * .6), fill=(220, 50, 50))
        d.rectangle((cx + r * .6 - w, cy + r * .05, cx + r * .6, cy + r * .6), fill=(60, 100, 220))
        d.rectangle((cx - r * .6, cy + r * .45, cx - r * .6 + w, cy + r * .6), fill=(235, 235, 235))
        d.rectangle((cx + r * .6 - w, cy + r * .45, cx + r * .6, cy + r * .6), fill=(235, 235, 235))
        d.polygon([(cx + 4, cy - r * .2), (cx - 16, cy + r * .2), (cx, cy + r * .2), (cx - 8, cy + r * .55),
                   (cx + 20, cy + r * .05), (cx + 4, cy + r * .05)], fill=(255, 230, 60))
    elif kind == "prism":
        p = [(cx - r * .1, cy - r * .6), (cx - r * .55, cy + r * .45), (cx + r * .35, cy + r * .45)]
        d.line(((cx - r * 1.1, cy + r * .05), (cx - r * .3, cy - r * .05)), fill=(255, 255, 255), width=6)
        cols = [(255, 60, 60), (255, 150, 40), (255, 240, 60), (80, 220, 80), (60, 160, 255), (120, 80, 230)]
        for k, c in enumerate(cols):
            d.polygon([(cx + r * .05, cy + r * .0 + k * 3), (cx + r * 1.0, cy - r * .1 + k * r * .14),
                       (cx + r * 1.0, cy - r * .1 + (k + 1) * r * .14), (cx + r * .05, cy + 3 + k * 3)], fill=c)
        d.polygon(p, fill=(190, 220, 240), outline=(255, 255, 255))
    elif kind == "spiral":
        a, b = 3.0, 0.3063
        prev = None
        for k in range(0, 700):
            t = k * 0.02
            rr = a * math.exp(b * t)
            if rr > r:
                break
            pt = (cx + rr * math.cos(t), cy - rr * math.sin(t))
            if prev:
                d.line((prev, pt), fill=(255, 230, 150), width=4)
            prev = pt
        d.rectangle((cx - r, cy - r * .62, cx + r, cy + r * .62), outline=(255, 255, 255), width=3)
        d.line((cx + r * .24, cy - r * .62, cx + r * .24, cy + r * .62), fill=(255, 255, 255), width=2)
    elif kind == "chip":
        s = r * .62
        for k in range(6):
            o = -s + (k + .5) * (2 * s / 6)
            for (x1, y1, x2, y2) in ((cx + o, cy - s, cx + o, cy - s - 22), (cx + o, cy + s, cx + o, cy + s + 22),
                                     (cx - s, cy + o, cx - s - 22, cy + o), (cx + s, cy + o, cx + s + 22, cy + o)):
                d.line((x1, y1, x2, y2), fill=(220, 190, 90), width=7)
        d.rounded_rectangle((cx - s, cy - s, cx + s, cy + s), 10, fill=(35, 40, 50), outline=(150, 160, 170), width=3)
        d.rounded_rectangle((cx - s * .55, cy - s * .55, cx + s * .55, cy + s * .55), 6, fill=(60, 140, 160))
        text_center(d, cx, cy - 18, "FPGA", font(F_BOLD, 26), (240, 250, 255))


# ---------------------------------------------------------------- 版式
def frame_common(img, accent):
    d = ImageDraw.Draw(img, "RGBA")
    # 底部 368 以下留给 OSD（波形 + 字幕），这里压暗做一条安静的底带
    d.rectangle((0, 366, W, H), fill=(0, 0, 0, 90))
    d.line((24, 364, W - 24, 364), fill=accent + (180,), width=2)
    return d


def make_notice():
    img = gradient((12, 40, 90), (20, 80, 150))
    d = frame_common(img, (120, 190, 255))
    stars(d, 1, 40)
    text_center(d, W // 2, 34, "科技馆", font(F_REG, 22), (180, 210, 255))
    text_center(d, W // 2, 60, NOTICE["title"], font(F_BOLD, 52), (255, 255, 255))
    d.rounded_rectangle((60, 140, 580, 350), 16, fill=(255, 255, 255, 30), outline=(150, 200, 255, 160), width=2)
    f = font(F_REG, 22)
    for k, s in enumerate(NOTICE["lines"]):
        y = 156 + k * 38
        d.ellipse((84, y + 10, 96, y + 22), fill=(255, 210, 80))
        d.text((110, y), s, font=f, fill=(240, 246, 255))
    return img


def make_exhibit(no, ex):
    title, sub, lines, kind, top, bottom, _ = ex
    img = gradient(top, bottom)
    accent = tuple(min(255, c + 120) for c in bottom)
    d = frame_common(img, accent)
    stars(d, no * 7, 60 if kind in ("planet", "rocket") else 18)
    d.text((40, 30), "展区 %02d" % (no - 1), font=font(F_REG, 20), fill=accent)
    d.text((40, 70), title, font=font(F_BOLD, 50 if len(title) <= 5 else 40), fill=(255, 255, 255))
    d.text((42, 140), sub, font=font(F_BOLD, 18), fill=accent)
    d.line((42, 172, 120, 172), fill=(255, 210, 80), width=4)
    f = font(F_REG, 22)
    for k, s in enumerate(lines):
        d.text((42, 196 + k * 40), s, font=f, fill=(235, 242, 250))
    d.ellipse((330, 50, 610, 330), fill=(255, 255, 255, 18))
    icon(d, kind, 470, 190, 110)
    return img


def make_fire_warning():
    img = gradient((255, 190, 20), (240, 140, 0))
    d = ImageDraw.Draw(img, "RGBA")
    for x in range(-40, W + 40, 40):        # 顶部黄黑警示条
        d.polygon([(x, 20), (x + 20, 20), (x + 40, 0), (x + 20, 0)], fill=(30, 30, 30))
    d.rectangle((0, 0, W, 2), fill=(30, 30, 30))
    cx, cy = 150, 190
    d.polygon([(cx, cy - 110), (cx + 120, cy + 95), (cx - 120, cy + 95)], fill=(30, 30, 30))
    d.polygon([(cx, cy - 80), (cx + 95, cy + 80), (cx - 95, cy + 80)], fill=(255, 210, 40))
    d.rounded_rectangle((cx - 11, cy - 40, cx + 11, cy + 30), 6, fill=(30, 30, 30))
    d.ellipse((cx - 12, cy + 42, cx + 12, cy + 66), fill=(30, 30, 30))
    d.text((300, 60), "火灾预警", font=font(F_BOLD, 64), fill=(40, 20, 0))
    d.text((304, 140), "FIRE WARNING", font=font(F_BOLD, 22), fill=(110, 50, 0))
    f = font(F_BOLD, 24)
    for k, s in enumerate(["检测到烟雾或温度异常", "请停止参观  保持冷静", "留意广播  听从工作人员指引"]):
        d.text((300, 194 + k * 46), s, font=f, fill=(40, 20, 0))
    d.rectangle((0, 366, W, H), fill=(60, 30, 0, 70))
    return img


def running_man(d, x, y, s, fill):
    """简化的安全出口奔跑小人，(x, y) 为头部中心，s 为比例。"""
    d.ellipse((x - 9 * s, y - 9 * s, x + 9 * s, y + 9 * s), fill=fill)
    w = int(7 * s)
    body = [(x - 4 * s, y + 12 * s), (x - 14 * s, y + 42 * s)]
    d.line(body, fill=fill, width=w)
    d.line([(x - 6 * s, y + 18 * s), (x + 12 * s, y + 26 * s), (x + 22 * s, y + 14 * s)], fill=fill, width=w)
    d.line([(x - 6 * s, y + 18 * s), (x - 22 * s, y + 30 * s)], fill=fill, width=w)
    d.line([(x - 14 * s, y + 42 * s), (x + 4 * s, y + 56 * s), (x + 8 * s, y + 74 * s)], fill=fill, width=w)
    d.line([(x - 14 * s, y + 42 * s), (x - 30 * s, y + 60 * s), (x - 44 * s, y + 58 * s)], fill=fill, width=w)


def make_fire_alarm():
    img = gradient((200, 0, 10), (130, 0, 0))
    d = ImageDraw.Draw(img, "RGBA")
    text_center(d, W // 2, 26, "火灾警报", font(F_BOLD, 66), (255, 255, 255))
    text_center(d, W // 2, 108, "请立即疏散   FIRE ALARM · EVACUATE NOW", font(F_BOLD, 22), (255, 220, 200))
    # 绿色安全出口标志
    d.rounded_rectangle((40, 160, 260, 340), 14, fill=(0, 154, 68), outline=(255, 255, 255), width=4)
    running_man(d, 110, 190, 1.45, (255, 255, 255))
    d.polygon([(190, 222), (240, 252), (190, 282), (190, 266), (160, 266), (160, 238), (190, 238)], fill=(255, 255, 255))
    d.text((92, 300), "安全出口 EXIT", font=font(F_BOLD, 20), fill=(255, 255, 255))
    f = font(F_BOLD, 24)
    for k, s in enumerate(["沿绿色疏散指示有序撤离", "不要乘坐电梯", "用湿毛巾捂住口鼻", "弯腰低姿前进"]):
        y = 168 + k * 44
        d.ellipse((290, y + 10, 304, y + 24), fill=(255, 230, 0))
        d.text((316, y), s, font=f, fill=(255, 255, 255))
    d.rectangle((0, 366, W, H), fill=(0, 0, 0, 80))
    return img


# ---------------------------------------------------------------- 音频
def tts(text, path):
    """Windows 自带中文语音合成到 48kHz/16bit/单声道 wav。"""
    with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False, encoding="utf-8") as t:
        t.write(text)
        tname = t.name
    ps = (
        "Add-Type -AssemblyName System.Speech;"
        "$s = New-Object System.Speech.Synthesis.SpeechSynthesizer;"
        "$v = $s.GetInstalledVoices() | Where-Object { $_.VoiceInfo.Culture.Name -eq 'zh-CN' } | Select-Object -First 1;"
        "if ($v) { $s.SelectVoice($v.VoiceInfo.Name) };"
        "$s.Rate = 0;"
        "$fmt = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(48000, "
        "[System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono);"
        "$s.SetOutputToWaveFile('%s', $fmt);"
        "$s.Speak((Get-Content -Raw -Encoding UTF8 '%s'));"
        "$s.Dispose()" % (path.replace("'", "''"), tname.replace("'", "''"))
    )
    subprocess.run(["powershell.exe", "-NoProfile", "-Command", ps], check=True)
    os.unlink(tname)
    with wave.open(path, "rb") as w:
        assert w.getframerate() == RATE and w.getsampwidth() == 2 and w.getnchannels() == 1
        raw = w.readframes(w.getnframes())
    v = list(struct.unpack("<%dh" % (len(raw) // 2), raw))
    # 去掉首尾静音
    th = 300
    a = next((i for i, s in enumerate(v) if abs(s) > th), 0)
    b = len(v) - next((i for i, s in enumerate(reversed(v)) if abs(s) > th), 0)
    return [s / 32768.0 for s in v[max(0, a - 960):min(len(v), b + 2400)]]


def note_freq(semi):
    return 440.0 * 2 ** (semi / 12.0)


def synth_music(seed, seconds, root, tempo, timbre):
    """简单的五声音阶背景乐：旋律 + 低音 + 和声垫。"""
    rnd = random.Random(seed)
    n = int(seconds * RATE)
    out = [0.0] * n
    beat = 60.0 / tempo
    scale = [0, 2, 4, 7, 9, 12, 14, 16]
    # 旋律：每拍一个音，偶尔半拍
    t = 0.0
    idx = 3
    while t < seconds - 0.3:
        idx = max(0, min(len(scale) - 1, idx + rnd.choice([-2, -1, -1, 1, 1, 2, 0])))
        dur = beat * rnd.choice([1, 1, 1, 0.5, 2])
        add_tone(out, t, dur * 1.6, note_freq(root + scale[idx]), 0.22, timbre)
        t += dur
    # 低音：每小节一个根音/五度
    t = 0.0
    k = 0
    prog = [0, -5, -3, -7]
    while t < seconds - 0.3:
        add_tone(out, t, beat * 4, note_freq(root - 24 + prog[k % 4]), 0.16, "soft")
        add_tone(out, t, beat * 4, note_freq(root - 12 + prog[k % 4] + 7), 0.06, "pad")
        t += beat * 4
        k += 1
    return out


def add_tone(out, t0, dur, f, amp, timbre):
    s0 = int(t0 * RATE)
    m = int(dur * RATE)
    w = 2 * math.pi * f / RATE
    for i in range(m):
        j = s0 + i
        if j >= len(out):
            break
        tt = i / RATE
        if timbre == "bell":
            env = math.exp(-tt * 3.0)
            v = math.sin(w * i) + 0.4 * math.sin(2.76 * w * i) * math.exp(-tt * 6) + 0.2 * math.sin(5.4 * w * i) * math.exp(-tt * 9)
        elif timbre == "pluck":
            env = math.exp(-tt * 5.0)
            v = math.sin(w * i) + 0.5 * math.sin(2 * w * i) + 0.25 * math.sin(3 * w * i)
        elif timbre == "pad":
            env = min(1.0, tt / 0.4) * min(1.0, (dur - tt) / 0.4)
            v = math.sin(w * i) + 0.3 * math.sin(2 * w * i + 0.5)
        else:  # soft
            env = min(1.0, tt / 0.02) * math.exp(-tt * 1.5)
            v = math.sin(w * i) + 0.15 * math.sin(2 * w * i)
        out[j] += amp * env * v


def mix_voice(music, voice, start, duck=0.3):
    n = max(len(music), start + len(voice) + RATE)
    out = music + [0.0] * (n - len(music))
    fade = int(0.25 * RATE)
    for i in range(n):
        # 语音期间背景压低
        g = 1.0
        if start - fade <= i < start + len(voice) + fade:
            if i < start:
                g = 1 - (1 - duck) * (i - (start - fade)) / fade
            elif i >= start + len(voice):
                g = duck + (1 - duck) * (i - start - len(voice)) / fade
            else:
                g = duck
        out[i] *= g
        k = i - start
        if 0 <= k < len(voice):
            out[i] += voice[k] * 0.9
    return out


def chime(out, t0, amp=0.4):
    add_tone(out, t0, 1.2, 659.25, amp, "bell")       # E5
    add_tone(out, t0 + 0.45, 1.6, 523.25, amp, "bell")  # C5


def siren(seconds, amp=0.35):
    n = int(seconds * RATE)
    out = [0.0] * n
    ph = 0.0
    for i in range(n):
        t = i / RATE
        f = 650 + 450 * (0.5 - 0.5 * math.cos(2 * math.pi * t / 1.2))  # 1.2s 一个起伏
        ph += 2 * math.pi * f / RATE
        v = math.sin(ph) + 0.3 * math.sin(3 * ph)
        out[i] = amp * v
    return out


def beeps(seconds, amp=0.35):
    """预警：两短一停的提示音。"""
    n = int(seconds * RATE)
    out = [0.0] * n
    t = 0.0
    while t < seconds:
        for k in range(2):
            add_tone(out, t + k * 0.25, 0.16, 988.0, amp, "soft")
        t += 1.5
    return out


def write_wav(path, samples):
    peak = max(1e-9, max(abs(s) for s in samples))
    g = min(1.0, 0.89 / peak)                       # 峰值约 -1dBFS
    fade = int(0.02 * RATE)                         # 首尾 20ms 淡入淡出，循环不爆音
    data = []
    n = len(samples)
    for i, s in enumerate(samples):
        e = min(1.0, i / fade, (n - 1 - i) / fade)
        data.append(max(-32768, min(32767, int(s * g * e * 32767))))
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(struct.pack("<%dh" % len(data), *data))
    return n / RATE


# ---------------------------------------------------------------- 主流程
def main():
    if len(sys.argv) != 2:
        raise SystemExit(__doc__)
    outdir = sys.argv[1]
    os.makedirs(outdir, exist_ok=True)
    tmp = tempfile.mkdtemp()

    images = [make_notice()] + [make_exhibit(i + 2, ex) for i, ex in enumerate(EXHIBITS)] + \
             [make_fire_warning(), make_fire_alarm()]
    finals = []
    for k, img in enumerate(images, 1):
        q = dither565(img)
        p = os.path.join(outdir, "PIC%d.BMP" % k)
        q.save(p, "BMP")
        finals.append(q)
        print("PIC%d.BMP  %d 字节" % (k, os.path.getsize(p)))

    # 预览拼版（不进卡）
    sheet = Image.new("RGB", (4 * 320 + 50, 4 * 240 + 50), (30, 30, 30))
    for k, q in enumerate(finals):
        sheet.paste(q.resize((320, 240)), (10 + (k % 4) * 330, 10 + (k // 4) * 250))
    sheet.save(os.path.join(os.path.dirname(os.path.abspath(outdir)),
                            os.path.basename(os.path.abspath(outdir)) + "_预览.png"))

    # 音频
    specs = [("notice", NOTICE["voice"])] + [("ex%d" % i, ex[6]) for i, ex in enumerate(EXHIBITS)] + \
            [("warn", FIRE_WARN_VOICE), ("alarm", FIRE_ALARM_VOICE)]
    timbres = ["bell", "pluck", "soft", "bell", "pluck", "soft", "bell", "pluck", "soft", "bell"]
    roots = [0, 3, -2, 5, 2, -4, 7, 1, -1, 4]
    tempos = [84, 96, 72, 104, 80, 92, 110, 76, 88, 100]
    for k, (kind, text) in enumerate(specs, 1):
        voice = tts(text, os.path.join(tmp, "v%d.wav" % k))
        vlen = len(voice) / RATE
        if kind == "notice":
            total = max(14.0, vlen + 3.5)
            bg = synth_music(101, total, 0, 76, "pad")
            bg = [s * 0.6 for s in bg]
            chime(bg, 0.1)
            out = mix_voice(bg, voice, int(1.8 * RATE))
        elif kind.startswith("ex"):
            i = int(kind[2:])
            total = max(16.0, vlen + 4.0)
            bg = synth_music(200 + i, total, roots[i], tempos[i], timbres[i])
            out = mix_voice(bg, voice, int(1.0 * RATE))
        elif kind == "warn":
            total = vlen * 2 + 4.0
            bg = beeps(total)
            out = mix_voice(bg, voice, int(1.6 * RATE), duck=0.15)
            out = mix_voice(out, voice, int((vlen + 3.2) * RATE), duck=0.15)
        else:
            total = vlen * 2 + 5.0
            bg = siren(total)
            out = mix_voice(bg, voice, int(1.8 * RATE), duck=0.2)
            out = mix_voice(out, voice, int((vlen + 4.0) * RATE), duck=0.2)
        p = os.path.join(outdir, "MUSIC%d.WAV" % k)
        sec = write_wav(p, out)
        print("MUSIC%d.WAV  %.1f 秒  %d 字节" % (k, sec, os.path.getsize(p)))


if __name__ == "__main__":
    main()
