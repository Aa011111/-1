#!/usr/bin/env python3
"""第十一讲 WAV音频播放（一图一音）：把任意 PCM WAV 转成 FPGA 能直接流式播放的 MUSICn.WAV。

输出格式：16 位有符号小端 PCM，48kHz，单声道（wav_stream_player 只认这个）。
只用 Python 标准库，线性插值重采样，多声道取平均混成单声道。

用法：
    python make_music_wav.py song_a.wav MUSIC1.WAV
    python make_music_wav.py song_b.wav MUSIC2.WAV

MUSIC1.WAV ~ MUSIC4.WAV 分别对应 PIC1~4.BMP，拷到 TF 卡根目录。
显示哪张图就放哪段，放完循环本段；缺哪个，那张图就静音。
（单个 MUSIC.WAV 和琶音源已删掉，不再识别。）
FPGA 会跳过文件开头 44 字节的 WAV 头（本脚本写出的就是标准 44 字节头）。
注意：FPGA 只按首簇连续读，不跟 FAT 链。最好先格式化卡，再依次拷入
图片和 WAV，保证文件在卡上是连续存放的。
"""
import struct
import sys
import wave

TARGET_RATE = 48000


def read_mono(path):
    with wave.open(path, "rb") as w:
        ch, width, rate, n = w.getnchannels(), w.getsampwidth(), w.getframerate(), w.getnframes()
        raw = w.readframes(n)
    if width == 1:
        vals = [(b - 128) << 8 for b in raw]
    elif width == 2:
        vals = list(struct.unpack("<%dh" % (len(raw) // 2), raw))
    elif width == 3:
        vals = [int.from_bytes(raw[i:i + 3], "little", signed=True) >> 8 for i in range(0, len(raw), 3)]
    elif width == 4:
        vals = [v >> 16 for v in struct.unpack("<%di" % (len(raw) // 4), raw)]
    else:
        raise SystemExit("不支持的位深: %d 字节" % width)
    mono = [sum(vals[i:i + ch]) // ch for i in range(0, len(vals) - ch + 1, ch)]
    return mono, rate


def resample(samples, src_rate, dst_rate):
    if src_rate == dst_rate or not samples:
        return samples
    out_len = int(len(samples) * dst_rate / src_rate)
    step = src_rate / dst_rate
    last = len(samples) - 1
    out = []
    for i in range(out_len):
        pos = i * step
        j = int(pos)
        frac = pos - j
        a = samples[min(j, last)]
        b = samples[min(j + 1, last)]
        out.append(int(a + (b - a) * frac))
    return out


def main():
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    samples, rate = read_mono(sys.argv[1])
    samples = resample(samples, rate, TARGET_RATE)
    samples = [max(-32768, min(32767, s)) for s in samples]
    with wave.open(sys.argv[2], "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(TARGET_RATE)
        w.writeframes(struct.pack("<%dh" % len(samples), *samples))
    print("写出 %s: %d 样本, %.1f 秒, 48kHz/16bit/单声道"
          % (sys.argv[2], len(samples), len(samples) / TARGET_RATE))


if __name__ == "__main__":
    main()
