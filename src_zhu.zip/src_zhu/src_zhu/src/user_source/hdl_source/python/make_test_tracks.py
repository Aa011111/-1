#!/usr/bin/env python3
"""一图一音功能测试：生成 MUSIC1~4.WAV。
（另外生成的 MUSIC.WAV 是早期回退用的，FPGA 现在已不再识别，可以不拷。）

格式与 make_music_wav.py 输出相同：48kHz / 16bit / 单声道，标准 44 字节头。
每段 3 秒，用"响几声"标识是第几段，音高也各不相同：
    MUSIC1.WAV  响 1 声  C5 523Hz
    MUSIC2.WAV  响 2 声  E5 659Hz
    MUSIC3.WAV  响 3 声  G5 784Hz
    MUSIC4.WAV  响 4 声  C6 1047Hz
    MUSIC.WAV   3 秒低音上滑 220->440Hz（已不再使用）
每声 0.25s，带 10ms 淡入淡出防爆音；末尾留静音，循环重播时听得出从头开始。

用法：
    py make_test_tracks.py [输出目录]      （默认 ./test_wav）
"""
import math
import os
import struct
import sys
import wave

RATE = 48000
SECONDS = 3.0
AMP = 0.5 * 32767
BEEP = 0.25
GAP = 0.15
RAMP = 0.010


def envelope(t, length):
    if t < RAMP:
        return t / RAMP
    if t > length - RAMP:
        return max(0.0, (length - t) / RAMP)
    return 1.0


def beeps(count, freq):
    n = int(RATE * SECONDS)
    out = [0] * n
    for k in range(count):
        start = int(RATE * (0.1 + k * (BEEP + GAP)))
        for i in range(int(RATE * BEEP)):
            t = i / RATE
            out[start + i] = int(AMP * envelope(t, BEEP) * math.sin(2 * math.pi * freq * t))
    return out


def sweep(f0, f1):
    n = int(RATE * SECONDS)
    out, phase = [], 0.0
    for i in range(n):
        t = i / RATE
        phase += 2 * math.pi * (f0 + (f1 - f0) * t / SECONDS) / RATE
        out.append(int(AMP * envelope(t, SECONDS) * math.sin(phase)))
    return out


def write(path, samples):
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(struct.pack("<%dh" % len(samples), *samples))
    print("写出 %-11s %6d 字节" % (os.path.basename(path), os.path.getsize(path)))


def main():
    out_dir = sys.argv[1] if len(sys.argv) > 1 else "test_wav"
    os.makedirs(out_dir, exist_ok=True)
    for idx, freq in enumerate([523.25, 659.25, 783.99, 1046.50], start=1):
        write(os.path.join(out_dir, "MUSIC%d.WAV" % idx), beeps(idx, freq))
    write(os.path.join(out_dir, "MUSIC.WAV"), sweep(220.0, 440.0))


if __name__ == "__main__":
    main()
