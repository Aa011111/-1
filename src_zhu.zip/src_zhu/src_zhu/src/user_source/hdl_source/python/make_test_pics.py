#!/usr/bin/env python3
"""坏图处理测试卡：生成 PIC1~5.BMP，可直接拷进 TF 卡根目录。

    python make_test_pics.py <输出目录> [--example <lab_ex5_i2s/doc 目录>]

  PIC1  640x480   24 位  正常
  PIC2  640x480   24 位  正常
  PIC3  640x480   32 位  坏：色深不对     -> 串口 BAD 03 34
  PIC4  320x240   24 位  坏：分辨率太小   -> 串口 BAD 04 32
  PIC5  1024x768  24 位  正常，FPGA 缩到 640x480

全部 4:3。素材取自例程 lab_ex5_i2s/doc（convert/1.png、3.png、TF卡图片/*.bmp），先用
ImageOps.fit 居中裁成 4:3 并缩到目标尺寸，再在画面中下方加一块标签，标明是哪张、哪种情况。
标签按 640x480 版面放在 y 286~358，避开 FPGA 的叠加层：四边 40 像素的频谱边框、左上状态条/
参数面板、右上时钟、y>=368 的波形和字幕。其他尺寸按宽度等比缩放。

正常的三张按例程流程转换：标签图存成 PNG，交给例程的 convert/convert_images_to_bmp.py 转成
24 位不压缩 BMP。它的命令行固定出 640x480，所以 PIC5 改调它的 convert_single_file 指定 1024x768。
坏的两张故意不经过转换脚本（脚本会把它们修好），模拟"没转换就直接拷进卡"。
例程的 sync_to_sd.py 不要用在本工程：它把文件改名成 00_xxx.bmp（FAT32 扫描器只认 PICn.BMP），
还会清空整张卡、最多只拷 4 张。
"""
import argparse
import importlib.util
import os
import struct
import subprocess
import sys
import tempfile

from PIL import Image, ImageDraw, ImageFont, ImageOps

EXAMPLE_DOC = ("D:/Baidu Netdisk path/Download file path from Baidu Netdisk/"
               "HX4S20_Contest_202606/7_lab_ex_2026_nosoft/"
               "全国大学生嵌入式芯片与系统设计竞赛'2026选题指南_康芯/lab_ex5_i2s/doc")
FONT_DIR = "C:/Windows/Fonts/"
F_BOLD = FONT_DIR + "msyhbd.ttc"
F_REG = FONT_DIR + "msyh.ttc"

# (序号, 素材（相对例程 doc 目录）, 尺寸, 位深, 是否经过例程转换脚本, 标题, 说明, 预期结果)
ITEMS = [
    (1, "convert/1.png", (640, 480), 24, True,
     "PIC1  正常", "640×480  24 位 BMP", "正常显示"),
    (2, "TF卡图片/A_工程适配版.bmp", (640, 480), 24, True,
     "PIC2  正常", "640×480  24 位 BMP", "正常显示"),
    (3, "TF卡图片/草莓_640x480_24bit_显示正常_工程适配版.bmp", (640, 480), 32, False,
     "PIC3  坏图：色深不对", "640×480  32 位 BMP（应为 24 位）", "串口 BAD 03 34"),
    (4, "TF卡图片/西瓜_640x480_24bit_显示正常_工程适配版.bmp", (320, 240), 24, False,
     "PIC4  坏图：分辨率太小", "320×240  24 位 BMP（至少 640×480）", "串口 BAD 04 32"),
    (5, "convert/3.png", (1024, 768), 24, True,
     "PIC5  正常（大图）", "1024×768  24 位 BMP，FPGA 缩到 640×480", "正常显示（FPGA 缩放）"),
]


def add_label(img, title, sub, bad):
    w, h = img.size
    s = w / 640.0
    fs = max(s, 0.75)                     # 320x240 那张字别缩得太小
    big = ImageFont.truetype(F_BOLD, round(30 * fs))
    small = ImageFont.truetype(F_REG, round(17 * fs))
    pad = 16 * fs
    bw = max(big.getlength(title), small.getlength(sub)) + 2 * pad
    bh = 72 * fs
    x0, y0 = (w - bw) / 2, 286 * s
    layer = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.rounded_rectangle((x0, y0, x0 + bw, y0 + bh), radius=10 * fs, fill=(0, 0, 0, 160))
    d.text((w / 2, y0 + 6 * fs), title, font=big, anchor="ma",
           fill=(255, 96, 96) if bad else (255, 255, 255))
    d.text((w / 2, y0 + 46 * fs), sub, font=small, anchor="ma", fill=(230, 230, 230))
    return Image.alpha_composite(img.convert("RGBA"), layer).convert("RGB")


def load_example_converter(path):
    # 按路径加载，不把例程目录加进 sys.path
    spec = importlib.util.spec_from_file_location("example_convert", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def check_bmp(path, size, bits, expect):
    """确认写出来的就是想要的格式（坏图也要坏在预定的地方），打印一行文件头摘要。"""
    n = os.path.getsize(path)
    with open(path, "rb") as f:
        hdr = f.read(54)
    bf_size, = struct.unpack_from("<I", hdr, 2)
    off, dib, w, h = struct.unpack_from("<IIii", hdr, 10)
    planes, bpp, comp = struct.unpack_from("<HHI", hdr, 26)
    if (hdr[:2], w, h, bpp, planes, bf_size) != (b"BM", size[0], size[1], bits, 1, n):
        sys.exit("%s 格式不对：%r %dx%d %d 位 planes=%d bfSize=%d 文件=%d"
                 % (path, hdr[:2], w, h, bpp, planes, bf_size, n))
    if bits == 24 and comp != 0:
        sys.exit("%s 不是不压缩 BMP（compression=%d）" % (path, comp))
    print("%-9s %4dx%-4d %2d 位  压缩=%d  信息头=%3d  数据偏移=%3d  %8d 字节   %s"
          % (os.path.basename(path), w, h, bpp, comp, dib, off, n, expect))


def main():
    ap = argparse.ArgumentParser(description="坏图处理测试卡 PIC1~5.BMP")
    ap.add_argument("out_dir", help="输出目录，生成的 PIC1~5.BMP 直接拷进 TF 卡根目录")
    ap.add_argument("--example", default=EXAMPLE_DOC, help="例程 lab_ex5_i2s/doc 目录")
    args = ap.parse_args()

    conv_py = os.path.join(args.example, "convert", "convert_images_to_bmp.py")
    if not os.path.isfile(conv_py):
        sys.exit("找不到例程转换脚本：" + conv_py)
    conv = load_example_converter(conv_py)
    os.makedirs(args.out_dir, exist_ok=True)

    results = []
    with tempfile.TemporaryDirectory() as tmp:
        for no, src, size, bits, via_script, title, sub, expect in ITEMS:
            with Image.open(os.path.join(args.example, src)) as im:
                img = ImageOps.fit(im.convert("RGB"), size, Image.Resampling.LANCZOS)
            img = add_label(img, title, sub, bad=not via_script)
            out = os.path.join(args.out_dir, "PIC%d.BMP" % no)
            if via_script:
                png = os.path.join(tmp, "PIC%d.png" % no)
                img.save(png)
                if size == (640, 480):
                    # 例程脚本的命令行用法：python convert_images_to_bmp.py <输入> <输出>
                    subprocess.run([sys.executable, "-I", conv_py, png, out], check=True)
                elif not conv.convert_single_file(png, out, size[0], size[1]):
                    sys.exit("例程脚本转换失败：PIC%d" % no)
            elif bits == 32:
                img.convert("RGBA").save(out, "BMP")
            else:
                img.save(out, "BMP")
            if not os.path.isfile(out):
                sys.exit("没有生成 " + out)
            results.append((out, size, bits, expect))

    print()
    for r in results:
        check_bmp(*r)
    print("\n把 %s 里的 PIC1~5.BMP 直接拷进 TF 卡根目录（FAT32）。" % args.out_dir)


if __name__ == "__main__":
    main()
