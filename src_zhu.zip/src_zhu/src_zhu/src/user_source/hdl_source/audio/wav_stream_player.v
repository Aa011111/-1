`timescale 1ns/1ps

// R3'-A: stream real audio content from the TF card and feed it into the
// existing HDMI audio chain (docs/29 rev: "what actually wins"). This module
// sits between the SD sector-read infrastructure and the PCM sample
// interface, using a dual-port BRAM circular buffer to absorb the ~12.5x
// rate mismatch between TF reads (~1.2 MB/s burst) and audio consumption
// (96 KB/s at 48 kHz 16-bit mono).
//
// Architecture:
//   TF sector bytes (mem_clk domain, byte-serial)
//     -> pair into 16-bit samples -> write into BRAM circular buffer
//   Audio sample ticks (pixel_clk domain, ~48 kHz)
//     -> read from BRAM -> output on valid/ready PCM interface
//
// The write side uses a sector-level state machine: issue one sector read,
// fill 256 samples (512 bytes), then issue the next. The read side consumes
// at the audio sample rate. Pointer crossing uses gray-coded 2FF sync (the
// established idiom). Buffer underflow outputs silence (zeros) with
// sample_valid still asserted, so the downstream HDMI chain never stalls.
//
// Data format: raw 16-bit signed little-endian PCM, 48 kHz mono. The PC
// tool (tools/make_audio_corpus.py) converts any WAV to this format before
// writing to the TF card. Endianness: TF bytes arrive LSB first.
//
// -----------------------------------------------------------------------------
// 【本工程修正】讲义原件接到本工程 sd_spi_sector_reader 上有四处会出问题，
// 端口不变，只改内部：
//   1. sd_lba 时序：原件在 WS_REQ 那一拍才 sd_lba <= cur_lba，而 sd_req
//      也是那一拍有效，reader 在同一个沿采 sector_lba，采到的是上一个值
//      （第一扇区更是复位后的不定值）。改为 cur_lba 更新时同步更新 sd_lba，
//      保证 sd_req 拉高时 sd_lba 已经就位。
//   2. 流控：原件注释说"水位检查隐含在消费速率里"，实际并没有——TF 读速
//      约为消费速率的 12 倍，不加限制 4096 深的环形缓冲几十毫秒就会被写
//      指针套圈，覆盖还没播的样本。改为 WS_REQ 里只有剩余空间 >= 一个扇区
//      才发请求。
//   3. 格雷码跨域：原件在【目的域】时钟里做 to_gray(对方二进制指针)，等于
//      直接用目的时钟采多位二进制，格雷码白做了。改为各自在【源域】寄存
//      格雷码，目的域只做两级同步。
//   4. play_enable / 写侧状态：原件读侧直接用 wr 域的 play_enable 和 3 位
//      wstate，未同步。改为 play_enable 在读侧过 2FF，写侧只同步一根
//      "已读完" 电平（1 位，2FF 安全）。
//   另外：水位计算原件用 {1'b0,a}-{1'b0,b}，a<b（指针回绕）时结果最高位
//   为 1，水位会被当成一个很大的数；改为 ADDR_WIDTH 位取模相减。
//   BRAM 读写各放进无复位的独立 always 块，便于 TD 推断成双口 BRAM。
//   stream_active / stream_end 改为读侧（rd_clk）信号，供读侧音源选择直接用。
//
// 【一图一音】播放中途要随图切曲，补两处：
//   1. writer_idle（wr_clk 域）：写侧回到 WS_IDLE。play_enable 拉低时写侧
//      可能正停在 WS_FILL 等一个扇区读完，这时马上再拉高会让它接着读旧文件
//      的下一扇区、wr_ptr 也没清零。上层必须等 writer_idle 再换参数、重新使能。
//   2. HEADER_BYTES：首扇区开头跳过这么多字节不入缓冲。make_music_wav.py
//      写出的是标准 44 字节头，不跳的话每次起播都会把头当 22 个样本放出来，
//      切曲/循环时听得到一声"咔"。必须是偶数，否则样本高低字节错位。
// -----------------------------------------------------------------------------
module wav_stream_player #(
    parameter integer ADDR_WIDTH = 12,         // 4096 x 16-bit = 8 KB
    parameter integer SAMPLES_PER_SECTOR = 256, // 512 bytes / 2
    parameter integer HEADER_BYTES = 0         // 首扇区跳过的字节数（偶数）
) (
    // write side: mem_clk domain (SD SPI engine clock)
    input  wire        wr_clk,
    input  wire        wr_rst_n,
    input  wire        play_enable,        // level: stream active (wr_clk 域)
    input  wire [31:0] start_lba,          // first data sector (after WAV header)
    input  wire [31:0] total_sectors,      // audio data extent in sectors
    output wire        sd_req,             // request a sector read
    output reg  [31:0] sd_lba,
    input  wire        sd_busy,
    input  wire        sd_valid,           // one byte per valid pulse
    input  wire [7:0]  sd_byte,
    input  wire [8:0]  sd_byte_index,      // 0..511 within sector
    input  wire        sd_done,
    input  wire [7:0]  sd_error,
    output wire        writer_idle,        // 写侧在 WS_IDLE（wr_clk 域）

    // read side: pixel_clk domain (audio chain clock)
    input  wire        rd_clk,
    input  wire        rd_rst_n,
    input  wire        sample_tick,        // ~48 kHz pulse: consume one sample
    output reg  signed [15:0] sample_out,
    output reg         sample_valid,
    input  wire        sample_ready,       // from downstream (always 1 in our chain)

    // status (read side)
    output reg  [31:0] sample_counter,     // samples consumed (for OSD)
    output wire        stream_active,      // play_enable && not drained (rd_clk 域)
    output wire        stream_end,         // all data consumed (rd_clk 域)
    output wire        buffer_low          // < 25% remaining (for OSD/status)
);
    localparam integer DEPTH = (1 << ADDR_WIDTH);

    // ---------------- circular buffer ----------------
    reg [15:0] buffer [0:DEPTH-1];
    reg [ADDR_WIDTH-1:0] wr_ptr;    // write pointer (wr_clk domain)
    reg [ADDR_WIDTH-1:0] rd_ptr;    // read pointer (rd_clk domain)
    reg [15:0] rd_data;             // BRAM 读出寄存器，始终等于 buffer[rd_ptr]（晚一拍）

    // gray-coded pointers, registered in their SOURCE domain
    reg [ADDR_WIDTH-1:0] wr_gray;                       // wr_clk
    reg [ADDR_WIDTH-1:0] rd_gray;                       // rd_clk
    // 2FF synchronizers in the DESTINATION domain
    reg [ADDR_WIDTH-1:0] wr_gray_sync1, wr_gray_sync2;  // rd_clk
    reg [ADDR_WIDTH-1:0] rd_gray_sync1, rd_gray_sync2;  // wr_clk

    // 1-bit level crossings
    reg wr_ended;                                       // wr_clk: 写侧已进 WS_END
    reg ended_sync1, ended_sync2;                       // rd_clk
    reg play_sync1, play_sync2;                         // rd_clk

    function [ADDR_WIDTH-1:0] to_gray;
        input [ADDR_WIDTH-1:0] b;
        begin
            to_gray = b ^ (b >> 1);
        end
    endfunction

    function [ADDR_WIDTH-1:0] from_gray;
        input [ADDR_WIDTH-1:0] g;
        reg [ADDR_WIDTH-1:0] b;
        integer i;
        begin
            b[ADDR_WIDTH-1] = g[ADDR_WIDTH-1];
            for (i = ADDR_WIDTH-2; i >= 0; i = i - 1)
                b[i] = b[i+1] ^ g[i];
            from_gray = b;
        end
    endfunction

    // synchronized pointers (each in the other domain)
    wire [ADDR_WIDTH-1:0] wr_ptr_in_rd = from_gray(wr_gray_sync2);
    wire [ADDR_WIDTH-1:0] rd_ptr_in_wr = from_gray(rd_gray_sync2);

    // fill level, modulo DEPTH. 写侧保证永远不写满（至少留一个扇区的空），
    // 所以 0 只可能表示"空"，不会和"满"混淆。
    wire [ADDR_WIDTH-1:0] level_wr = wr_ptr - rd_ptr_in_wr;
    wire [ADDR_WIDTH-1:0] level_rd = wr_ptr_in_rd - rd_ptr;

    // 还能再装下一整扇区（256 样本）才允许发下一次读请求
    wire room_for_sector = (level_wr < (DEPTH - SAMPLES_PER_SECTOR));

    wire play_rd  = play_sync2;
    wire ended_rd = ended_sync2;

    // ---------------- write side state machine ----------------
    localparam [2:0] WS_IDLE  = 3'd0;
    localparam [2:0] WS_REQ   = 3'd1;
    localparam [2:0] WS_FILL  = 3'd2;
    localparam [2:0] WS_DONE  = 3'd3;
    localparam [2:0] WS_END   = 3'd4;
    reg [2:0]  wstate;
    reg [31:0] cur_lba;
    reg [31:0] sectors_read;
    reg [7:0]  lo_byte;             // little-endian pair assembly
    reg        lo_pending;

    // 首扇区的文件头字节不算样本
    wire skip_byte = (sectors_read == 32'd0) && (sd_byte_index < HEADER_BYTES);
    wire take_byte = sd_valid && !skip_byte;
    wire buf_we = (wstate == WS_FILL) && take_byte && lo_pending;

    assign sd_req = (wstate == WS_REQ) && room_for_sector;
    assign writer_idle = (wstate == WS_IDLE);
    assign stream_end    = ended_rd && (level_rd == {ADDR_WIDTH{1'b0}});
    assign stream_active = play_rd && !stream_end;
    assign buffer_low = (level_rd < (1 << (ADDR_WIDTH-2))); // < 25%

    // BRAM 写口（无复位，便于推断 BRAM）
    always @(posedge wr_clk) begin
        if (buf_we)
            buffer[wr_ptr] <= {sd_byte, lo_byte};
    end

    // BRAM 读口（无复位、无条件读）
    always @(posedge rd_clk) begin
        rd_data <= buffer[rd_ptr];
    end

    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) begin
            wstate         <= WS_IDLE;
            cur_lba        <= 32'd0;
            sd_lba         <= 32'd0;
            sectors_read   <= 32'd0;
            wr_ptr         <= {ADDR_WIDTH{1'b0}};
            wr_gray        <= {ADDR_WIDTH{1'b0}};
            wr_ended       <= 1'b0;
            lo_pending     <= 1'b0;
            lo_byte        <= 8'd0;
            rd_gray_sync1  <= {ADDR_WIDTH{1'b0}};
            rd_gray_sync2  <= {ADDR_WIDTH{1'b0}};
        end else begin
            // wr_ptr 的格雷码在本域寄存，rd_ptr 的格雷码从读侧两级同步进来
            wr_gray       <= to_gray(wr_ptr);
            rd_gray_sync1 <= rd_gray;
            rd_gray_sync2 <= rd_gray_sync1;
            wr_ended      <= (wstate == WS_END);

            case (wstate)
            WS_IDLE: begin
                // 指针在 play_enable 为低期间就清零，等 play_enable 拉高时
                // 两侧同步器早已稳定，不会在播放开始时出现多位跳变
                if (!play_enable) begin
                    wr_ptr     <= {ADDR_WIDTH{1'b0}};
                    lo_pending <= 1'b0;
                end else if (start_lba != 32'd0 && total_sectors != 32'd0) begin
                    cur_lba      <= start_lba;
                    sd_lba       <= start_lba;
                    sectors_read <= 32'd0;
                    lo_pending   <= 1'b0;
                    wstate       <= WS_REQ;
                end
            end
            WS_REQ: begin
                if (!play_enable) begin
                    wstate <= WS_IDLE;
                end else if (!sd_busy && room_for_sector) begin
                    // sd_req 在本拍有效，sd_lba 已在上一次更新 cur_lba 时就位
                    wstate <= WS_FILL;
                end
            end
            WS_FILL: begin
                if (take_byte) begin
                    if (!lo_pending) begin
                        lo_byte    <= sd_byte;
                        lo_pending <= 1'b1;
                    end else begin
                        wr_ptr     <= wr_ptr + 1'b1;   // 数据由上方 BRAM 写口写入
                        lo_pending <= 1'b0;
                    end
                end
                if (sd_done) begin
                    if (sd_error != 8'd0) begin
                        wstate <= WS_END;  // sector error: stop streaming
                    end else begin
                        sectors_read <= sectors_read + 1'b1;
                        cur_lba      <= cur_lba + 1'b1;
                        sd_lba       <= cur_lba + 1'b1;
                        if (sectors_read + 1'b1 >= total_sectors)
                            wstate <= WS_END;
                        else
                            wstate <= WS_REQ;
                    end
                end
            end
            WS_DONE: wstate <= WS_REQ;  // unused, reserved
            WS_END: begin
                // stay ended until play_enable drops
                if (!play_enable)
                    wstate <= WS_IDLE;
            end
            default: wstate <= WS_IDLE;
            endcase
        end
    end

    // ---------------- read side ----------------
    always @(posedge rd_clk or negedge rd_rst_n) begin
        if (!rd_rst_n) begin
            rd_ptr         <= {ADDR_WIDTH{1'b0}};
            rd_gray        <= {ADDR_WIDTH{1'b0}};
            sample_out     <= 16'sd0;
            sample_valid   <= 1'b0;
            sample_counter <= 32'd0;
            wr_gray_sync1  <= {ADDR_WIDTH{1'b0}};
            wr_gray_sync2  <= {ADDR_WIDTH{1'b0}};
            ended_sync1    <= 1'b0;
            ended_sync2    <= 1'b0;
            play_sync1     <= 1'b0;
            play_sync2     <= 1'b0;
        end else begin
            rd_gray       <= to_gray(rd_ptr);
            wr_gray_sync1 <= wr_gray;
            wr_gray_sync2 <= wr_gray_sync1;
            ended_sync1   <= wr_ended;
            ended_sync2   <= ended_sync1;
            play_sync1    <= play_enable;
            play_sync2    <= play_sync1;

            sample_valid <= 1'b0;

            if (sample_tick && sample_ready) begin
                if (play_rd &&
                    (level_rd >= SAMPLES_PER_SECTOR ||
                     (ended_rd && level_rd != {ADDR_WIDTH{1'b0}}))) begin
                    // enough data (or stream ended with residual): play
                    // rd_data 恒等于 buffer[rd_ptr]：rd_ptr 两次 tick 之间
                    // 保持几百拍不变，读口晚一拍早已追上
                    sample_out     <= rd_data;
                    rd_ptr         <= rd_ptr + 1'b1;
                    sample_valid   <= 1'b1;
                    sample_counter <= sample_counter + 1'b1;
                end else begin
                    // prefill or underflow: silence, don't consume
                    sample_out   <= 16'sd0;
                    sample_valid <= 1'b1;
                end
            end

            if (!play_rd) begin
                rd_ptr         <= {ADDR_WIDTH{1'b0}};
                sample_counter <= 32'd0;
            end
        end
    end
endmodule
