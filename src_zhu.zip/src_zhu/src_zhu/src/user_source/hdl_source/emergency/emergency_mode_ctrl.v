`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// SW1 应急模式开关：同步 + 消抖，输出 ctrl(sd_card_clk) 域电平。
//
// 原理图 6_EX_DEVICE "4 bit Switch"：SW1 是三脚拨动开关，公共端 SW_1 在
// 3V3 / GND 之间二选一，经 RN38(120R) 成 SWKEY_1 进 FPGA 的 C8 脚。电平是
// 开关硬拉的，不需要上下拉。哪个拨向算"导通"由 ACTIVE_LEVEL 决定，
// 上板发现反了只改这个参数。
//
// 【复位值 = 应急】复位期间和消抖确认前一律当作应急模式。顶层用它门住
// TF 卡摄入的启动脉冲：如果复位值是"正常"，开关拨着应急上电时，摄入会在
// 消抖确认之前的第一拍就被踢起来，TF 卡就被碰了。代价只是正常上电时摄入
// 晚 DEBOUNCE_MS 才启动，而 SD 初始化本身就要先等 100ms，感觉不到。
// -----------------------------------------------------------------------------
module emergency_mode_ctrl #(
    parameter integer CLK_FREQ_HZ  = 100_000_000,
    parameter integer DEBOUNCE_MS  = 20,
    parameter         ACTIVE_LEVEL = 1'b1     // 开关读到这个电平 = 应急模式
) (
    input  wire clk,
    input  wire rst_n,
    input  wire sw_in,                        // 板上 SWKEY_1，异步
    output reg  emergency                     // 1 = 应急模式
);
    localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

    (* async_reg = "true" *) reg s1, s2;
    reg [31:0] cnt;

    wire sw_active = (s2 == ACTIVE_LEVEL);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1        <= ACTIVE_LEVEL;
            s2        <= ACTIVE_LEVEL;
            cnt       <= 32'd0;
            emergency <= 1'b1;
        end else begin
            s1 <= sw_in;
            s2 <= s1;
            if (sw_active == emergency) begin
                cnt <= 32'd0;
            end else if (cnt >= DEBOUNCE_CYCLES - 1) begin
                cnt       <= 32'd0;
                emergency <= sw_active;
            end else begin
                cnt <= cnt + 32'd1;
            end
        end
    end
endmodule
