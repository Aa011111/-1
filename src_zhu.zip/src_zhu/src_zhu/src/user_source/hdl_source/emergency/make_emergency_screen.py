# -*- coding: utf-8 -*-
"""
应急逃生画面 ROM 生成脚本（SW1 应急模式）

画面在 320x240 下绘制、硬件里 2x 放大到 640x480；每像素 2 位调色板索引，
4 像素打包成 1 字节（低位在左），共 19200 字节，emergency_screen_rom.v
用 $readmemh 读入、TD 推断成 BRAM。

调色板（和 emergency_screen.v 的 PAL_* 参数一一对应，改一边必须改另一边）：
    0 = 安全绿   底色
    1 = 白       文字 / 图标 / 平面图底板
    2 = 红       【硬件里按 1Hz 闪烁】，只用在"您在此处"这类要闪的元素上
    3 = 深灰     平面图墙线 / 小字

箭头流动带（屏幕 y 120~179）在 ROM 里只留绿底，白色箭头由硬件逻辑实时画，
位置参数和 emergency_screen.v 的 ARROW_* 对应。

用法：
    python make_emergency_screen.py                 # 生成默认画面
    python make_emergency_screen.py --image my.png  # 用自己画的图（任意尺寸，
                                                    # 缩放到 320x240 后按最近颜色映射到 4 色调色板）

输出：
    emergency_screen.hex           本目录（.v 源文件目录，TD/ModelSim 都从这里读）
    ../../../td_project/emergency_screen.hex   同一份拷贝（.al 根目录，TD 文档允许的另一位置）
    emergency_screen_preview.png   640x480 预览（含箭头流动带第 0 帧的样子）
"""
import argparse
import os

from PIL import Image, ImageDraw, ImageFont

W, H = 320, 240
SCALE = 2

PALETTE = [
    (0x00, 0x9A, 0x44),   # 0 安全绿
    (0xFF, 0xFF, 0xFF),   # 1 白
    (0xE6, 0x00, 0x12),   # 2 红（闪烁）
    (0x26, 0x26, 0x26),   # 3 深灰
]
GREEN, WHITE, RED, DARK = 0, 1, 2, 3

# 箭头流动带（屏幕坐标，和 emergency_screen.v 一致）
ARROW_X0, ARROW_X1 = 24, 616
ARROW_Y0, ARROW_H = 120, 60
ARROW_PERIOD = 64

HERE = os.path.dirname(os.path.abspath(__file__))
TD_ROOT = os.path.normpath(os.path.join(HERE, "..", "..", "..", "td_project"))

FONT_DIRS = [os.path.join(os.environ.get("WINDIR", "C:/Windows"), "Fonts"), "/usr/share/fonts"]


def load_font(names, size):
    for d in FONT_DIRS:
        for n in names:
            p = os.path.join(d, n)
            if os.path.exists(p):
                return ImageFont.truetype(p, size)
    raise SystemExit("找不到字体 %s，请修改 FONT_DIRS" % names)


def font_bold(size):
    return load_font(["msyhbd.ttc", "simhei.ttf"], size)


def font_reg(size):
    return load_font(["msyh.ttc", "simhei.ttf"], size)


def text(d, xy, s, font, fill, anchor="la"):
    d.text(xy, s, font=font, fill=fill, anchor=anchor)


def draw_running_man(d, ox, oy, s, fill):
    """标准安全出口奔跑小人的简化版，(ox,oy) 左上角，s = 边长"""
    k = s / 40.0

    def P(x, y):
        return (ox + x * k, oy + y * k)

    w = max(2, int(round(4 * k)))
    d.ellipse([P(23, 1), P(31, 9)], fill=fill)                    # 头
    d.line([P(25, 11), P(19, 25)], fill=fill, width=w + 1)        # 躯干
    d.line([P(24, 13), P(31, 19), P(37, 16)], fill=fill, width=w)  # 前臂
    d.line([P(23, 13), P(15, 15), P(10, 21)], fill=fill, width=w)  # 后臂
    d.line([P(19, 25), P(27, 30), P(26, 39)], fill=fill, width=w)  # 前腿
    d.line([P(19, 25), P(13, 32), P(3, 33)], fill=fill, width=w)   # 后腿


def draw_door(d, x0, y0, x1, y1, fill, frame):
    d.rectangle([x0, y0, x1, y1], fill=fill, outline=frame, width=2)


def draw_arrow_right(d, x, y, length, fill, width=3, head=6):
    d.line([(x, y), (x + length - head, y)], fill=fill, width=width)
    d.polygon([(x + length, y), (x + length - head, y - head),
               (x + length - head, y + head)], fill=fill)


def render_default():
    img = Image.new("P", (W, H), GREEN)
    img.putpalette([c for rgb in PALETTE for c in rgb] + [0] * (768 - 12))
    d = ImageDraw.Draw(img)
    d.fontmode = "1"   # 关抗锯齿，只出调色板里的纯色

    # 外框
    d.rectangle([2, 2, W - 3, H - 3], outline=WHITE, width=2)

    # ---- 标题区 y 6~56 ----
    draw_running_man(d, 12, 9, 44, WHITE)
    # 门框（小人跑向的门）
    d.rectangle([60, 9, 76, 52], outline=WHITE, width=3)
    text(d, (86, 3), "安全出口", font_bold(36), WHITE)
    text(d, (88, 44), "EMERGENCY  EXIT", font_bold(11), WHITE)
    text(d, (308, 30), "EXIT", font_bold(30), WHITE, anchor="rm")

    # ---- 箭头流动带 y 60~89（硬件画箭头，这里留绿底）----

    # ---- 平面图 y 94~198 ----
    px0, py0, px1, py1 = 8, 94, 311, 198
    d.rectangle([px0, py0, px1, py1], fill=WHITE, outline=DARK, width=2)
    text(d, (px0 + 5, py0 + 2), "本层疏散示意图", font_bold(12), DARK)

    # 走廊（上下两排房间之间）
    cy0, cy1 = 140, 160
    rooms_top = [(14, 112, 74), (74, 112, 134), (134, 112, 194), (194, 112, 248)]
    rooms_bot = [(14, 160, 74), (74, 160, 134), (134, 160, 194)]
    f_room = font_reg(11)
    for i, (x0, y0, x1) in enumerate(rooms_top):
        d.rectangle([x0, y0, x1, cy0], outline=DARK, width=2)
        text(d, ((x0 + x1) // 2, (y0 + cy0) // 2), "%d" % (301 + i), f_room, DARK, "mm")
    for i, (x0, y0, x1) in enumerate(rooms_bot):
        d.rectangle([x0, cy1, x1, 192], outline=DARK, width=2)
        text(d, ((x0 + x1) // 2, (cy1 + 192) // 2), "%d" % (305 + i), f_room, DARK, "mm")
    # 电梯（禁止乘坐）
    d.rectangle([194, cy1, 248, 192], outline=DARK, width=2)
    text(d, (221, 176), "电梯", font_bold(12), DARK, "mm")
    d.line([(198, 164), (244, 189)], fill=DARK, width=3)   # 叉不能用 RED：RED 会闪
    d.line([(244, 164), (198, 189)], fill=DARK, width=3)

    # 走廊里的疏散路线（绿色箭头）
    for x in range(52, 238, 34):
        draw_arrow_right(d, x, 150, 26, GREEN, width=4, head=6)

    # 楼梯间 / 安全出口
    d.rectangle([252, 112, 305, 192], fill=GREEN, outline=DARK, width=2)
    text(d, (278, 132), "安全", font_bold(14), WHITE, "mm")
    text(d, (278, 150), "出口", font_bold(14), WHITE, "mm")
    for i in range(4):   # 楼梯踏步
        d.line([(258, 166 + i * 6), (299, 166 + i * 6)], fill=WHITE, width=2)

    # 您在此处（红色，硬件闪烁）
    d.ellipse([22, 143, 36, 157], fill=RED)
    d.rectangle([px1 - 76, py0 + 2, px1 - 4, py0 + 15], fill=RED)
    text(d, (px1 - 40, py0 + 9), "● 您在此处", font_bold(11), WHITE, "mm")

    # ---- 底部提示 y 202~236 ----
    text(d, (W // 2, 210), "请勿乘坐电梯 · 弯腰低姿 · 湿毛巾捂住口鼻", font_bold(14), WHITE, "mm")
    text(d, (W // 2, 228), "火警 119      急救 120", font_bold(14), WHITE, "mm")
    return img


def quantize_image(path):
    src = Image.open(path).convert("RGB").resize((W, H), Image.NEAREST)
    img = Image.new("P", (W, H), GREEN)
    img.putpalette([c for rgb in PALETTE for c in rgb] + [0] * (768 - 12))
    sp, dp = src.load(), img.load()
    for y in range(H):
        for x in range(W):
            r, g, b = sp[x, y]
            dp[x, y] = min(range(4), key=lambda i: (PALETTE[i][0] - r) ** 2 +
                           (PALETTE[i][1] - g) ** 2 + (PALETTE[i][2] - b) ** 2)
    return img


def arrow_hit(x, y, phase):
    """与 emergency_screen.v 的箭头判定逐位相同（向右、第 phase 帧）"""
    if not (ARROW_X0 <= x < ARROW_X1 and ARROW_Y0 <= y < ARROW_Y0 + ARROW_H):
        return False
    v = abs(y - (ARROW_Y0 + ARROW_H // 2))
    u = (x - phase) & (ARROW_PERIOD - 1)
    return v < 24 and 24 <= u + v < 40


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", help="自定义画面（任意尺寸，映射到 4 色调色板）")
    args = ap.parse_args()

    img = quantize_image(args.image) if args.image else render_default()
    px = img.load()
    for y in range(H):
        for x in range(W):
            if px[x, y] > 3:
                raise SystemExit("像素 (%d,%d) 索引越界" % (x, y))

    # 4 像素 1 字节，x&3 = 0 放 bit[1:0]
    lines = []
    for y in range(H):
        for xb in range(W // 4):
            b = 0
            for k in range(4):
                b |= px[xb * 4 + k, y] << (2 * k)
            lines.append("%02X" % b)
    data = "\n".join(lines) + "\n"
    for out_dir in (HERE, TD_ROOT):
        if os.path.isdir(out_dir):
            with open(os.path.join(out_dir, "emergency_screen.hex"), "w") as f:
                f.write(data)
            print("写出", os.path.join(out_dir, "emergency_screen.hex"))

    prev = Image.new("RGB", (W * SCALE, H * SCALE))
    pp = prev.load()
    for y in range(H * SCALE):
        for x in range(W * SCALE):
            pp[x, y] = (255, 255, 255) if arrow_hit(x, y, 0) else PALETTE[px[x // SCALE, y // SCALE]]
    prev.save(os.path.join(HERE, "emergency_screen_preview.png"))
    print("写出 emergency_screen_preview.png，共 %d 字节" % len(lines))


if __name__ == "__main__":
    main()
