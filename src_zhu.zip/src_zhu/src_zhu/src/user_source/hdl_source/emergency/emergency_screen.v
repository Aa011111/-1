`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 应急逃生画面：SW1 应急模式下整屏替换成逃生指示，不依赖 TF 卡 / SDRAM。
//
// 画面三部分：
//   1) 静态底图：emergency_screen_rom，320x240 4 色，2x 放大到 640x480。
//      内容（标题、平面图、提示语）全在 make_emergency_screen.py 里改。
//   2) 闪烁：调色板索引 2（红）按 BLINK_FRAMES 帧亮/灭交替，灭时显示白色，
//      用在"您在此处"这类元素上。
//   3) 流动箭头：ARROW_* 区域内由逻辑实时画 V 形箭头，每帧平移 ARROW_SPEED
//      像素。ROM 在这一带只留绿底。ARROW_DIR 选方向。
//
// 时序和 osd/timestamp_osd 同一套：用 next_x = de ? x+1 : 0 提前一拍出 ROM
// 地址和箭头判定，寄存一拍后正好对齐当前像素，输出路径只剩一级 mux。
// next_x 的规则和顶层 osd_pixel_x 计数器绑死，动那个计数器要一起动。
//
// enable 是 video 域电平（顶层已过 sync_2ff），这里在 frame_start 锁存，
// 进出应急模式都落在帧边界，不会半屏切换。
// -----------------------------------------------------------------------------
module emergency_screen #(
    parameter         INIT_FILE    = "emergency_screen.hex",
    // 调色板，和 make_emergency_screen.py 的 PALETTE 一一对应
    parameter [23:0]  PAL_0        = 24'h009A44,   // 安全绿
    parameter [23:0]  PAL_1        = 24'hFFFFFF,   // 白
    parameter [23:0]  PAL_2        = 24'hE60012,   // 红（闪烁）
    parameter [23:0]  PAL_3        = 24'h262626,   // 深灰
    parameter [23:0]  ARROW_COLOR  = 24'hFFFFFF,
    parameter integer BLINK_FRAMES = 30,           // 约 0.5s 亮 / 0.5s 灭 @59.5fps
    // 箭头流动带（屏幕坐标），和 make_emergency_screen.py 的 ARROW_* 一致
    parameter integer ARROW_X0     = 24,
    parameter integer ARROW_X1     = 616,
    parameter integer ARROW_Y0     = 120,
    parameter integer ARROW_H      = 60,
    parameter integer ARROW_SPEED  = 2,            // 像素/帧，约 120 像素/秒
    parameter         ARROW_DIR    = 1'b0          // 0 = 向右，1 = 向左
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        enable,
    input  wire        de,
    input  wire        frame_start,
    input  wire [11:0] pixel_x,
    input  wire [11:0] pixel_y,
    input  wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire        screen_active
);
    localparam integer ARROW_CY = ARROW_Y0 + ARROW_H / 2;

    // ---- 帧级状态：使能锁存、闪烁、箭头相位 ----
    reg       en_q;
    reg [5:0] blink_cnt;
    reg       blink_on;
    reg [5:0] phase;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            en_q      <= 1'b0;
            blink_cnt <= 6'd0;
            blink_on  <= 1'b1;
            phase     <= 6'd0;
        end else if (frame_start) begin
            en_q  <= enable;
            phase <= phase + ARROW_SPEED;     // 赋值截到 6 位，自然回绕
            if (blink_cnt >= BLINK_FRAMES - 1) begin
                blink_cnt <= 6'd0;
                blink_on  <= ~blink_on;
            end else begin
                blink_cnt <= blink_cnt + 6'd1;
            end
        end
    end

    // ---- 下一个像素：ROM 地址 ----
    // 源图坐标 = 屏幕坐标 / 2；一行 80 字节，addr = sy*80 + sx/4 = sy*64 + sy*16 + nx/8
    wire [11:0] next_x = de ? (pixel_x + 12'd1) : 12'd0;
    wire [8:0]  src_y  = (pixel_y < 12'd480) ? pixel_y[9:1] : 9'd0;
    wire [6:0]  src_xb = (next_x  < 12'd640) ? next_x[9:3]  : 7'd0;
    wire [14:0] rom_addr = {src_y, 6'd0} + {2'd0, src_y, 4'd0} + {8'd0, src_xb};

    wire [7:0] rom_q;
    emergency_screen_rom #(
        .INIT_FILE (INIT_FILE)
    ) u_rom (
        .clk  (clk),
        .addr (rom_addr),
        .q    (rom_q)
    );

    // ---- 下一个像素：V 形箭头 ----
    // 一个周期 64 像素，u = 周期内列号，v = 离中心行的距离；
    // 24 <= u+v < 40 且 v < 24 是一个尖朝右、笔画 16 像素宽的 ">"。
    // 向左时把 u 镜像（63-u），尖朝左、相位反向就变成往左流。
    wire [11:0] dy_signed = pixel_y - ARROW_CY;
    wire [11:0] v_full    = dy_signed[11] ? (12'd0 - dy_signed) : dy_signed;
    wire [5:0]  u_right   = next_x[5:0] - phase;
    wire [5:0]  u_left    = ~(next_x[5:0] + phase);
    wire [5:0]  u         = ARROW_DIR ? u_left : u_right;
    wire [12:0] uv        = {7'd0, u} + {1'b0, v_full};

    wire next_arrow = (next_x  >= ARROW_X0) && (next_x  < ARROW_X1) &&
                      (pixel_y >= ARROW_Y0) && (pixel_y < ARROW_Y0 + ARROW_H) &&
                      (v_full < 12'd24) && (uv >= 13'd24) && (uv < 13'd40);

    reg [1:0] sel_q;      // 字节内第几个像素，和 rom_q 同拍
    reg       arrow_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sel_q   <= 2'd0;
            arrow_q <= 1'b0;
        end else begin
            sel_q   <= next_x[2:1];
            arrow_q <= next_arrow;
        end
    end

    // ---- 当前像素：调色板 + 叠加 ----
    reg [1:0]  pix_idx;
    reg [23:0] pix_rgb;
    always @* begin
        case (sel_q)
            2'd0: pix_idx = rom_q[1:0];
            2'd1: pix_idx = rom_q[3:2];
            2'd2: pix_idx = rom_q[5:4];
            default: pix_idx = rom_q[7:6];
        endcase
        case (pix_idx)
            2'd0: pix_rgb = PAL_0;
            2'd1: pix_rgb = PAL_1;
            2'd2: pix_rgb = blink_on ? PAL_2 : PAL_1;
            default: pix_rgb = PAL_3;
        endcase
    end

    assign screen_active = en_q;
    assign rgb_out = (en_q && de) ? (arrow_q ? ARROW_COLOR : pix_rgb) : rgb_in;
endmodule
