`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 火灾判定 + 画面降级选择（ctrl = sd_card_clk 域）
//
// 输入（已接真传感器，见 emergency/README.md "硬件连接"）：
//   smoke_in  MQ-2 模块 DO（LM393 比较器输出，浓度超过模块电位器设定值时 = 低电平）
//             J2 第 2 脚（丝印 GPIOB_1）-> RN29 47R -> FPGA 网络 GPIOB19 = N4
//   temp_in   am2302_reader 的 temp_alarm（AM2302 温度超限 = 高电平），同一时钟域
// SMOKE_ACTIVE_LEVEL / TEMP_ACTIVE_LEVEL 是各自"报警"对应的电平。
// MQ-2 的 AO（J2 第 4 脚，丝印 GPIOB_3）是 0~5V 模拟量，FPGA 普通 IO 读不了，没有使用。
// 原来的拨码开关 SW1(C8) / SW2(C7) 已不再参与。
//
// 判定：
//   两个都报警        -> 火灾发生，目标图 PIC13（index FIRE_INDEX）
//   只有一个报警      -> 火灾预警，目标图 PIC12（index WARN_INDEX）
//   都不报警          -> 正常播放
// 降级（安全冗余）：有报警时目标图能不能显示，只看它有没有真的进 SDRAM：
//   player_ready（= 顶层 display_valid：摄入结束且 reader 已放行）
//   且 image_complete[目标] = 1    -> alarm_pic=1，像素域把 reader 改读目标 bank
//   否则                           -> rom_screen=1，片内 ROM 逃生画面整屏覆盖
// "否则"覆盖了 TF 卡的所有坏法：没插卡 / 初始化失败 / 文件系统坏 / 只有
// PIC13.BMP 坏 / 摄入卡住一直不结束 / 掉电重启后读不出来。摄入没结束之前
// 一律走 ROM，所以不需要单独的超时——摄入一结束且图在，自动切回图片。
// 开机时卡是好的、运行中才坏的情况：图早已在 SDRAM 里，照样显示图片。
//
// 复位值 = 不报警。消抖确认前的 20ms 里报警会晚 20ms 才生效，和 HDMI
// 起来的时间比可以忽略；反过来取"报警"会让每次上电都闪一下 ROM 画面。
// 所有输出都是寄存器，下游跨域直接用 sync_2ff / cdc_bus_commit。
// -----------------------------------------------------------------------------
module fire_alarm_ctrl #(
    parameter integer CLK_FREQ_HZ  = 100_000_000,
    parameter integer DEBOUNCE_MS  = 20,
    parameter         SMOKE_ACTIVE_LEVEL = 1'b0,   // MQ-2 DO：低电平 = 烟雾超标
    parameter         TEMP_ACTIVE_LEVEL  = 1'b1,   // am2302_reader.temp_alarm：高 = 超温
    parameter integer IMAGE_COUNT  = 13,
    parameter integer INDEX_W      = 4,
    parameter integer WARN_INDEX   = 11,       // PIC12 火灾预警
    parameter integer FIRE_INDEX   = 12        // PIC13 火灾发生
) (
    input  wire                   clk,
    input  wire                   rst_n,
    input  wire                   smoke_in,     // MQ-2 DO，异步
    input  wire                   temp_in,      // am2302_reader.temp_alarm
    input  wire                   player_ready,
    input  wire [IMAGE_COUNT-1:0] image_complete,

    output wire                   smoke,        // 消抖后，1 = 报警
    output wire                   temp,
    output reg                    alarm,        // 任一报警（预警或火灾）
    output reg                    fire,         // 两个都报警
    output reg  [INDEX_W-1:0]     alarm_index,  // 当前该显示的火灾图
    output reg                    alarm_pic,    // 1 = 显示 SDRAM 里的 alarm_index
    output reg                    rom_screen    // 1 = 目标图不可用，显示 ROM 逃生画面
);
    alarm_switch_debounce #(
        .CLK_FREQ_HZ (CLK_FREQ_HZ),
        .DEBOUNCE_MS (DEBOUNCE_MS),
        .ACTIVE_LEVEL(SMOKE_ACTIVE_LEVEL)
    ) u_smoke (
        .clk(clk), .rst_n(rst_n), .sw_in(smoke_in), .active(smoke)
    );

    alarm_switch_debounce #(
        .CLK_FREQ_HZ (CLK_FREQ_HZ),
        .DEBOUNCE_MS (DEBOUNCE_MS),
        .ACTIVE_LEVEL(TEMP_ACTIVE_LEVEL)
    ) u_temp (
        .clk(clk), .rst_n(rst_n), .sw_in(temp_in), .active(temp)
    );

    wire               any_alarm  = smoke | temp;
    wire               both_alarm = smoke & temp;
    wire [INDEX_W-1:0] want_index = both_alarm ? FIRE_INDEX[INDEX_W-1:0] :
                                                 WARN_INDEX[INDEX_W-1:0];
    wire               want_ok    = player_ready &&
                                    (both_alarm ? image_complete[FIRE_INDEX] :
                                                  image_complete[WARN_INDEX]);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            alarm       <= 1'b0;
            fire        <= 1'b0;
            alarm_index <= WARN_INDEX[INDEX_W-1:0];
            alarm_pic   <= 1'b0;
            rom_screen  <= 1'b0;
        end else begin
            alarm       <= any_alarm;
            fire        <= both_alarm;
            alarm_index <= want_index;
            alarm_pic   <= any_alarm &&  want_ok;
            rom_screen  <= any_alarm && !want_ok;
        end
    end
endmodule

// 单路报警输入：2FF 同步 + 稳定 DEBOUNCE_MS 才翻转（比较器在阈值附近会抖）。
// 第一级叫 s1，被 media_player_promax_top.sdc 的 */s1 通配 false_path 覆盖。
module alarm_switch_debounce #(
    parameter integer CLK_FREQ_HZ  = 100_000_000,
    parameter integer DEBOUNCE_MS  = 20,
    parameter         ACTIVE_LEVEL = 1'b1
) (
    input  wire clk,
    input  wire rst_n,
    input  wire sw_in,
    output reg  active
);
    localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

    (* async_reg = "true" *) reg s1, s2;
    reg [31:0] cnt;

    wire sw_active = (s2 == ACTIVE_LEVEL);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1     <= ~ACTIVE_LEVEL;
            s2     <= ~ACTIVE_LEVEL;
            cnt    <= 32'd0;
            active <= 1'b0;
        end else begin
            s1 <= sw_in;
            s2 <= s1;
            if (sw_active == active) begin
                cnt <= 32'd0;
            end else if (cnt >= DEBOUNCE_CYCLES - 1) begin
                cnt    <= 32'd0;
                active <= sw_active;
            end else begin
                cnt <= cnt + 32'd1;
            end
        end
    end
endmodule
