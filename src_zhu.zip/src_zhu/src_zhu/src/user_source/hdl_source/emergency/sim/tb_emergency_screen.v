`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// emergency_screen + emergency_mode_ctrl 自检仿真
//
// 1) emergency_mode_ctrl：复位值=应急、抖动不翻转、稳定 DEBOUNCE 后才翻转
// 2) emergency_screen：640x480@800x525 时序，坐标计数器逐字复刻顶层
//    osd_pixel_x/y。enable 在帧中间拉高，检查当帧不生效（帧边界锁存）；
//    之后把第 2、3 帧有效区像素写进 frame2.txt / frame3.txt，由
//    check_frames.py 和 Python 参考模型逐像素比对（ROM 2x 放大 + 箭头 + 闪烁）。
// 跑法见 run.do。
// -----------------------------------------------------------------------------
module tb_emergency_screen;
    // ---------------- emergency_mode_ctrl ----------------
    reg clk100 = 1'b0;
    always #5 clk100 = ~clk100;
    reg rst_sd_n = 1'b0;
    reg sw = 1'b0;
    wire emg;

    emergency_mode_ctrl #(
        .CLK_FREQ_HZ (1_000_000),   // 仿真压缩：1ms = 1000 拍
        .DEBOUNCE_MS (1),
        .ACTIVE_LEVEL(1'b1)
    ) u_ctrl (
        .clk(clk100), .rst_n(rst_sd_n), .sw_in(sw), .emergency(emg)
    );

    integer errors = 0;
    integer i;

    initial begin : ctrl_test
        #1;
        if (emg !== 1'b1) begin $display("FAIL ctrl: 复位期间应为应急"); errors = errors + 1; end
        #100 rst_sd_n = 1'b1;
        // sw=0（正常），1000 拍后才退出应急
        repeat (500) @(posedge clk100);
        if (emg !== 1'b1) begin $display("FAIL ctrl: 消抖未完成就退出应急"); errors = errors + 1; end
        repeat (600) @(posedge clk100);
        if (emg !== 1'b0) begin $display("FAIL ctrl: 稳定后应退出应急"); errors = errors + 1; end
        // 抖动：每 300 拍翻一次，不该翻转
        for (i = 0; i < 6; i = i + 1) begin
            sw = ~sw;
            repeat (300) @(posedge clk100);
        end
        if (emg !== 1'b0) begin $display("FAIL ctrl: 抖动导致误翻转"); errors = errors + 1; end
        sw = 1'b1;
        repeat (1100) @(posedge clk100);
        if (emg !== 1'b1) begin $display("FAIL ctrl: 稳定拨到应急后应进入应急"); errors = errors + 1; end
        $display("ctrl test done");
    end

    // ---------------- emergency_screen ----------------
    reg clk25 = 1'b0;
    always #20 clk25 = ~clk25;
    reg rst_n = 1'b0;

    localparam H_ACT = 640, H_FP = 16, H_SYNC = 96, H_BP = 48, H_TOT = 800;
    localparam V_ACT = 480, V_FP = 10, V_SYNC = 2,  V_BP = 33, V_TOT = 525;

    reg [9:0] hc = 0, vc = 0;
    always @(posedge clk25) begin
        if (hc == H_TOT - 1) begin
            hc <= 0;
            vc <= (vc == V_TOT - 1) ? 0 : vc + 1;
        end else
            hc <= hc + 1;
    end
    wire de = (hc < H_ACT) && (vc < V_ACT);
    wire vs = (vc >= V_ACT + V_FP) && (vc < V_ACT + V_FP + V_SYNC);

    // 顶层 osd_pixel_x/y 计数器原样复刻
    reg [11:0] osd_pixel_x, osd_pixel_y;
    reg de_d, vs_d;
    wire frame_start = vs & ~vs_d;
    always @(posedge clk25 or negedge rst_n) begin
        if (!rst_n) begin
            osd_pixel_x <= 0; osd_pixel_y <= 0; de_d <= 0; vs_d <= 0;
        end else begin
            de_d <= de;
            vs_d <= vs;
            if (de) osd_pixel_x <= osd_pixel_x + 1;
            else begin
                osd_pixel_x <= 0;
                if (de_d) osd_pixel_y <= osd_pixel_y + 1;
            end
            if (vs & ~vs_d) osd_pixel_y <= 0;
        end
    end

    reg enable = 1'b0;
    // 输入图像：坐标做的渐变，用来认出"没被替换"的像素
    wire [23:0] rgb_in = {osd_pixel_x[7:0], osd_pixel_y[7:0], 8'h55};
    wire [23:0] rgb_out;
    wire active;

    emergency_screen #(
        .INIT_FILE    ("../emergency_screen.hex"),
        .BLINK_FRAMES (4)            // 仿真缩短：第 3 帧红色亮、第 4 帧灭
    ) dut (
        .clk(clk25), .rst_n(rst_n), .enable(enable), .de(de),
        .frame_start(frame_start), .pixel_x(osd_pixel_x), .pixel_y(osd_pixel_y),
        .rgb_in(rgb_in), .rgb_out(rgb_out), .screen_active(active)
    );

    integer frame_no = 0;
    integer fd = 0;
    always @(posedge clk25) if (frame_start) frame_no <= frame_no + 1;

    // 像素坐标 = 顶层计数器（与 rgb_out 同拍对齐）
    always @(posedge clk25) begin
        if (de && (frame_no == 3 || frame_no == 4) && fd != 0)
            $fwrite(fd, "%0d %0d %06h\n", osd_pixel_x, osd_pixel_y, rgb_out);
        if (de && rgb_out !== rgb_in && !active) begin
            $display("FAIL screen: 未使能时像素被改动 (%0d,%0d)", osd_pixel_x, osd_pixel_y);
            errors = errors + 1;
        end
        if (de && (^rgb_out === 1'bx)) begin
            $display("FAIL screen: 输出含 X (%0d,%0d)", osd_pixel_x, osd_pixel_y);
            errors = errors + 1;
        end
    end

    initial begin
        #200 rst_n = 1'b1;
        // 第 1 帧中间拉高 enable：本帧必须仍是直通
        wait (frame_no == 1);
        wait (osd_pixel_y == 200 && de);
        enable = 1'b1;
        @(posedge clk25);
        if (active) begin $display("FAIL screen: 帧中间就生效了"); errors = errors + 1; end
        wait (frame_no == 2);
        @(posedge clk25); @(posedge clk25);
        if (!active) begin $display("FAIL screen: 下一帧应生效"); errors = errors + 1; end
        wait (frame_no == 3);
        fd = $fopen("frame3.txt", "w");
        wait (frame_no == 4);
        $fclose(fd);
        fd = $fopen("frame4.txt", "w");
        wait (frame_no == 5);
        $fclose(fd);
        fd = 0;
        if (errors == 0) $display("TB PASS (frame3.txt/frame4.txt 交给 check_frames.py 比对)");
        else             $display("TB FAIL errors=%0d", errors);
        $finish;
    end
endmodule
