# -*- coding: utf-8 -*-
"""
比对 tb_emergency_screen 写出的 frame3.txt / frame4.txt 与参考模型，
并各存一张 PNG 供肉眼看。参考模型 = ROM 2x 放大 + 调色板 + 闪烁 + 箭头，
箭头判定直接复用 make_emergency_screen.py 的 arrow_hit（与 RTL 同式）。
"""
import os
import sys

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
import make_emergency_screen as m  # noqa: E402

ARROW_SPEED = 2
BLINK_FRAMES = 4      # 与 tb 里的参数一致


def load_rom():
    data = [int(l, 16) for l in open(os.path.join(HERE, "..", "emergency_screen.hex")) if l.strip()]
    assert len(data) == 19200
    return data


def expected(rom, x, y, starts):
    phase = (ARROW_SPEED * starts) & 63
    blink_on = (starts // BLINK_FRAMES) % 2 == 0
    if m.arrow_hit(x, y, phase):
        return (0xFF, 0xFF, 0xFF)
    sx, sy = x // 2, y // 2
    idx = (rom[sy * 80 + sx // 4] >> (2 * (sx & 3))) & 3
    if idx == 2 and not blink_on:
        idx = 1
    return m.PALETTE[idx]


def check(name, starts, rom):
    path = os.path.join(HERE, name)
    img = Image.new("RGB", (640, 480), (255, 0, 255))
    px = img.load()
    seen, bad = 0, 0
    for line in open(path):
        xs, ys, hs = line.split()
        x, y, v = int(xs), int(ys), int(hs, 16)
        rgb = ((v >> 16) & 255, (v >> 8) & 255, v & 255)
        px[x, y] = rgb
        seen += 1
        exp = expected(rom, x, y, starts)
        if rgb != exp:
            if bad < 10:
                print("  MISMATCH %s (%d,%d) got %06X exp %02X%02X%02X" % ((name, x, y, v) + exp))
            bad += 1
    img.save(os.path.join(HERE, name.replace(".txt", ".png")))
    ok = seen == 640 * 480 and bad == 0
    print("%s: pixels=%d mismatches=%d -> %s" % (name, seen, bad, "PASS" if ok else "FAIL"))
    return ok


if __name__ == "__main__":
    rom = load_rom()
    ok = check("frame3.txt", 3, rom) & check("frame4.txt", 4, rom)
    print("CHECK PASS" if ok else "CHECK FAIL")
    sys.exit(0 if ok else 1)
