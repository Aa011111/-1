# AM2302 单总线读取自检：vsim -c -do run_am2302.do
if {[file exists work_dht]} { vdel -lib work_dht -all }
vlib work_dht
vlog -quiet -work work_dht ../am2302_reader.v
vlog -quiet -work work_dht tb_am2302.v
vsim -quiet -c -lib work_dht tb_am2302
run -all
quit -f
