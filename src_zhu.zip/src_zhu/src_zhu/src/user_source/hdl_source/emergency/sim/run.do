# 在 emergency/sim 目录下：
#   vsim -c -do run.do
#   python check_frames.py
vlib work
vlog ../emergency_mode_ctrl.v ../emergency_screen_rom.v ../emergency_screen.v tb_emergency_screen.v
vsim -c work.tb_emergency_screen
run -all
quit -f
