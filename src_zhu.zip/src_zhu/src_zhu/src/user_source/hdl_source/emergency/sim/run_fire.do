# 火灾图覆盖自检：vsim -c -do run_fire.do
if {[file exists work_fire]} { vdel -lib work_fire -all }
vlib work_fire
set H ../..
vlog -quiet -work work_fire $H/emergency/fire_alarm_ctrl.v
vlog -quiet -work work_fire $H/common/sync_2ff.v $H/common/cdc_bus_commit.v
vlog -quiet -work work_fire $H/framebuf4bank/media_video_pipeline.v
vlog -quiet -work work_fire $H/framebuf4bank/media_player_control.v
vlog -quiet -work work_fire $H/framebuf4bank/media_frame_reader.v
vlog -quiet -work work_fire $H/framebuf4bank/fifo_prefetch_2.v
vlog -quiet -work work_fire $H/framebuf4bank/video_fade_transition.v
vlog -quiet -work work_fire $H/framebuf4bank/video_timing_ctrl.v
vlog -quiet -work work_fire $H/framebuf4bank/rgb_video_adapter.v
vlog -quiet -work work_fire $H/IP/afifo_32_16_256.v
vlog -quiet -work work_fire $H/display/thumbnail_layout.v
vlog -quiet -work work_fire $H/control/thumbnail_controller.v
vlog -quiet -work work_fire $H/adjust/brightness_contrast_adjust.v
vlog -quiet -work work_fire tb_fire_alarm.v
vsim -quiet -c -lib work_fire tb_fire_alarm
run -all
quit -f
