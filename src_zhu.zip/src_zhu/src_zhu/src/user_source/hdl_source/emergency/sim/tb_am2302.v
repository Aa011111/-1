`timescale 1ns/1ps
// am2302_reader 自检：vsim -c -do run_am2302.do
// 传感器模型按手册表 6 的典型时序应答（起始信号 >= 800us 才响应），
// 覆盖：正常读数、校验错、无应答、负温度、40℃ 置位 / 回差解除、失联后报警保持。
module tb_am2302;
    reg clk = 0;
    always #50 clk = ~clk;              // 10MHz
    reg rst_n = 0;

    tri1 sda;                           // 上拉
    reg  sensor_low = 0;
    assign sda = sensor_low ? 1'b0 : 1'bz;

    wire [15:0] humi, temp;
    wire valid, ok_pulse, alarm;

    am2302_reader #(
        .CLK_FREQ_HZ(10_000_000), .POWERUP_MS(1), .PERIOD_MS(3),
        .ALARM_TEMP_X10(400), .HYST_X10(20), .FAIL_LIMIT(3)
    ) dut (
        .clk(clk), .rst_n(rst_n), .sda(sda),
        .humi_x10(humi), .temp_x10(temp), .data_valid(valid),
        .read_ok_pulse(ok_pulse), .temp_alarm(alarm)
    );

    // ---------------- 传感器模型 ----------------
    reg [15:0] m_humi = 16'd658, m_temp = 16'd269;
    reg        m_bad_sum = 0, m_mute = 0;
    integer    k;
    realtime   t_fall;
    reg [39:0] frame;

    task send_bit(input b);
        begin
            sensor_low = 1; #(50_000);
            sensor_low = 0; #(b ? 70_000 : 26_000);
        end
    endtask

    always begin
        @(negedge sda);
        t_fall = $realtime;
        @(posedge sda);
        if (!m_mute && ($realtime - t_fall) >= 800_000) begin
            frame[39:24] = m_humi;
            frame[23:8]  = m_temp;
            frame[7:0]   = m_humi[15:8] + m_humi[7:0] + m_temp[15:8] + m_temp[7:0]
                           + (m_bad_sum ? 8'd1 : 8'd0);
            #(30_000);                               // Tgo
            sensor_low = 1; #(80_000);               // Trel
            sensor_low = 0; #(80_000);               // Treh
            for (k = 39; k >= 0; k = k - 1) send_bit(frame[k]);
            sensor_low = 1; #(50_000);               // Ten
            sensor_low = 0;
        end
    end

    // ---------------- 检查 ----------------
    integer errors = 0;
    task expect(input [15:0] h, input [15:0] t, input v, input a, input [8*24-1:0] tag);
        begin
            if (humi !== h || temp !== t || valid !== v || alarm !== a) begin
                errors = errors + 1;
                $display("FAIL %0s: humi=%0d temp=%h valid=%b alarm=%b (want %0d %h %b %b)",
                         tag, humi, temp, valid, alarm, h, t, v, a);
            end else
                $display("ok   %0s: humi=%0d temp=%h valid=%b alarm=%b", tag, humi, temp, valid, alarm);
        end
    endtask

    task wait_ok;
        begin @(posedge ok_pulse); @(posedge clk); end
    endtask
    task wait_reads(input integer n);   // 无应答时按周期数等
        begin repeat (n) #(3_000_000 + 2_000_000); end
    endtask

    initial begin
        #(1000); rst_n = 1;

        wait_ok;  expect(16'd658, 16'h010D, 1, 0, "26.9C normal");

        m_temp = 16'd400;
        wait_ok;  expect(16'd658, 16'd400, 1, 1, "40.0C -> alarm");

        m_temp = 16'd385;
        wait_ok;  expect(16'd658, 16'd385, 1, 1, "38.5C hold (hyst)");

        m_temp = 16'd379;
        wait_ok;  expect(16'd658, 16'd379, 1, 0, "37.9C -> clear");

        m_temp = 16'h8065;               // -10.1℃
        wait_ok;  expect(16'd658, 16'h8065, 1, 0, "-10.1C");

        // 校验错：数据不更新
        m_temp = 16'd500; m_bad_sum = 1;
        wait_reads(2);
        expect(16'd658, 16'h8065, 1, 0, "bad checksum ignored");
        m_bad_sum = 0;
        wait_ok;  expect(16'd658, 16'd500, 1, 1, "50.0C -> alarm");

        // 失联：3 次失败后 valid=0，报警保持
        m_mute = 1;
        wait_reads(4);
        expect(16'd658, 16'd500, 0, 1, "sensor lost, alarm held");
        m_mute = 0; m_temp = 16'd250;
        wait_ok;  expect(16'd658, 16'd250, 1, 0, "back, 25.0C clear");

        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL (%0d)", errors);
        $finish;
    end

    initial begin #(200_000_000); $display("RESULT: FAIL (timeout)"); $finish; end
endmodule
