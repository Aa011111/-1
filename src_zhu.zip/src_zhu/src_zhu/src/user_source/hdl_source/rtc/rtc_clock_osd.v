`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// rtc_clock_osd：显示 DS3231 实时时间 HH:MM:SS（video_clk 域）
//
// 和 osd/timestamp_osd.v 同一套写法：4x6 数字字模、frame_start 锁存显示值、
// 字模查表预取一拍（next_x = de ? x+1 : 0），输出路径只剩一级 mux。
// 区别只在尺寸和位置：
//   - 字模放大 2^SCALE_SHIFT 倍（默认 8 倍）：一个字模点 = 8x8 像素，字形 32x48；
//     字符间距 1 列，字符格 40 像素宽。8 个字符（含两个冒号）共 8*40-8 = 312 像素宽。
//     SCALE_SHIFT=2 时为 4 倍：字形 16x24，字符格 20，共 156 像素宽。
//   - TEXT_X / TEXT_Y 为文字区左上角；取 -1 表示该方向居中
//     （默认居中，640x480 下文字区 x 164~475 / y 216~263）。
//   - 文字区外扩 PANEL_PAD 像素的暗底（原像素各通道 >>1，半透明），
//     任何底图上都看得清。
//
// 放大倍数是 2 的幂：行号取 dy >> SCALE_SHIFT，格内列号取 within >> SCALE_SHIFT，不用除法。
// 字符格宽 5*SCALE 不是 2 的幂，"第几个字符 / 格内第几列"用一对计数器跟着 next_x
// 走（next_x 到 X0-1 时清零，之后每拍 +1、满一格进位），代替 dx 上的
// 7 组减法比较，省面积。计数器在文字区外的值无意义，由 in_text 屏蔽。
//
// time_valid=0（模块没接 / I2C 不应答 / 读到的不是合法 BCD）时显示 --:--:--，
// 一眼就能区分"没读到"和"读到了 00:00:00"。
// -----------------------------------------------------------------------------

module rtc_clock_osd #(
    parameter integer H_ACTIVE   = 640,
    parameter integer V_ACTIVE   = 480,
    parameter integer PANEL_PAD  = 16,
    parameter integer SCALE_SHIFT = 3,             // 放大倍数 = 2^SCALE_SHIFT，取 1~3
    parameter integer TEXT_X     = -1,             // 文字区左上角，-1 = 水平居中
    parameter integer TEXT_Y     = -1,             // -1 = 垂直居中
    parameter [23:0]  TEXT_COLOR = 24'hFFFFFF
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        enable,
    input  wire        de,
    input  wire        frame_start,
    input  wire [11:0] pixel_x,
    input  wire [11:0] pixel_y,
    input  wire [23:0] time_bcd,       // {时十, 时个, 分十, 分个, 秒十, 秒个}
    input  wire        time_valid,
    input  wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire        clock_active
);
    localparam integer SCALE  = 1 << SCALE_SHIFT;
    localparam integer PITCH  = 5 * SCALE;              // 字符格宽（8 倍时 40）
    localparam integer TEXT_W = 8 * PITCH - SCALE;      // 8 倍时 312，最后一格不留间距
    localparam integer TEXT_H = 6 * SCALE;              // 8 倍时 48
    localparam integer X0     = (TEXT_X < 0) ? (H_ACTIVE - TEXT_W) / 2 : TEXT_X;
    localparam integer Y0     = (TEXT_Y < 0) ? (V_ACTIVE - TEXT_H) / 2 : TEXT_Y;
    localparam integer PX0    = X0 - PANEL_PAD;
    localparam integer PX1    = X0 + TEXT_W + PANEL_PAD;
    localparam integer PY0    = Y0 - PANEL_PAD;
    localparam integer PY1    = Y0 + TEXT_H + PANEL_PAD;

    localparam [3:0] CH_DASH  = 4'hA;
    localparam [3:0] CH_COLON = 4'hB;

    // ---- 帧边界锁存（一帧内恒定，不撕裂）----
    reg [23:0] digits_q;
    reg        valid_q;
    reg        en_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            digits_q <= 24'd0;
            valid_q  <= 1'b0;
            en_q     <= 1'b0;
        end else if (frame_start) begin
            digits_q <= time_bcd;
            valid_q  <= time_valid;
            en_q     <= enable;
        end
    end

    // ---- 4x6 字模：0~9 与 timestamp_osd 逐位相同，另加 - 和大号冒号 ----
    function font_pixel;
        input [3:0] ch;
        input [1:0] col;    // 0..3
        input [2:0] row;    // 0..5
        begin
            case (ch)
                4'd0: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2 && (col==0||col==3)) ||
                                   (row==3 && (col==0||col==3)) ||
                                   (row==4 && (col==0||col==3)) ||
                                   (row==5 && (col==1||col==2));
                4'd1: font_pixel = (col==2) ||
                                   (row==0 && col==1) ||
                                   (row==5 && (col==1||col==3));
                4'd2: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && col==3) ||
                                   (row==2 && (col==1||col==2)) ||
                                   (row==3 && col==1) ||
                                   (row==4 && col==0) ||
                                   (row==5 && (col==1||col==2||col==3));
                4'd3: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && col==3) ||
                                   (row==2 && (col==1||col==2)) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && (col==1||col==2));
                4'd4: font_pixel = (row==0 && (col==0||col==3)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && col==3);
                4'd5: font_pixel = (row==0) ||
                                   (row==1 && col==0) ||
                                   (row==2 && (col==0||col==1||col==2)) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && (col==1||col==2));
                4'd6: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && col==0) ||
                                   (row==2 && (col==0||col==1||col==2)) ||
                                   (row==3 && (col==0||col==3)) ||
                                   (row==4 && (col==0||col==3)) ||
                                   (row==5 && (col==1||col==2));
                4'd7: font_pixel = (row==0) ||
                                   (row==1 && col==3) ||
                                   (row==2 && col==2) ||
                                   (row==3 && col==2) ||
                                   (row==4 && col==2) ||
                                   (row==5 && col==2);
                4'd8: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2 && (col==1||col==2)) ||
                                   (row==3 && (col==0||col==3)) ||
                                   (row==4 && (col==0||col==3)) ||
                                   (row==5 && (col==1||col==2));
                4'd9: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2 && (col==1||col==2||col==3)) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && (col==1||col==2));
                // timestamp_osd 的冒号是 2x4 的竖条，放大 8 倍成了一根 16x32 的柱子，
                // 这里改成上下两个 16x8 的点
                CH_COLON: font_pixel = (col==1||col==2) && (row==1||row==4);
                CH_DASH:  font_pixel = (row==2);
                default:  font_pixel = 1'b0;
            endcase
        end
    endfunction

    // 第 slot 个字符位显示什么
    function [3:0] slot_char;
        input [2:0]  slot;
        input [23:0] d;
        input        valid;
        begin
            case (slot)
                3'd0: slot_char = valid ? d[23:20] : CH_DASH;
                3'd1: slot_char = valid ? d[19:16] : CH_DASH;
                3'd2: slot_char = CH_COLON;
                3'd3: slot_char = valid ? d[15:12] : CH_DASH;
                3'd4: slot_char = valid ? d[11:8]  : CH_DASH;
                3'd5: slot_char = CH_COLON;
                3'd6: slot_char = valid ? d[7:4]   : CH_DASH;
                default: slot_char = valid ? d[3:0] : CH_DASH;
            endcase
        end
    endfunction

    // ---- 下一个像素的渲染（预取一拍）----
    wire [11:0] next_x = de ? (pixel_x + 12'd1) : 12'd0;
    wire [11:0] dy     = pixel_y - Y0;

    wire in_text  = (next_x  >= X0)  && (next_x  < X0 + TEXT_W) &&
                    (pixel_y >= Y0)  && (pixel_y < Y0 + TEXT_H);
    wire in_panel = (next_x  >= PX0) && (next_x  < PX1) &&
                    (pixel_y >= PY0) && (pixel_y < PY1);

    // slot = (next_x - X0) / PITCH，within = (next_x - X0) % PITCH。
    // 本拍的值对应本拍的 next_x；行内 de 连续，下一拍 next_x 恰好 +1。
    reg [2:0] slot;
    reg [5:0] within;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            slot   <= 3'd0;
            within <= 6'd0;
        end else if (next_x == X0 - 1) begin
            slot   <= 3'd0;
            within <= 6'd0;
        end else if (within == PITCH - 1) begin
            slot   <= slot + 3'd1;
            within <= 6'd0;
        end else begin
            within <= within + 6'd1;
        end
    end

    wire [5:0]  gcol_w = within >> SCALE_SHIFT;
    wire [11:0] grow_w = dy     >> SCALE_SHIFT;
    wire [2:0]  gcol   = gcol_w[2:0];   // 0~3 字形，4 = 字间距
    wire [2:0]  grow   = grow_w[2:0];   // 0~5（文字区外由 in_text 屏蔽）

    wire next_hit = en_q && in_text && (gcol < 3'd4) &&
                    font_pixel(slot_char(slot, digits_q, valid_q), gcol[1:0], grow);
    wire next_panel = en_q && in_panel;

    reg hit_q, panel_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            hit_q   <= 1'b0;
            panel_q <= 1'b0;
        end else begin
            hit_q   <= next_hit;
            panel_q <= next_panel;
        end
    end

    wire [23:0] rgb_dim = {1'b0, rgb_in[23:17], 1'b0, rgb_in[15:9], 1'b0, rgb_in[7:1]};

    assign clock_active = de && panel_q;
    assign rgb_out = !de     ? rgb_in     :
                     hit_q   ? TEXT_COLOR :
                     panel_q ? rgb_dim    : rgb_in;
endmodule
