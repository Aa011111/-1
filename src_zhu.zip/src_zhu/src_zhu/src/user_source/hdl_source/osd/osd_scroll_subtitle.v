`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第九讲 OSD字幕叠加
// osd_scroll_subtitle：讲义 2.5「动态文字与平滑滚动」+ promax_text_overlay.v
//   的滚动字幕部分，按本工程的时序约定重写。
//
// 功能：屏幕底部一条半透明字幕带，12 个字符的文本从右往左匀速滚动，
//       ASCII（5x7 字模纵横各放大 2 倍）和 16x16 汉字混排。
//
// 相对讲义 promax_text_overlay.v 的三处改动，都是为了能真的综合进这块片子：
//
//  改动1（去掉真除法）：讲义原件用 CELL_W=12 / SUBTITLE_CELL_W=18，渲染时
//    写的是 `param_local_x / CELL_W`、`subtitle_stream_x / SUBTITLE_CELL_W`。
//    除数不是 2 的幂，综合器只能摊一个组合除法器出来——25MHz 像素时钟下
//    面积和路径延迟都亏。这里把字符格宽高统一成 16，除法退化成 >>4、
//    取模退化成取低 4 位，一个除法器都不综合。
//    附带好处：16x16 的汉字字模刚好 1:1 填满一格，不用再算居中偏移。
//
//  改动2（字模查表提前一拍）：本工程顶层的 OSD 是纯组合叠加（rgb 旁路，
//    hs/vs/de 不延迟），status_osd_overlay 那条 4 字符状态条字库小，组合
//    深度扛得住。但字幕这条字库大得多（50+ ASCII 分支 + 9 个 256 位汉字
//    点阵），再和状态条、时间戳串起来就未必够 40ns。这里把"算下一个像素
//    命中哪一位字模"整段放到寄存器前，输出路径只剩一级 mux + 底条混合。
//    预取坐标 next_x = de ? pixel_x+1 : 0，必须和顶层 osd_pixel_x 的递增
//    规则完全一致，改顶层那个计数器时这里要跟着改。
//    next_y 直接用 pixel_y：y 只在行消隐期（de 下降沿）变一次，行内恒定，
//    预取一拍不会跨行。
//
//  改动3（底条走 Alpha 混合）：讲义原件底条是不透明纯色 24'he8eef2，直接
//    盖掉图片。这里换成 osd_alpha_blend 压暗，图片能透出来——这才是讲义
//    2.4 说的"多图层混合"，也是扩展要求第1点真正要的效果。
//
// 【字模坐标约定】5x7 字模每行 5 位，bit[4] 是最左像素；16x16 汉字每行
// 16 位，bit[15] 是最左像素。两套字模的位序方向一致，别搞反。
// -----------------------------------------------------------------------------

module osd_scroll_subtitle #(
    parameter integer H_ACTIVE   = 640,      // 有效行宽
    parameter integer BAND_Y     = 440,      // 字幕带顶部行号
    parameter integer BAND_H     = 24,       // 字幕带高度（含上下留白）
    parameter integer BAND_MARGIN= 8,        // 字幕带左右留白
    parameter integer CELL_W     = 16,       // 字符格宽，必须是 16（见改动1）
    parameter integer CELL_H     = 16,       // 字符格高，必须是 16
    parameter integer MAX_CHARS  = 12,       // 文本最大字符数（96 位 / 8）
    parameter integer SCROLL_GAP = 128,      // 两轮滚动之间的空白像素
    parameter integer SCROLL_DIV = 0,        // 每 (SCROLL_DIV+1) 帧移 1 像素
    parameter integer ENABLE_CJK = 1,        // 0 时汉字点阵不综合，省 LUT
    parameter integer USE_MULT   = 0,        // 传给 osd_alpha_blend
    parameter [7:0]   BAND_ALPHA = 8'd128,   // 底条不透明度（128 = 半透明）
    parameter [23:0]  BAND_COLOR = 24'h101018,   // 底条压暗用的深色
    parameter [23:0]  TEXT_COLOR = 24'hf8f8f0    // 字幕文字颜色
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        de,               // 当前像素有效
    input  wire        frame_start,      // 帧开始脉冲（vs 上升沿，顶层给）
    input  wire [11:0] pixel_x,          // 当前像素列号（与 rgb_in 同拍）
    input  wire [11:0] pixel_y,          // 当前像素行号
    input  wire [23:0] rgb_in,
    input  wire        enable,           // 字幕总开关（已在帧边界锁存）
    input  wire [95:0] text,             // 12 字符，text[i*8 +: 8] 是第 i 个
    input  wire [5:0]  length,           // 有效字符数 0~12
    output wire [23:0] rgb_out,
    output wire        subtitle_active   // 本像素被字幕层占用（含底条）
);
    localparam integer SCROLL_CYCLE = H_ACTIVE + SCROLL_GAP;
    localparam integer TEXT_Y       = BAND_Y + (BAND_H - CELL_H) / 2;

    // ---- 滚动位置：每 (SCROLL_DIV+1) 帧左移一个像素 ----
    reg [11:0] scroll_pos;
    reg [3:0]  scroll_div_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            scroll_pos     <= 12'd0;
            scroll_div_cnt <= 4'd0;
        end else if (frame_start) begin
            if (scroll_div_cnt >= SCROLL_DIV) begin
                scroll_div_cnt <= 4'd0;
                scroll_pos <= (scroll_pos >= SCROLL_CYCLE - 1) ?
                              12'd0 : scroll_pos + 12'd1;
            end else begin
                scroll_div_cnt <= scroll_div_cnt + 4'd1;
            end
        end
    end

    // ---- 5x7 ASCII 字模 ----
    // 取自讲义 promax_text_overlay.v 的 glyph_row，字符集原样保留。
    function [4:0] ascii_row;
        input [7:0] character;
        input [2:0] row;
        begin
            ascii_row = 5'b00000;
            case (character)
                "0": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10011;3:ascii_row=5'b10101;4:ascii_row=5'b11001;5:ascii_row=5'b10001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "1": case(row) 0:ascii_row=5'b00100;1:ascii_row=5'b01100;2:ascii_row=5'b00100;3:ascii_row=5'b00100;4:ascii_row=5'b00100;5:ascii_row=5'b00100;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "2": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b00001;3:ascii_row=5'b00010;4:ascii_row=5'b00100;5:ascii_row=5'b01000;6:ascii_row=5'b11111;default:ascii_row=0;endcase
                "3": case(row) 0:ascii_row=5'b11110;1:ascii_row=5'b00001;2:ascii_row=5'b00001;3:ascii_row=5'b01110;4:ascii_row=5'b00001;5:ascii_row=5'b00001;6:ascii_row=5'b11110;default:ascii_row=0;endcase
                "4": case(row) 0:ascii_row=5'b00010;1:ascii_row=5'b00110;2:ascii_row=5'b01010;3:ascii_row=5'b10010;4:ascii_row=5'b11111;5:ascii_row=5'b00010;6:ascii_row=5'b00010;default:ascii_row=0;endcase
                "5": case(row) 0:ascii_row=5'b11111;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b11110;4:ascii_row=5'b00001;5:ascii_row=5'b00001;6:ascii_row=5'b11110;default:ascii_row=0;endcase
                "6": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b11110;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "7": case(row) 0:ascii_row=5'b11111;1:ascii_row=5'b00001;2:ascii_row=5'b00010;3:ascii_row=5'b00100;4:ascii_row=5'b01000;5:ascii_row=5'b01000;6:ascii_row=5'b01000;default:ascii_row=0;endcase
                "8": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b01110;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "9": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b01111;4:ascii_row=5'b00001;5:ascii_row=5'b00001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "A": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b11111;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "B": case(row) 0:ascii_row=5'b11110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b11110;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b11110;default:ascii_row=0;endcase
                "C": case(row) 0:ascii_row=5'b01111;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b10000;4:ascii_row=5'b10000;5:ascii_row=5'b10000;6:ascii_row=5'b01111;default:ascii_row=0;endcase
                "D": case(row) 0:ascii_row=5'b11110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b10001;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b11110;default:ascii_row=0;endcase
                "E": case(row) 0:ascii_row=5'b11111;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b11110;4:ascii_row=5'b10000;5:ascii_row=5'b10000;6:ascii_row=5'b11111;default:ascii_row=0;endcase
                "F": case(row) 0:ascii_row=5'b11111;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b11110;4:ascii_row=5'b10000;5:ascii_row=5'b10000;6:ascii_row=5'b10000;default:ascii_row=0;endcase
                "G": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10000;3:ascii_row=5'b10111;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "H": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b11111;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "I": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b00100;2:ascii_row=5'b00100;3:ascii_row=5'b00100;4:ascii_row=5'b00100;5:ascii_row=5'b00100;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "J": case(row) 0:ascii_row=5'b00111;1:ascii_row=5'b00010;2:ascii_row=5'b00010;3:ascii_row=5'b00010;4:ascii_row=5'b10010;5:ascii_row=5'b10010;6:ascii_row=5'b01100;default:ascii_row=0;endcase
                "K": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10010;2:ascii_row=5'b10100;3:ascii_row=5'b11000;4:ascii_row=5'b10100;5:ascii_row=5'b10010;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "L": case(row) 0:ascii_row=5'b10000;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b10000;4:ascii_row=5'b10000;5:ascii_row=5'b10000;6:ascii_row=5'b11111;default:ascii_row=0;endcase
                "M": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b11011;2:ascii_row=5'b10101;3:ascii_row=5'b10101;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "N": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b11001;2:ascii_row=5'b10101;3:ascii_row=5'b10011;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "O": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b10001;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "P": case(row) 0:ascii_row=5'b11110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b11110;4:ascii_row=5'b10000;5:ascii_row=5'b10000;6:ascii_row=5'b10000;default:ascii_row=0;endcase
                "Q": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b10001;4:ascii_row=5'b10101;5:ascii_row=5'b10010;6:ascii_row=5'b01101;default:ascii_row=0;endcase
                "R": case(row) 0:ascii_row=5'b11110;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b11110;4:ascii_row=5'b10100;5:ascii_row=5'b10010;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "S": case(row) 0:ascii_row=5'b01111;1:ascii_row=5'b10000;2:ascii_row=5'b10000;3:ascii_row=5'b01110;4:ascii_row=5'b00001;5:ascii_row=5'b00001;6:ascii_row=5'b11110;default:ascii_row=0;endcase
                "T": case(row) 0:ascii_row=5'b11111;1:ascii_row=5'b00100;2:ascii_row=5'b00100;3:ascii_row=5'b00100;4:ascii_row=5'b00100;5:ascii_row=5'b00100;6:ascii_row=5'b00100;default:ascii_row=0;endcase
                "U": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b10001;4:ascii_row=5'b10001;5:ascii_row=5'b10001;6:ascii_row=5'b01110;default:ascii_row=0;endcase
                "V": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b10001;4:ascii_row=5'b10001;5:ascii_row=5'b01010;6:ascii_row=5'b00100;default:ascii_row=0;endcase
                "W": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10001;2:ascii_row=5'b10001;3:ascii_row=5'b10101;4:ascii_row=5'b10101;5:ascii_row=5'b10101;6:ascii_row=5'b01010;default:ascii_row=0;endcase
                "X": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10001;2:ascii_row=5'b01010;3:ascii_row=5'b00100;4:ascii_row=5'b01010;5:ascii_row=5'b10001;6:ascii_row=5'b10001;default:ascii_row=0;endcase
                "Y": case(row) 0:ascii_row=5'b10001;1:ascii_row=5'b10001;2:ascii_row=5'b01010;3:ascii_row=5'b00100;4:ascii_row=5'b00100;5:ascii_row=5'b00100;6:ascii_row=5'b00100;default:ascii_row=0;endcase
                "Z": case(row) 0:ascii_row=5'b11111;1:ascii_row=5'b00001;2:ascii_row=5'b00010;3:ascii_row=5'b00100;4:ascii_row=5'b01000;5:ascii_row=5'b10000;6:ascii_row=5'b11111;default:ascii_row=0;endcase
                ":": case(row) 1:ascii_row=5'b00100;2:ascii_row=5'b00100;4:ascii_row=5'b00100;5:ascii_row=5'b00100;default:ascii_row=0;endcase
                ".": case(row) 5:ascii_row=5'b00100;6:ascii_row=5'b00100;default:ascii_row=0;endcase
                ",": case(row) 5:ascii_row=5'b00100;6:ascii_row=5'b01000;default:ascii_row=0;endcase
                "!": case(row) 0:ascii_row=5'b00100;1:ascii_row=5'b00100;2:ascii_row=5'b00100;3:ascii_row=5'b00100;5:ascii_row=5'b00100;default:ascii_row=0;endcase
                "?": case(row) 0:ascii_row=5'b01110;1:ascii_row=5'b10001;2:ascii_row=5'b00010;3:ascii_row=5'b00100;5:ascii_row=5'b00100;default:ascii_row=0;endcase
                "-": case(row) 3:ascii_row=5'b11111;default:ascii_row=0;endcase
                "_": case(row) 6:ascii_row=5'b11111;default:ascii_row=0;endcase
                "/": case(row) 0:ascii_row=5'b00001;1:ascii_row=5'b00010;2:ascii_row=5'b00010;3:ascii_row=5'b00100;4:ascii_row=5'b01000;5:ascii_row=5'b01000;6:ascii_row=5'b10000;default:ascii_row=0;endcase
                default: ascii_row = 5'b00000;
            endcase
        end
    endfunction

    // ---- 16x16 汉字点阵 ----
    // 宋体 16x16 点阵，9 个字依次是：欢 迎 来 到 星 澜 科 技 馆
    // （原来讲义的"米醋电子工作室忧郁"已整体替换，旧点阵见 .bak_before_welcome）。
    // 文本里用 8'h80 + glyph_id 引用，即 0x80=欢 … 0x88=馆。
    // 换成别的字：找一个 16x16 点阵取模工具，横向取模、高位在左，把 256 位
    // 二进制串替换掉即可，不用改渲染逻辑。
    localparam [255:0] CN_GLYPH_0 = 256'b0000000010000000000000001000000011111100100000000000010011111100000001010000010001001001000010000010101001000000000101000100000000010000010000000010100010100000001001001010000001000101000100001000000100010000000000100000100000000100000001000000100000000010;
    localparam [255:0] CN_GLYPH_1 = 256'b0000000000000000001000001000000000010011001111000001001000100100000000100010010000000010001001001111001000100100000100100010010000010010001001000001001010110100000100110010100000010010001000000001000000100000001010000010000001000111111111100000000000000000;
    localparam [255:0] CN_GLYPH_2 = 256'b0000000100000000000000010000000000000001000000000111111111111100000000010000000000010001000100000000100100010000000010010010000011111111111111100000001110000000000001010100000000001001001000000011000100011000110000010000011000000001000000000000000100000000;
    localparam [255:0] CN_GLYPH_3 = 256'b0000000000000100111111111000010000001000000001000001000000100100001000100010010001000001001001001111111110100100000010001010010000001000001001000000100000100100011111110010010000001000001001000000100000000100000011111000010011111000000101000100000000001000;
    localparam [255:0] CN_GLYPH_4 = 256'b0000000000000000000111111111000000010000000100000001111111110000000100000001000000011111111100000000000100000000000100010000000000011111111110000010000100000000010000010000000000011111111100000000000100000000000000010000000001111111111111000000000000000000;
    localparam [255:0] CN_GLYPH_5 = 256'b0000001000000000001000010111110000010101000001000001010001000100100001011111010001000100010001000100010111110100000101010101010000010101011101000010010111010100111001010101010000100101111101000010010011100100001001010101010000100100010001000000010001001100;
    localparam [255:0] CN_GLYPH_6 = 256'b0000100000010000000111010001000011110000100100000001000010010000000100000001000011111101000100000001000010010000001110001001000000110100000100000101000000011110010100111111000010010000000100000001000000010000000100000001000000010000000100000001000000010000;
    localparam [255:0] CN_GLYPH_7 = 256'b0001000000100000000100000010000000010000001000000001001111111110111111000010000000010000001000000001000000100000000101011111110000011000100001000011000010001000110100000100100000010000010100000001000000100000000100000101000001010001100010000010011000000110;
    localparam [255:0] CN_GLYPH_8 = 256'b0010000001000000001000000010000000100011111111100011101000000010010011000000010001010001111110001000000100001000001000010000100000100001111110000010000100000000001000010000000000100001111111000010100100000100001100010000010000100001111111000000000100000100;

    function [15:0] cjk_row;
        input [3:0] glyph_id;
        input [3:0] row;
        reg [255:0] glyph_bits;
        begin
            case (glyph_id)
                4'd0: glyph_bits = CN_GLYPH_0;
                4'd1: glyph_bits = CN_GLYPH_1;
                4'd2: glyph_bits = CN_GLYPH_2;
                4'd3: glyph_bits = CN_GLYPH_3;
                4'd4: glyph_bits = CN_GLYPH_4;
                4'd5: glyph_bits = CN_GLYPH_5;
                4'd6: glyph_bits = CN_GLYPH_6;
                4'd7: glyph_bits = CN_GLYPH_7;
                4'd8: glyph_bits = CN_GLYPH_8;
                default: glyph_bits = 256'b0;
            endcase
            cjk_row = glyph_bits[255 - row*16 -: 16];
        end
    endfunction

    // ---- 取文本第 idx 个字符（12 选 1 的 mux）----
    function [7:0] text_char;
        input [95:0] text_value;
        input [3:0]  idx;
        begin
            if (idx < MAX_CHARS)
                text_char = text_value[idx*8 +: 8];
            else
                text_char = 8'h20;   // 越界填空格
        end
    endfunction

    // ---- 下一个像素的渲染（结果寄一拍，见改动2）----
    // next_x 必须复刻顶层 osd_pixel_x 的递增规则：de 期间 +1，否则归 0
    wire [11:0] next_x = de ? (pixel_x + 12'd1) : 12'd0;

    // 文本总宽 = 字符数 * CELL_W。CELL_W 固定 16，综合器把这个乘法折成移位。
    wire [11:0] text_width = length * CELL_W;

    // 滚动坐标：stream_x = next_x + scroll_pos，对 SCROLL_CYCLE 取模。
    // next_x < H_ACTIVE 且 scroll_pos < SCROLL_CYCLE，和一定小于 2 倍周期，
    // 所以一次条件减法就够，不需要真取模。
    wire [12:0] stream_sum = {1'b0, next_x} + {1'b0, scroll_pos};
    wire [12:0] stream_x   = (stream_sum >= SCROLL_CYCLE) ?
                             (stream_sum - SCROLL_CYCLE) : stream_sum;

    // cell_idx 只取 4 位就够：真正会渲染的区间是 stream_x < text_width，而
    // text_width 最大 12*16=192，>>4 之后最大 11。stream_x 超过 255 时这里会
    // 回绕，但那时 in_text_run 里的 stream_x < text_width 已经为假，不渲染。
    wire [3:0]  cell_idx = stream_x[7:4];        // 第几个字符（stream_x>>4）
    wire [3:0]  cell_col = stream_x[3:0];        // 字符格内列号 0~15
    wire [3:0]  cell_row = (pixel_y - TEXT_Y);   // 字符格内行号 0~15

    wire [7:0]  cur_char = text_char(text, cell_idx);
    wire        cur_is_cjk = (ENABLE_CJK != 0) && cur_char[7];

    // ASCII 放大 2 倍后占 10x14，在 16x16 格内水平留 3、垂直留 1
    wire        ascii_col_valid = (cell_col >= 4'd3) && (cell_col <= 4'd12);
    wire        ascii_row_valid = (cell_row >= 4'd1) && (cell_row <= 4'd14);
    wire [2:0]  ascii_gcol = (cell_col - 4'd3) >> 1;     // 0~4
    wire [2:0]  ascii_grow = (cell_row - 4'd1) >> 1;     // 0~6
    wire [4:0]  ascii_bits = ascii_row(cur_char, ascii_grow);
    wire [15:0] cjk_bits   = cjk_row(cur_char[3:0], cell_row);

    // 命中范围：文本带内、字符在有效长度内
    wire in_band_x   = (next_x >= BAND_MARGIN) &&
                       (next_x <  H_ACTIVE - BAND_MARGIN);
    wire in_band_y   = (pixel_y >= BAND_Y) && (pixel_y < BAND_Y + BAND_H);
    wire in_text_y   = (pixel_y >= TEXT_Y) && (pixel_y < TEXT_Y + CELL_H);
    wire in_text_run = (stream_x < {1'b0, text_width}) && (cell_idx < length[3:0]);

    wire next_band_hit = enable && in_band_x && in_band_y;
    wire next_text_hit = enable && in_band_x && in_text_y && in_text_run &&
                         (cur_is_cjk ? cjk_bits[15 - cell_col]
                                     : (ascii_col_valid && ascii_row_valid &&
                                        ascii_bits[4 - ascii_gcol]));

    reg band_hit_q;
    reg text_hit_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            band_hit_q <= 1'b0;
            text_hit_q <= 1'b0;
        end else begin
            band_hit_q <= next_band_hit;
            text_hit_q <= next_text_hit;
        end
    end

    // ---- 输出：文字 > 半透明底条 > 原像素 ----
    wire [23:0] band_rgb;
    osd_alpha_blend #(.USE_MULT(USE_MULT)) u_band_blend (
        .fg      (BAND_COLOR),
        .bg      (rgb_in),
        .alpha   (BAND_ALPHA),
        .blended (band_rgb)
    );

    assign subtitle_active = de && (text_hit_q || band_hit_q);
    assign rgb_out = (de && text_hit_q) ? TEXT_COLOR :
                     (de && band_hit_q) ? band_rgb   : rgb_in;
endmodule
