# osd —— 第九讲 OSD字幕叠加

本目录是第九讲新加的代码，与 `framebuf4bank/`、`fat32/`、`stable/` 解耦。

## 这一讲补了什么

第八讲结束时，工程的 OSD 只有 `stable/status_osd_overlay.v` 那一条：4 个字符
（图片编号 / A或E / 错误码两位），32×8 像素，钉在左上角 (8,8)，纯静态。

第九讲讲义的重点是扩展要求第 1 点——**图层叠加与字幕效果：在图片播放时叠加
动态文字，探索多图层混合与平滑滚动**。工程原来一条都没有：

| 讲义要求 | 改造前 | 本讲后 |
|---|---|---|
| 动态文字 | 无（状态条是静态的） | `timestamp_osd` MM:SS 运行计时 |
| 平滑滚动 | 无 | `osd_scroll_subtitle` 每帧移 1 像素 |
| 多图层混合 | 无（像素级替换，硬盖） | `osd_alpha_blend` 字幕底条半透明 |
| 字幕文本跨域 | 无 | `subtitle_frame_commit` toggle+2FF+帧边界 |

## 文件清单

| 文件 | 来源 | 改动 |
|---|---|---|
| `subtitle_frame_commit.v` | 讲义原件 | 无（只补注释） |
| `osd_scroll_subtitle.v` | 讲义 `promax_text_overlay.v` 的字幕部分 | **去真除法 + 字模预取寄存一拍 + 底条改 Alpha 混合** |
| `timestamp_osd.v` | 讲义原件 | **去真除法 + 秒基准换时钟计数 + 帧边界锁存显示值** |
| `osd_alpha_blend.v` | 新写（讲义 2.4 只给了公式） | — |
| `osd_subtitle_source.v` | 新写（替代讲义的 UART 文本源） | — |
| `reference/*.v` | 讲义原件 | 归档不综合，见 `reference/说明.txt` |

## 视频链路里的位置

```
media_video_pipeline ── vout_data ──┐
                                    │
  status_osd_overlay (8,8)     32×8 │  ← 第八讲，纯组合
        ↓ vout_data_osd             │
  osd_scroll_subtitle (8,440)  624×24│  ← 第九讲，内部寄一拍
        ↓ vout_data_sub             │
  timestamp_osd (568,8)        40×16 │  ← 第九讲，内部寄一拍
        ↓ vout_data_ts              │
  video_rgb_to_axis_640x480 ── HDMI ─┘
```

三块区域互不相交（状态条 x=8~39、时间戳 x=568~607、字幕 y=440~463），
所以串联顺序不影响画面，调换也可以。

文本侧是另一条链，跨时钟域：

```
sd_card_clk 域                      │  video_clk 域
osd_subtitle_source                 │
  （按 pending_index 选标语）        │
   text/length/enable ──────────────┼──► subtitle_frame_commit ──► osd_scroll_subtitle
   commit ─► toggle ────────────────┤      2FF + frame_start 锁存
```

## 改这些代码前必须知道的三件事

### 1. 字模预取一拍的坐标规则，和顶层计数器是绑死的

`osd_scroll_subtitle` 和 `timestamp_osd` 内部都有一句：

```verilog
wire [11:0] next_x = de ? (pixel_x + 12'd1) : 12'd0;
```

这是在**复刻** `top_tf_hdmi_audio.v` 里 `osd_pixel_x` 的递增规则
（de 期间 +1，否则归 0）。两边必须完全一致，否则字幕会整体错一个像素，
或者在行首/行尾多出一个亮点。**动顶层那个计数器时，这两处要跟着动。**

`next_y` 不需要预取，直接用 `pixel_y`：y 只在行消隐期（de 下降沿）变一次，
一行之内恒定，提前一拍读到的还是同一行。

为什么要预取：`status_osd_overlay` 是第八讲留下的纯组合叠加，它字库小
（16 个字符 × 7 行）扛得住。字幕这条字库大得多（50+ ASCII 分支 + 9 个
256 位汉字点阵），三级串起来的组合深度在 40ns 里不保险。把字模查表整段
挪到寄存器前，输出路径只剩一级 mux + 底条混合。

### 2. 讲义原件里的除法必须换掉，不是风格问题

讲义 `promax_text_overlay.v` 用 `CELL_W=12`、`SUBTITLE_CELL_W=18`，渲染时写
`subtitle_stream_x / SUBTITLE_CELL_W`；`timestamp_osd.v` 用 `sec_cnt/60`、
`sec_cnt%60`。除数都不是 2 的幂，综合器只能摊出组合除法器，而且这些路径
直通像素渲染。

本目录把字符格统一成 16×16（除法退化成 `>>4`、取模退化成取低 4 位），
时间戳换成 BCD 进位链。**照抄讲义原件会综合出一堆除法器，别抄。**

16×16 的附带好处：汉字点阵刚好 1:1 填满一格，不用再算居中偏移。

### 3. bundled data 跨域的规矩：数据稳一拍之后才能发 commit

`subtitle_frame_commit` 的 `src_text`/`src_length`/`src_enable` 是 96+7 位
bundled data，**没有过同步器**，是裸跨域的。安全的唯一前提是：源侧发出
`src_commit` 之后不再改这三个信号，直到下一次提交。

`osd_subtitle_source` 用 `pending` 标志强制把"更新数据"和"发 commit"隔开
一拍来守这条规矩。**改那个状态机时不要把两件事并到同一拍**，否则目标域
可能在 `frame_start` 采到半新半旧的文本。

## 时序约束

不需要给 `media_player_promax_top.sdc` 新增任何一条。`subtitle_frame_commit`
的 2FF 第一级寄存器名是 `commit_sync1`，已被现有的

```tcl
set_false_path -to [get_regs -hier {*/commit_sync1}]
```

通配覆盖。**代价是这个 reg 名不能改**，改名就得同时补约束。

## 参数怎么调

| 想改什么 | 改哪里 |
|---|---|
| 字幕滚动速度 | `osd_scroll_subtitle` 的 `SCROLL_DIV`，0=每帧 1 像素（约 60px/s），1=每 2 帧 1 像素 |
| 字幕带位置/高度 | `BAND_Y` / `BAND_H`，注意 `BAND_Y+BAND_H` 不能超过 480 |
| 字幕底条透明度 | `BAND_ALPHA`，移位近似只认高 2 位：0/64/128/192 四档 + 255=不透明 |
| 要精确 256 级混合 | `USE_MULT=1`，代价是 3 个乘法器 |
| 字幕文字内容 | `osd_subtitle_source.v` 里的 case，ASCII 最多 12 个字符 |
| 加新汉字 | `osd_scroll_subtitle.v` 里的 `CN_GLYPH_*`（16×16 横向取模、高位在左），同时改 `osd_subtitle_source` 里的引用编号 |
| 关掉汉字省 LUT | `ENABLE_CJK=0`，`cur_is_cjk` 恒假，综合器会把整个汉字点阵锥剪掉 |
| 时间戳位置 | `timestamp_osd` 的 `OSD_X`/`OSD_Y`，注意别撞上状态条的 x=8~39 |

## 还没做 / 已知限制

- **字幕文本源不是 UART**。讲义的 `subtitle_uart_controller.v` 需要
  `uart_rx`/`uart_tx` 和两个引脚约束，本工程顶层没有串口端口、`pin.adc`
  里也没有留，接不上。原件归档在 `reference/`，要接的话看那里的说明。
  现在的文本源是 `osd_subtitle_source`：每张图片配一句标语，切图换字幕。
- **字幕跟的是 `pending_index` 而不是 `active_index`**。前者是 ctrl 域
  （和未来的 UART 文本源同域，换源时下游一行不用改），比屏幕上真正显示的
  图片早最多一帧。肉眼看不出来，撕裂由帧边界提交兜住了。
- **Alpha 混合只用在字幕底条**。状态条和时间戳还是像素级替换（硬盖）。
  要让它们也半透明，把各自输出那句 mux 换成 `osd_alpha_blend` 即可，
  模块是通用的。
- **汉字只有 9 个字**（欢 迎 来 到 星 澜 科 技 馆，编号 0x80~0x88），
  宋体 16×16 点阵。要别的字得自己取模。
