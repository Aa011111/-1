`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第九讲 OSD字幕叠加
// timestamp_osd：讲义选讲的时间戳 OSD，屏幕右上角一个 MM:SS 运行计时。
//   扩展要求第1点原文是"叠加动态文字（如时间戳或标语）"——标语由
//   osd_scroll_subtitle 负责，时间戳是这个。
//
// 相对讲义原件 timestamp_osd.v 的三处改动：
//
//  改动1（去掉真除法，必须改）：讲义原件用 sec_cnt/60、sec_cnt%60 直接算
//    分秒，除数 60 不是 2 的幂，综合器会摊出一个 16 位组合除法器，而且这
//    条路径直通像素渲染。这里换成 4 个 BCD 计数器（个位到 9 进位、十位到
//    5 进位），只有加法和比较。
//
//  改动2（秒基准换成时钟计数）：讲义原件按"60 帧 = 1 秒"计时。本工程的
//    真实帧率是 25MHz / (800*525) = 59.52Hz，按 60 帧算会慢 0.8%，跑一小时
//    差近半分钟。这里直接用像素时钟数 CLK_HZ 拍，秒是准的。
//    代价只是把 6 位帧计数器换成 25 位时钟计数器。
//
//  改动3（显示值帧边界锁存）：秒进位可能落在一帧中间，那一帧上半屏显示
//    旧值下半屏显示新值，就是讲义 2.3 说的撕裂。这里 MM:SS 四位数字在
//    frame_start 统一锁存一次，一帧内恒定。
//    另外和 osd_scroll_subtitle 一样做了字模预取一拍（next_x = de?x+1:0），
//    输出路径只剩一级 mux，保证串在 OSD 链最后一级也不吃掉时序余量。
//
// 【复位即清零】计时从 pix_rst_n 释放开始算，等于"本次上电播放了多久"。
// 讲义原件留了个 sys_rst_n 端口说"UART 复位计时以后再加"，本工程没有
// UART，那个端口就不留了，省一根悬空线。
// -----------------------------------------------------------------------------

module timestamp_osd #(
    parameter integer OSD_X    = 568,           // 右上角，568+40=608 < 640
    parameter integer OSD_Y    = 8,             // 与状态条 OSD 同一行
    parameter integer CHAR_W   = 8,             // 字符格宽（4x6 字模横向放大2倍）
    parameter integer CHAR_H   = 16,            // 字符格高（纵向放大2倍=12行有效）
    parameter integer CLK_HZ   = 25_000_000,    // 像素时钟频率，用来数秒
    parameter [23:0]  TEXT_COLOR = 24'hE0F0FF   // 淡青白
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        enable,
    input  wire        de,
    input  wire        frame_start,
    input  wire [11:0] pixel_x,
    input  wire [11:0] pixel_y,
    input  wire [23:0] rgb_in,
    output wire [23:0] rgb_out,
    output wire        ts_active
);
    // ---- 秒计时：时钟分频 + BCD 进位链 ----
    localparam integer TICK_MAX = CLK_HZ - 1;

    reg [24:0] tick_cnt;
    reg [3:0]  sec_ones;
    reg [3:0]  sec_tens;
    reg [3:0]  min_ones;
    reg [3:0]  min_tens;
    wire       tick = (tick_cnt >= TICK_MAX);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tick_cnt <= 25'd0;
            sec_ones <= 4'd0;
            sec_tens <= 4'd0;
            min_ones <= 4'd0;
            min_tens <= 4'd0;
        end else if (tick) begin
            tick_cnt <= 25'd0;
            // 个位满 9 进十位，十位满 5 进分，分到 59:59 回零
            if (sec_ones != 4'd9) begin
                sec_ones <= sec_ones + 4'd1;
            end else begin
                sec_ones <= 4'd0;
                if (sec_tens != 4'd5) begin
                    sec_tens <= sec_tens + 4'd1;
                end else begin
                    sec_tens <= 4'd0;
                    if (min_ones != 4'd9) begin
                        min_ones <= min_ones + 4'd1;
                    end else begin
                        min_ones <= 4'd0;
                        min_tens <= (min_tens == 4'd5) ? 4'd0 : min_tens + 4'd1;
                    end
                end
            end
        end else begin
            tick_cnt <= tick_cnt + 25'd1;
        end
    end

    // ---- 帧边界锁存显示值（改动3）----
    reg [3:0] so_q, st_q, mo_q, mt_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            so_q <= 4'd0; st_q <= 4'd0; mo_q <= 4'd0; mt_q <= 4'd0;
        end else if (frame_start) begin
            so_q <= sec_ones; st_q <= sec_tens;
            mo_q <= min_ones; mt_q <= min_tens;
        end
    end

    // ---- 4x6 数字字模（沿用讲义原件的布尔表达式写法）----
    // 只有字符"1"改了：原件多一条 (row==2 && (col==1||col==3)) 的横刺，
    // 放大 2 倍后在屏幕上是一道很突兀的毛刺，这里去掉。其余 9 个数字和
    // 冒号的点阵与原件逐位相同。
    // 写法上 (row==N) 不带 col 条件 = 该行 4 列全亮，与原件把 4 个 col
    // 逐个列出等价。
    function font_pixel;
        input [3:0] digit;
        input [1:0] col;    // 0..3
        input [2:0] row;    // 0..5
        begin
            case (digit)
                4'd0: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2 && (col==0||col==3)) ||
                                   (row==3 && (col==0||col==3)) ||
                                   (row==4 && (col==0||col==3)) ||
                                   (row==5 && (col==1||col==2));
                4'd1: font_pixel = (col==2) ||
                                   (row==0 && col==1) ||
                                   (row==5 && (col==1||col==3));
                4'd2: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && col==3) ||
                                   (row==2 && (col==1||col==2)) ||
                                   (row==3 && col==1) ||
                                   (row==4 && col==0) ||
                                   (row==5 && (col==1||col==2||col==3));
                4'd3: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && col==3) ||
                                   (row==2 && (col==1||col==2)) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && (col==1||col==2));
                4'd4: font_pixel = (row==0 && (col==0||col==3)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && col==3);
                4'd5: font_pixel = (row==0) ||
                                   (row==1 && col==0) ||
                                   (row==2 && (col==0||col==1||col==2)) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && (col==1||col==2));
                4'd6: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && col==0) ||
                                   (row==2 && (col==0||col==1||col==2)) ||
                                   (row==3 && (col==0||col==3)) ||
                                   (row==4 && (col==0||col==3)) ||
                                   (row==5 && (col==1||col==2));
                4'd7: font_pixel = (row==0) ||
                                   (row==1 && col==3) ||
                                   (row==2 && col==2) ||
                                   (row==3 && col==2) ||
                                   (row==4 && col==2) ||
                                   (row==5 && col==2);
                4'd8: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2 && (col==1||col==2)) ||
                                   (row==3 && (col==0||col==3)) ||
                                   (row==4 && (col==0||col==3)) ||
                                   (row==5 && (col==1||col==2));
                4'd9: font_pixel = (row==0 && (col==1||col==2)) ||
                                   (row==1 && (col==0||col==3)) ||
                                   (row==2 && (col==1||col==2||col==3)) ||
                                   (row==3 && col==3) ||
                                   (row==4 && col==3) ||
                                   (row==5 && (col==1||col==2));
                default: font_pixel = 1'b0;
            endcase
        end
    endfunction

    function colon_pixel;
        input [1:0] col;
        input [2:0] row;
        begin
            colon_pixel = (col >= 2'd1 && col <= 2'd2) &&
                          (row >= 3'd1 && row <= 3'd4);
        end
    endfunction

    // ---- 下一个像素的渲染（预取一拍，规则同 osd_scroll_subtitle）----
    wire [11:0] next_x = de ? (pixel_x + 12'd1) : 12'd0;
    wire [11:0] dx = next_x  - OSD_X;
    wire [11:0] dy = pixel_y - OSD_Y;

    wire in_region = enable &&
                     (next_x  >= OSD_X)  && (next_x  < OSD_X + 5*CHAR_W) &&
                     (pixel_y >= OSD_Y)  && (pixel_y < OSD_Y + CHAR_H);

    wire [2:0] slot  = dx[5:3];          // dx / 8，0~4 共 5 个字符位
    wire [1:0] gcol  = dx[2:1];          // 格内列 /2 -> 字模列 0~3
    wire [2:0] grow  = dy[3:1];          // 格内行 /2 -> 字模行 0~7（用 0~5）

    reg next_hit;
    always @* begin
        next_hit = 1'b0;
        if (in_region && grow < 3'd6) begin
            case (slot)
                3'd0: next_hit = font_pixel(mt_q, gcol, grow);
                3'd1: next_hit = font_pixel(mo_q, gcol, grow);
                3'd2: next_hit = colon_pixel(gcol, grow);
                3'd3: next_hit = font_pixel(st_q, gcol, grow);
                3'd4: next_hit = font_pixel(so_q, gcol, grow);
                default: next_hit = 1'b0;
            endcase
        end
    end

    reg hit_q;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            hit_q <= 1'b0;
        else
            hit_q <= next_hit;
    end

    assign ts_active = de && hit_q;
    assign rgb_out   = (de && hit_q) ? TEXT_COLOR : rgb_in;
endmodule
