`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第九讲 OSD字幕叠加
// osd_subtitle_source：字幕文本源（ctrl 域）。
//
// 讲义配的文本源是 subtitle_uart_controller.v —— 串口下发 "SUB=xxx"。本工程
// 顶层没有串口端口，pin.adc 里也没有可用的 UART 引脚约束，那条路接不上，
// 原件已归档到 osd/reference/ 备查。这里用板上已有的状态当文本源：
// 每张图片配一句标语，切图就换字幕，滚动效果和讲义一致，不用加任何引脚。
//
// 【为什么放在 ctrl 域而不是直接放 pix 域】
// 用的是 media_player_control 的 pending_index（sd_card_clk 域），不是 pix 域
// 的 active_index。这样做有意为之：把 subtitle_frame_commit 那条
// toggle+2FF+帧边界 的跨域链路真正用起来，将来换成 UART 文本源（也是 ctrl 域）
// 时，下游一行都不用改。代价是 pending 比屏幕上真正显示的 active 早半帧到
// 一帧——字幕比画面早一帧换，肉眼看不出来，而且撕裂由帧边界提交兜住了。
//
// 【bundled data 的规矩】text/length/enable 是裸跨域的 bundled data，必须先
// 把它们寄存稳定，下一拍才允许发 commit 脉冲。这里用 pending 标志强制隔开
// 一拍，改这个状态机时不要把两件事并到同一拍。
//
// 【改字幕内容】直接改下面 case 里的字符串。ASCII 最多 12 个字符；汉字用
// 8'h80 + 字模编号引用 osd_scroll_subtitle 里的 16x16 点阵（0x80~0x88 共 9 个
// 字：欢 迎 来 到 星 澜 科 技 馆），要换字得同时改那边的点阵常量。
//
// 13 张图扩展：media_index 宽 INDEX_W，每张图一句。本工程分配：
//   PIC1~11 = 通知 / 展馆内容，统一滚动"欢迎来到星澜科技馆"；
//   PIC12 = 火灾预警，PIC13 = 火灾发生，保留英文火警字幕。
// ASCII 字库只有大写字母、数字、空格和少量标点。
// -----------------------------------------------------------------------------

module osd_subtitle_source #(
    parameter integer MAX_CHARS = 12,
    parameter integer INDEX_W = 2
) (
    input  wire        clk,               // ctrl 域时钟（本工程 = sd_card_clk）
    input  wire        rst_n,
    input  wire [INDEX_W-1:0] media_index, // 当前/待显示的图片编号 0~n-1
    input  wire        subtitle_enable,   // 字幕总开关

    output reg  [95:0] text,              // text[i*8 +: 8] 是第 i 个显示的字符
    output reg  [5:0]  length,            // 有效字符数
    output reg         enable,
    output reg         commit             // 一拍提交脉冲，给 subtitle_frame_commit
);
    // 96 位字面量里第一个字符在最高字节，而渲染侧 index0 取的是最低字节，
    // 顺序正好相反。这个函数把字面量翻过来，省得手写倒序拼接。
    function [95:0] rev_text;
        input [95:0] literal;
        reg [95:0] acc;
        integer k;
        begin
            acc = 96'd0;
            for (k = 0; k < MAX_CHARS; k = k + 1)
                acc[k*8 +: 8] = literal[(MAX_CHARS-1-k)*8 +: 8];
            rev_text = acc;
        end
    endfunction

    // 汉字标语："欢迎来到星澜科技馆"，9 个字，编号 0x80~0x88 顺序排列。
    // 这里不用 rev_text：直接按"最低字节先显示"的顺序写好了。
    localparam [95:0] CN_SLOGAN = {
        8'h00, 8'h00, 8'h00,
        8'h88, 8'h87, 8'h86, 8'h85, 8'h84, 8'h83, 8'h82, 8'h81, 8'h80
    };

    reg [95:0] text_next;
    reg [5:0]  length_next;

    always @* begin
        case (media_index)
            11: begin text_next = rev_text("FIRE WARNING");   length_next = 6'd12; end
            12: begin text_next = rev_text("FIRE ALARM  ");   length_next = 6'd10; end
            // PIC1~11（以及越界编号）统一显示"欢迎来到星澜科技馆"
            default: begin text_next = CN_SLOGAN;             length_next = 6'd9;  end
        endcase
    end

    reg [INDEX_W-1:0] index_q;
    reg       enable_q;
    reg       loaded;      // 上电后是否已经装过一次
    reg       pending;     // 数据已更新，下一拍发 commit

    wire changed = (media_index != index_q) || (subtitle_enable != enable_q);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            text     <= 96'd0;
            length   <= 6'd0;
            enable   <= 1'b0;
            commit   <= 1'b0;
            index_q  <= {INDEX_W{1'b0}};
            enable_q <= 1'b0;
            loaded   <= 1'b0;
            pending  <= 1'b0;
        end else begin
            commit   <= 1'b0;
            index_q  <= media_index;
            enable_q <= subtitle_enable;

            if (!loaded || changed) begin
                // 第一步：只更新数据，这一拍不发 commit
                text    <= text_next;
                length  <= length_next;
                enable  <= subtitle_enable;
                loaded  <= 1'b1;
                pending <= 1'b1;
            end else if (pending) begin
                // 第二步：数据已经稳了一整拍，现在才允许翻 toggle
                commit  <= 1'b1;
                pending <= 1'b0;
            end
        end
    end
endmodule
