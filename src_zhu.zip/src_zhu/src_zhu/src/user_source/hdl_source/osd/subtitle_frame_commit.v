`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第九讲 OSD字幕叠加
// subtitle_frame_commit：讲义 2.3 的跨时钟域字幕帧提交，toggle + 2FF + 帧边界
//   锁存三步。逻辑与讲义原件一致，只补注释和一处复位值说明。
//
// 要解决的是两个不同的问题叠在一起：
//   1) 文本来自 ctrl 域（本工程是 sd_card_clk，未来接 UART 也是这个域），
//      渲染在 pix 域（video_clk），96 位文本是 bundled data，不能逐位同步。
//   2) 就算同域，文本在一帧中间换掉也会撕裂——上半屏旧字幕下半屏新字幕。
//
// 三步的分工：
//   toggle   ：src_commit 是一拍脉冲，跨域会丢；翻转成电平就丢不了。
//   2FF      ：commit_sync1/2 打两拍消亚稳态。第一级已被 sdc 第 6 节的
//              `set_false_path -to [get_regs -hier {*/commit_sync1}]` 覆盖，
//              这个模块加进来不用再补约束（reg 名必须保持 commit_sync1）。
//   frame_start：真正的数据搬运只在帧开始那一拍发生，一帧内 dst_text 恒定。
//
// 【bundled data 的安全性】src_text/src_length/src_enable 没有过同步器，是
// 裸跨域的。这样做安全的前提是：源侧在发出 src_commit 之后不再改这三个信号，
// 直到下一次提交前它们都是稳的。本工程的 osd_subtitle_source 满足这一点
// （先寄存文本，下一拍才发 commit）。接 UART 时也要守住同一条规矩。
//
// 【dst_initialized】保证上电后第一帧就把初始文本搬过去，不用干等第一次
// 提交，否则开机到第一次切图之间字幕是空的。
// -----------------------------------------------------------------------------

module subtitle_frame_commit (
    // 源域（控制域）
    input  wire        src_clk,
    input  wire        src_rst_n,
    input  wire        src_commit,      // 一拍提交脉冲
    input  wire [95:0] src_text,        // 12 个字符
    input  wire [5:0]  src_length,
    input  wire        src_enable,

    // 目标域（像素域）
    input  wire        dst_clk,
    input  wire        dst_rst_n,
    input  wire        frame_start,     // 帧开始，只在这一拍更新
    output reg  [95:0] dst_text,
    output reg  [5:0]  dst_length,
    output reg         dst_enable
);
    reg commit_toggle;      // 源域：每次提交翻转一次
    reg commit_sync1;       // 目标域 2FF 第一级（sdc 按这个名字打 false_path）
    reg commit_sync2;       // 目标域 2FF 第二级
    reg commit_seen;        // 目标域：已经处理过的 toggle 值
    reg dst_initialized;    // 目标域：上电首帧强制搬一次

    always @(posedge src_clk or negedge src_rst_n) begin
        if (!src_rst_n)
            commit_toggle <= 1'b0;
        else if (src_commit)
            commit_toggle <= ~commit_toggle;
    end

    always @(posedge dst_clk or negedge dst_rst_n) begin
        if (!dst_rst_n) begin
            commit_sync1    <= 1'b0;
            commit_sync2    <= 1'b0;
            commit_seen     <= 1'b0;
            dst_initialized <= 1'b0;
            dst_text        <= 96'd0;
            dst_length      <= 6'd0;
            dst_enable      <= 1'b0;
        end else begin
            commit_sync1 <= commit_toggle;
            commit_sync2 <= commit_sync1;

            if (frame_start && (!dst_initialized || commit_sync2 != commit_seen)) begin
                dst_text        <= src_text;
                dst_length      <= src_length;
                dst_enable      <= src_enable;
                commit_seen     <= commit_sync2;
                dst_initialized <= 1'b1;
            end
        end
    end
endmodule
