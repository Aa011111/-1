`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第九讲 OSD字幕叠加
// osd_alpha_blend：讲义 2.4 只给了 Alpha 混合的公式和"架构上预留"，没有给实现。
// 这里把它补成一个纯组合的通用模块，字幕底条用它做半透明压暗。
//
//   blended = fg * a + bg * (1 - a)
//
// 【为什么默认不用乘法器】讲义说"24位RGB×8位Alpha，每通道一个乘法器，共3个"。
// EG4S20 的 DSP 要留给别处（fade 分支、音频缩放），而字幕底条只需要一档固定
// 透明度，用不上 256 级精度。USE_MULT=0 时把 alpha 量化成 4 档（0/¼/½/¾）
// 外加 255=全不透明，全部用移位加法实现，一个乘法器都不占：
//     x*¼ = x>>2      x*½ = x>>1      x*¾ = (x>>1)+(x>>2)
// 量化误差最大 1/8 满量程，对一条压暗的字幕底条完全看不出来。
// 真要精确渐变（比如做 OSD 淡入淡出）再把 USE_MULT 打开。
//
// 【USE_MULT=1 的 +1 修正】用 (alpha+1)/256 而不是 alpha/255：alpha=255 时
// 得到 256/256 正好是原值，不会因为 255/256 把纯白压成 254。这和
// media_video_pipeline.v 里 fade 分支的 (brightness+1)>>8 是同一个套路。
//
// 【function 写在 generate 外面】不是风格问题：把 function 塞进 named
// generate block 里，标准允许但一些综合前端（含部分老版 TD 前端）解析不了。
// 放模块级最保险，未被选中的分支反正会被优化掉。
// -----------------------------------------------------------------------------

module osd_alpha_blend #(
    parameter integer USE_MULT = 0      // 0=移位近似(无乘法器) 1=精确8位乘法
) (
    input  wire [23:0] fg,              // 前景色（OSD）
    input  wire [23:0] bg,              // 背景色（视频原像素）
    input  wire [7:0]  alpha,           // 0=全透明(只剩bg) 255=全不透明(只剩fg)
    output wire [23:0] blended
);
    // x * weight/4，weight 取 0~3，只用移位加法
    function [7:0] quarter_scale;
        input [7:0] value;
        input [1:0] weight;
        begin
            case (weight)
                2'd0: quarter_scale = 8'd0;
                2'd1: quarter_scale = value >> 2;
                2'd2: quarter_scale = value >> 1;
                default: quarter_scale = (value >> 1) + (value >> 2);
            endcase
        end
    endfunction

    generate
    if (USE_MULT != 0) begin : g_mult
        // 精确混合：每通道一次 8x9 乘法，综合器按需映射到 DSP 或 LUT。
        // fg*a9 + bg*(256-a9) 最大 255*256 = 65280，17 位容器不会溢出；
        // 除以 256 就是取 [15:8]。
        wire [8:0]  a9  = {1'b0, alpha} + 9'd1;     // 1..256
        wire [8:0]  ia9 = 9'd256 - a9;              // 255..0
        wire [16:0] mr = fg[23:16]*a9 + bg[23:16]*ia9;
        wire [16:0] mg = fg[15:8] *a9 + bg[15:8] *ia9;
        wire [16:0] mb = fg[7:0]  *a9 + bg[7:0]  *ia9;
        assign blended = {mr[15:8], mg[15:8], mb[15:8]};
    end else begin : g_shift
        // 移位近似：alpha 高两位选档，255 单独判为全不透明。
        //   fg*lvl/4 + bg*(4-lvl)/4
        // quarter_scale 最多只能表达 ¾，所以 bg 那一份拆成
        //   bg*(3-lvl)/4 + bg/4
        // 两项相加正好补回 (4-lvl)/4。各通道最大值 254，8 位不溢出。
        wire       full = (alpha == 8'hff);
        wire [1:0] lvl  = alpha[7:6];               // 0=0 1=¼ 2=½ 3=¾
        wire [1:0] ilvl = 2'd3 - lvl;

        wire [7:0] mix_r = quarter_scale(fg[23:16], lvl) +
                           quarter_scale(bg[23:16], ilvl) + (bg[23:16] >> 2);
        wire [7:0] mix_g = quarter_scale(fg[15:8],  lvl) +
                           quarter_scale(bg[15:8],  ilvl) + (bg[15:8]  >> 2);
        wire [7:0] mix_b = quarter_scale(fg[7:0],   lvl) +
                           quarter_scale(bg[7:0],   ilvl) + (bg[7:0]   >> 2);

        assign blended = full ? fg :
                         (lvl == 2'd0) ? bg : {mix_r, mix_g, mix_b};
    end
    endgenerate
endmodule
