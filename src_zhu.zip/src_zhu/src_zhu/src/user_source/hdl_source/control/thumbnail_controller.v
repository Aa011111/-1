`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十五讲（讲义第14课）缩略图交互选择
// thumbnail_controller：讲义 3.2 的缩略图交互控制器，本工程版。
//
// 讲义脚手架的四个 TODO 全部落地（代码里用 TODO1~4 标出对应位置），另外按
// 本工程的架构做了三处调整：
//
//  1) active_index 不在本模块里。本工程的 active_index 归 media_player_control
//     （ctrl 域发请求、pix 域 frame_start 原子提交，讲义 3.3 钩子2）。本模块只
//     输出 select_event + select_index，把"目标图片号"按那条现成流程送进
//     pending_index，不重写跨时钟域——正是讲义 3.3 最后一段建议的做法。
//
//  2) 没有 frame_start 口。本模块在 ctrl 域，"帧边界生效"在下游做：
//       view_mode   -> media_video_pipeline 的 pix 域 frame_start 锁成 thumb_frame_q
//                      （reader 同一拍锁同一个值决定这一帧怎么读）
//       focus_index -> 经 cdc_bus_commit 进 pix 域，再在 frame_start 锁存
//       active_index-> media_player_control 在 frame_start 提交
//     三者都整帧恒定，不撕裂（讲义 Q1）。
//
//  3) transition_req 是一次完整握手，不是"发一拍就算"：
//       发请求 -> video_fade_transition 淡出到全黑 -> 放行脉冲 transition_black
//       -> 此刻才翻 view_mode、发 select -> 新画面从黑淡入
//     模式切换和图片切换都落在全黑那几帧里，屏幕上看不到中间态。
//     只翻模式（进缩略图 / 返回全屏）时也发一次 select（目标 = 当前图）：
//     转场模块在全黑态要等 index_commit 才开始淡入，没有 commit 会一直黑着。
//
// 与讲义行为上的一处不同：进入缩略图时焦点落在"当前正在看的那张"，而不是
// 固定回到图片1——从第3张进缩略图，黄框就在第3格，确认键原地回来不换图。
// 上电后当前图是图片1，所以讲义 3.2.3 第1条的现象不变。
//
// 状态：
//   S_IDLE   接收按键
//   S_QUEUE  动作已定，等转场模块空闲（它忙时会丢请求，比如自动轮播的 Wipe 还没走完）
//   S_BLACK  已发 transition_req，等全黑放行脉冲
//   S_SELECT 模式已翻，等 media_player_control 空闲再发 select
// S_BLACK 带超时兜底：万一请求被转场模块丢掉（只可能与 Wipe 起跑同拍相撞），
// 超时后不带转场直接生效，不会卡死在这个状态。
//
// 13 张图扩展：焦点在 0 ~ IMAGE_COUNT-1 之间循环（4x4 网格的后 3 格没有图，
// 焦点不会停上去）；index 位宽 INDEX_W。默认 4 / 2 与改造前相同。
//
// 触控屏扩展（FOC=NN）：
//   - FOCUS_COUNT：焦点只在前 FOCUS_COUNT 格里循环（顶层 = 11，PIC12/13 火警图
//     不进缩略图）。默认 = IMAGE_COUNT，与改造前相同。
//   - focus_cfg_valid/index：直接把焦点设到某一格。触控屏的上下左右、点格子
//     都由屏幕算好格子号发过来，FPGA 照设，两边不会走偏。任何状态下都收
//     （紧跟 THUMB 发来的 FOC 会落在 S_QUEUE/S_BLACK 里，不能丢），并且
//     优先于同拍的方向键/进缩略图落位；越界（>= FOCUS_COUNT）忽略。
//
// FADE_FRAMES=0（转场旁路）时放行脉冲与 transition_req 同拍组合直通，
// transition_owned 在那一拍已经为 1，同样走得通，只是没有淡变。
// -----------------------------------------------------------------------------

module thumbnail_controller #(
    // 淡出 16 帧 ≈ 0.27s @60fps，给 1s 足够宽
    parameter [31:0] BLACK_TIMEOUT_CYCLES = 32'd50_000_000,   // 1s @ 50MHz sd_card_clk
    parameter integer IMAGE_COUNT = 4,
    parameter integer INDEX_W = 2,
    parameter integer FOCUS_COUNT = IMAGE_COUNT   // 焦点可达的格子数（<= IMAGE_COUNT）
) (
    input  wire       clk,              // ctrl 域 = sd_card_clk
    input  wire       rst_n,

    // 讲义 3.2 的四个键（单拍事件，已由 media_key_events 裁决，映射见 pipeline）
    input  wire       key_right,        // 焦点右移（到最后一张回 0）
    input  wire       key_left,         // 焦点左移（到 0 回最后一张）
    input  wire       key_confirm,      // 选中焦点那张，回全屏
    input  wire       key_mode,         // 全屏 <-> 缩略图，不换图
    // 串口 THUMB / FULL：明确设定目标模式，和当前一样就不动
    input  wire       mode_cfg_valid,
    input  wire       mode_cfg_thumb,
    // 触控屏 FOC=NN：直接设焦点（单拍）
    input  wire       focus_cfg_valid,
    input  wire [INDEX_W-1:0] focus_cfg_index,

    input  wire [IMAGE_COUNT-1:0] image_complete,
    input  wire [INDEX_W-1:0] current_index,    // media_player_control 的 pending_index（同域）
    input  wire       select_busy,      // media_player_control 的 request_busy
    input  wire       transition_busy,  // video_fade_transition 的 fade_busy
    input  wire       transition_black, // 转场淡到全黑时的放行脉冲（已按 owned 分流）

    output reg        view_mode,        // 0 = 全屏，1 = 缩略图（ctrl 域电平）
    output reg  [INDEX_W-1:0] focus_index,
    output reg        select_event,     // 单拍：请 media_player_control 切到 select_index
    output reg  [INDEX_W-1:0] select_index,
    output reg        transition_req,   // 单拍：请求一次淡出-淡入
    output wire       transition_owned, // 1 = 转场放行脉冲归本模块，不能当 next 用
    output wire       auto_hold         // 浏览缩略图/切换途中暂停自动轮播
);
    localparam [1:0] S_IDLE   = 2'd0;
    localparam [1:0] S_QUEUE  = 2'd1;
    localparam [1:0] S_BLACK  = 2'd2;
    localparam [1:0] S_SELECT = 2'd3;

    reg [1:0]  state;
    reg        target_view;
    reg [INDEX_W-1:0] target_index;
    reg [31:0] black_cnt;

    assign transition_owned = (state == S_BLACK);
    // 缩略图下 4 张全在屏上，后台再轮播只会让音乐/字幕/状态条莫名其妙地变；
    // 切换途中也要停，免得自动请求和本模块的 select 抢 media_player_control
    assign auto_hold = view_mode || (state != S_IDLE);

    // 串口明确设定优先于按键翻转（和 auto_cfg / toggle_auto 同一套思路）
    wire mode_req = mode_cfg_valid ? (mode_cfg_thumb != view_mode) : key_mode;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            // 复位初值：全屏、焦点0、当前图由 media_player_control 管
            state          <= S_IDLE;
            view_mode      <= 1'b0;
            focus_index    <= {INDEX_W{1'b0}};
            select_event   <= 1'b0;
            select_index   <= {INDEX_W{1'b0}};
            transition_req <= 1'b0;
            target_view    <= 1'b0;
            target_index   <= {INDEX_W{1'b0}};
            black_cnt      <= 32'd0;
        end else begin
            // TODO4：两根请求都是单拍脉冲
            transition_req <= 1'b0;
            select_event   <= 1'b0;

            case (state)
            S_IDLE: begin
                if (mode_req) begin
                    // TODO1：模式键翻转 view_mode（真正翻转推迟到全黑那一刻）
                    target_view  <= ~view_mode;
                    target_index <= current_index;    // 不换图
                    if (!view_mode)
                        focus_index <= current_index; // 进缩略图：焦点落在当前图
                    state <= S_QUEUE;
                end else if (view_mode && key_confirm) begin
                    // TODO3：确认 = 选焦点那张 + 回全屏 + 一次转场；
                    // 焦点在未加载的格子上时忽略（屏上那格是占位符 + 红框）
                    if (image_complete[focus_index]) begin
                        target_view  <= 1'b0;
                        target_index <= focus_index;
                        state        <= S_QUEUE;
                    end
                end else if (view_mode && key_right) begin
                    // TODO2：只有缩略图模式才响应方向键；全屏下这两个键是
                    // 下一张/上一张，由 pipeline 直接交给 media_player_control
                    focus_index <= (focus_index >= FOCUS_COUNT - 1) ? {INDEX_W{1'b0}} :
                                                                     focus_index + 1'b1;
                end else if (view_mode && key_left) begin
                    focus_index <= (focus_index == 0) ? FOCUS_COUNT - 1 : focus_index - 1'b1;
                end
            end

            S_QUEUE: begin
                if (!transition_busy) begin
                    transition_req <= 1'b1;
                    black_cnt      <= 32'd0;
                    state          <= S_BLACK;
                end
            end

            S_BLACK: begin
                // TODO4：屏幕全黑时才翻模式，下游在紧接着的 frame_start 锁存
                if (transition_black || (black_cnt >= BLACK_TIMEOUT_CYCLES - 1)) begin
                    view_mode <= target_view;
                    state     <= S_SELECT;
                end else begin
                    black_cnt <= black_cnt + 32'd1;
                end
            end

            S_SELECT: begin
                // 还有一条请求在飞（比如刚好赶上的上一张）就等它提交完，
                // 否则 media_player_control 会报 ERR_REQUEST_BUSY(0x52)
                // 目标图没加载时不发：只可能是摄入完成前收到串口 THUMB/FULL
                // （按键有 ready 门控），那时转场模块也没在跑，不需要 commit 收尾，
                // 发了反而让 media_player_control 报 ERR_NO_RESOURCE(0x53)
                if (!select_busy) begin
                    select_event <= image_complete[target_index];
                    select_index <= target_index;
                    state        <= S_IDLE;
                end
            end
            endcase

            // 触控屏直接设焦点：放在 case 之后，同拍覆盖上面对 focus_index 的赋值
            if (focus_cfg_valid && (focus_cfg_index < FOCUS_COUNT))
                focus_index <= focus_cfg_index;
        end
    end
endmodule
