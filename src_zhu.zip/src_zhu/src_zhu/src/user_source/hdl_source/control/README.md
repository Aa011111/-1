# 第十五讲 —— 缩略图交互选择（讲义第14课）

## 讲义要求 vs 本工程补齐情况

| 讲义内容 | 本工程改造前（第十三讲状态） | 补齐后 |
|---|---|---|
| `thumbnail_controller.v`（练习，完赛未实现） | 无 | `control/thumbnail_controller.v`，4 个 TODO 全部落地 |
| 独立的 `focus_index` | 焦点 = `active_index`，挪框就是真切图（音乐/字幕/状态条跟着变） | 焦点单独一个寄存器，挪框不动当前图 |
| 确认键：`active_index = focus_index` + 回全屏 | 无，只能来回切模式 | KEY1 长按 / 串口 `SEL`，走 `media_player_control` 新增的 `select_event` |
| 确认前查 `image_complete[focus_index]` | 焦点直接跳过未加载的格子 | 焦点 0→1→2→3 全走，未加载的格子确认无效 |
| 模式键：翻模式、不换图 | KEY1 长按翻 | 全屏 KEY1 长按进，缩略图 KEY2 短按回；串口 `THUMB`/`FULL` |
| `transition_req` 触发转场（2.5 入门级） | 进出缩略图是硬切（缩略图帧强制 alpha=255） | 进/出/确认都淡出→全黑→淡入，模式和图片都在全黑时切 |
| 帧边界生效（Q1） | view_mode、active_index 已经是 | 焦点也经 `cdc_bus_commit` 进 pix 域并在 `frame_start` 锁存 |
| 未加载格子显示占位符（2.4 扩展） | 纯黑 | 深灰底 + 灰色 X；焦点停在上面画红框 |
| — | 缩略图下自动轮播照常在后台切图 | 缩略图期间暂停，回全屏重新计时 |
| — | — | 缩略图里当前正在播的那张描白框（和黄色焦点框区分） |

## 按键映射（讲义 2.2 方案C，板上只有两个键，用短按/长按凑四个功能）

| 操作 | 全屏模式 | 缩略图模式 |
|---|---|---|
| KEY1 短按 / 串口 `NEXT` | 下一张（淡变） | 焦点**右移**，3→0 wrap |
| KEY2 长按 / 串口 `PREV` | 上一张（Wipe） | 焦点**左移**，0→3 wrap |
| KEY1 长按 ≥1s / 串口 `SEL` | 进缩略图（淡变） | **确认**：全屏显示焦点那张（淡变） |
| KEY2 短按 / 串口 `FULL` | 自动轮播开关 | **返回**全屏，不换图（淡变） |
| 串口 `THUMB` | 进缩略图 | 无动作 |

焦点移动顺序是阅读顺序：左上(0) → 右上(1) → 左下(2) → 右下(3)。

## 模块怎么接的

```
media_key_events ──(按了什么)──> media_video_pipeline
                                   ├─ 按 thumb_mode 翻译成 right/left/confirm/mode
                                   ├─ thumbnail_controller ──select──> media_player_control
                                   │        │  ▲                          (帧边界原子提交)
                                   │  transition_req │ 全黑放行脉冲(按 owned 分流)
                                   │        ▼  │
                                   ├─ video_fade_transition
                                   └─ focus_index ─cdc_bus_commit─> frame_start 锁存 ─> thumbnail_layout
```

- 控制器放在 pipeline 内部而不是顶层：它要和转场模块握手（请求 + 全黑放行），
  还要用 `media_player_control` 的 `pending_index`/`request_busy`，这些都在 pipeline 里。
- 只翻模式时也发一次 `select`（目标=当前图）：转场模块全黑后要等 `index_commit`
  才开始淡入，不 commit 会一直黑着。
- `thumb_mode` 的所有权从 `media_player_control` 挪到了控制器，那三个 thumb 口删掉了。

## 改动文件

| 文件 | 改动 |
|---|---|
| `control/thumbnail_controller.v` | **新增** |
| `control/sim/tb_thumbnail_controller.v` | **新增**，自检仿真，覆盖讲义 3.2.3 的 1~4 条 + 超时兜底 |
| `framebuf4bank/media_player_control.v` | 删 thumb 三口；加 `select_event/select_index`、`auto_hold` |
| `framebuf4bank/media_video_pipeline.v` | 例化控制器、按键翻译、转场分流、焦点跨域、格子着色；缩略图帧参与淡变 |
| `framebuf4bank/media_key_events.v` | 加 `thumb_mode` 输入：缩略图下 KEY2 短按不受"至少两张图"门控 |
| `display/thumbnail_layout.v` | 焦点框不再要求已加载；加 `cell_edge`、`placeholder` 输出 |
| `uart/uart_line_parser.v` 等 4 个 | 新增 `SEL` 命令，逐层透传 |
| `top_tf_hdmi_audio.v` | 接 `thumb_mode` 到按键模块、`SEL` 到 pipeline |
| `transition/sim/tb_video_fade_transition.v` | 跟着 `media_player_control` 新端口改连线 |
| `.al` | 备份为 `.al.bak_before_lesson15`，新增 `control/thumbnail_controller.v`（CompileOrder 94） |

sdc 不用改：焦点跨域用的 `cdc_bus_commit` 第一级叫 `commit_sync1`，第 6 节已有通配。

## 上板验证

| # | 操作 | 预期 | 不对时看哪里 |
|---|---|---|---|
| 1 | TD 编译 | 无 undefined module，`thumbnail_controller` 无 latch 警告 | `.al` 清单 |
| 2 | 全屏 KEY1 长按 1s 松开 | 画面淡黑 → 2x2 缩略图淡入；黄框和白框都在当前图那格 | 硬切 → `frame_alpha` 还被强制 255 |
| 3 | KEY1 短按 4 次 | 黄框 1→2→3→0 循环；**白框、音乐、字幕、状态条都不变** | 白框跟着走 → 焦点又接回了 `active_index` |
| 4 | KEY2 长按 | 黄框反向走 | — |
| 5 | 黄框移到图片3，KEY1 长按 | 淡黑 → 全屏显示图片3 淡入，字幕/状态条换成图3（没放 MUSIC.WAV 时琶音也换） | 卡黑屏 → `select` 没发，看 `select_busy` |
| 6 | 拿掉 PIC2.BMP 重启，进缩略图 | 右上格深灰底 + 灰 X；黄框走到这格变**红框**，KEY1 长按无反应 | 格子全黑 → `placeholder` 没接 |
| 7 | 缩略图下 KEY2 短按 | 淡变回全屏，还是进来前那张 | 换了图 → `target_index` |
| 8 | 开自动轮播后进缩略图，等 10s | 白框不动（轮播暂停）；回全屏后 3s 再切下一张 | `auto_hold` |
| 9 | 串口 `THUMB` / `SEL` / `FULL` | 都回 `OK`，行为同按键 | parser 的 `hit_sel` |
| 10 | ILA 抓 `thumb_frame_q`/`focus_frame_q`/`active_index` | 只在 `frame_start` 后一拍变化 | 撕裂 → 锁存点 |
