`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第七讲 FAT32文件系统升级
// fat32_storage_ingest_top：开机一次性把TF卡上PIC1~4.BMP摄入到SDRAM 4个固定区。
//
// 和资料原样的 media_storage_ingest_top/media_ingest_pipeline/media_frame_loader
// 的关键区别：资料原样代码直连SDRAM控制器的 App_wr_en/App_wr_addr/App_wr_din/
// App_wr_dm，这会跟本工程显示读取路径（video_timing_data->video_delay->
// frame_read_write读侧）持续不断发的 App_rd_en 在同一个单端口SDRAM核上抢总线——
// frame_read_write.v 内部靠 App_wr_busy/App_rd_busy 互相协调才能安全共享这一个
// SDRAM端口，绕开它直连控制器就丢了这层仲裁，是真实的数据损坏风险。
// 所以本模块改走 frame_read_write 现成的 write_req/write_req_ack/write_en/
// write_data 接口写入，仲裁交给它，不自己碰 App_wr_*。
//
// 【第八讲更新】frame_read_write 已被 media_frame_loader + media_frame_reader
// 取代，上面那层 App_wr_busy/App_rd_busy 仲裁随之消失。新架构改用**时间互斥**
// 保证单端口 SDRAM 安全：开机摄入期只有 loader 写（顶层 player_enable=0，
// reader 一条读指令都不发），摄入完成后只有 reader 读（loader 永久 idle）。
// 所以本模块的写接口从 write_req/write_req_ack/write_en/write_data 换成
// 直接把 bmp24_decoder 的像素流引出去喂 loader：
//   load_start/load_busy/load_done + pixel_valid/pixel_rgb/frame_commit/decode_error。
// loader 与本模块同在 sd_card_clk 域，原来那套 write_finish_toggle 三级同步
// 检脉冲不再需要，删掉；跨到 mem 域由顶层的 media_sdram_write_cdc 负责，
// 它的 dst_idle 同步回本域后作为 cdc_idle 输入，确保整帧真的落进 SDRAM。
//
// 另外资料原样的 media_ingest_pipeline 状态机里，任何一张图解析失败就整批放弃
// （不会继续尝试剩下的图），这里改成单张失败只标记该图 image_complete 位为0，
// 继续尝试下一张，四张都试完才算 ingest_done——和现工程"缺一张图也能正常显示
// 其余几张"的既有策略一致。
//
// 13 张图扩展：IMAGE_COUNT / INDEX_W 参数化（默认 4 / 2），PIC1~n 依次摄入。
// 卷扫描器的复位从 sub_rst_n 改成 rst_n，其输出（每张图的首簇/大小、音乐的
// 起始扇区/扇区数）直接用，不再在本模块锁存一份副本——13 张时那份副本
// 有一千多个触发器。这样改是安全的：sub_abort 只会在 LOAD_START/STREAM/
// FLUSH 三个状态里产生，此时扫描早已结束、扫描器停在 IDLE 不发请求，局部
// 复位它本来就只是清掉这些输出，现在不清了而已。
// -----------------------------------------------------------------------------
module fat32_storage_ingest_top #(
    // 识别阶段（CMD0~CMD58）必须≤400kHz，否则真实SD卡常见CMD0握手不上
    // （ERR_CMD0_TIMEOUT）；100MHz下125对应400kHz，200左右更保守更安全
    parameter integer INIT_SPI_CLK_DIV          = 125,
    // 数据传输阶段（读扇区）用的分频，识别阶段完成后才切换到这个速度
    parameter integer READ_SPI_CLK_DIV          = 4,
    parameter integer BMP_WIDTH                 = 640,
    parameter integer BMP_HEIGHT                = 480,
    parameter integer INIT_STARTUP_DELAY_CYCLES = 4000000,   // 100ms @ 40MHz，实际时钟不同请按需调整
    parameter integer IMAGE_TIMEOUT_CYCLES      = 32'd200_000_000, // 单张图摄入watchdog，约2s@100MHz
    // 第十三讲：非0时 bmp24_decoder 额外接受 2*BMP_WIDTH x 2*BMP_HEIGHT 的源图，
    // 解码时 2x2 求平均缩成 BMP_WIDTH x BMP_HEIGHT（像素数不变，下游无感）。
    // 源文件是 4 倍大，IMAGE_TIMEOUT_CYCLES 要相应放宽。
    parameter integer ALLOW_2X_SOURCE           = 0,
    // 照片缩放自适应：非0时额外接受 BMP_WIDTH..MAX_SOURCE_DIM x BMP_HEIGHT..MAX_SOURCE_DIM
    // 的任意尺寸，居中裁成 4:3 再最近邻缩到 BMP_WIDTH x BMP_HEIGHT（见 bmp24_decoder.v）。
    // 大图读卡时间按约 1MB/s 估算，IMAGE_TIMEOUT_CYCLES 同样要放宽。
    parameter integer ALLOW_SCALE_SOURCE        = 0,
    parameter integer MAX_SOURCE_DIM            = 4096,
    parameter integer IMAGE_COUNT               = 4,
    parameter integer INDEX_W                   = 2
)(
    input  wire        clk,           // sd_card_clk 域
    input  wire        rst_n,         // 本域同步释放复位（rst_n_sd，见第5课 reset_sync）

    input  wire        start,         // 单脉冲：启动一次"扫描+摄入4张图"
    output wire        busy,
    output reg         ingest_done,   // 本轮摄入(不论成败)全部尝试完成，1拍脉冲
    output wire        card_ready,    // SD卡初始化完成且就绪
    output reg  [IMAGE_COUNT-1:0] resource_valid,    // 扫描到的PIC1~n.BMP位图
    // 本模块本地记录的"这张图流程走完且没报错"位图。第八讲后顶层以
    // media_frame_loader 的 image_complete 为准（它还额外校验了像素计数和
    // 落盘字数），这里保留作对照调试用。
    output reg  [IMAGE_COUNT-1:0] image_complete,
    // 调试用：resource_valid==0时具体卡在哪一步。init_error取值范围0x00~0x0c
    // （sd_spi_init.v的ERR_*），scan_error取值范围0x10/0x20/0x21/0x22
    // （fat32_volume_scanner.v的ERR_*），两个命名空间不重叠，可以共用一个输出
    output reg  [7:0]  diag_code,
    // 调试用：fat32_volume_scanner里"匹配最深的目录项"信息，[7:4]匹配深度、
    // [3:0]该项属性位attr[4:1]，直通到顶层数码管排查文件名匹配失败的具体原因
    output wire [7:0]  diag2_code,

    // SD卡物理引脚
    output wire        sd_ncs,
    output wire        sd_dclk,
    output wire        sd_mosi,
    input  wire        sd_miso,

    // 顶层 media_sdram_write_cdc 的 dst_idle 同步回本域：整帧真的落进SDRAM
    input  wire        cdc_idle,

    // 写入 media_frame_loader 的接口（全部在本模块clk=sd_card_clk域）
    output reg         load_start,     // 单拍脉冲：让loader为这张图开一次加载
    input  wire        load_busy,      // loader已接单（相当于原write_req_ack）
    input  wire        load_done,      // loader这张图收尾完成（成功或报错）
    output wire [INDEX_W-1:0] image_index,    // 目标bank编号=图片序号
    output wire        pixel_valid,    // 来自bmp24_decoder
    output wire [23:0] pixel_rgb,
    output wire        frame_commit,   // 整帧像素发完（bmp24_decoder已校验像素数）
    output wire [7:0]  decode_error,   // bmp24_decoder错误码，让loader能及时放弃

    // ===== 第十一讲 WAV音频播放（一图一音）=====
    // 扫描阶段顺带找到的 MUSIC1~n.WAV（打包 {n-1,...,1,0}，每路 32 位）。
    // track_valid 在扫描完成时锁存；起始扇区/扇区数直接取扫描器输出，
    // 只在对应 valid 位为 1 时才有意义，扫描完成后不再变
    output reg  [IMAGE_COUNT-1:0]    track_valid,
    output wire [IMAGE_COUNT*32-1:0] track_start_lba,
    output wire [IMAGE_COUNT*32-1:0] track_sectors,
    // 外部扇区读口（给 wav_stream_player）。SD 卡只有一个 SPI 读引擎，
    // 这里同样用【时间互斥】：开机摄入全部结束、且卡初始化成功之后
    // ext_ready 才拉高，读引擎整体切给外部口；此前 ext_sector_busy 恒为 1，
    // 外部请求不会发出去。摄入只在上电跑一次，交出去后不会再收回。
    output reg         ext_ready,
    input  wire        ext_sector_req,
    input  wire [31:0] ext_sector_lba,
    output wire        ext_sector_busy,
    output wire        ext_sector_done,
    output wire        ext_sector_valid,
    output wire [7:0]  ext_sector_byte,
    output wire [8:0]  ext_sector_byte_index,
    output wire [7:0]  ext_sector_error
);
    localparam [2:0] ST_IDLE          = 3'd0;
    localparam [2:0] ST_SD_INIT       = 3'd1;
    localparam [2:0] ST_SCAN          = 3'd2;
    localparam [2:0] ST_FILE_START    = 3'd3;
    localparam [2:0] ST_LOAD_START    = 3'd4;
    localparam [2:0] ST_STREAM        = 3'd5;
    localparam [2:0] ST_FLUSH         = 3'd6;
    localparam [2:0] ST_NEXT_IMAGE    = 3'd7;

    reg [2:0]  state;
    reg [INDEX_W-1:0] current_image;
    reg        init_start;
    reg        scan_start;
    reg        file_start;
    reg        sub_abort;             // 单张图watchdog超时，强制该图放弃并前进
    reg [31:0] image_timeout_cnt;
    reg        source_done_seen;      // bmp24_decoder已判定这张图流结束
    reg        load_done_seen;        // loader已把这张图收尾（成功或报错）
    reg        latched_frame_commit;  // dec_frame_commit只在bmp_done那一拍有效，要锁存
    reg        dec_error_live;        // 本张的 file_start 已经发出，dec_bmp_error 是本张的（见 decode_error）


    wire init_busy, init_done, init_ready;
    wire [7:0] init_error;
    wire card_high_capacity;

    wire service_sd_cs_n, service_sd_sclk, service_sd_mosi;

    wire        service_sector_req;
    wire [31:0] service_sector_lba;
    wire        service_sector_busy;
    wire        service_sector_done;
    wire        service_sector_valid;
    wire [7:0]  service_sector_byte;
    wire [8:0]  service_sector_byte_index;
    wire [7:0]  service_sector_error;

    wire        replay_busy, replay_valid, replay_done;
    wire [7:0]  replay_byte, replay_error;
    wire [8:0]  replay_byte_index;
    wire        reader_req_from_replay;
    wire [31:0] reader_lba_from_replay;

    wire        scan_busy, scan_done_i;
    wire [7:0]  scan_error;
    wire [7:0]  sectors_per_cluster;
    wire [31:0] fat_start_lba, data_start_lba, max_cluster;
    wire [IMAGE_COUNT-1:0]    scan_resource_valid;
    wire [IMAGE_COUNT*32-1:0] scan_resource_cluster;
    wire [IMAGE_COUNT*32-1:0] scan_resource_size;
    wire        scan_sector_req;
    wire [31:0] scan_sector_lba;
    wire [IMAGE_COUNT-1:0]    scan_track_valid;
    wire        replay_reader_req;
    wire [31:0] replay_reader_lba;

    wire        file_busy, file_done;
    wire        file_valid;
    wire [7:0]  file_byte;
    wire [31:0] file_byte_offset;
    wire [7:0]  file_error;
    wire        file_sector_req;
    wire [31:0] file_sector_lba;

    wire        dec_pixel_valid;
    wire [23:0] dec_pixel_rgb;
    wire        dec_frame_commit;
    wire        dec_bmp_done;
    wire [7:0]  dec_bmp_error;

    reg  [31:0] selected_cluster;
    reg  [31:0] selected_size;

    // 只有单张图watchdog超时才需要局部复位，让卷扫描器/流读取器/仲裁分时复用回到空闲
    // （不复位 sd_media_service，物理SPI初始化状态不受单张图失败影响）
    wire sub_rst_n = rst_n & ~sub_abort;

    assign busy       = (state != ST_IDLE);
    assign card_ready = init_ready;
    assign sd_ncs      = service_sd_cs_n;
    assign sd_dclk     = service_sd_sclk;
    assign sd_mosi     = service_sd_mosi;

    // 直通 bmp24_decoder 的像素流给 loader。注意字节序：原来喂 frame_read_write
    // 时 RGB 放在高24位（{rgb, 8'h00}，读侧取 read_data[31:8]）；loader 内部
    // 自己拼 {8'h00, pixel_rgb}、reader 取 prefetch_data[23:0]，所以这里只传
    // 裸的 24 位 RGB，不要再自己拼字。
    assign image_index  = current_image;
    assign pixel_valid  = dec_pixel_valid;
    assign pixel_rgb    = dec_pixel_rgb;
    assign frame_commit = dec_frame_commit;
    // 单张图watchdog超时(sub_abort)时，loader 既等不到 frame_commit 也等不到
    // decode_error，会一直停在 active 上，下一张的 load_start 因为
    // "load_start && !active" 而被吞掉，整个摄入就卡死在第二张图。所以把
    // sub_abort 也当成一种解码错误报给 loader，让它 fail_load 释放出来。
    // 0x39 接在 bmp24_decoder 的 ERR_* 段(0x31~0x38)之后，命名空间不冲突。
    //
    // dec_bmp_error 要等本张的 file_start 发出之后才转给 loader：bmp24_decoder
    // 到 file_start 那一拍才清上一张的 bmp_error，而 loader 在 load_start 之后、
    // file_start 之前就已经 active 了，中间这两拍看到的是上一张坏图留下的错误码，
    // 会把紧跟着的这张好图也判成 ERR_DECODE——坏一张连带丢下一张，中间隔着没扫到
    // 的图也一样（sim/bad_image 整链路仿真复现过）。sub_abort 是本张自己的
    // watchdog，不受这个门控。
    assign decode_error = (dec_error_live && dec_bmp_error != 8'h00) ? dec_bmp_error :
                          (sub_abort ? 8'h39 : 8'h00);

    // current_image 只会走到 IMAGE_COUNT-1，索引不越界。
    // 13 选 1 的 32 位 mux 后面直接接 bmp24_decoder 的尺寸判断，一拍走不完，
    // 寄存一拍：current_image 在 ST_NEXT_IMAGE 变，file_start 最早也要
    // ST_FILE_START -> ST_LOAD_START 等到 load_busy 之后才发，至少隔 3 拍。
    always @(posedge clk) begin
        selected_cluster <= scan_resource_cluster[current_image*32 +: 32];
        selected_size    <= scan_resource_size[current_image*32 +: 32];
    end

    // sd_media_service.v自己的MAX_ACMD41_ATTEMPTS默认值只有64，是给仿真用的，
    // 远低于sd_spi_init.v内部真正调好的默认值2048（真实TF卡SPI初始化ACMD41
    // 轮询到就绪需要的重试次数），这里显式覆盖回2048，否则真卡会在没就绪前就
    // 被判超时（ERR_ACMD41_TIMEOUT=0x08）
    // MAX_TOKEN_BYTES：读扇区发完 CMD17 后等数据令牌 0xFE 的最多字节数。
    // sd_media_service 的默认值 4096 在 12.5MHz SPI 下只有 2.6ms，而 SD 规范给
    // 读访问时间留到 100ms（SDHC/SDXC 固定 100ms），慢一点的卡第一次读扇区就会
    // 判 ERR_TOKEN_TIMEOUT，扫描器报 0x10、WAV 读一次断一次。200000 字节在
    // 12.5MHz 下约 128ms，盖住规范上限。正常卡几十微秒就回令牌，不影响速度。
    sd_media_service #(
        .SPI_CLK_DIV(INIT_SPI_CLK_DIV),
        .READ_SPI_CLK_DIV(READ_SPI_CLK_DIV),
        .MAX_ACMD41_ATTEMPTS(2048),
        .MAX_TOKEN_BYTES(200000),
        .INIT_STARTUP_DELAY_CYCLES(INIT_STARTUP_DELAY_CYCLES)
    ) u_sd_service (
        .clk(clk), .rst_n(rst_n),
        .init_start(init_start), .init_busy(init_busy), .init_done(init_done),
        .init_ready(init_ready), .init_error(init_error),
        .card_high_capacity(card_high_capacity), .card_ocr(), .owner_reader(),
        .sector_req(service_sector_req), .sector_lba(service_sector_lba),
        .sector_busy(service_sector_busy), .sector_done(service_sector_done),
        .sector_valid(service_sector_valid), .sector_byte(service_sector_byte),
        .sector_byte_index(service_sector_byte_index), .sector_error(service_sector_error),
        .sd_cs_n(service_sd_cs_n), .sd_sclk(service_sd_sclk), .sd_mosi(service_sd_mosi),
        .sd_miso(sd_miso)
    );

    // 扫描器和流读取器共用同一个SD读接口：外层控制逻辑保证扫描和摄入不会同时进行，
    // 所以这里用简单的“谁在请求就转发谁”做仲裁，不需要额外的忙碌互斥
    assign reader_req_from_replay = scan_sector_req | file_sector_req;
    assign reader_lba_from_replay = scan_sector_req ? scan_sector_lba : file_sector_lba;

    sd_sector_replay_buffer u_replay (
        .clk(clk), .rst_n(sub_rst_n),
        .sector_req(reader_req_from_replay), .sector_lba(reader_lba_from_replay),
        .sector_busy(replay_busy), .sector_valid(replay_valid),
        .sector_byte(replay_byte), .sector_byte_index(replay_byte_index),
        .sector_done(replay_done), .sector_error(replay_error),
        .reader_req(replay_reader_req), .reader_lba(replay_reader_lba),
        .reader_busy(service_sector_busy), .reader_valid(service_sector_valid),
        .reader_byte(service_sector_byte), .reader_byte_index(service_sector_byte_index),
        .reader_done(service_sector_done), .reader_error(service_sector_error)
    );

    // 第十一讲：读引擎归属切换。ext_ready 之前只有 replay 缓冲（扫描/摄入）
    // 能发请求；之后只有外部口能发。读引擎的输出广播给两边，
    // replay 缓冲不发请求就停在 ST_IDLE，不理会这些输出。
    assign service_sector_req    = ext_ready ? ext_sector_req : replay_reader_req;
    assign service_sector_lba    = ext_ready ? ext_sector_lba : replay_reader_lba;
    assign ext_sector_busy       = ext_ready ? service_sector_busy : 1'b1;
    assign ext_sector_done       = ext_ready & service_sector_done;
    assign ext_sector_valid      = ext_ready & service_sector_valid;
    assign ext_sector_byte       = service_sector_byte;
    assign ext_sector_byte_index = service_sector_byte_index;
    assign ext_sector_error      = service_sector_error;

    // 复位用 rst_n 而不是 sub_rst_n，见文件头"13 张图扩展"
    fat32_volume_scanner #(
        .IMAGE_COUNT(IMAGE_COUNT), .INDEX_W(INDEX_W)
    ) u_scanner (
        .clk(clk), .rst_n(rst_n), .scan_start(scan_start), .scan_busy(scan_busy),
        .scan_done(scan_done_i), .fs_error(scan_error), .partition_lba(),
        .sectors_per_cluster(sectors_per_cluster), .fat_start_lba(fat_start_lba),
        .data_start_lba(data_start_lba), .max_cluster(max_cluster),
        .resource_valid(scan_resource_valid),
        .resource_cluster(scan_resource_cluster), .resource_size(scan_resource_size),
        .sector_req(scan_sector_req), .sector_lba(scan_sector_lba),
        .sector_busy(replay_busy), .sector_valid(replay_valid), .sector_byte(replay_byte),
        .sector_byte_index(replay_byte_index), .sector_done(replay_done),
        .sector_error(replay_error),
        .track_valid(scan_track_valid), .track_start_lba(track_start_lba),
        .track_sectors(track_sectors),
        .diag2_code(diag2_code)
    );

    fat32_file_streamer u_streamer (
        .clk(clk), .rst_n(sub_rst_n), .file_start(file_start),
        .first_cluster(selected_cluster), .file_size(selected_size),
        .sectors_per_cluster(sectors_per_cluster), .fat_start_lba(fat_start_lba),
        .data_start_lba(data_start_lba), .max_cluster(max_cluster),
        .file_busy(file_busy), .file_done(file_done), .file_valid(file_valid),
        .file_byte(file_byte), .file_byte_offset(file_byte_offset), .fs_error(file_error),
        .sector_req(file_sector_req), .sector_lba(file_sector_lba),
        .sector_busy(replay_busy), .sector_valid(replay_valid), .sector_byte(replay_byte),
        .sector_byte_index(replay_byte_index), .sector_done(replay_done),
        .sector_error(replay_error)
    );

    // 复用工程里已有但之前一直未接入的 bmp24_decoder（hdl_source/stable/），
    // 端口和这里 fat32_file_streamer 的 file_* 输出天然匹配，不需要额外拼装
    bmp24_decoder #(
        .EXPECTED_WIDTH(BMP_WIDTH), .EXPECTED_HEIGHT(BMP_HEIGHT), .ALLOW_2X_SOURCE(ALLOW_2X_SOURCE),
        .ALLOW_SCALE_SOURCE(ALLOW_SCALE_SOURCE), .MAX_SOURCE_DIM(MAX_SOURCE_DIM)
    ) u_bmp24_decoder (
        .clk(clk), .rst_n(rst_n), .file_start(file_start), .file_size(selected_size),
        .file_valid(file_valid), .file_byte(file_byte), .file_byte_offset(file_byte_offset),
        .file_end(file_done), .upstream_error(file_error), .header_accepted(),
        .pixel_valid(dec_pixel_valid), .pixel_rgb(dec_pixel_rgb), .pixel_x(), .pixel_y(),
        .frame_commit(dec_frame_commit), .bmp_done(dec_bmp_done), .bmp_error(dec_bmp_error),
        .top_down(), .pixel_offset(), .row_stride(), .source_scale_2x()
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state             <= ST_IDLE;
            current_image     <= {INDEX_W{1'b0}};
            init_start        <= 1'b0;
            scan_start        <= 1'b0;
            file_start        <= 1'b0;
            load_start        <= 1'b0;
            sub_abort         <= 1'b0;
            image_timeout_cnt <= 32'd0;
            source_done_seen  <= 1'b0;
            load_done_seen    <= 1'b0;
            latched_frame_commit <= 1'b0;
            dec_error_live    <= 1'b0;
            ingest_done       <= 1'b0;
            resource_valid    <= {IMAGE_COUNT{1'b0}};
            image_complete    <= {IMAGE_COUNT{1'b0}};
            diag_code         <= 8'd0;
            track_valid      <= {IMAGE_COUNT{1'b0}};
            ext_ready        <= 1'b0;
        end else begin
            init_start     <= 1'b0;
            scan_start     <= 1'b0;
            file_start     <= 1'b0;
            sub_abort      <= 1'b0;
            ingest_done    <= 1'b0;
            load_start     <= 1'b0;

            // 这两个标志必须跟状态机的case分支解耦，独立每拍检测：load_done
            // 可能在还没进ST_FLUSH之前（比如还在ST_STREAM时）就先到，只在ST_FLUSH里
            // 判断会漏拍卡死。和原sd_card_bmp.v里"if (load_busy && write_finish_pulse)"
            // 不挂在具体state上是同一个道理。
            if (dec_bmp_done) begin
                source_done_seen     <= 1'b1;
                latched_frame_commit <= dec_frame_commit;
            end
            if (load_done)
                load_done_seen <= 1'b1;
            // file_start 这一拍解码器正在清 bmp_error，下一拍起就是本张自己的错误码
            if (file_start)
                dec_error_live <= 1'b1;

            // 第十一讲：本轮摄入结束（成败都算）且卡已就绪，读引擎交给外部口。
            // ingest_done 在本块里是寄存器，这里看到的是上一拍置起的脉冲。
            if (ingest_done && init_ready)
                ext_ready <= 1'b1;

            case (state)
                ST_IDLE: if (start) begin
                    resource_valid    <= {IMAGE_COUNT{1'b0}};
                    image_complete    <= {IMAGE_COUNT{1'b0}};
                    current_image     <= {INDEX_W{1'b0}};
                    init_start        <= 1'b1;
                    state             <= ST_SD_INIT;
                end

                ST_SD_INIT: if (init_done) begin
                    if (!init_ready || init_error != 0) begin
                        // SD卡初始化失败：没有可用图片，直接结束本轮摄入
                        diag_code   <= init_error;
                        ingest_done <= 1'b1;
                        state       <= ST_IDLE;
                    end else begin
                        scan_start <= 1'b1;
                        state      <= ST_SCAN;
                    end
                end

                ST_SCAN: if (scan_done_i) begin
                    // 第十一讲：音频文件有效位在这里锁存（起始扇区/扇区数直接用扫描器输出）
                    track_valid      <= scan_track_valid;
                    if (scan_error != 0) begin
                        // 一张图都没找到（或读盘出错），resource_valid保持全0
                        diag_code   <= scan_error;
                        ingest_done <= 1'b1;
                        state       <= ST_IDLE;
                    end else begin
                        resource_valid <= scan_resource_valid;
                        current_image  <= {INDEX_W{1'b0}};
                        state          <= ST_FILE_START;
                    end
                end

                ST_FILE_START: begin
                    image_timeout_cnt    <= 32'd0;
                    source_done_seen     <= 1'b0;
                    load_done_seen       <= 1'b0;
                    latched_frame_commit <= 1'b0;
                    dec_error_live       <= 1'b0;
                    if (resource_valid[current_image]) begin
                        load_start <= 1'b1;   // 单拍脉冲，下一拍自动清零
                        state      <= ST_LOAD_START;
                    end else begin
                        // 这张图没扫到，跳过，不占用SD/SDRAM带宽
                        state <= ST_NEXT_IMAGE;
                    end
                end

                // load_busy 在这里扮演原来 write_req_ack 的角色：loader 接单了
                // 才让 fat32_file_streamer 开始吐字节，保证第一个像素到达时
                // loader 已经 active（否则 loader 会报 ERR_NOT_ACTIVE=0x41）
                ST_LOAD_START: begin
                    image_timeout_cnt <= image_timeout_cnt + 32'd1;
                    if (load_busy) begin
                        file_start <= 1'b1;
                        state      <= ST_STREAM;
                    end else if (image_timeout_cnt >= IMAGE_TIMEOUT_CYCLES) begin
                        sub_abort <= 1'b1;
                        state     <= ST_NEXT_IMAGE;
                    end
                end

                ST_STREAM: begin
                    image_timeout_cnt <= image_timeout_cnt + 32'd1;
                    if (file_done)
                        state <= ST_FLUSH;
                    else if (image_timeout_cnt >= IMAGE_TIMEOUT_CYCLES) begin
                        sub_abort <= 1'b1;
                        state     <= ST_NEXT_IMAGE;
                    end
                end

                // 三个条件都满足才提交，避免下一张的 load_start 提前发出去和
                // 这一张的 FIFO 排空撞车：
                //   source_done_seen — bmp24_decoder 判完这张图
                //   load_done_seen   — loader 侧 FIFO 排空、整帧收尾
                //   cdc_idle         — media_sdram_write_cdc 也搬空了，数据
                //                      真的落进 SDRAM（loader 的 load_done 只
                //                      管到 CDC 入口，管不到 CDC 里那 512 深 FIFO）
                ST_FLUSH: begin
                    image_timeout_cnt <= image_timeout_cnt + 32'd1;

                    if ((source_done_seen || dec_bmp_done) &&
                        (load_done_seen || load_done) && cdc_idle) begin
                        if (file_error == 8'h00 && dec_bmp_error == 8'h00 &&
                            (latched_frame_commit || dec_frame_commit))
                            image_complete[current_image] <= 1'b1;
                        state <= ST_NEXT_IMAGE;
                    end else if (image_timeout_cnt >= IMAGE_TIMEOUT_CYCLES) begin
                        sub_abort <= 1'b1;
                        state     <= ST_NEXT_IMAGE;
                    end
                end

                ST_NEXT_IMAGE: begin
                    if (current_image == IMAGE_COUNT - 1) begin
                        ingest_done <= 1'b1;
                        state       <= ST_IDLE;
                    end else begin
                        current_image <= current_image + 1'b1;
                        state         <= ST_FILE_START;
                    end
                end

                default: state <= ST_IDLE;
            endcase
        end
    end
endmodule
