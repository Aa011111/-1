`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第七讲 FAT32文件系统升级
// media_playback_selector：预加载架构下的播放控制。
//
// 和原 sd_card_bmp.v 的区别：原来的双缓冲+按需加载架构下，切一张图要重新去SD卡
// 读一次，所以要有 load_busy/load_start_pulse 这套"发起加载->等加载完->才提交
// 显示"的状态机；现在 fat32_storage_ingest_top 已经在开机时把找到的图一次性都
// 摄入到SDRAM固定的4个区了，切图只是换 media_id（即换 frame_read_write 的
// read_addr_index），不需要再等待——所以这里没有加载状态机，只有"在
// image_complete位图里找下一个/上一个置1的位"这一件事。
// 按键消抖/短按切自动播放/长按上一张 这套裁决逻辑和原 sd_card_bmp.v 保持一致。
// -----------------------------------------------------------------------------
module media_playback_selector #(
    parameter integer CLK_FREQ_HZ  = 100_000_000,
    parameter integer LONG_PRESS_MS = 1000,   // KEY2长按触发时间
    parameter integer AUTO_PLAY_MS  = 3000    // 自动轮播间隔
)(
    input  wire       clk,
    input  wire       rst,            // 高有效复位，和原sd_card_bmp端口习惯一致

    input  wire       key_next,       // 下一张，低有效
    input  wire       key_auto,       // 自动播放/长按上一张

    input  wire       ingest_done,    // fat32_storage_ingest_top 摄入完成脉冲
    input  wire [3:0] resource_valid, // FAT32扫描到的PIC1~4.BMP位图（调试用，区分"没扫到"和"扫到但摄入失败"）
    input  wire [3:0] image_complete, // 摄入成功的图片位图

    output reg        display_valid,
    output wire [3:0] state_code,
    output wire [1:0] media_id,
    output wire       auto_play_on,
    output wire [7:0] player_error_code
);
    reg [1:0]  media_id_r;
    reg        auto_play_en;
    reg [31:0] auto_cnt;
    reg [31:0] long_press_cnt;
    reg        long_press_marked;
    reg        key_auto_stable_d;
    reg        ingest_finished;   // ingest_done 是否已经来过一次
    reg [3:0]  fail_reason;       // ingest_finished且display_valid=0时，卡在哪一步

    wire key_next_press;
    wire key_auto_press;
    wire key_auto_stable;
    wire key_auto_release = key_auto_stable & ~key_auto_stable_d;

    wire [2:0] valid_count = image_complete[0] + image_complete[1] +
                             image_complete[2] + image_complete[3];
    wire [31:0] auto_play_cycles = (CLK_FREQ_HZ / 1000) * AUTO_PLAY_MS;
    wire        auto_tick = (auto_cnt == (auto_play_cycles - 1));

    assign media_id           = media_id_r;
    assign auto_play_on       = auto_play_en;
    // 数码管调试码：0=还在摄入中（没结束）；1=摄入结束但一张图都没扫到
    // （SD卡没插好/没格式化成FAT32/根目录没有PIC1~4.BMP这几个名字）；
    // 2=扫到了文件但全部摄入失败（BMP格式/FAT链/写SDRAM超时等）；
    // 3~6=正在显示图0~3（数字+3，给上面两个失败码让位）
    assign state_code         = !ingest_finished ? 4'd0 :
                                 display_valid   ? ({2'b00, media_id_r} + 4'd3) :
                                 fail_reason;
    assign player_error_code  = (display_valid && !image_complete[media_id_r]) ? 8'hB0 : 8'h00;

    function [1:0] next_valid_index;
        input [1:0] cur;
        input [3:0] mask;
        integer i;
        reg [1:0] cand;
        reg       found;
        begin
            cand  = cur;
            found = 1'b0;
            for (i = 0; i < 4; i = i + 1) begin
                cand = cand + 2'd1;
                if (!found && mask[cand]) begin
                    next_valid_index = cand;
                    found = 1'b1;
                end
            end
            if (!found)
                next_valid_index = cur;
        end
    endfunction

    function [1:0] prev_valid_index;
        input [1:0] cur;
        input [3:0] mask;
        integer i;
        reg [1:0] cand;
        reg       found;
        begin
            cand  = cur;
            found = 1'b0;
            for (i = 0; i < 4; i = i + 1) begin
                cand = cand - 2'd1;
                if (!found && mask[cand]) begin
                    prev_valid_index = cand;
                    found = 1'b1;
                end
            end
            if (!found)
                prev_valid_index = cur;
        end
    endfunction

    function [1:0] first_valid_index;
        input [3:0] mask;
        begin
            if (mask[0])      first_valid_index = 2'd0;
            else if (mask[1]) first_valid_index = 2'd1;
            else if (mask[2]) first_valid_index = 2'd2;
            else              first_valid_index = 2'd3;
        end
    endfunction

    fat32_key_press_debounce #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(50)
    ) u_key_next (
        .clk(clk), .rst(rst), .button_in(key_next),
        .press_pulse(key_next_press), .button_stable_out()
    );

    fat32_key_press_debounce #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(20)
    ) u_key_auto (
        .clk(clk), .rst(rst), .button_in(key_auto),
        .press_pulse(key_auto_press), .button_stable_out(key_auto_stable)
    );

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            media_id_r         <= 2'd0;
            display_valid      <= 1'b0;
            auto_play_en       <= 1'b0;
            auto_cnt           <= 32'd0;
            long_press_cnt     <= 32'd0;
            long_press_marked  <= 1'b0;
            key_auto_stable_d  <= 1'b1;
            ingest_finished    <= 1'b0;
            fail_reason        <= 4'd0;
        end else begin
            if (ingest_done) begin
                ingest_finished <= 1'b1;
                if (image_complete != 4'd0) begin
                    media_id_r    <= first_valid_index(image_complete);
                    display_valid <= 1'b1;
                end else begin
                    display_valid <= 1'b0;
                    // resource_valid==0：SD卡初始化失败或FAT32扫描没找到任何一张
                    // PIC1~4.BMP；resource_valid!=0：扫到了文件名，但文件流读取/
                    // BMP解析/写SDRAM某一步全部失败了
                    fail_reason <= (resource_valid == 4'd0) ? 4'd1 : 4'd2;
                end
                auto_play_en <= 1'b0;
                auto_cnt     <= 32'd0;
            end else if (display_valid) begin
                if (key_next_press)
                    media_id_r <= next_valid_index(media_id_r, image_complete);

                // 自动轮播计时：只有找到不止一张图才计时
                if (auto_play_en && (valid_count > 3'd1)) begin
                    if (auto_tick) begin
                        auto_cnt   <= 32'd0;
                        media_id_r <= next_valid_index(media_id_r, image_complete);
                    end else begin
                        auto_cnt <= auto_cnt + 32'd1;
                    end
                end else begin
                    auto_cnt <= 32'd0;
                end

                // KEY2 短按/长按二选一裁决：只在松开那一刻判定，避免一次按压触发两个动作
                key_auto_stable_d <= key_auto_stable;
                if (key_auto_stable == 1'b0) begin
                    if (long_press_cnt < ((CLK_FREQ_HZ / 1000) * LONG_PRESS_MS - 1))
                        long_press_cnt <= long_press_cnt + 32'd1;
                    else
                        long_press_marked <= 1'b1;
                end else begin
                    if (key_auto_release) begin
                        if (long_press_marked)
                            media_id_r <= prev_valid_index(media_id_r, image_complete);
                        else if (valid_count > 3'd1) begin
                            auto_play_en <= ~auto_play_en;
                            auto_cnt     <= 32'd0;
                        end
                    end
                    long_press_cnt    <= 32'd0;
                    long_press_marked <= 1'b0;
                end
            end
        end
    end
endmodule

//按下触发（从原sd_card_bmp.v挪过来，逻辑不变）
module fat32_key_press_debounce #(
        parameter integer CLK_FREQ_HZ = 100_000_000,
        parameter integer DEBOUNCE_MS = 20
    )(
        input  wire clk,
        input  wire rst,
        input  wire button_in,    // 默认：松开=1，按下=0
        output reg  press_pulse,
        output reg  button_stable_out
    );

    localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

    reg button_sync0;
    reg button_sync1;
    reg button_stable;
    reg [31:0] cnt;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            button_sync0      <= 1'b1;
            button_sync1      <= 1'b1;
            button_stable     <= 1'b1;
            cnt               <= 32'd0;
            press_pulse       <= 1'b0;
            button_stable_out <= 1'b1;
        end else begin
            button_sync0 <= button_in;
            button_sync1 <= button_sync0;
            press_pulse  <= 1'b0;

            if (button_sync1 == button_stable) begin
                cnt <= 32'd0;
            end else begin
                if (cnt >= DEBOUNCE_CYCLES - 1) begin
                    if (button_stable && !button_sync1)
                        press_pulse <= 1'b1;
                    button_stable     <= button_sync1;
                    button_stable_out <= button_sync1;
                    cnt               <= 32'd0;
                end else begin
                    cnt <= cnt + 32'd1;
                end
            end
        end
    end
endmodule
