`timescale 1ns/1ps
// 13 张图扩展：图片号改成两位十进制（01~13），状态条从 4 个字符变成 5 个：
//   [图号十位][图号个位][A=自动/E=手动][错误码高位][错误码低位]，宽 40 像素。
// INDEX_W 默认 2，此时十位恒为 0。

module status_osd_overlay #(
    parameter integer OSD_X = 8,
    parameter integer OSD_Y = 8,
    parameter integer INDEX_W = 2
) (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        frame_start,
    input  wire [INDEX_W-1:0] active_index,
    input  wire        auto_enabled,
    input  wire [7:0]  error_code,
    input  wire        in_de,
    input  wire [23:0] in_rgb,
    input  wire [11:0] pixel_x,
    input  wire [11:0] pixel_y,
    output reg  [23:0] out_rgb,
    output reg         out_de,
    output wire        osd_pixel
);
    reg [INDEX_W-1:0] index_q;
    // 图号 = index + 1，拆成两位十进制（最大 19，十位只会是 0 或 1）
    wire [4:0] pic_no   = index_q + 1'b1;
    wire       pic_tens = pic_no >= 5'd10;
    wire [3:0] pic_ones = pic_tens ? pic_no - 5'd10 : pic_no[3:0];
    reg auto_q;
    reg [7:0] error_q;
    reg osd_hit;
    reg [3:0] char_value;
    reg [2:0] char_row;
    reg [2:0] char_col;
    reg [4:0] glyph_row;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            index_q <= {INDEX_W{1'b0}};
            auto_q <= 1'b0;
            error_q <= 8'd0;
        end else if (frame_start) begin
            index_q <= active_index;
            auto_q <= auto_enabled;
            error_q <= error_code;
        end
    end

    function [4:0] font_row;
        input [3:0] value;
        input [2:0] row;
        begin
            case (value)
                4'h0: case(row) 0:font_row=5'b11111;1:font_row=5'b10001;2:font_row=5'b10001;3:font_row=5'b10001;4:font_row=5'b10001;5:font_row=5'b10001;default:font_row=5'b11111; endcase
                4'h1: case(row) 0:font_row=5'b00100;1:font_row=5'b01100;2:font_row=5'b00100;3:font_row=5'b00100;4:font_row=5'b00100;5:font_row=5'b00100;default:font_row=5'b11111; endcase
                4'h2: case(row) 0:font_row=5'b11111;1:font_row=5'b00001;2:font_row=5'b00001;3:font_row=5'b11111;4:font_row=5'b10000;5:font_row=5'b10000;default:font_row=5'b11111; endcase
                4'h3: case(row) 0:font_row=5'b11111;1:font_row=5'b00001;2:font_row=5'b00001;3:font_row=5'b11111;4:font_row=5'b00001;5:font_row=5'b00001;default:font_row=5'b11111; endcase
                4'h4: case(row) 0:font_row=5'b10001;1:font_row=5'b10001;2:font_row=5'b10001;3:font_row=5'b11111;4:font_row=5'b00001;5:font_row=5'b00001;default:font_row=5'b00001; endcase
                4'h5: case(row) 0:font_row=5'b11111;1:font_row=5'b10000;2:font_row=5'b10000;3:font_row=5'b11111;4:font_row=5'b00001;5:font_row=5'b00001;default:font_row=5'b11111; endcase
                4'h6: case(row) 0:font_row=5'b11111;1:font_row=5'b10000;2:font_row=5'b10000;3:font_row=5'b11111;4:font_row=5'b10001;5:font_row=5'b10001;default:font_row=5'b11111; endcase
                4'h7: case(row) 0:font_row=5'b11111;1:font_row=5'b00001;2:font_row=5'b00010;3:font_row=5'b00100;4:font_row=5'b01000;5:font_row=5'b01000;default:font_row=5'b01000; endcase
                4'h8: case(row) 0:font_row=5'b11111;1:font_row=5'b10001;2:font_row=5'b10001;3:font_row=5'b11111;4:font_row=5'b10001;5:font_row=5'b10001;default:font_row=5'b11111; endcase
                4'h9: case(row) 0:font_row=5'b11111;1:font_row=5'b10001;2:font_row=5'b10001;3:font_row=5'b11111;4:font_row=5'b00001;5:font_row=5'b00001;default:font_row=5'b11111; endcase
                4'ha: case(row) 0:font_row=5'b01110;1:font_row=5'b10001;2:font_row=5'b10001;3:font_row=5'b11111;4:font_row=5'b10001;5:font_row=5'b10001;default:font_row=5'b10001; endcase
                4'he: case(row) 0:font_row=5'b11111;1:font_row=5'b10000;2:font_row=5'b10000;3:font_row=5'b11110;4:font_row=5'b10000;5:font_row=5'b10000;default:font_row=5'b11111; endcase
                4'hf: case(row) 0:font_row=5'b11111;1:font_row=5'b10000;2:font_row=5'b10000;3:font_row=5'b11110;4:font_row=5'b10000;5:font_row=5'b10000;default:font_row=5'b10000; endcase
                default: font_row = 5'b00000;
            endcase
        end
    endfunction

    always @* begin
        osd_hit = 1'b0;
        char_value = 4'h0;
        char_row = pixel_y - OSD_Y;
        char_col = pixel_x - OSD_X;
        glyph_row = 5'b00000;
        if (pixel_x >= OSD_X && pixel_x < OSD_X + 40 &&
            pixel_y >= OSD_Y && pixel_y < OSD_Y + 8) begin
            case ((pixel_x - OSD_X) / 8)
                0: char_value = {3'b000, pic_tens};
                1: char_value = pic_ones;
                2: char_value = auto_q ? 4'ha : 4'he;
                3: char_value = error_q[7:4];
                4: char_value = error_q[3:0];
                default: char_value = 4'h0;
            endcase
            glyph_row = font_row(char_value, char_row);
            if ((pixel_x - OSD_X) % 8 < 5 && char_row < 7)
                osd_hit = glyph_row[4 - ((pixel_x - OSD_X) % 8)];
        end
        out_de = in_de;
        out_rgb = in_rgb;
        if (in_de && osd_hit)
            out_rgb = error_q == 0 ? 24'hffff00 : 24'hff4444;
    end

    assign osd_pixel = osd_hit && in_de;
endmodule
