`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第八讲 四bank帧缓存架构
// media_sdram_write_cdc：讲义原件 + 本工程对 dst 侧搬运判决的重构。
//
// 【为什么要改讲义原件】
// 讲义原件的 dst 侧用一对跨域格雷码块指针（src_block_gray / dst_block_gray）
// 决定何时搬运：src 侧每凑满 BURST_SIZE 个字就推进一次块指针，dst 侧看到
// block_pending 就固定搬 BURST_SIZE 个字。这套机制只在"写入总字数恰好是
// BURST_SIZE 整数倍"时才闭合。
//
// 正常情况下本工程是闭合的：一帧 307200 字 / 128 = 2400 整块。但摄入状态机
// 有单张图 watchdog（fat32_storage_ingest_top 的 IMAGE_TIMEOUT_CYCLES），
// 某张图中途 abort 时 loader 只写了非 128 倍数的字数，于是：
//   - 不足一块的残余永远卡在 FIFO 里不搬（dst 侧等不到 block_pending）
//   - 下一张图会先替它把这块凑满才搬走，块边界从此永久错位
//   - 于是每张图结束时 FIFO 里都留着一截同样大小的尾巴，dst_idle 永远为 0
//     -> ST_FLUSH 等不到 cdc_idle -> watchdog 超时 -> 后面每张好图都被误判为失败
// 也就是"一张图坏了会连累后面所有图"。
//
// 试过在块指针上补一条排空路径，但补不干净：dst 把残余排掉之后，src 侧那个
// src_burst_word_count 仍停在半块上，下一块只剩 BURST_SIZE-r 个字就会置起
// block_pending，dst 却按满 BURST_SIZE 去搬，直接读空 FIFO——要修就得把
// "已排空"反馈回 src 域，又是一条新的跨域握手。
//
// 【改法】干脆不用块指针，dst 侧直接看 async_command_fifo 已经提供、但讲义
// 原例化里空着的 rd_level（可读字数）：
//   - level >= BURST_SIZE  -> 发一个满 BURST_SIZE 的 burst（与原行为一致）
//   - src 静默够久且 level != 0 -> 按实际字数把残余搬走
// 没有"块"的概念，也就不存在错位，src 侧只剩溢出检测。
//
// 一个必须小心的点：rd_level 组合路径上有一条 10 级格雷码转二进制链，
// 在 125MHz 上不该每拍都评估，所以这里寄存一拍再用（rd_level_q）。寄存值
// 滞后 = 偏小，本身是安全的（顶多晚发一个 burst）；但 burst 刚结束的一两拍里
// 它会偏大（最后两拍的读还在途中），偏大会导致按虚高的字数发 burst 而读空。
// 所以 burst 之间插一段固定冷却（COOLDOWN_CYCLES）等它稳定下来。
// 代价是每 128 字 burst 多 3 拍间隔（约 2% 吞吐），而写入只发生在开机摄入期、
// 真正的瓶颈是 SD 卡读速度，完全无感。
// -----------------------------------------------------------------------------

module media_sdram_write_cdc #(
    parameter integer ADDR_WIDTH = 21,
    parameter integer FIFO_ADDR_WIDTH = 9,
    parameter integer BURST_SIZE = 128
) (
    input  wire                  src_clk,
    input  wire                  src_rst_n,
    input  wire                  src_wr_en,
    input  wire [ADDR_WIDTH-1:0] src_wr_addr,
    input  wire [3:0]            src_wr_mask,
    input  wire [31:0]           src_wr_data,
    output wire                  src_full,
    output reg                   src_overflow,

    input  wire                  dst_clk,
    input  wire                  dst_rst_n,
    output wire                  dst_app_wr_en,
    output wire [ADDR_WIDTH-1:0] dst_app_wr_addr,
    output wire [3:0]            dst_app_wr_mask,
    output wire [31:0]           dst_app_wr_data,
    output wire                  dst_idle
);
    localparam integer COMMAND_WIDTH = ADDR_WIDTH + 36;
    localparam integer BURST_CNT_W = $clog2(BURST_SIZE + 1);
    localparam integer LEVEL_W     = FIFO_ADDR_WIDTH + 1;
    // src 静默多少个 dst 时钟后，认为这一批写完了，把不足一块的残余搬走。
    // "静默"= rd_level_q 连续这么多拍没变过（见下面 drain_idle_cnt 的清零条件）。
    // loader 在一个 burst 里是逐拍连续供数的，src 每来一个字 level 就会变，
    // 两次变化之间最多隔 ceil(dst/src 频率比) 拍（src=50MHz/dst=125MHz 时 3 拍），
    // 255 拍(约2us@125MHz)绰绰有余，不会把一个正在进行的 burst 误判成"静默"。
    // 摄入状态机换下一张图至少要几十 us（还要等 SD 卡读扇区），也远大于它。
    //
    // 【sd_card_clk 100MHz -> 50MHz 时修过的坑】原来计数器只在"搬着/有整块/
    // 空了"时清零，src 送新字时并不清零，数的其实是"FIFO 非空了多久"而不是
    // "src 静默了多久"。100MHz 下 loader 推 128 字只要 160 个 dst 拍，碰不到 255；
    // 降到 50MHz 后要 320 拍，推到第 ~103 字就被当成静默排空，每个 128 字
    // burst 被拆成 103+25 两段，SDRAM 控制器吃不下非整块 burst，屏幕上每 128
    // 像素出现一条竖向花纹（拆分点 2*(128k+103) mod 640）。现在 level 一变就清零。
    localparam integer DRAIN_IDLE_CYCLES = 255;
    // burst 之间的冷却拍数：等 rd_level_q 把在途的读吸收干净，避免它偏大。
    // 在途最多 2 拍（fifo_rd_en 寄存一拍 + FIFO 内部 rd_accept 一拍），取 3 留余量。
    localparam [1:0] COOLDOWN_CYCLES = 2'd3;

    wire [COMMAND_WIDTH-1:0] fifo_rd_data;
    wire fifo_rd_valid;
    wire fifo_empty;
    wire [LEVEL_W-1:0] fifo_rd_level;
    reg  [LEVEL_W-1:0] fifo_rd_level_q;
    reg  [LEVEL_W-1:0] fifo_rd_level_qq;   // 上一拍的 level_q，用来判断 src 是否还在送数
    reg  fifo_rd_en;
    reg  burst_active;
    reg  [BURST_CNT_W-1:0] burst_remaining;
    reg  [1:0] cooldown;
    reg  [7:0] drain_idle_cnt;

    wire settled        = !burst_active && cooldown == 2'd0;
    wire has_full_burst = fifo_rd_level_q >= BURST_SIZE;
    // 静默排空：FIFO 里有残余、又攒不出整块，这个状态持续够久就说明
    // src 这一批写完了（通常是某张图 watchdog abort 导致字数不是整数块）
    wire drain_due      = (drain_idle_cnt == DRAIN_IDLE_CYCLES) &&
                          (fifo_rd_level_q != 0);
    wire start_burst    = settled && (has_full_burst || drain_due);
    // 满 burst 走 BURST_SIZE；drain 只在 level < BURST_SIZE 时成立，
    // 两者都装得进 BURST_CNT_W 位
    localparam [BURST_CNT_W-1:0] BURST_WORDS = BURST_SIZE;
    wire [BURST_CNT_W-1:0] next_burst_words =
        has_full_burst ? BURST_WORDS : fifo_rd_level_q[BURST_CNT_W-1:0];

    async_command_fifo #(
        .DATA_WIDTH(COMMAND_WIDTH),
        .ADDR_WIDTH(FIFO_ADDR_WIDTH)
    ) u_fifo (
        .wr_clk(src_clk), .wr_rst_n(src_rst_n),
        .wr_en(src_wr_en),
        .wr_data({src_wr_addr, src_wr_mask, src_wr_data}),
        .wr_full(src_full),
        .rd_clk(dst_clk), .rd_rst_n(dst_rst_n),
        .rd_en(fifo_rd_en), .rd_data(fifo_rd_data),
        .rd_valid(fifo_rd_valid), .rd_empty(fifo_empty),
        .rd_level(fifo_rd_level)
    );

    // src 侧只剩溢出检测：media_frame_loader 没有 ready 反压输入、看不到
    // src_full，真溢出了只能在这里立旗，由顶层报成 0x47
    always @(posedge src_clk or negedge src_rst_n) begin
        if (!src_rst_n)
            src_overflow <= 1'b0;
        else if (src_wr_en && src_full)
            src_overflow <= 1'b1;
    end

    always @(posedge dst_clk or negedge dst_rst_n) begin
        if (!dst_rst_n) begin
            fifo_rd_en      <= 1'b0;
            burst_active    <= 1'b0;
            burst_remaining <= 0;
            cooldown        <= 2'd0;
            drain_idle_cnt  <= 8'd0;
            fifo_rd_level_q <= 0;
            fifo_rd_level_qq <= 0;
        end else begin
            fifo_rd_en      <= 1'b0;
            fifo_rd_level_q <= fifo_rd_level;
            fifo_rd_level_qq <= fifo_rd_level_q;

            if (burst_active)
                cooldown <= COOLDOWN_CYCLES;
            else if (cooldown != 2'd0)
                cooldown <= cooldown - 2'd1;

            // 只在"攒不出整块、但 FIFO 里还有残余、且 src 没在送数"时计时；
            // 有整块可搬、正在搬、已经搬空了、或 level 刚变过（src 还在写），
            // 都清零重新计
            if (!settled || has_full_burst || fifo_rd_level_q == 0 ||
                fifo_rd_level_q != fifo_rd_level_qq)
                drain_idle_cnt <= 8'd0;
            else if (drain_idle_cnt != DRAIN_IDLE_CYCLES)
                drain_idle_cnt <= drain_idle_cnt + 8'd1;

            if (start_burst) begin
                burst_active    <= 1'b1;
                burst_remaining <= next_burst_words;
                drain_idle_cnt  <= 8'd0;
            end else if (burst_active) begin
                fifo_rd_en <= 1'b1;
                if (burst_remaining == 1) begin
                    burst_active    <= 1'b0;
                    burst_remaining <= 0;
                end else begin
                    burst_remaining <= burst_remaining - 1'b1;
                end
            end
        end
    end

    assign dst_app_wr_en   = fifo_rd_valid;
    assign dst_app_wr_addr = fifo_rd_data[COMMAND_WIDTH-1:36];
    assign dst_app_wr_mask = fifo_rd_data[35:32];
    assign dst_app_wr_data = fifo_rd_data[31:0];
    // 摄入状态机靠它判断整帧真的落进 SDRAM 了。fifo_empty 是 dst 域寄存器，
    // 已经涵盖"没有残余"；再加上没有在搬、没有在途数据，才算真空闲。
    assign dst_idle = fifo_empty && !burst_active && !fifo_rd_valid &&
                      fifo_rd_level_q == 0;
endmodule

module async_command_fifo #(
    parameter integer DATA_WIDTH = 57,
    parameter integer ADDR_WIDTH = 9
) (
    input  wire                  wr_clk,
    input  wire                  wr_rst_n,
    input  wire                  wr_en,
    input  wire [DATA_WIDTH-1:0] wr_data,
    output reg                   wr_full,

    input  wire                  rd_clk,
    input  wire                  rd_rst_n,
    input  wire                  rd_en,
    output reg  [DATA_WIDTH-1:0] rd_data,
    output reg                   rd_valid,
    output reg                   rd_empty,
    output wire [ADDR_WIDTH:0]   rd_level
);
    localparam integer PTR_WIDTH = ADDR_WIDTH + 1;
    localparam integer DEPTH = 1 << ADDR_WIDTH;

    reg [DATA_WIDTH-1:0] memory [0:DEPTH-1];
    reg [PTR_WIDTH-1:0] wr_binary;
    reg [PTR_WIDTH-1:0] wr_gray;
    reg [PTR_WIDTH-1:0] rd_binary;
    reg [PTR_WIDTH-1:0] rd_gray;
    reg [PTR_WIDTH-1:0] rd_gray_sync1;
    reg [PTR_WIDTH-1:0] rd_gray_sync2;
    reg [PTR_WIDTH-1:0] wr_gray_sync1;
    reg [PTR_WIDTH-1:0] wr_gray_sync2;

    wire wr_accept = wr_en && !wr_full;
    wire rd_accept = rd_en && !rd_empty;
    wire [PTR_WIDTH-1:0] wr_binary_next = wr_binary + wr_accept;
    wire [PTR_WIDTH-1:0] rd_binary_next = rd_binary + rd_accept;
    wire [PTR_WIDTH-1:0] wr_gray_next =
        (wr_binary_next >> 1) ^ wr_binary_next;
    wire [PTR_WIDTH-1:0] rd_gray_next =
        (rd_binary_next >> 1) ^ rd_binary_next;
    wire wr_full_next = wr_gray_next ==
        {~rd_gray_sync2[PTR_WIDTH-1:PTR_WIDTH-2],
         rd_gray_sync2[PTR_WIDTH-3:0]};
    wire rd_empty_next = rd_gray_next == wr_gray_sync2;

    function [PTR_WIDTH-1:0] gray_to_binary;
        input [PTR_WIDTH-1:0] value;
        integer bit_index;
        begin
            gray_to_binary[PTR_WIDTH-1] = value[PTR_WIDTH-1];
            for (bit_index = PTR_WIDTH-2; bit_index >= 0;
                 bit_index = bit_index - 1)
                gray_to_binary[bit_index] =
                    gray_to_binary[bit_index+1] ^ value[bit_index];
        end
    endfunction

    wire [PTR_WIDTH-1:0] wr_binary_rd = gray_to_binary(wr_gray_sync2);
    assign rd_level = wr_binary_rd - rd_binary;

    always @(posedge wr_clk or negedge wr_rst_n) begin
        if (!wr_rst_n) begin
            wr_binary <= 0;
            wr_gray <= 0;
            rd_gray_sync1 <= 0;
            rd_gray_sync2 <= 0;
            wr_full <= 1'b0;
        end else begin
            rd_gray_sync1 <= rd_gray;
            rd_gray_sync2 <= rd_gray_sync1;
            if (wr_accept)
                memory[wr_binary[ADDR_WIDTH-1:0]] <= wr_data;
            wr_binary <= wr_binary_next;
            wr_gray <= wr_gray_next;
            wr_full <= wr_full_next;
        end
    end

    always @(posedge rd_clk or negedge rd_rst_n) begin
        if (!rd_rst_n) begin
            rd_binary <= 0;
            rd_gray <= 0;
            wr_gray_sync1 <= 0;
            wr_gray_sync2 <= 0;
            rd_data <= 0;
            rd_valid <= 1'b0;
            rd_empty <= 1'b1;
        end else begin
            wr_gray_sync1 <= wr_gray;
            wr_gray_sync2 <= wr_gray_sync1;
            rd_valid <= rd_accept;
            if (rd_accept)
                rd_data <= memory[rd_binary[ADDR_WIDTH-1:0]];
            rd_binary <= rd_binary_next;
            rd_gray <= rd_gray_next;
            rd_empty <= rd_empty_next;
        end
    end
endmodule
