`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十三讲 图片缩放与缩略图：在讲义原件上加"缩略图读模式"（thumb_mode）。
// thumb_mode=0 时每一拍、每个地址都与原件相同。
//
// 缩略图模式 = 2x2 铺满整屏，每格 (FRAME_WIDTH/2)x(FRAME_HEIGHT/2)，
// 4 张图各 2:1 最近邻缩小（source_x = local_x*2, source_y = local_y*2，
// 与 display/thumbnail_layout.v 的映射一致）。
//
// 【为什么不按像素坐标去"跳着读"】sdr_as_ram 是加密 IP，原件的读 burst
// 永远是 128 字对齐的连续地址，从不跨 SDRAM 行（256 字）。逐像素跳地址会让一个
// burst 跨行，这种访问模式 IP 支不支持没法验证。所以这里保持 burst 形态不变：
//   - 每条屏幕行 y 需要两张图（左/右）各一条源行 sy = (y mod 240)*2；
//     一条源行 640 字 = 5 个整 128 字 burst，起址 bank_base + sy*640 天然 128 对齐；
//   - 读回来的字只把偶数列写进 FIFO（丢奇数列），就是 2:1 最近邻的水平抽取；
//   - 一帧读 2*IMAGE_WORDS 字，写进 FIFO 的仍是 IMAGE_WORDS 字，
//     pix 侧消费节奏、underflow 判据与全屏模式完全相同。
// 带宽：读量翻倍 = 每行 1280 字 / 32us，约占 125MHz 下 burst 能力的 35%，够用。
// FIFO 预留仍按"每 burst 128 字"算，缩略图模式实际只写 64 字——偏保守，安全。
//
// thumb_mode 与 active_index 一样在 frame_start 被整帧锁定，随同一个 request
// toggle 跨到 mem 域；它比 toggle 早一个像素拍（5 个 mem 拍）稳定，采样无竞争。
//
// 16 位色存储（PACK_RGB565=1，与 media_frame_loader 同名参数必须一致）：
// 每字 = {右像素565, 左像素565}，每张图 IMAGE_WORDS/2 字，一条源行 320 字。
//   - 全屏：一帧读 IMAGE_WORDS/2 字，pix 侧每字拆两个像素（先低半字后高半字），
//     每消费两个像素才从 prefetch 弹一个字；
//   - 缩略图：源行 320 字切成 5 个 64 字 burst（起址 64 对齐，仍不跨 256 字
//     SDRAM 行），字全部进 FIFO，pix 侧每字只取低半字 = 偶数列，正好是 2:1 抽取；
//     一帧读 480*2*320 = IMAGE_WORDS 字，pix 侧每像素弹一个字。
//   - 565 -> 888 用高位回填（0x1F -> 0xFF），纯白纯黑不偏色。
// consumed_count_pix 始终按像素计，underflow 判据不变。
// PACK_RGB565=0 时与改造前逐位等价。DIAG_* 两个诊断模式只按 24 位格式写，
// 打开它们时须 PACK_RGB565=0。
//
// 13 张图扩展（默认参数下与改造前逐位等价）：
//   - IMAGE_COUNT / INDEX_W：bank 数和 index 位宽；bank 基址按常量表查。
//   - THUMB_COLS / THUMB_ROWS：缩略图网格，缩小倍数 = 列数（要求列数 = 行数）。
//     读序列从"左/右两半"推广成"第 t_col 列"：每条屏幕行依次读 THUMB_COLS 张图
//     各一条源行。水平抽取 = 每 KEEP_EVERY 个字留一个：
//       24 位 2x2：每 2 字留 1（原样）；565 2x2：字字都留（pix 侧取低半字）；
//       565 4x4：每 2 字留 1，再取低半字 = 每 4 个像素取 1。
//     4x4 下一帧读 480*4*320 = 614400 字，与 24 位 2x2 的读量相同。
//   - 缩略图格子号 >= IMAGE_COUNT（4x4 的后 3 格）一律读 bank0：数据由 pix 侧
//     遮掉，这样读地址永远不会越出已用的 SDRAM 范围。
//   - mem 域 reload 时直接取 index_sync2_mem（当拍值），不再用检测到 toggle
//     那一拍锁下的值：reload 至少比检测晚一拍，多位 index 已经稳定。
//   - 读地址不再例化 display/thumbnail_layout 做"屏幕行 -> 源图/源行"映射：
//     4x4 时格高 120 不是 2 的幂，那套比较+减法在 125MHz 下一拍走不完。
//     改成随 t_row 一起走的两个计数器 t_ly（格内行 0..THUMB_H-1）/ t_crow
//     （格子行），源行 = t_ly * THUMB_ROWS、源图 = t_crow * COLS + t_col，
//     都是移位/小常数，与 thumbnail_layout 的映射逐项相同。
// -----------------------------------------------------------------------------

module media_frame_reader #(
    parameter integer ADDR_WIDTH = 21,
    parameter integer IMAGE_WORDS = 307200,
    parameter integer FIFO_DEPTH = 512,
    parameter integer FIFO_MARGIN = 8,
    parameter integer BURST_SIZE = 128,
    parameter integer BURST_GAP_CYCLES = 12,
    parameter integer MAX_INFLIGHT_BURSTS = 2,
    parameter integer DIAG_RETURN_PATTERN = 0,
    parameter integer DIAG_SYNTH_STREAM = 0,
    // 第十三讲：缩略图模式的源图尺寸。约束：FRAME_WIDTH 是 BURST_SIZE 的整数倍
    // （640 = 5*128，源行起址才 burst 对齐）、BURST_SIZE 为偶数（奇偶抽取才不
    // 跨 burst 错位）、FRAME_WIDTH*FRAME_HEIGHT == IMAGE_WORDS。
    parameter integer FRAME_WIDTH = 640,
    parameter integer FRAME_HEIGHT = 480,
    // 1 = RGB565 两像素一字；0 = 原来的一像素一字（24 位）
    parameter integer PACK_RGB565 = 0,
    parameter integer IMAGE_COUNT = 4,
    parameter integer INDEX_W = 2,
    parameter integer THUMB_COLS = 2,
    parameter integer THUMB_ROWS = 2,
    parameter integer CELL_W = 2         // 缩略图格子号位宽，>= clog2(COLS*ROWS)
) (
    input  wire                  mem_clk,
    input  wire                  mem_rst_n,
    input  wire                  controller_init_done,
    input  wire                  controller_busy,
    input  wire                  refresh_active,
    output reg                   app_rd_en,
    output reg  [ADDR_WIDTH-1:0] app_rd_addr,
    input  wire                  sdram_rd_valid,
    input  wire [31:0]           sdram_rd_data,

    input  wire                  pix_clk,
    input  wire                  pix_rst_n,
    input  wire                  frame_start,
    input  wire [INDEX_W-1:0]    active_index,
    input  wire                  thumb_mode,     // 第十三讲：pix 域电平，frame_start 时锁定
    input  wire                  pixel_consume,
    output wire [23:0]           pixel_rgb,
    output wire                  pixel_valid,
    output reg                   underflow,

    output reg                   reader_busy,
    output reg                   frame_read_done,
    output reg  [INDEX_W-1:0]    reader_index,
    output reg  [7:0]            reader_error
);
    localparam [7:0] ERR_NONE          = 8'h00;
    localparam [7:0] ERR_FRAME_OVERRUN = 8'h61;
    localparam [7:0] ERR_FIFO_OVERFLOW = 8'h62;
    localparam [7:0] ERR_UNDERFLOW     = 8'h63;
    localparam [7:0] ERR_SHORT_FRAME   = 8'h64;
    localparam integer FIFO_COUNT_W = (FIFO_DEPTH <= 2) ? 1 : $clog2(FIFO_DEPTH);
    localparam integer BURST_COUNT_W =
        (BURST_SIZE < 2) ? 1 : $clog2(BURST_SIZE + 1);
    localparam integer INFLIGHT_COUNT_W =
        (MAX_INFLIGHT_BURSTS * BURST_SIZE < 2) ? 1 :
        $clog2(MAX_INFLIGHT_BURSTS * BURST_SIZE + 1);

    reg request_pending_pix;
    reg request_toggle_pix;
    reg [INDEX_W-1:0] request_index_pix;
    reg frame_armed_pix;
    reg [ADDR_WIDTH:0] consumed_count_pix;

    reg request_sync1_mem;
    reg request_sync2_mem;
    reg request_seen_mem;
    reg [INDEX_W-1:0] index_sync1_mem;
    reg [INDEX_W-1:0] index_sync2_mem;
    reg reload_pending_mem;
    reg [2:0] fifo_reset_count_mem;
    reg [ADDR_WIDTH:0] issued_count_mem;
    reg [ADDR_WIDTH:0] returned_count_mem;
    reg [INFLIGHT_COUNT_W-1:0] inflight_count_mem;
    reg inflight_empty_mem /* fehdl keep="true" */;
    reg burst_active_mem;
    reg [BURST_COUNT_W-1:0] burst_issued_mem;
    reg [BURST_COUNT_W-1:0] burst_target_mem;
    reg [7:0] burst_gap_count_mem;
    reg [ADDR_WIDTH:0] diag_written_count_mem;
    reg [9:0] diag_column_mem;
    reg [23:0] diag_rgb_mem;
    reg [1:0] fifo_release_mem;
    reg [1:0] fifo_release_pix;

    // ---- 第十三讲：缩略图读模式 ----
    localparam integer THUMB_W = FRAME_WIDTH / THUMB_COLS;
    localparam integer THUMB_H = FRAME_HEIGHT / THUMB_ROWS;
    localparam integer COL_W   = (THUMB_COLS <= 2) ? 1 : $clog2(THUMB_COLS);
    // 存储格式：每张图字数、每条源行字数、缩略图 burst 长度
    localparam integer BANK_WORDS  = (PACK_RGB565 != 0) ? IMAGE_WORDS / 2 : IMAGE_WORDS;
    localparam integer ROW_WORDS   = (PACK_RGB565 != 0) ? FRAME_WIDTH / 2 : FRAME_WIDTH;
    localparam integer THUMB_BURST = (PACK_RGB565 != 0) ? BURST_SIZE / 2 : BURST_SIZE;
    localparam integer ROW_BURSTS = ROW_WORDS / THUMB_BURST;        // 640/128 = 320/64 = 5
    localparam integer BLK_W = (ROW_BURSTS <= 2) ? 1 : $clog2(ROW_BURSTS);
    // 每屏幕行读 THUMB_COLS 条整源行
    localparam integer THUMB_FRAME_READS = ROW_WORDS * FRAME_HEIGHT * THUMB_COLS;
    // 水平抽取：每 KEEP_EVERY 个返回字留一个（缩小倍数 / 每字像素数）
    localparam integer PIX_PER_WORD = (PACK_RGB565 != 0) ? 2 : 1;
    localparam integer KEEP_EVERY   = (THUMB_COLS > PIX_PER_WORD) ? THUMB_COLS / PIX_PER_WORD : 1;
    localparam [ADDR_WIDTH:0] KEEP_MASK = KEEP_EVERY - 1;

    reg request_thumb_pix;
    reg thumb_sync1_mem;
    reg thumb_sync2_mem;
    reg reload_thumb_mem;
    reg thumb_active_mem;          // 当前这一帧是否按缩略图读
    // 读序列游标：屏幕行 t_row -> 第 t_col 列 -> 源行内第 t_blk 个 burst
    reg [BLK_W-1:0] t_blk_mem;
    reg [COL_W-1:0] t_col_mem;
    reg [11:0] t_row_mem;
    localparam integer ROWSEL_W = (THUMB_ROWS <= 2) ? 1 : $clog2(THUMB_ROWS);
    reg [9:0] t_ly_mem;                // 格内行号
    reg [ROWSEL_W-1:0] t_crow_mem;     // 格子行号
    // 地址三级流水：游标 -> (源图号, 源行) -> (bank 基址, 行偏移, burst 偏移) -> burst 起址。
    // 游标只在 burst 结束时变，下一个 burst 至少隔 BURST_GAP_CYCLES 拍才开始
    // （重载时 fifo_reset_count 也至少 4 拍），三拍流水早已稳定；拆级只是为了
    // 125MHz 下单拍组合路径短。原来两级时"行号 x ROW_WORDS"的乘法器（DSP，
    // clk2q 3.4ns）后面直接串三个加法器，是 ext_mem_clk 最差的一条路径，余量
    // 只有 0.2ns 左右，加了串口补发后布局一变就差 0.08ns 不收敛，所以把三项先寄存。
    wire [CELL_W-1:0] t_layout_index = t_crow_mem * THUMB_COLS + t_col_mem;
    wire [9:0] t_layout_y = t_ly_mem * THUMB_ROWS;
    reg [INDEX_W-1:0] t_src_index_mem;
    reg [9:0] t_src_y_mem;
    reg [BLK_W-1:0] t_src_blk_mem;
    reg [ADDR_WIDTH-1:0] t_bank_base_mem;
    reg [ADDR_WIDTH-1:0] t_row_offset_mem;
    reg [ADDR_WIDTH-1:0] t_blk_offset_mem;
    reg [ADDR_WIDTH-1:0] t_burst_base_mem;
    wire [ADDR_WIDTH:0] frame_words_mem =
        thumb_active_mem ? THUMB_FRAME_READS : BANK_WORDS;
    // 2:1 水平抽取：源行 640 字、burst 128 字都是偶数，
    // 所以"返回序号为偶数"就等于"源列为偶数"。推广到 KEEP_EVERY：
    // 源行字数、burst 长度都是 KEEP_EVERY 的整数倍，返回序号取模即可。
    // 565 格式下每字再在 pix 侧取低半字
    wire keep_word = !thumb_active_mem || ((returned_count_mem & KEEP_MASK) == 0);

    wire fifo_reset_request = !mem_rst_n || !pix_rst_n ||
                              (fifo_reset_count_mem != 0);
    wire fifo_reset = fifo_reset_request ||
                      !fifo_release_mem[1] || !fifo_release_pix[1];
    wire fifo_full;
    wire fifo_empty;
    wire fifo_almost_full;
    wire [FIFO_COUNT_W-1:0] fifo_wrusedw;
    wire [31:0] fifo_raw_data;
    wire fifo_raw_valid;
    wire fifo_raw_read_en;
    wire prefetch_valid;
    wire [31:0] prefetch_data;
    wire pixel_pop = pixel_consume && prefetch_valid;
    // 565 拆包：pix_half=1 表示当前字的低半字已经用掉，正在出高半字。
    // 全屏每两个像素弹一个字，缩略图每个像素弹一个字（只用低半字）
    reg  pix_half;
    wire word_pop = pixel_pop &&
                    ((PACK_RGB565 == 0) || request_thumb_pix || pix_half);
    wire [ADDR_WIDTH:0] inflight_words =
        {{(ADDR_WIDTH+1-INFLIGHT_COUNT_W){1'b0}}, inflight_count_mem};
    wire final_return = returned_count_mem == frame_words_mem - 1;
    wire [ADDR_WIDTH+1:0] reserved_words =
        {{(ADDR_WIDTH+2-FIFO_COUNT_W){1'b0}}, fifo_wrusedw} +
        {{1{1'b0}}, inflight_words};
    localparam integer FULL_BURSTS_ONLY = (BANK_WORDS % BURST_SIZE) == 0;
    wire [ADDR_WIDTH:0] remaining_words = frame_words_mem - issued_count_mem;
    // 565 缩略图固定按 THUMB_BURST(64) 字一个 burst，与 t_blk 游标一一对应
    wire [ADDR_WIDTH:0] next_burst_words =
        ((PACK_RGB565 != 0) && thumb_active_mem) ? THUMB_BURST :
        FULL_BURSTS_ONLY ? BURST_SIZE :
        ((remaining_words > BURST_SIZE) ? BURST_SIZE : remaining_words);
    wire [ADDR_WIDTH+2:0] reserved_after_burst =
        {{1{1'b0}}, reserved_words} + {{2{1'b0}}, next_burst_words};
    wire inflight_window_ok = (MAX_INFLIGHT_BURSTS == 1) ?
        inflight_empty_mem :
        ((inflight_words + next_burst_words) <=
         (MAX_INFLIGHT_BURSTS * BURST_SIZE));
    wire fifo_reservation_ok =
        reserved_after_burst <= (FIFO_DEPTH - FIFO_MARGIN);
    reg inflight_window_ok_q;
    reg fifo_reservation_ok_q;
    wire start_burst = !DIAG_SYNTH_STREAM && reader_busy && controller_init_done &&
                       fifo_reset_count_mem == 0 && !burst_active_mem &&
                       burst_gap_count_mem == 0 &&
                       issued_count_mem != frame_words_mem &&
                       inflight_window_ok_q && fifo_reservation_ok_q;
    wire issue_allowed = !DIAG_SYNTH_STREAM && reader_busy && burst_active_mem;
    wire diag_stream_write = DIAG_SYNTH_STREAM && reader_busy &&
                             !fifo_reset && !fifo_full;
    wire fifo_write_enable = DIAG_SYNTH_STREAM ? diag_stream_write :
                             (sdram_rd_valid && keep_word && !fifo_reset && !fifo_full);
    wire [31:0] fifo_write_data = (DIAG_RETURN_PATTERN || DIAG_SYNTH_STREAM) ?
                                  {8'h00, diag_rgb_mem} : sdram_rd_data;

    always @* begin
        if (diag_column_mem < 10'd80)
            diag_rgb_mem = 24'hffffff;
        else if (diag_column_mem < 10'd160)
            diag_rgb_mem = 24'hffff00;
        else if (diag_column_mem < 10'd240)
            diag_rgb_mem = 24'h00ffff;
        else if (diag_column_mem < 10'd320)
            diag_rgb_mem = 24'h00ff00;
        else if (diag_column_mem < 10'd400)
            diag_rgb_mem = 24'hff00ff;
        else if (diag_column_mem < 10'd480)
            diag_rgb_mem = 24'hff0000;
        else if (diag_column_mem < 10'd560)
            diag_rgb_mem = 24'h0000ff;
        else
            diag_rgb_mem = 24'h000000;
    end

    // 常量表：越界 index 落到最后一个 bank，与改造前 case 的 default 一致
    function [ADDR_WIDTH-1:0] bank_base;
        input [INDEX_W-1:0] index;
        integer k;
        begin
            bank_base = (IMAGE_COUNT - 1) * BANK_WORDS;
            for (k = 0; k < IMAGE_COUNT; k = k + 1)
                if (index == k)
                    bank_base = k * BANK_WORDS;
        end
    endfunction

    // Delay the request by one pixel clock so media_player_control can commit
    // active_index on the frame_start edge before this module captures it.
    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            request_pending_pix <= 1'b0;
            request_toggle_pix <= 1'b0;
            request_index_pix <= {INDEX_W{1'b0}};
            request_thumb_pix <= 1'b0;
            frame_armed_pix <= 1'b0;
            consumed_count_pix <= 0;
            pix_half <= 1'b0;
            underflow <= 1'b0;
            fifo_release_pix <= 2'b00;
        end else begin
            if (fifo_reset_request)
                fifo_release_pix <= 2'b00;
            else
                fifo_release_pix <= {fifo_release_pix[0], 1'b1};

            if (frame_start) begin
                if (frame_armed_pix && consumed_count_pix != IMAGE_WORDS) begin
                    underflow <= 1'b1;
                end
                consumed_count_pix <= 0;
                // 新一帧的 FIFO 复位在这之后才发生，这里先把拆包相位对齐到低半字
                pix_half <= 1'b0;
                request_pending_pix <= 1'b1;
                // 第十三讲：模式在 frame_start 这一拍锁定，比下一拍的 toggle 早一拍
                request_thumb_pix <= thumb_mode;
            end else if (request_pending_pix) begin
                request_index_pix <= active_index;
                request_toggle_pix <= ~request_toggle_pix;
                request_pending_pix <= 1'b0;
                frame_armed_pix <= 1'b1;
            end

            if (pixel_consume) begin
                if (prefetch_valid)
                    consumed_count_pix <= consumed_count_pix + 1'b1;
                else if (frame_armed_pix)
                    underflow <= 1'b1;
            end
            // 缩略图每字只用低半字，相位始终停在 0
            if (pixel_pop && !frame_start && (PACK_RGB565 != 0) && !request_thumb_pix)
                pix_half <= ~pix_half;
        end
    end

    always @(posedge mem_clk or negedge mem_rst_n) begin
        if (!mem_rst_n) begin
            request_sync1_mem <= 1'b0;
            request_sync2_mem <= 1'b0;
            request_seen_mem <= 1'b0;
            index_sync1_mem <= {INDEX_W{1'b0}};
            index_sync2_mem <= {INDEX_W{1'b0}};
            reload_pending_mem <= 1'b0;
            thumb_sync1_mem <= 1'b0;
            thumb_sync2_mem <= 1'b0;
            reload_thumb_mem <= 1'b0;
            thumb_active_mem <= 1'b0;
            t_blk_mem <= 0;
            t_col_mem <= 0;
            t_row_mem <= 12'd0;
            t_ly_mem <= 10'd0;
            t_crow_mem <= 0;
            fifo_reset_count_mem <= 3'd0;
            issued_count_mem <= 0;
            returned_count_mem <= 0;
            inflight_count_mem <= 0;
            inflight_empty_mem <= 1'b1;
            burst_active_mem <= 1'b0;
            burst_issued_mem <= 0;
            burst_target_mem <= 0;
            burst_gap_count_mem <= 0;
            diag_written_count_mem <= 0;
            diag_column_mem <= 0;
            fifo_release_mem <= 2'b00;
            inflight_window_ok_q <= 1'b1;
            fifo_reservation_ok_q <= 1'b1;
            app_rd_en <= 1'b0;
            app_rd_addr <= 0;
            reader_busy <= 1'b0;
            frame_read_done <= 1'b0;
            reader_index <= {INDEX_W{1'b0}};
            reader_error <= ERR_NONE;
        end else begin
            if (fifo_reset_request)
                fifo_release_mem <= 2'b00;
            else
                fifo_release_mem <= {fifo_release_mem[0], 1'b1};

            request_sync1_mem <= request_toggle_pix;
            request_sync2_mem <= request_sync1_mem;
            index_sync1_mem <= request_index_pix;
            index_sync2_mem <= index_sync1_mem;
            thumb_sync1_mem <= request_thumb_pix;
            thumb_sync2_mem <= thumb_sync1_mem;
            app_rd_en <= 1'b0;
            frame_read_done <= 1'b0;
            inflight_window_ok_q <= inflight_window_ok;
            fifo_reservation_ok_q <= fifo_reservation_ok;

            if (fifo_reset_count_mem != 0)
                fifo_reset_count_mem <= fifo_reset_count_mem - 1'b1;
            if (burst_gap_count_mem != 0)
                burst_gap_count_mem <= burst_gap_count_mem - 1'b1;

            case ({issue_allowed, sdram_rd_valid})
                2'b10: begin
                    inflight_count_mem <= inflight_count_mem + 1'b1;
                    inflight_empty_mem <= 1'b0;
                end
                2'b01: begin
                    if (!inflight_empty_mem) begin
                        inflight_count_mem <= inflight_count_mem - 1'b1;
                        if (inflight_count_mem == 1)
                            inflight_empty_mem <= 1'b1;
                    end
                end
                default: begin
                    inflight_count_mem <= inflight_count_mem;
                    inflight_empty_mem <= inflight_empty_mem;
                end
            endcase

            if (request_sync2_mem != request_seen_mem) begin
                request_seen_mem <= request_sync2_mem;
                reload_pending_mem <= 1'b1;
                reload_thumb_mem <= thumb_sync2_mem;
                if (reader_busy || !inflight_empty_mem) begin
                    reader_busy <= 1'b0;
                    burst_active_mem <= 1'b0;
                    reader_error <= ERR_FRAME_OVERRUN;
                end
            end

            if (reload_pending_mem && inflight_empty_mem) begin
                reload_pending_mem <= 1'b0;
                reader_index <= index_sync2_mem;
                thumb_active_mem <= reload_thumb_mem;
                t_blk_mem <= 0;
                t_col_mem <= 0;
                t_row_mem <= 12'd0;
                t_ly_mem <= 10'd0;
                t_crow_mem <= 0;
                issued_count_mem <= 0;
                returned_count_mem <= 0;
                inflight_count_mem <= 0;
                inflight_empty_mem <= 1'b1;
                burst_active_mem <= 1'b0;
                burst_issued_mem <= 0;
                burst_target_mem <= 0;
                burst_gap_count_mem <= 0;
                diag_written_count_mem <= 0;
                diag_column_mem <= 0;
                fifo_reset_count_mem <= 3'd4;
                reader_busy <= 1'b1;
                reader_error <= ERR_NONE;
            end

            if (start_burst) begin
                burst_active_mem <= 1'b1;
                burst_issued_mem <= 0;
                burst_target_mem <= next_burst_words[BURST_COUNT_W-1:0];
            end

            if (issue_allowed) begin
                app_rd_en <= 1'b1;
                if (thumb_active_mem)
                    app_rd_addr <= t_burst_base_mem + burst_issued_mem;
                else
                    app_rd_addr <= bank_base(reader_index) + issued_count_mem[ADDR_WIDTH-1:0];
                issued_count_mem <= issued_count_mem + 1'b1;
                burst_issued_mem <= burst_issued_mem + 1'b1;
                if (burst_issued_mem + 1'b1 == burst_target_mem) begin
                    burst_active_mem <= 1'b0;
                    burst_gap_count_mem <= BURST_GAP_CYCLES;
                    // 第十三讲：一个 burst 发完，缩略图读序列走一步
                    if (thumb_active_mem) begin
                        if (t_blk_mem == ROW_BURSTS - 1) begin
                            t_blk_mem <= 0;
                            if (t_col_mem == THUMB_COLS - 1) begin
                                t_col_mem <= 0;
                                t_row_mem <= t_row_mem + 1'b1;
                                if (t_ly_mem == THUMB_H - 1) begin
                                    t_ly_mem <= 10'd0;
                                    t_crow_mem <= t_crow_mem + 1'b1;
                                end else begin
                                    t_ly_mem <= t_ly_mem + 1'b1;
                                end
                            end else begin
                                t_col_mem <= t_col_mem + 1'b1;
                            end
                        end else begin
                            t_blk_mem <= t_blk_mem + 1'b1;
                        end
                    end
                end
            end

            if (!DIAG_SYNTH_STREAM && sdram_rd_valid) begin
                returned_count_mem <= returned_count_mem + 1'b1;
                // 缩略图模式下被丢弃的奇数列不进 FIFO，也就谈不上溢出
                if (fifo_full && keep_word) begin
                    reader_busy <= 1'b0;
                    burst_active_mem <= 1'b0;
                    reader_error <= ERR_FIFO_OVERFLOW;
                end else if (final_return) begin
                    reader_busy <= 1'b0;
                    burst_active_mem <= 1'b0;
                    frame_read_done <= 1'b1;
                end
            end

            if (DIAG_SYNTH_STREAM && diag_stream_write) begin
                diag_written_count_mem <= diag_written_count_mem + 1'b1;
                diag_column_mem <= (diag_column_mem == 10'd639) ?
                                   10'd0 : diag_column_mem + 1'b1;
                if (diag_written_count_mem == IMAGE_WORDS - 1) begin
                    reader_busy <= 1'b0;
                    frame_read_done <= 1'b1;
                end
            end else if (!DIAG_SYNTH_STREAM && DIAG_RETURN_PATTERN &&
                         sdram_rd_valid) begin
                diag_column_mem <= (diag_column_mem == 10'd639) ?
                                   10'd0 : diag_column_mem + 1'b1;
            end
        end
    end

    // ---- 第十三讲：缩略图读地址 ----
    // 源图号/源行由上面的 t_crow/t_col/t_ly 计数器直接给出（见文件头），
    // 再经三级寄存得到 burst 起址（见 t_burst_base_mem 声明处的说明）。
    always @(posedge mem_clk or negedge mem_rst_n) begin
        if (!mem_rst_n) begin
            t_src_index_mem <= {INDEX_W{1'b0}};
            t_src_y_mem <= 10'd0;
            t_src_blk_mem <= 0;
            t_bank_base_mem <= 0;
            t_row_offset_mem <= 0;
            t_blk_offset_mem <= 0;
            t_burst_base_mem <= 0;
        end else begin
            // 没有对应图片的格子读 bank0（pix 侧会遮掉），读地址不越界
            t_src_index_mem <= (t_layout_index < IMAGE_COUNT) ? t_layout_index : {INDEX_W{1'b0}};
            t_src_y_mem <= t_layout_y;
            t_src_blk_mem <= t_blk_mem;
            t_bank_base_mem <= bank_base(t_src_index_mem);
            t_row_offset_mem <= t_src_y_mem * ROW_WORDS;
            t_blk_offset_mem <= t_src_blk_mem * THUMB_BURST;
            t_burst_base_mem <= t_bank_base_mem + t_row_offset_mem + t_blk_offset_mem;
        end
    end

    rfifo_32_32_512 #(
        .DATA_WIDTH_W(32), .DATA_WIDTH_R(32),
        .ADDR_WIDTH_W(FIFO_COUNT_W), .ADDR_WIDTH_R(FIFO_COUNT_W),
        .AL_FULL_NUM(FIFO_DEPTH-FIFO_MARGIN), .AL_EMPTY_NUM(2),
        .SHOW_AHEAD_EN(1'b0), .OUTREG_EN("NOREG")
    ) u_read_fifo (
        .rst(fifo_reset), .clkw(mem_clk), .clkr(pix_clk),
        .we(fifo_write_enable), .di(fifo_write_data),
        .re(fifo_raw_read_en), .dout(fifo_raw_data), .valid(fifo_raw_valid),
        .full_flag(fifo_full), .empty_flag(fifo_empty),
        .afull(fifo_almost_full), .aempty(),
        .wrusedw(fifo_wrusedw), .rdusedw()
    );

    fifo_prefetch_2 #(.DATA_WIDTH(32)) u_prefetch (
        .clk(pix_clk), .rst(fifo_reset), .raw_empty(fifo_empty),
        .raw_valid(fifo_raw_valid), .raw_data(fifo_raw_data),
        .raw_read_en(fifo_raw_read_en), .consume(word_pop),
        .out_valid(prefetch_valid), .out_empty(), .out_data(prefetch_data)
    );

    generate
        if (PACK_RGB565 != 0) begin : g_unpack_565
            wire [15:0] p565 = pix_half ? prefetch_data[31:16] : prefetch_data[15:0];
            assign pixel_rgb = {p565[15:11], p565[15:13],
                                p565[10:5],  p565[10:9],
                                p565[4:0],   p565[4:2]};
        end else begin : g_unpack_888
            assign pixel_rgb = prefetch_data[23:0];
        end
    endgenerate
    assign pixel_valid = prefetch_valid;

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            // The memory-domain error remains authoritative for controller faults.
        end else if (underflow) begin
            // underflow is exported separately; the Top may merge it as 8'h63.
        end
    end

endmodule
