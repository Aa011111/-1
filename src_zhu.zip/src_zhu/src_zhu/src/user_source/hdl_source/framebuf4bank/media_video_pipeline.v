`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第八讲 四bank帧缓存架构
// media_video_pipeline：讲义原件 + 本工程的两处修正。
//
// 差异1（端口透传）：media_player_control 加了 prev_event/init_event 两个事件，
//   这里跟着透传出去。本工程 KEY2 长按=上一张、摄入完成要落到首张有效图。
//
// 差异2（跨时钟域修正）：讲义原件第183行把 ctrl 域的 player_enable 裸接进
//   mem 域的 controller_init_done，没过同步器——它在 pix 域是规规矩矩过了
//   u_player_enable_pix 的，mem 域这一路漏了。这里补一个对称的
//   u_player_enable_mem（复用 common/sync_2ff.v）。
//   本工程里这一路尤其要紧：player_enable 就是 SDRAM 单端口的读写时间互斥开关
//   （摄入期只写不读，摄入完只读不写），它一旦在 mem 域亚稳，reader 可能在
//   loader 还在写的时候就发出读指令，跟写指令在同一个单端口 SDRAM 上撞车。
//
// 差异3（第十三讲 图片缩放与缩略图）：缩略图/全屏两种显示模式。
//   - thumb_mode（ctrl 域，media_player_control 持有）过 2FF 进 pix 域，在
//     frame_start 锁定成 thumb_frame_pix；同一拍 reader 也锁同一个值去决定
//     这一帧怎么读，两边永远同帧切换，不撕裂（讲义 Q3）。
//   - pix 侧挂一个 display/thumbnail_layout：未加载完成的格子涂黑，
//     焦点格（= active_index）描 2 像素黄框。reader 输出的像素流已经是按
//     2x2 排好、2:1 缩好的，这里只做遮罩，不改像素节奏。
//   - 缩略图模式下 NEXT 不走淡出淡入（那会把整屏 4 格一起淡黑再亮，
//     只为挪一下框），直接交给 control；Wipe/淡变 alpha 也不作用于缩略图帧，
//     亮度(BRT=)仍然生效。
//
// 差异4（第十四讲 亮度对比度调节）：
//   - brightness 以前直接进 eff_alpha，一帧中间变就会上下半屏两种亮度
//     （讲义 2.5 / Q1）。现在和新增的 contrast 一起在 frame_start 锁存成
//     brightness_frame / contrast_frame，一帧内恒定。
//   - 转场/亮度乘法之后插一级 adjust/brightness_contrast_adjust
//     （BRIGHTNESS_EN=0：亮度已经折在 alpha 里，不再乘第二次），只做对比度。
//     该模块寄存一拍，所以 hs/vs 同样延一拍、video_x 多延一拍，
//     rgb_video_adapter 看到的整组信号仍然同拍对齐。
//     整条视频输出因此比改造前晚 1 个像素时钟，hs/vs/de/rgb 一起晚，
//     下游（OSD 链、AXIS、HDMI 发射核）全部由这组输出反推时序，无感。
//   - contrast=128 时对比度级逐位旁路，默认上电画面与第十三讲逐位相同。
//
// 差异6（四边环绕频谱加入后的时序修正）：
//   坐标 → thumbnail_layout（对角线占位符）→ 显示选择 → 转场/亮度乘法 →
//   对比度乘加 → 寄存，这一整条原来在一拍里走完（26 级、约 40ns），
//   25MHz 下只剩 0.12ns 余量；芯片再满一点就违例。在转场乘法之后、对比度级
//   之前插一级寄存（faded_rgb_q），de/hs/vs/video_x 同步多延一拍。
//   和差异4同理：整组输出一起晚 1 拍，下游全部由这组输出反推时序，无感。
//
// 差异5（第十五讲 = 讲义第14课 缩略图交互选择）：
//   - 新增 control/thumbnail_controller（ctrl 域），接管 view_mode(=thumb_mode)
//     和独立的 focus_index。按键事件按当前模式翻译（讲义 2.2 方案C，板上只有
//     KEY1/KEY2 两个键，用短按/长按凑出四个功能）：
//                      全屏模式              缩略图模式
//       KEY1 短按      下一张(淡变)          焦点右移 key_right
//       KEY2 长按      上一张(Wipe)          焦点左移 key_left
//       KEY1 长按      进缩略图 key_mode     确认选择 key_confirm
//       KEY2 短按      自动轮播开关          返回全屏 key_mode（不换图）
//     串口 NEXT/PREV 与 KEY1短/KEY2长 同路，THUMB/FULL 是明确设定，SEL = 确认。
//   - 进/出缩略图、确认选择都走一次淡出->全黑->淡入：thumbnail_controller 借用
//     video_fade_transition 的 next 通道发请求，全黑放行脉冲按 transition_owned
//     分流回控制器（不当 next 用），控制器在全黑时翻模式 + 发 select。
//     因此缩略图帧不再强制 alpha=255（原来那样进出缩略图是硬切）；Wipe 遮罩
//     仍然不作用于缩略图帧。
//   - 焦点框改用 focus_index（经 cdc_bus_commit 进 pix 域，frame_start 锁存），
//     不再是 active_index。格子着色优先级：
//       焦点框（已加载=黄 / 未加载=红，表示"这格选不了"）
//       > 当前播放那张的白框 > 缩略图像素 > 未加载占位符（深灰底 + 灰色 X）
//
// 13 张图扩展（默认参数下与改造前相同）：
//   - IMAGE_COUNT / INDEX_W / NAV_MASK 透传给 control、reader、thumbnail_controller。
//   - THUMB_COLS / THUMB_ROWS：缩略图网格（本工程 4x4，每格 160x120）。
//     没有对应图片的格子（格子号 >= IMAGE_COUNT）只画底色，不画 X、不画框。
//   - 转场种类原来直接取 2 位 active_index，现在取它的低 2 位，效果相同。
//
// 差异7（火灾图覆盖，见 emergency/fire_alarm_ctrl.v）：
//   - alarm_show=1 时 pix 域在 frame_start 把 reader 的读 index 换成 alarm_index，
//     并强制全屏（缩略图读模式/遮罩关掉）、不做淡变和 Wipe（alpha=255，亮度仍生效）。
//   - 覆盖只在像素域做，media_player_control / thumbnail_controller /
//     video_fade_transition 一个都不碰：它们之间的握手（比如转场 S_HOLD
//     死等 index_commit）照常在底下跑完，不会因为报警插进来而卡在黑屏。
//     报警解除后画面回到底下播放器当时的状态。
//   - alarm_show/alarm_index 是 ctrl 域慢变总线，用 cdc_bus_commit 整组搬到
//     pix 域；reader 和显示选择在同一个 frame_start 锁同一个值，整帧不撕裂。
//   - display_index 输出"屏幕上实际是哪张"，给状态条用。
//   alarm_show 恒 0 时与改造前逐位相同。
// -----------------------------------------------------------------------------

module media_video_pipeline #(
    parameter integer IMAGE_WORDS = 307200,
    // 1 = SDRAM 按 RGB565 两像素一字存放，必须与 media_frame_loader 一致
    parameter integer PACK_RGB565 = 0,
    parameter integer IMAGE_COUNT = 4,
    parameter integer INDEX_W = 2,
    parameter [IMAGE_COUNT-1:0] NAV_MASK = {IMAGE_COUNT{1'b1}},
    parameter integer THUMB_COLS = 2,
    parameter integer THUMB_ROWS = 2,
    parameter integer CELL_W = 2,       // 缩略图格子号位宽，>= clog2(COLS*ROWS)，且 >= INDEX_W
    // 触控屏扩展：缩略图里显示/可选的图片数（前 THUMB_COUNT 张）。顶层 = 11，
    // PIC12/13 火警图不进缩略图，那两格和网格末尾一样只画底色。
    parameter integer THUMB_COUNT = IMAGE_COUNT,
    parameter integer FIFO_DEPTH = 512,
    parameter integer FIFO_MARGIN = 16,
    parameter integer H_ACT = 640,
    parameter integer H_FP = 16,
    parameter integer H_SYNC = 96,
    parameter integer H_BP = 48,
    parameter integer V_ACT = 480,
    parameter integer V_FP = 10,
    parameter integer V_SYNC = 2,
    parameter integer V_BP = 33,
    parameter [31:0] DEFAULT_PERIOD_CYCLES = 32'd250000000,
    parameter [31:0] MIN_PERIOD_CYCLES = 32'd50000000,
    parameter [31:0] MAX_PERIOD_CYCLES = 32'd3000000000,
    // Non-zero enables the fade-out/black/fade-in transition on manual
    // switches and a fade-in on automatic slideshow switches. Zero keeps the
    // legacy direct-switch behaviour for the existing regression suites.
    parameter integer FADE_FRAMES = 0,
    // 第十三讲：缩略图焦点框颜色
    parameter [23:0] FOCUS_COLOR = 24'hFFC800,
    // 第十五讲：缩略图交互选择的其余配色
    parameter [23:0] FOCUS_EMPTY_COLOR = 24'hE02020,   // 焦点停在未加载格子上
    parameter [23:0] CURRENT_COLOR     = 24'hFFFFFF,   // 当前正在播放的那张
    parameter [23:0] PLACEHOLDER_BG    = 24'h202020,   // 未加载格子底色
    parameter [23:0] PLACEHOLDER_LINE  = 24'h606060    // 未加载格子里的 X
) (
    input  wire        ctrl_clk,
    input  wire        ctrl_rst_n,
    input  wire        next_event,
    input  wire        prev_event,
    input  wire        init_event,
    input  wire        toggle_auto_event,
    input  wire        period_cfg_valid,
    input  wire [31:0] period_cfg_cycles,
    input  wire        auto_cfg_valid,
    input  wire        auto_cfg_enabled,
    input  wire [IMAGE_COUNT-1:0] image_complete,
    input  wire        player_enable,
    // 第十三讲：缩略图/全屏切换（ctrl 域）
    input  wire        thumb_toggle_event,
    input  wire        thumb_cfg_valid,
    input  wire        thumb_cfg_enabled,
    input  wire        confirm_event,       // 第十五讲：串口 SEL，缩略图下确认选择
    input  wire        focus_cfg_valid,     // 触控屏：串口 FOC=NN，直接设焦点（ctrl 域单拍）
    input  wire [INDEX_W-1:0] focus_cfg_index,
    output wire        thumb_mode,          // ctrl 域电平
    output wire        thumb_frame_pix,     // pix 域，按帧锁定后的实际显示模式
    // 差异7：火灾图覆盖（ctrl 域电平）
    input  wire        alarm_show,
    input  wire [INDEX_W-1:0] alarm_index,

    input  wire        mem_clk,
    input  wire        mem_rst_n,
    input  wire        controller_init_done,
    input  wire        controller_busy,
    input  wire        refresh_active,
    output wire        app_rd_en,
    output wire [20:0] app_rd_addr,
    input  wire        sdram_rd_valid,
    input  wire [31:0] sdram_rd_data,

    input  wire [7:0]  brightness,
    input  wire [7:0]  contrast,        // 第十四讲，128 = 原样
    input  wire        pix_clk,
    input  wire        pix_rst_n,
    output wire        video_clk,
    output wire        video_hs,
    output wire        video_vs,
    output wire        video_de,
    output wire [23:0] video_rgb,
    output wire [9:0]  video_x,

    output wire [INDEX_W-1:0] active_index,
    output wire [INDEX_W-1:0] display_index,   // 差异7：pix 域，本帧屏幕上实际显示的那张
    output wire [INDEX_W-1:0] pending_index,
    output wire        auto_enabled,
    output wire        frame_start,
    output wire        reader_busy,
    output wire        reader_underflow,
    output wire [7:0]  video_error,
    // 第十一讲：转场 alpha 引出给 sync_fade_gain，做音画同步淡入淡出（pix 域）
    output wire [7:0]  fade_alpha_pix,
    output wire        fade_active_pix
);
    wire raw_hs;
    wire raw_vs;
    wire raw_de;
    wire [11:0] raw_x;
    wire [11:0] raw_y;
    localparam integer H_BLANK = H_FP + H_SYNC + H_BP;
    wire [11:0] active_x = (raw_x >= H_BLANK) ? raw_x - H_BLANK : 12'd0;
    // ACTIVE_LAST=1：有效行落在 y = V_BLANK .. V_TOTAL-1，减掉消隐得到 0..V_ACT-1
    localparam integer V_BLANK = V_FP + V_SYNC + V_BP;
    wire [11:0] active_y = (raw_y >= V_BLANK) ? raw_y - V_BLANK : 12'd0;
    reg raw_vs_q;
    reg [9:0] video_x_q1;
    reg [9:0] video_x_q;
    wire index_commit;
    wire [7:0] control_error;
    wire request_busy;
    wire [31:0] active_period_cycles;
    wire [23:0] reader_rgb;
    wire reader_pixel_valid;
    wire reader_done;
    wire [INDEX_W-1:0] reader_index;
    wire [7:0] reader_error;
    wire player_enable_pix;
    wire player_enable_mem;
    reg [7:0] reader_error_pix1;
    reg [7:0] reader_error_pix2;
    reg [7:0] control_error_pix1;
    reg [7:0] control_error_pix2;
    wire [23:0] selected_rgb =
        (player_enable_pix && reader_pixel_valid && reader_error_pix2 == 0) ?
        reader_rgb : 24'h000000;

    sync_2ff u_player_enable_pix (
        .clk(pix_clk), .rst_n(pix_rst_n), .async_in(player_enable),
        .sync_out(player_enable_pix)
    );

    // 本工程修正：player_enable 是 ctrl 域信号，进 mem 域同样要过同步器，
    // 不能像讲义原件那样裸接进 u_reader 的 controller_init_done。
    sync_2ff u_player_enable_mem (
        .clk(mem_clk), .rst_n(mem_rst_n), .async_in(player_enable),
        .sync_out(player_enable_mem)
    );

    // ---- 第十三讲：缩略图模式跨到 pix 域 ----
    wire thumb_mode_ctrl;
    wire thumb_mode_sync_pix;     // 同步后的电平，reader 在 frame_start 锁它
    reg  thumb_frame_q;           // 本帧实际模式，与 reader 同一拍锁同一个值
    wire [IMAGE_COUNT-1:0] image_complete_pix;
    assign thumb_mode = thumb_mode_ctrl;
    assign thumb_frame_pix = thumb_frame_q;

    sync_2ff u_thumb_mode_pix (
        .clk(pix_clk), .rst_n(pix_rst_n), .async_in(thumb_mode_ctrl),
        .sync_out(thumb_mode_sync_pix)
    );

    // image_complete 只在开机摄入期置位，display_valid（=player_enable）
    // 拉高之前就已经全部稳定，所以逐位 2FF 不存在"多位撕裂"的问题
    genvar gi;
    generate
        for (gi = 0; gi < IMAGE_COUNT; gi = gi + 1) begin : g_complete_pix
            sync_2ff u_complete_pix (
                .clk(pix_clk), .rst_n(pix_rst_n), .async_in(image_complete[gi]),
                .sync_out(image_complete_pix[gi])
            );
        end
    endgenerate

    // ---- 差异7：火灾图覆盖跨到 pix 域，frame_start 锁存 ----
    // {alarm_show, alarm_index} 一起变（预警->火灾时 index 变、show 不变），
    // 不能逐位 2FF。第一级 commit_sync1 已被 sdc 第 6 节通配 false_path 覆盖。
    wire [INDEX_W:0] alarm_bus_pix;
    wire             alarm_show_pix  = alarm_bus_pix[INDEX_W];
    wire [INDEX_W-1:0] alarm_index_pix = alarm_bus_pix[INDEX_W-1:0];
    reg              alarm_frame_q;
    reg  [INDEX_W-1:0] alarm_index_frame_q;
    cdc_bus_commit #(.WIDTH(INDEX_W + 1)) u_alarm_pix (
        .src_clk(ctrl_clk), .src_rst_n(ctrl_rst_n),
        .src_data({alarm_show, alarm_index}), .src_busy(),
        .dst_clk(pix_clk), .dst_rst_n(pix_rst_n),
        .dst_data(alarm_bus_pix), .dst_update()
    );

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            alarm_frame_q       <= 1'b0;
            alarm_index_frame_q <= {INDEX_W{1'b0}};
        end else if (frame_start) begin
            alarm_frame_q       <= alarm_show_pix;
            alarm_index_frame_q <= alarm_index_pix;
        end
    end
    assign display_index = alarm_frame_q ? alarm_index_frame_q : active_index;

    // reader 在 frame_start 当拍锁 thumb_mode、下一拍才取 index（等 control
    // 提交 active_index）。所以 thumb 用和 alarm_frame_q 同一拍的实时值，
    // index 直接用已锁存的 display_index，两者都和 alarm_frame_q 同帧。
    wire               reader_req_thumb = thumb_mode_sync_pix && !alarm_show_pix;

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n)
            thumb_frame_q <= 1'b0;
        else if (frame_start)
            thumb_frame_q <= reader_req_thumb;
    end

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            reader_error_pix1 <= 8'd0;
            reader_error_pix2 <= 8'd0;
            control_error_pix1 <= 8'd0;
            control_error_pix2 <= 8'd0;
        end else begin
            reader_error_pix1 <= reader_error;
            reader_error_pix2 <= reader_error_pix1;
            control_error_pix1 <= control_error;
            control_error_pix2 <= control_error_pix1;
        end
    end

    video_timing_ctrl #(
        .H_ACT(H_ACT), .H_FP(H_FP), .H_SYNC(H_SYNC), .H_BP(H_BP),
        .V_ACT(V_ACT), .V_FP(V_FP), .V_SYNC(V_SYNC), .V_BP(V_BP),
        .ACTIVE_LAST(1)
    ) u_timing (
        .pclk(pix_clk), .rst_n(pix_rst_n), .hsync(raw_hs),
        .vsync(raw_vs), .de(raw_de), .x(raw_x), .y(raw_y)
    );

    // Fade transition: manual switch requests are held until the display has
    // faded to black, then released to the control FSM at the frame boundary.
    // The bypass branch (FADE_FRAMES=0) wires next_event straight through so
    // legacy regression timing is unchanged.
    wire fade_next_event;
    wire fade_busy;
    wire [7:0] fade_alpha;
    wire wipe_active;
    wire [4:0] wipe_ramp;
    wire [1:0] transition_kind;

    // ---- 第十五讲：缩略图交互控制器 + 按模式翻译按键（见文件头差异5的表）----
    wire [INDEX_W-1:0] focus_index_ctrl;
    wire       select_event;
    wire [INDEX_W-1:0] select_index;
    wire       view_transition_req;
    wire       view_transition_owned;
    wire       auto_hold;
    // 全屏模式：原样交给播放控制
    wire full_next = next_event        && !thumb_mode_ctrl;
    wire full_prev = prev_event        && !thumb_mode_ctrl;
    wire full_auto = toggle_auto_event && !thumb_mode_ctrl;
    // 缩略图模式：方向键控制器内部自己看 view_mode，这里只拆 KEY1长/KEY2短
    wire key_confirm = (thumb_toggle_event || confirm_event) && thumb_mode_ctrl;
    wire key_mode    = (thumb_toggle_event && !thumb_mode_ctrl) ||
                       (toggle_auto_event  &&  thumb_mode_ctrl);
    // 转场的全黑放行脉冲：控制器占用时归它，否则是普通的"下一张"
    wire fade_release_next = fade_next_event && !view_transition_owned;
    wire fade_release_view = fade_next_event &&  view_transition_owned;

    thumbnail_controller #(
        .IMAGE_COUNT(IMAGE_COUNT), .INDEX_W(INDEX_W), .FOCUS_COUNT(THUMB_COUNT)
    ) u_thumb_ctrl (
        .clk(ctrl_clk), .rst_n(ctrl_rst_n),
        .key_right(next_event), .key_left(prev_event),
        .key_confirm(key_confirm), .key_mode(key_mode),
        .mode_cfg_valid(thumb_cfg_valid), .mode_cfg_thumb(thumb_cfg_enabled),
        .focus_cfg_valid(focus_cfg_valid), .focus_cfg_index(focus_cfg_index),
        .image_complete(image_complete),
        .current_index(pending_index), .select_busy(request_busy),
        .transition_busy(fade_busy), .transition_black(fade_release_view),
        .view_mode(thumb_mode_ctrl), .focus_index(focus_index_ctrl),
        .select_event(select_event), .select_index(select_index),
        .transition_req(view_transition_req),
        .transition_owned(view_transition_owned),
        .auto_hold(auto_hold)
    );

    video_fade_transition #(.FADE_FRAMES(FADE_FRAMES)) u_fade (
        .ctrl_clk(ctrl_clk), .ctrl_rst_n(ctrl_rst_n),
        .next_event_in(full_next || view_transition_req), .next_event_out(fade_next_event),
        .fade_busy(fade_busy),
        .pix_clk(pix_clk), .pix_rst_n(pix_rst_n),
        .player_active(player_enable_pix), .frame_start(frame_start),
        .index_commit(index_commit), .active_index(active_index[1:0]),
        .alpha_out(fade_alpha), .fade_active(fade_active_pix),
        .wipe_active(wipe_active), .ramp_out(wipe_ramp),
        .transition_kind(transition_kind)
    );
    assign fade_alpha_pix = fade_alpha;

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n)
            raw_vs_q <= 1'b1;
        else
            raw_vs_q <= raw_vs;
    end
    assign frame_start = raw_vs_q && !raw_vs;

    // rgb_video_adapter registers hs/vs/de/rgb by one pixel. Register x in
    // parallel so the HDMI Data Island scheduler sees the coordinate belonging
    // to the same output character, rather than the next raw VTC position.
    // 第十四讲：前面多了一级对比度寄存，x 也要多延一拍（共两拍）。
    // 差异6：转场乘法后又插了一级，共三拍。
    reg [9:0] video_x_q0;
    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            video_x_q0 <= 10'd0;
            video_x_q1 <= 10'd0;
            video_x_q  <= 10'd0;
        end else begin
            video_x_q0 <= active_x[9:0];
            video_x_q1 <= video_x_q0;
            video_x_q  <= video_x_q1;
        end
    end
    assign video_x = video_x_q;

    // ---- 第十四讲：画面参数帧边界锁存（讲义 2.5）----
    // brightness / contrast 从 cdc_bus_commit 出来可能在任意一拍变，
    // 这里只在 frame_start（消隐期）采一次，一帧内用锁存值。
    reg [7:0] brightness_frame;
    reg [7:0] contrast_frame;
    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            brightness_frame <= 8'd255;
            contrast_frame   <= 8'd128;
        end else if (frame_start) begin
            brightness_frame <= brightness;
            contrast_frame   <= contrast;
        end
    end

    media_player_control #(
        .DEFAULT_PERIOD_CYCLES(DEFAULT_PERIOD_CYCLES),
        .MIN_PERIOD_CYCLES(MIN_PERIOD_CYCLES),
        .MAX_PERIOD_CYCLES(MAX_PERIOD_CYCLES),
        .IMAGE_COUNT(IMAGE_COUNT), .INDEX_W(INDEX_W), .NAV_MASK(NAV_MASK)
    ) u_control (
        .sys_clk(ctrl_clk), .sys_rst_n(ctrl_rst_n),
        .next_event(fade_release_next), .prev_event(full_prev),
        .init_event(init_event), .toggle_auto_event(full_auto),
        .period_cfg_valid(period_cfg_valid),
        .period_cfg_cycles(period_cfg_cycles),
        .auto_cfg_valid(auto_cfg_valid),
        .auto_cfg_enabled(auto_cfg_enabled),
        .image_complete(image_complete),
        .select_event(select_event), .select_index(select_index),
        .auto_hold(auto_hold),
        .auto_enabled(auto_enabled),
        .active_period_cycles(active_period_cycles),
        .pending_index(pending_index), .control_error(control_error),
        .request_busy(request_busy), .pix_clk(pix_clk),
        .pix_rst_n(pix_rst_n), .frame_start(frame_start),
        .active_index(active_index), .index_commit(index_commit)
    );

    media_frame_reader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(IMAGE_WORDS),
        .FIFO_DEPTH(FIFO_DEPTH), .FIFO_MARGIN(FIFO_MARGIN),
        .MAX_INFLIGHT_BURSTS(2), .DIAG_RETURN_PATTERN(0),
        .DIAG_SYNTH_STREAM(0),
        .FRAME_WIDTH(H_ACT), .FRAME_HEIGHT(V_ACT),
        .PACK_RGB565(PACK_RGB565),
        .IMAGE_COUNT(IMAGE_COUNT), .INDEX_W(INDEX_W),
        .THUMB_COLS(THUMB_COLS), .THUMB_ROWS(THUMB_ROWS), .CELL_W(CELL_W)
    ) u_reader (
        .mem_clk(mem_clk), .mem_rst_n(mem_rst_n),
        .controller_init_done(controller_init_done && player_enable_mem),
        .controller_busy(controller_busy), .refresh_active(refresh_active),
        .app_rd_en(app_rd_en), .app_rd_addr(app_rd_addr),
        .sdram_rd_valid(sdram_rd_valid), .sdram_rd_data(sdram_rd_data),
        .pix_clk(pix_clk), .pix_rst_n(pix_rst_n),
        .frame_start(frame_start && player_enable_pix), .active_index(display_index),
        .thumb_mode(reader_req_thumb),
        .pixel_consume(raw_de && player_enable_pix), .pixel_rgb(reader_rgb),
        .pixel_valid(reader_pixel_valid), .underflow(reader_underflow),
        .reader_busy(reader_busy), .frame_read_done(reader_done),
        .reader_index(reader_index), .reader_error(reader_error)
    );

    // Fade multiplies the selected frame by the ramp alpha; an automatic
    // slideshow switch instead reveals the new frame left-to-right: pixels
    // right of the moving boundary stay black, the rest show full colour.
    // With FADE_FRAMES=0 the direct assignment keeps every pixel bit-identical
    // to the legacy path so strict regression comparisons still hold.
    // ---- 第十三讲：缩略图遮罩 + 焦点框 ----
    // 与 selected_rgb 同一拍的 raw_de/active_x/active_y 做坐标映射。
    // source_index/x/y 在这里用不到（reader 已经按同一套映射把像素排好了）。
    // 第十五讲：focus_index 是 2 位总线，不能逐位 2FF（0->1->2->3 里 1->2 两位同变），
    // 用 cdc_bus_commit 整组搬到 pix 域，再在 frame_start 锁存，一帧内焦点框不动。
    // 按键间隔是百毫秒级，远大于一次搬运（两域各 3~4 拍），不会丢值。
    // 第一级 commit_sync1 已被 sdc 第 6 节通配 false_path 覆盖。
    wire [INDEX_W-1:0] focus_index_pix;
    reg  [INDEX_W-1:0] focus_frame_q;
    cdc_bus_commit #(.WIDTH(INDEX_W)) u_focus_pix (
        .src_clk(ctrl_clk), .src_rst_n(ctrl_rst_n),
        .src_data(focus_index_ctrl), .src_busy(),
        .dst_clk(pix_clk), .dst_rst_n(pix_rst_n),
        .dst_data(focus_index_pix), .dst_update()
    );
    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n)
            focus_frame_q <= {INDEX_W{1'b0}};
        else if (frame_start)
            focus_frame_q <= focus_index_pix;
    end

    wire thumb_de;
    wire focus_border;
    wire [CELL_W-1:0] cell_index;
    wire cell_edge;
    wire placeholder;
    wire cell_unused;
    localparam integer CELLS = THUMB_COLS * THUMB_ROWS;
    // 格子数可能多于图片数（4x4 放 13 张），多出来的格子 complete 恒 0
    wire [CELLS-1:0] cell_complete_pix =
        {{(CELLS > IMAGE_COUNT ? CELLS - IMAGE_COUNT : 1){1'b0}}, image_complete_pix};
    thumbnail_layout #(
        .DISPLAY_WIDTH(H_ACT), .DISPLAY_HEIGHT(V_ACT),
        .THUMB_WIDTH(H_ACT / THUMB_COLS), .THUMB_HEIGHT(V_ACT / THUMB_ROWS),
        .COLS(THUMB_COLS), .ROWS(THUMB_ROWS), .CELL_W(CELL_W),
        .USED_CELLS(THUMB_COUNT)        // 触控屏扩展：只画前 THUMB_COUNT 张
    ) u_thumb_layout (
        .in_de(raw_de), .pixel_x(active_x), .pixel_y(active_y),
        .focus_index({{(CELL_W-INDEX_W+1){1'b0}}, focus_frame_q} ),
        .image_complete(cell_complete_pix[CELLS-1:0]),
        .thumb_de(thumb_de), .source_index(cell_index), .source_x(), .source_y(),
        .focus_border(focus_border),
        .cell_edge(cell_edge), .placeholder(placeholder), .cell_unused(cell_unused)
    );
    // 第十五讲：active_index 本身就是 frame_start 提交的，整帧恒定
    wire current_border = cell_edge && !cell_unused && (cell_index == active_index);
    wire [23:0] thumb_rgb = cell_unused    ? PLACEHOLDER_BG :
                            focus_border   ? (thumb_de ? FOCUS_COLOR : FOCUS_EMPTY_COLOR) :
                            current_border ? CURRENT_COLOR :
                            thumb_de       ? selected_rgb :
                            placeholder    ? PLACEHOLDER_LINE : PLACEHOLDER_BG;
    wire [23:0] display_rgb = thumb_frame_q ? thumb_rgb : selected_rgb;

    wire [23:0] faded_rgb;
    generate
        if (FADE_FRAMES == 0) begin : g_fade_bypass
            assign faded_rgb = display_rgb;
        end else begin : g_fade_mul
            // Session-level brightness folds into the transition alpha with
            // one extra 8x8 multiply, so the steady display and the fade both
            // scale together.
            // (brightness+1)/256 keeps full brightness bit-exact (256/256)
            // while lower steps land within 0.4% of brightness/255.
            // 第十三讲原来在这里让缩略图帧 alpha 固定 255（不参与转场）。
            // 第十五讲去掉：缩略图下 next 已被 thumbnail_controller 截走，
            // 能跑到缩略图帧上的淡变只剩进/出缩略图和确认选择这三种，正是要淡的。
            // Wipe 在淡变里 alpha 本来就是 255，遮罩另有 !thumb_frame_q 门控。
            // 差异7：火灾图帧不参与转场，底下的淡变/Wipe 照跑但不作用到屏幕上
            wire [7:0] frame_alpha = alarm_frame_q ? 8'd255 : fade_alpha;
            // 第十四讲：brightness 换成帧边界锁存后的 brightness_frame
            wire [7:0] eff_alpha = ({8'd0, frame_alpha} * (brightness_frame + 8'd1)) >> 8;
            wire [15:0] fade_mul_r = {8'd0, display_rgb[23:16]} * eff_alpha;
            wire [15:0] fade_mul_g = {8'd0, display_rgb[15:8]}  * eff_alpha;
            wire [15:0] fade_mul_b = {8'd0, display_rgb[7:0]}   * eff_alpha;
            wire [23:0] alpha_rgb =
                {fade_mul_r[15:8], fade_mul_g[15:8], fade_mul_b[15:8]};
            // Reveal boundary advances one H_ACT/FADE_FRAMES column step per
            // frame; the comparison uses the same raw_x that aligns with
            // selected_rgb at this point in the pipeline.
            localparam integer WIPE_STEP = H_ACT / FADE_FRAMES;
            wire [9:0] wipe_boundary = wipe_ramp * WIPE_STEP;
            wire [6:0] blind_x_boundary = wipe_ramp * 4;
            reg transition_pixel;
            always @* begin
                case (transition_kind)
                    2'd0: transition_pixel = active_x[9:0] < wipe_boundary;
                    2'd1: transition_pixel = active_x[9:0] >= H_ACT - wipe_boundary;
                    2'd2: transition_pixel = {1'b0, active_x[5:0]} < blind_x_boundary;
                    default: transition_pixel = (active_x[6] ^ raw_y[6]) ?
                        ({1'b0, active_x[5:0]} < blind_x_boundary) :
                        ({1'b0, active_x[5:0]} >= 7'd64 - blind_x_boundary);
                endcase
            end
            assign faded_rgb = (wipe_active && !thumb_frame_q && !alarm_frame_q) ?
                (transition_pixel ? alpha_rgb : 24'h000000) :
                alpha_rgb;
        end
    endgenerate

    // 本工程修正：de_in 不再被 player_enable_pix 门控（讲义原件是
    // raw_de && player_enable_pix）。播放未使能时像素内容已经由 selected_rgb
    // 黑掉了，再把 de 也拉掉会让 HDMI 彻底失去有效视频时序——显示器会报
    // "无信号"而不是显示黑屏，摄入完成那一刻还要重新锁一次，画面闪一下。
    // 改造前 video_timing_data 是一直在跑时序、只把 vout_data 黑掉的，保持一致。
    // ---- 差异6：转场乘法后寄存一拍，切断 坐标→占位符→乘法→对比度 长路径 ----
    reg  [23:0] faded_rgb_q;
    reg         faded_de_q;
    reg         faded_hs_q;
    reg         faded_vs_q;
    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            faded_rgb_q <= 24'd0;
            faded_de_q  <= 1'b0;
            faded_hs_q  <= 1'b1;   // sync 低有效，空闲 = 高
            faded_vs_q  <= 1'b1;
        end else begin
            faded_rgb_q <= faded_rgb;
            faded_de_q  <= raw_de;
            faded_hs_q  <= raw_hs;
            faded_vs_q  <= raw_vs;
        end
    end

    // ---- 第十四讲：对比度级（寄存一拍），hs/vs 同步延一拍 ----
    wire        bc_de;
    wire [23:0] bc_rgb;
    reg         bc_hs_q;
    reg         bc_vs_q;

    brightness_contrast_adjust #(
        .BRIGHTNESS_EN(0)          // 亮度已折进上面的 eff_alpha
    ) u_contrast (
        .clk       (pix_clk),
        .rst_n     (pix_rst_n),
        .in_de     (faded_de_q),
        .rgb_in    (faded_rgb_q),
        .brightness(8'd255),
        .contrast  (contrast_frame),
        .out_de    (bc_de),
        .rgb_out   (bc_rgb)
    );

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            bc_hs_q <= 1'b1;       // 课程合同 sync 低有效，空闲 = 高
            bc_vs_q <= 1'b1;
        end else begin
            bc_hs_q <= faded_hs_q;
            bc_vs_q <= faded_vs_q;
        end
    end

    rgb_video_adapter u_video_adapter (
        .pclk(pix_clk), .rst_n(pix_rst_n), .hs_in(bc_hs_q),
        .vs_in(bc_vs_q), .de_in(bc_de),
        .rgb_in(bc_rgb), .video_clk(video_clk),
        .video_hs(video_hs), .video_vs(video_vs),
        .video_de(video_de), .video_rgb(video_rgb)
    );

    assign video_error = reader_error_pix2 != 0 ? reader_error_pix2 :
                         reader_underflow ? 8'h63 : control_error_pix2;
endmodule
