`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第八讲 四bank帧缓存架构
// media_frame_loader：讲义原件 + 本工程需要的 V_FLIP 扩展。
//
// 与讲义原件的唯一差异：新增 V_FLIP/FRAME_WIDTH/FRAME_HEIGHT 三个参数。
// 讲义原件的写地址是 bank_base(active_image) + pixels_written（纯线性递增），
// 而 BMP 文件是自底向上存储的——本工程原先靠 SD/frame_fifo_write.v 的
// WRITE_V_FLIP=1 在写地址上做翻转，换成 loader 后这层翻转会丢，画面会上下颠倒。
// 这里把翻转按 frame_fifo_write.v 的同一套做法搬进来：用一个随 pop 走的地址
// 寄存器 + 行内计数器，纯递增/递减实现，不引入除法器。
// V_FLIP=0（默认）时行为与讲义原件逐字等价。
//
// 资源优化：fifo_mem 原来写在带异步复位的 always 块里，综合器推不出 BRAM，
// 落成 512x32 的分布式 RAM，整个模块吃掉约 2200 个 LUT。现在把存储体单独拿到
// 无复位的块里（写法同 bmp24_decoder 的 promax_scale_line_buffer），并且：
//   - 只存 24 位 RGB，高 8 位本来恒为 0，在输出端拼回去；
//   - 存储深度取 2*FIFO_DEPTH、读写指针多 1 位。fifo_count 最大就是 FIFO_DEPTH，
//     读写指针因此永远不会在同一拍指向同一地址，不存在 BRAM 同址读写冲突，
//     读出的数据与原来寄存器阵列的"读旧值"语义逐拍一致。
// 读写使能与原来赋值 fifo_mem / app_wr_data 的条件完全相同（load_ok 分支内）。
//
// 16 位色存储（PACK_RGB565=1）：为了在 8MB SDRAM 里放更多张图，像素截成
// RGB565，相邻两个像素拼成一个 32 位字 {后一个, 前一个}，每张图占
// IMAGE_WORDS/2 字。IMAGE_WORDS 沿用旧名，含义始终是"每张图的像素数"。
//   - 偶数像素先暂存在 pair_lo，奇数像素到来时才整字入 FIFO；
//   - pixels_received 仍按像素数校验，pixels_written 按字数校验；
//   - V_FLIP 按"每行 FRAME_WIDTH/2 字"倒序落盘，一行内像素对不跨行（640 为偶数）。
// 截位而不是四舍五入：PC 端若已按 565 色阶做过抖动，截位能原样保住。
// PACK_RGB565=0 时与改造前逐位等价。
//
// 13 张图扩展：IMAGE_COUNT / INDEX_W 两个参数（默认 4 / 2，与改造前一致）。
// bank 基址 = index * BANK_WORDS，用"按 index 查常量表"写，综合成每位一个
// 4 输入查找表，不出乘法器，sd 域时序不受影响。
// -----------------------------------------------------------------------------

module media_frame_loader #(
    parameter integer ADDR_WIDTH = 21,
    parameter integer IMAGE_WORDS = 307200,
    parameter integer FIFO_DEPTH = 512,
    parameter integer BURST_SIZE = 128,
    parameter integer STALL_TIMEOUT = 65535,
    // 本工程扩展：BMP 自底向上，写地址按行倒序落盘
    parameter integer V_FLIP = 0,
    parameter integer FRAME_WIDTH = 640,
    parameter integer FRAME_HEIGHT = 480,
    // 1 = RGB565 两像素一字；0 = 原来的一像素一字（24 位）
    parameter integer PACK_RGB565 = 0,
    parameter integer IMAGE_COUNT = 4,
    parameter integer INDEX_W = 2
) (
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  load_start,
    input  wire [INDEX_W-1:0]    image_index,
    input  wire                  pixel_valid,
    input  wire [23:0]           pixel_rgb,
    input  wire                  frame_commit,
    input  wire [7:0]            decode_error,
    output wire                  load_busy,
    output reg                   load_done,
    output reg  [IMAGE_COUNT-1:0] image_complete,
    output reg  [7:0]            memory_error,
    input  wire                  controller_init_done,
    input  wire                  controller_busy,
    input  wire                  refresh_active,
    output reg                   app_wr_en,
    output reg  [ADDR_WIDTH-1:0] app_wr_addr,
    output reg  [3:0]            app_wr_mask,
    output wire [31:0]           app_wr_data
);
    localparam ERR_NONE          = 8'h00;
    localparam ERR_NOT_ACTIVE    = 8'h41;
    localparam ERR_FIFO_OVERFLOW = 8'h42;
    localparam ERR_PIXEL_COUNT   = 8'h43;
    localparam ERR_DECODE        = 8'h44;
    localparam ERR_SHORT_FRAME   = 8'h45;
    localparam ERR_WRITE_STALL   = 8'h46;

    localparam integer PTR_WIDTH = (FIFO_DEPTH <= 2) ? 1 : $clog2(FIFO_DEPTH);
    localparam [PTR_WIDTH:0] EFFECTIVE_BURST =
        (BURST_SIZE < FIFO_DEPTH) ? BURST_SIZE : FIFO_DEPTH;
    // 每张图在 SDRAM 里占的字数 / 每行字数
    localparam integer BANK_WORDS = (PACK_RGB565 != 0) ? IMAGE_WORDS / 2 : IMAGE_WORDS;
    localparam integer ROW_WORDS  = (PACK_RGB565 != 0) ? FRAME_WIDTH / 2 : FRAME_WIDTH;
    localparam integer FIFO_W     = (PACK_RGB565 != 0) ? 32 : 24;

    // V_FLIP 地址映射常量（与 SD/frame_fifo_write.v 一致）：
    // 输入像素流顺序不变，只重映射落盘地址——流第0行写到显存最后一行。
    localparam [ADDR_WIDTH-1:0] VFLIP_FIRST_OFFSET = (FRAME_HEIGHT - 1) * ROW_WORDS;
    localparam [ADDR_WIDTH-1:0] VFLIP_LINE_JUMP    = (ROW_WORDS * 2) - 1;
    localparam integer          X_WIDTH            = (ROW_WORDS <= 2) ? 1 : $clog2(ROW_WORDS);

    reg active;
    reg [INDEX_W-1:0] active_image;
    reg commit_seen;
    reg [31:0] pixels_received;
    reg [31:0] pixels_written;
    reg [31:0] stall_count;
    localparam integer MEM_DEPTH = FIFO_DEPTH * 2;
    reg [FIFO_W-1:0] fifo_mem [0:MEM_DEPTH-1] /* fehdl force_ram=1, ram_style="bram" */;
    reg [FIFO_W-1:0] fifo_rd_data;
    // RGB565 打包：pair_half=1 表示 pair_lo 里已存着本对的前一个像素
    reg        pair_half;
    reg [15:0] pair_lo;
    wire [15:0] pixel_565 = {pixel_rgb[23:19], pixel_rgb[15:10], pixel_rgb[7:3]};
    // 本拍是否有一个整字要入 FIFO
    wire word_valid = (PACK_RGB565 != 0) ? (pixel_valid && pair_half) : pixel_valid;
    wire [FIFO_W-1:0] word_data;
    reg [PTR_WIDTH:0] wr_ptr;
    reg [PTR_WIDTH:0] rd_ptr;
    reg [PTR_WIDTH:0] fifo_count;
    reg burst_active;
    reg [PTR_WIDTH:0] burst_remaining;
    // 本工程扩展：写地址游标 + 行内列计数
    reg [ADDR_WIDTH-1:0] wr_addr_cursor;
    reg [X_WIDTH-1:0]    wr_x;
    wire pop_allowed;
    wire push_allowed;
    wire start_burst;
    wire [PTR_WIDTH:0] next_burst_words;

    assign load_busy = active;
    // The inherited controller consumes a continuous App_wr_en burst and
    // handles busy/refresh internally. Those status outputs are not per-word
    // ready signals and must not split an active write burst.
    assign start_burst = active && controller_init_done && !burst_active &&
                         fifo_count != 0 &&
                         (fifo_count >= EFFECTIVE_BURST || commit_seen);
    assign next_burst_words = (fifo_count >= EFFECTIVE_BURST) ?
                              EFFECTIVE_BURST : fifo_count;
    assign pop_allowed = active && controller_init_done && burst_active &&
                         fifo_count != 0;
    assign push_allowed = active && word_valid &&
                          (fifo_count < FIFO_DEPTH || pop_allowed);

    // 主状态机里"没有 fail_load"的那个分支条件，FIFO 读写只在这个分支里发生
    wire load_ok  = (decode_error == 0) &&
                    !(pixel_valid && pixels_received >= IMAGE_WORDS) &&
                    !(word_valid && !push_allowed);
    wire fifo_we  = load_ok && push_allowed;
    wire fifo_re  = load_ok && pop_allowed;

    generate
        if (PACK_RGB565 != 0) begin : g_word_565
            assign word_data = {pixel_565, pair_lo};   // 低半字 = 先到的（左边）像素
        end else begin : g_word_888
            assign word_data = pixel_rgb;
        end
    endgenerate

    always @(posedge clk) begin
        if (fifo_we)
            fifo_mem[wr_ptr] <= word_data;
        if (fifo_re)
            fifo_rd_data <= fifo_mem[rd_ptr];
    end
    // 24 位时高 8 位零扩展，32 位时原样
    assign app_wr_data = fifo_rd_data;

    // 越界 index（>= IMAGE_COUNT）落到最后一个 bank，与改造前 case 的 default 一致
    function [ADDR_WIDTH-1:0] bank_base;
        input [INDEX_W-1:0] index;
        integer k;
        begin
            bank_base = (IMAGE_COUNT - 1) * BANK_WORDS;
            for (k = 0; k < IMAGE_COUNT; k = k + 1)
                if (index == k)
                    bank_base = k * BANK_WORDS;
        end
    endfunction

    // image_complete 的位号，越界同样归到最后一位（与 bank_base 一致）
    function [INDEX_W-1:0] clamp_index;
        input [INDEX_W-1:0] index;
        begin
            clamp_index = (index < IMAGE_COUNT) ? index : IMAGE_COUNT - 1;
        end
    endfunction

    // 本次加载的落盘起点：V_FLIP 时从这一 bank 的最后一行开始往回写
    function [ADDR_WIDTH-1:0] start_addr;
        input [INDEX_W-1:0] index;
        begin
            start_addr = (V_FLIP != 0) ? (bank_base(index) + VFLIP_FIRST_OFFSET) :
                                          bank_base(index);
        end
    endfunction

    task fail_load;
        input [7:0] code;
        begin
            memory_error <= code;
            active <= 1'b0;
            burst_active <= 1'b0;
            burst_remaining <= 0;
            load_done <= 1'b1;
        end
    endtask

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            active <= 1'b0;
            active_image <= {INDEX_W{1'b0}};
            commit_seen <= 1'b0;
            pixels_received <= 32'd0;
            pixels_written <= 32'd0;
            stall_count <= 32'd0;
            wr_ptr <= {(PTR_WIDTH+1){1'b0}};
            rd_ptr <= {(PTR_WIDTH+1){1'b0}};
            fifo_count <= {(PTR_WIDTH+1){1'b0}};
            burst_active <= 1'b0;
            burst_remaining <= 0;
            wr_addr_cursor <= {ADDR_WIDTH{1'b0}};
            wr_x <= {X_WIDTH{1'b0}};
            pair_half <= 1'b0;
            pair_lo <= 16'd0;
            load_done <= 1'b0;
            image_complete <= {IMAGE_COUNT{1'b0}};
            memory_error <= ERR_NONE;
            app_wr_en <= 1'b0;
            app_wr_addr <= {ADDR_WIDTH{1'b0}};
            app_wr_mask <= 4'b0000;
        end else begin
            load_done <= 1'b0;
            app_wr_en <= 1'b0;

            if (load_start && !active) begin
                active <= 1'b1;
                active_image <= image_index;
                commit_seen <= 1'b0;
                pixels_received <= 32'd0;
                pixels_written <= 32'd0;
                stall_count <= 32'd0;
                wr_ptr <= {(PTR_WIDTH+1){1'b0}};
                rd_ptr <= {(PTR_WIDTH+1){1'b0}};
                fifo_count <= {(PTR_WIDTH+1){1'b0}};
                burst_active <= 1'b0;
                burst_remaining <= 0;
                wr_addr_cursor <= start_addr(image_index);
                wr_x <= {X_WIDTH{1'b0}};
                pair_half <= 1'b0;
                memory_error <= ERR_NONE;
                image_complete[clamp_index(image_index)] <= 1'b0;
            end

            if (active) begin
                if (decode_error != 0) begin
                    fail_load(ERR_DECODE);
                end else if (pixel_valid && pixels_received >= IMAGE_WORDS) begin
                    fail_load(ERR_PIXEL_COUNT);
                end else if (word_valid && !push_allowed) begin
                    fail_load(ERR_FIFO_OVERFLOW);
                end else begin
                    if (start_burst) begin
                        burst_active <= 1'b1;
                        burst_remaining <= next_burst_words;
                    end

                    // 这个分支里 pixel_valid 的像素一定被收下：
                    // 24 位时 pixel_valid 即 push_allowed；565 时偶数像素进 pair_lo
                    if (pixel_valid) begin
                        pixels_received <= pixels_received + 1'b1;
                        pair_half <= ~pair_half;
                        pair_lo <= pixel_565;
                    end
                    if (push_allowed) begin
                        // 数据写入见上方 fifo_mem 存储体（fifo_we）
                        wr_ptr <= wr_ptr + 1'b1;
                    end

                    if (pop_allowed) begin
                        app_wr_en <= 1'b1;
                        app_wr_addr <= wr_addr_cursor;
                        // app_wr_data 由存储体同拍读出（fifo_re），与 app_wr_en 对齐
                        app_wr_mask <= 4'b0000;
                        rd_ptr <= rd_ptr + 1'b1;
                        pixels_written <= pixels_written + 1'b1;
                        stall_count <= 32'd0;
                        // 地址游标推进：V_FLIP 时每写完一行往回跳两行再进一列
                        if (V_FLIP != 0 && wr_x == ROW_WORDS - 1) begin
                            wr_x <= {X_WIDTH{1'b0}};
                            wr_addr_cursor <= wr_addr_cursor - VFLIP_LINE_JUMP;
                        end else begin
                            wr_x <= wr_x + 1'b1;
                            wr_addr_cursor <= wr_addr_cursor + 1'b1;
                        end
                        if (burst_remaining == 1) begin
                            burst_active <= 1'b0;
                            burst_remaining <= 0;
                        end else begin
                            burst_remaining <= burst_remaining - 1'b1;
                        end
                    end else if (fifo_count != 0 &&
                                 (commit_seen || fifo_count >= EFFECTIVE_BURST)) begin
                        if (stall_count == STALL_TIMEOUT)
                            fail_load(ERR_WRITE_STALL);
                        else
                            stall_count <= stall_count + 1'b1;
                    end else begin
                        stall_count <= 32'd0;
                    end

                    case ({push_allowed, pop_allowed})
                        2'b10: fifo_count <= fifo_count + 1'b1;
                        2'b01: fifo_count <= fifo_count - 1'b1;
                        default: fifo_count <= fifo_count;
                    endcase

                    if (frame_commit)
                        commit_seen <= 1'b1;

                    if (commit_seen && fifo_count == 0 && !pop_allowed &&
                        !burst_active) begin
                        if (pixels_received != IMAGE_WORDS || pixels_written != BANK_WORDS) begin
                            fail_load(ERR_SHORT_FRAME);
                        end else begin
                            image_complete[clamp_index(active_image)] <= 1'b1;
                            active <= 1'b0;
                            load_done <= 1'b1;
                        end
                    end
                end
            end else if (pixel_valid) begin
                memory_error <= ERR_NOT_ACTIVE;
            end
        end
    end
endmodule
