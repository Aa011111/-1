`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第八讲 四bank帧缓存架构
// media_player_control：讲义原件 + 本工程需要的 prev_event / init_event 扩展。
//
// 与讲义原件的差异（两处加法，原有结构一行没动）：
//  1) 新增 prev_event：本工程 KEY2 长按=上一张，讲义原件只有"下一张"。
//     对应新增 prev_available()，与 next_available() 完全对称，只是 candidate
//     从 current-step 走。
//  2) 新增 init_event：讲义原件复位后 active_index=0，若 PIC1.BMP 缺失或解析
//     失败，会去读 bank0 的垃圾数据。原工程是靠 media_playback_selector.v 的
//     first_valid_index(image_complete) 在 ingest_done 时落位的，这个行为必须
//     保住——所以加一个 init_event，触发时选 image_complete 里最低位有效的 index。
//     如果直接用 next_event 代替，4 张图都在时会落到 1 而不是 0，不正确。
//
// 事件优先级：init_event > next_event > prev_event > 自动轮播。
// 三个事件共用同一套 busy/no-resource 判定，错误码语义不变。
//
// 第十三讲扩展：缩略图/全屏模式（讲义 4.1 "控制层：增加缩略图模式/全屏模式切换"）。
//  - thumb_mode 是 ctrl 域电平：KEY1 长按翻转（thumb_toggle_event），
//    串口 THUMB / FULL 明确设定（thumb_cfg_*，优先于翻转）。
//  - 焦点 focus_index 不另设寄存器，直接复用 active_index：缩略图模式下
//    NEXT/PREV/自动轮播照常改 active_index，屏幕上表现为黄框在 4 格间移动；
//    退回全屏时显示的就是焦点那张。index 的帧边界原子提交因此一并复用。
//  - 模式本身的帧边界锁定在 media_video_pipeline 的 pix 域做。
//
// 第十五讲（讲义第14课）缩略图交互选择：
//  - thumb_mode 连同 thumb_toggle/thumb_cfg 三个口整体搬到
//    control/thumbnail_controller（它要和转场握手，放这里不合适）。
//  - 焦点不再复用 active_index，改由 thumbnail_controller 的 focus_index
//    单独持有：缩略图下挪框不再真的切图。
//  - 新增 select_event/select_index：快速选择，直接切到指定 index，
//    走同一个 issue_request（busy/no-resource 判定、帧边界原子提交全部复用）。
//    目标图未加载完成时报 ERR_NO_RESOURCE，与 next/prev 语义一致。
//  - 新增 auto_hold：为 1 时自动轮播计数器清零、不发请求（浏览缩略图期间暂停，
//    回到全屏后重新数满一个周期）。
// 事件优先级：init_event > select_event > next_event > prev_event > 自动轮播。
//
// 13 张图扩展（默认参数下行为与改造前相同）：
//  - IMAGE_COUNT / INDEX_W：图片数与 index 位宽。next/prev 按 IMAGE_COUNT 取模回绕。
//  - NAV_MASK：哪些图参与 next/prev/自动轮播/首图落位（本工程 = PIC1~11，
//    PIC12/13 是火灾图，平时不出现）。select_event 不受它限制，缩略图里照样能选。
//  - 下一张/上一张/首图三个候选每拍预先算好寄存起来（next_q/prev_q/first_q），
//    事件到来时直接用：13 路循环优先查找不再挤在 100MHz 的单拍组合路径上。
//    候选从 pending_index 算（不是 sys_current_index）：pending_index 只在发请求
//    时变，随后 request_busy 至少维持一次跨域往返，等 busy 撤掉时候选早已更新。
//  - pix 域在 frame_start 提交时才取 index_sync2（不再用检测 toggle 那拍锁的值），
//    多位 index 过 2FF 时各位可能差一拍，提交至少晚检测一拍，届时已全部稳定。
// -----------------------------------------------------------------------------

module media_player_control #(
    parameter [31:0] DEFAULT_PERIOD_CYCLES = 32'd250000000,
    parameter [31:0] MIN_PERIOD_CYCLES = 32'd50000000,
    parameter [31:0] MAX_PERIOD_CYCLES = 32'd3000000000,
    parameter integer IMAGE_COUNT = 4,
    parameter integer INDEX_W = 2,
    parameter [IMAGE_COUNT-1:0] NAV_MASK = {IMAGE_COUNT{1'b1}}
) (
    input  wire        sys_clk,
    input  wire        sys_rst_n,
    input  wire        next_event,
    input  wire        prev_event,        // 本工程扩展：上一张（KEY2 长按）
    input  wire        init_event,        // 本工程扩展：摄入完成后首图落位
    input  wire        toggle_auto_event,
    input  wire        period_cfg_valid,
    input  wire [31:0] period_cfg_cycles,
    input  wire        auto_cfg_valid,
    input  wire        auto_cfg_enabled,
    input  wire [IMAGE_COUNT-1:0] image_complete,
    input  wire        select_event,       // 第十五讲：快速选择，直接切到 select_index
    input  wire [INDEX_W-1:0] select_index,
    input  wire        auto_hold,          // 第十五讲：1 = 暂停自动轮播
    output reg         auto_enabled,
    output reg  [31:0] active_period_cycles,
    output reg  [INDEX_W-1:0] pending_index,
    output reg  [7:0]  control_error,
    output wire        request_busy,
    input  wire        pix_clk,
    input  wire        pix_rst_n,
    input  wire        frame_start,
    output reg  [INDEX_W-1:0] active_index,
    output reg         index_commit
);
    localparam ERR_NONE = 8'h00;
    localparam ERR_PERIOD_RANGE = 8'h51;
    localparam ERR_REQUEST_BUSY = 8'h52;
    localparam ERR_NO_RESOURCE = 8'h53;

    reg [31:0] auto_counter;
    reg request_toggle;
    reg ack_toggle_pix;
    reg ack_sync1, ack_sync2;
    reg [INDEX_W-1:0] index_sync1, index_sync2;
    reg req_sync1, req_sync2;
    reg req_seen_pix;
    reg commit_pending_pix;
    // 预先算好的候选：{有效位, index}
    reg [INDEX_W:0] next_q;
    reg [INDEX_W:0] prev_q;
    reg [INDEX_W:0] first_q;
    wire [IMAGE_COUNT-1:0] nav_complete = image_complete & NAV_MASK;

    assign request_busy = request_toggle != ack_sync2;

    // 从 current 往后找第一个 complete 位为 1 的，按 IMAGE_COUNT 回绕；找不到时
    // 有效位为 0。只剩 current 自己一张时返回它自己——与改造前 4 张版一致。
    // 写法不做"current+step 再取模"的绕圈查找（13 级取模加法串联太长），
    // 而是：比 current 大的位里找最低的 1；没有就在全部位里找最低的 1。
    // 两者合起来正好是循环顺序里的第一个，结果与绕圈查找逐项相同。
    function [INDEX_W:0] next_available;
        input [INDEX_W-1:0] current;
        input [IMAGE_COUNT-1:0] complete;
        integer k;
        reg [INDEX_W:0] hi, any;
        begin
            hi  = {(INDEX_W+1){1'b0}};
            any = {(INDEX_W+1){1'b0}};
            for (k = IMAGE_COUNT - 1; k >= 0; k = k - 1) begin
                if (complete[k] && k > current) hi  = {1'b1, k[INDEX_W-1:0]};
                if (complete[k])                any = {1'b1, k[INDEX_W-1:0]};
            end
            next_available = hi[INDEX_W] ? hi :
                             any[INDEX_W] ? any : {1'b0, current};
        end
    endfunction

    // 本工程扩展：与 next_available 对称——比 current 小的位里找最高的 1，
    // 没有就在全部位里找最高的 1
    function [INDEX_W:0] prev_available;
        input [INDEX_W-1:0] current;
        input [IMAGE_COUNT-1:0] complete;
        integer k;
        reg [INDEX_W:0] lo, any;
        begin
            lo  = {(INDEX_W+1){1'b0}};
            any = {(INDEX_W+1){1'b0}};
            for (k = 0; k < IMAGE_COUNT; k = k + 1) begin
                if (complete[k] && k < current) lo  = {1'b1, k[INDEX_W-1:0]};
                if (complete[k])                any = {1'b1, k[INDEX_W-1:0]};
            end
            prev_available = lo[INDEX_W] ? lo :
                             any[INDEX_W] ? any : {1'b0, current};
        end
    endfunction

    // 本工程扩展：从 bank0 起找第一个已加载完成的，供 init_event 首图落位
    function [INDEX_W:0] first_available;
        input [IMAGE_COUNT-1:0] complete;
        integer k;
        begin
            first_available = {(INDEX_W+1){1'b0}};
            for (k = IMAGE_COUNT - 1; k >= 0; k = k - 1)
                if (complete[k])
                    first_available = {1'b1, k[INDEX_W-1:0]};
        end
    endfunction

    // 讲义原件的 issue_next_request 拆成带参数版，三个事件共用
    task issue_request;
        input [INDEX_W:0] selected;
        begin
            if (request_busy) begin
                control_error <= ERR_REQUEST_BUSY;
            end else if (!selected[INDEX_W]) begin
                control_error <= ERR_NO_RESOURCE;
            end else begin
                pending_index <= selected[INDEX_W-1:0];
                request_toggle <= ~request_toggle;
                auto_counter <= 32'd0;
            end
        end
    endtask

    always @(posedge sys_clk or negedge sys_rst_n) begin
        if (!sys_rst_n) begin
            auto_enabled <= 1'b0;
            active_period_cycles <= DEFAULT_PERIOD_CYCLES;
            pending_index <= {INDEX_W{1'b0}};
            control_error <= ERR_NONE;
            auto_counter <= 32'd0;
            request_toggle <= 1'b0;
            ack_sync1 <= 1'b0;
            ack_sync2 <= 1'b0;
            next_q <= {(INDEX_W+1){1'b0}};
            prev_q <= {(INDEX_W+1){1'b0}};
            first_q <= {(INDEX_W+1){1'b0}};
        end else begin
            ack_sync1 <= ack_toggle_pix;
            ack_sync2 <= ack_sync1;
            next_q  <= next_available(pending_index, nav_complete);
            prev_q  <= prev_available(pending_index, nav_complete);
            first_q <= first_available(nav_complete);

            if (period_cfg_valid) begin
                if (period_cfg_cycles < MIN_PERIOD_CYCLES ||
                    period_cfg_cycles > MAX_PERIOD_CYCLES) begin
                    control_error <= ERR_PERIOD_RANGE;
                end else begin
                    active_period_cycles <= period_cfg_cycles;
                    auto_counter <= 32'd0;
                end
            end

            if (auto_cfg_valid) begin
                auto_enabled <= auto_cfg_enabled;
                auto_counter <= 32'd0;
            end

            if (toggle_auto_event) begin
                auto_enabled <= ~auto_enabled;
                auto_counter <= 32'd0;
            end

            if (init_event) begin
                issue_request(first_q);
            end else if (select_event) begin
                // 第十五讲：快速选择。目标就是 select_index 本身，有效位看它有没有加载完
                issue_request({(select_index < IMAGE_COUNT) && image_complete[select_index],
                               select_index});
            end else if (next_event) begin
                issue_request(next_q);
            end else if (prev_event) begin
                issue_request(prev_q);
            end else if (auto_enabled && !auto_hold) begin
                if (request_busy)
                    auto_counter <= 32'd0;
                else if (auto_counter >= active_period_cycles - 1'b1)
                    issue_request(next_q);
                else
                    auto_counter <= auto_counter + 1'b1;
            end else begin
                auto_counter <= 32'd0;
            end
        end
    end

    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            index_sync1 <= {INDEX_W{1'b0}};
            index_sync2 <= {INDEX_W{1'b0}};
            req_sync1 <= 1'b0;
            req_sync2 <= 1'b0;
            req_seen_pix <= 1'b0;
            commit_pending_pix <= 1'b0;
            active_index <= {INDEX_W{1'b0}};
            index_commit <= 1'b0;
            ack_toggle_pix <= 1'b0;
        end else begin
            index_sync1 <= pending_index;
            index_sync2 <= index_sync1;
            req_sync1 <= request_toggle;
            req_sync2 <= req_sync1;
            index_commit <= 1'b0;

            if (req_sync2 != req_seen_pix && !commit_pending_pix) begin
                req_seen_pix <= req_sync2;
                commit_pending_pix <= 1'b1;
            end

            // pending_index 在 ack 回来之前不会再变，提交时取当拍同步值
            if (frame_start && commit_pending_pix) begin
                active_index <= index_sync2;
                index_commit <= 1'b1;
                commit_pending_pix <= 1'b0;
                ack_toggle_pix <= req_seen_pix;
            end
        end
    end
endmodule
