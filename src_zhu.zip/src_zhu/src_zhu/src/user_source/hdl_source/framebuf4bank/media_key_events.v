`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第八讲 四bank帧缓存架构
// media_key_events：从 fat32/media_playback_selector.v 里拆出来的"只管按键"的一半。
//
// 为什么要拆：原 media_playback_selector 把三件事写在同一个 always 块里——
// 按键消抖裁决、media_id 选择、数码管状态码。第八讲把 index 管理连同"帧消隐期
// 原子提交"一起交给 media_player_control（那是防撕裂的关键），所以这里只保留
// 按键裁决部分，输出纯事件脉冲；index 归 media_player_control，状态码回顶层。
//
// 按键逻辑与 media_playback_selector.v:117-191 逐条对应，包括它的两个门控：
//   - KEY1 按下沿 -> next_event（第十三讲起改为松开沿裁决，见下）
//   - KEY2 松开沿裁决：长按(≥LONG_PRESS_MS) -> prev_event，短按 -> toggle_auto_event
//     （在松开那一刻二选一，避免一次按压同时触发两个动作）
//   - ingest_done -> init_event（原来是 selector 内部 first_valid_index 落位，
//     现在转成一个脉冲交给 media_player_control 去选首图）
//   - 门控1 `ready`：对应原 selector 的 `else if (display_valid)`——摄入还没出
//     结果时按键一律不响应。少了它的话，摄入期按一下 KEY1，
//     media_player_control 会报 ERR_NO_RESOURCE(0x53) 把数码管点亮，是误报。
//   - 门控2 `image_complete`：对应原 selector 的 `valid_count > 1`——只有一张图
//     时不允许开自动轮播（开了也只会反复切到自己）。
// 消抖器直接实例化 media_playback_selector.v 里已有的 fat32_key_press_debounce，
// 不复制一份。
//
// 注意复位极性：原 selector 用高有效 rst（沿袭 sd_card_bmp 习惯），这里改成
// 与本讲其余模块一致的低有效 rst_n，内部转换后再喂给消抖器。
//
// 第十三讲：KEY1 也改成和 KEY2 一样的"松开时二选一"：
//   - 短按 -> next_event（缩略图模式下=焦点移到下一格）
//   - 长按(≥LONG_PRESS_MS) -> thumb_toggle_event，缩略图/全屏切换
// 代价是 next 从"按下沿"推迟到"松开沿"触发（几十~几百 ms，人手无感）；
// 不这样做的话长按一定会先触发一次 next。
//
// 第十五讲：本模块输出的仍是"按了什么"，不是"要做什么"——四个事件在缩略图
// 模式下的含义由 media_video_pipeline 翻译（KEY1短=焦点右移、KEY2长=焦点左移、
// KEY1长=确认选择、KEY2短=返回全屏）。唯一改动：新增 thumb_mode 输入，
// 缩略图模式下 KEY2 短按不再受"至少两张图"门控，否则只有一张图时没法返回全屏。
//
// 13 张图扩展：image_complete 宽度参数化（IMAGE_COUNT）。"至少两张"改用
// x & (x-1) != 0 判断（去掉最低的 1 后还有 1），不用逐位相加。顶层接进来的是
// 只含参与轮播那几张（PIC1~11）的掩码，火灾图不算数。
// -----------------------------------------------------------------------------

module media_key_events #(
    parameter integer CLK_FREQ_HZ   = 100_000_000,
    parameter integer LONG_PRESS_MS = 1000,
    parameter integer IMAGE_COUNT   = 4
)(
    input  wire       clk,              // sd_card_clk 域
    input  wire       rst_n,            // 低有效
    input  wire       key_next,         // KEY1，低有效
    input  wire       key_auto,         // KEY2，低有效：短按切自动播放/长按上一张
    input  wire       ingest_done,      // 开机摄入全部尝试完成，1拍脉冲
    input  wire       ready,            // 有图可显示了才响应按键（=display_valid）
    input  wire [IMAGE_COUNT-1:0] image_complete,   // 判断是否够两张图，决定能否开自动轮播
    input  wire       thumb_mode,       // 第十五讲：缩略图模式下 KEY2 短按 = 返回，不门控

    output reg        next_event,       // 下一张（KEY1 短按）
    output reg        prev_event,       // 上一张
    output reg        toggle_auto_event,// 自动播放开关翻转
    output reg        init_event,       // 首图落位
    output reg        thumb_toggle_event// 第十三讲：缩略图/全屏切换（KEY1 长按）
);
    wire rst = ~rst_n;

    wire key_next_stable;
    reg  key_next_stable_d;
    wire key_next_release = key_next_stable & ~key_next_stable_d;
    wire key_auto_stable;
    reg  key_auto_stable_d;
    wire key_auto_release = key_auto_stable & ~key_auto_stable_d;

    reg [31:0] long_press_cnt;
    reg        long_press_marked;
    reg [31:0] next_long_cnt;
    reg        next_long_marked;

    localparam [31:0] LONG_PRESS_CYCLES = (CLK_FREQ_HZ / 1000) * LONG_PRESS_MS;

    wire       multi_image = (image_complete & (image_complete - 1'b1)) != 0;

    fat32_key_press_debounce #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(50)
    ) u_key_next (
        .clk(clk), .rst(rst), .button_in(key_next),
        .press_pulse(), .button_stable_out(key_next_stable)
    );

    fat32_key_press_debounce #(
        .CLK_FREQ_HZ(CLK_FREQ_HZ), .DEBOUNCE_MS(20)
    ) u_key_auto (
        .clk(clk), .rst(rst), .button_in(key_auto),
        .press_pulse(), .button_stable_out(key_auto_stable)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            next_event        <= 1'b0;
            prev_event        <= 1'b0;
            toggle_auto_event <= 1'b0;
            init_event        <= 1'b0;
            thumb_toggle_event <= 1'b0;
            key_next_stable_d <= 1'b1;
            key_auto_stable_d <= 1'b1;
            long_press_cnt    <= 32'd0;
            long_press_marked <= 1'b0;
            next_long_cnt     <= 32'd0;
            next_long_marked  <= 1'b0;
        end else begin
            next_event        <= 1'b0;
            prev_event        <= 1'b0;
            toggle_auto_event <= 1'b0;
            thumb_toggle_event <= 1'b0;
            init_event        <= ingest_done;

            key_next_stable_d <= key_next_stable;
            key_auto_stable_d <= key_auto_stable;

            // 第十三讲：KEY1 短按/长按二选一，与下面 KEY2 同一套写法
            if (key_next_stable == 1'b0) begin
                if (next_long_cnt < LONG_PRESS_CYCLES - 1)
                    next_long_cnt <= next_long_cnt + 32'd1;
                else
                    next_long_marked <= 1'b1;
            end else begin
                if (key_next_release && ready) begin
                    if (next_long_marked)
                        thumb_toggle_event <= 1'b1;
                    else
                        next_event <= 1'b1;
                end
                next_long_cnt    <= 32'd0;
                next_long_marked <= 1'b0;
            end

            // KEY2 短按/长按二选一裁决：按住期间计时，松开那一刻才判定。
            // 计时本身不门控（按住的时候 ready 可能刚好翻转），只门控最终发事件
            if (key_auto_stable == 1'b0) begin
                if (long_press_cnt < LONG_PRESS_CYCLES - 1)
                    long_press_cnt <= long_press_cnt + 32'd1;
                else
                    long_press_marked <= 1'b1;
            end else begin
                if (key_auto_release && ready) begin
                    if (long_press_marked)
                        prev_event <= 1'b1;
                    else if (multi_image || thumb_mode)   // 只有一张图时开轮播没有意义
                        toggle_auto_event <= 1'b1;
                end
                long_press_cnt    <= 32'd0;
                long_press_marked <= 1'b0;
            end
        end
    end
endmodule
