# 光敏电阻模块 —— HDMI 画面亮度跟随环境光（src_zhu）

和 src 工程是同一个功能、同一份 `ambient_light_ctrl.v`（逐字节相同），接法也完全一样。
区别只有两处：本工程 sd_card_clk 是 50MHz（src 是 100MHz）；本工程的频谱环带没有亮度口，环带不跟着变暗。

## 接线（必须改一根线）

| 模块脚 | 接排针 | 丝印 -> 排阻 -> 网络 -> 管脚 | 说明 |
|---|---|---|---|
| VCC | J1-29 或 J2-29 | 3V3 | **不要接 5V**：ADC_VREF=3V3，AO 最高等于 VCC |
| GND | J1-30 / J2-30（或 J1-12 / J2-12） | GND | |
| DO  | J2-10 | GPIOB_9 -> RN31 -> GPIOB6 -> **H4** | 光弱 = 高；只作兜底 |
| AO  | **J1-37** | GPIOA_32 -> RN28 -> GPIOB33 -> **R16（ADC_CH_7）** | J2-14（GPIOB_11 -> GPIOB12 -> M2）是 BANK3 普通 IO，**没有 ADC，读不了模拟量** |

- AO、DO 都直接接排针，**不要经过 TXS0108E**：它传不了模拟量，模块也是 3V3 供电，不需要电平转换。
- 本工程 J2 已用：J2-1/3 触控屏串口、J2-2 MQ-2、J2-6 TXS0108E OE、J2-8 AM2302、J2-32/34/36 RS-485。
  J2-10（H4）和 J1-37（R16）都空着，不冲突。

EG4S20BG256 的 ADC 通道只在 BANK2：CH1=M10 CH2=L10 CH3=P11 CH4=M12 CH5=N12 CH6=P12 CH7=R16
（CH0=N11 是配置脚 M1，不能用）。排针上对应：J1-16(M10) J1-15(L10) J1-14(P11) J1-37(R16)、
J2-35(M12) J2-37(N12) J2-39(P12)。改用别的通道时同步改顶层实例的 `ADC_CHANNEL`。

暂时没法改线：把顶层 `LIGHT_USE_ADC` 改成 0，只用 DO 两档（暗 176 / 亮 255，阈值由模块上的电位器调）。
**不改线又保持 `LIGHT_USE_ADC=1` 的话，R16 是悬空的，ADC 会读到乱码，亮度会乱跳。**

## SW4 总开关

板上 SW4 拨动开关控制光敏自动亮度开/关（不用重新编译）：

| 开关 | 网络 | 管脚 | 说明 |
|---|---|---|---|
| SW4 | SW_4（3V3 / GND 二选一）-> RN38 120R -> SWKEY_4 | **C5** | 6_EX_DEVICE "4 bit Switch" -> 2_FPGA 页核对；电平由开关硬拉，不需要上下拉 |

- 读到顶层 `LIGHT_SW_ON_LEVEL`（默认 1，拨向 3V3）= 启用；拨到另一边 = 关闭。上板发现方向反了只改这个参数。
- 关闭时 `auto_level` 目标固定 255、跳过死区，按爬坡速度平滑回到 255（最多约 5s），之后就是纯手动亮度（BRT= / KEY3）；
  重新打开再平滑降到光照对应的亮度，两个方向都不会突跳。
- 开关进模块先过 `sync_2ff`（第一级 `s1`，已被 sdc 的 `*/s1` 覆盖），不单独消抖：抖动只有几 ms，爬坡 20ms 才看一次，最多多走 1 级。
- 顶层 `AUTO_BRIGHT_EN=0` 时 SW4 不起作用。

## 数据通路

```
AO ─> EG_PHY_ADC(CH7, 50MHz/8 = 6.25MHz) ─> 每 1ms 一次 ─> 64 次平均 ─> IIR 1/8 ─> 光照曲线 ─> 死区 4 + 每 20ms 一级 ─> auto_level
DO ─> sync_2ff ──────────────────────────────────────── (ADC 不应答时) ─> 176 / 255 ──────────┘
                                                                                             │
picture_param_ctrl(BRT= / KEY3) ─ 手动亮度 ─┬─> final = auto × (手动+1) / 256 ─> cdc[39:32] ─> pipeline
                                             └─────────────────────────────────> cdc[15:8]  ─> 参数面板 B:
```

- 默认 BRT=FF，最终亮度 = 纯自动；BRT= 仍然能在自动值上整体再压暗。
- 参数面板显示手动值，不显示自动值，否则亮度每变一级面板就会弹一次。
- 顶层 `AUTO_BRIGHT_EN=0` 关掉自动亮度：pipeline 直接接 cdc[15:8]（手动值），画面和改造前逐位相同。
- 四边频谱环带（`spectrum/spectrum_border_overlay.v`，带火警特效）本来就没有 brightness 口，
  改造前它也不跟 BRT=，这次没有动它：画面变暗时环带亮度不变。

### 50MHz 下的取值

| 参数 | 值 | 结果 |
|---|---|---|
| `CLK_FREQ_HZ` | `SD_CLK_HZ`（50_000_000） | SAMPLE = 50_000 拍，RAMP = 1_000_000 拍，24 位计数器够用 |
| `ADC_CLK_DIV` | 8（偶数且 >= 8） | ADC 时钟 6.25MHz（手册上限 16MHz），和 src 的 100MHz/16 一样； |
| | | soc 驱动、eoc/dout 采样离 ADC 时钟沿 2 拍 × 20ns = 40ns，也和 src 一样 |
| 其余 | 同 src | SAMPLE_MS 1 / AVG_SHIFT 6 / IIR_SHIFT 3 / RAMP_MS 20 / DEADBAND 4 / DO_DARK_LEVEL 176 / EN_ACTIVE_LEVEL = `LIGHT_SW_ON_LEVEL` |

`ambient_light_ctrl.v` 文件头里"ADC_CLK_DIV=16 -> 6.25MHz""100MHz 下"几处注释说的是模块默认参数（100MHz），
逻辑全按参数算，本工程没有改这个文件，两边保持同一份。

## 光照曲线（`ambient_light_ctrl.v` 里的 `curve_point`）

按 5528 光敏电阻（10lux ≈ 10k）估算，AO 码越小越亮：

| ADC 码 | 约光敏电阻 | 场景 | 亮度 |
|---|---|---|---|
| 0~512 | < 1.4k | 窗边/强光 | 255 |
| 1024 | 3.3k | 普通室内 | 240 |
| 2048 | 10k | 台灯/昏暗 | 200 |
| 3072 | 30k | 很暗 | 88 |
| 3584 | 70k | 几乎全黑 | 32 |
| ≥3840 | > 150k | 关灯 | 4（下限，画面几乎熄灭） |

第一版是 255 / 200 / 136 / 88 / 64，上板觉得整体偏暗，整条抬高了（DO 兜底暗档也从 112 提到 176）。

之后又嫌关灯时 128 的下限太亮（2026-11-03）：2048 以下的亮段不动，2048 往上每段降 28，末端 4。
乘到像素上白色只剩约 3/255，画面几乎熄灭；想要全黑就把末端改成 0。
暗段变陡后，爬坡会在 IIR 收敛尾段追上目标、停在死区里，所以关灯实际停在 4~8（白色约 3~7/255）；
从满亮降到底约 5s（每 20ms 一级）。DO 兜底暗档仍是 176，没动。

光敏电阻个体差异很大，觉得整体偏亮/偏暗就直接改这张表，保持单调不增即可。
改的话 src 那份也一起改，两边保持同一份。

## TD 工程变更（src_zhu）

- 备份：`top_tf_hdmi_audio.v.bak_before_light`、`pin.adc.bak_before_light`、`HDMI1.4b_Transmitter_v1.0.al.bak_before_light`
- SW4 总开关（2026-11-02）：备份 `*.bak_before_sw4`；顶层新增端口 `light_en_sw`、参数 `LIGHT_SW_ON_LEVEL`；`pin.adc` 新增 `light_en_sw = C5`；
  `ambient_light_ctrl` 新增端口 `light_en` / 参数 `EN_ACTIVE_LEVEL`，曲线整体调亮、`DO_DARK_LEVEL` 112 -> 176。.al 不用改。
- 新增 `light_sensor/ambient_light_ctrl.v`（.al 里 CompileOrder 84，接在 rtc_clock_osd 的 83 后面）；
  它用到的 `common/sync_2ff.v`、`common/cdc_bus_commit.v` 原来就在工程里。
- 顶层 `top_tf_hdmi_audio.v`：
  - 端口表最后加 `input light_do`（`lvl_oe` 后面补逗号，`LESSON14_KEY34` 的条件编译不变）；
  - 参数 `AUTO_BRIGHT_EN = 1`、`LIGHT_USE_ADC = 1`（放在 `VIDEO_CONTRAST` 后面）；
  - `u_picture_param_ctrl` 后面加 `u_ambient_light_ctrl` 和 `final_brightness_sd`（sd 域寄存器，复位值 `VIDEO_BRIGHTNESS`）；
  - `u_cfg_sd_to_video` 从 32 位扩到 40 位，`[39:32]` = `final_brightness_sd`，RESET_VAL 最高字节 = `VIDEO_BRIGHTNESS`；
    其余 4 个字段的位置不变；
  - `u_media_video_pipeline.brightness` 改接 `video_brightness_eff`；参数面板、串口日志仍用手动值，环带不变。
- `pin.adc` 新增 `light_do = H4`（LVCMOS33，内部上拉）；R16 不约束（由 ADC 原语占用）。
- sdc 没有改：DO 同步器第一级叫 `s1`，被现有的 `*/s1` 通配覆盖；cfg 总线 32->40 位还是同一个 `cdc_bus_commit`
  （`*/commit_sync1`、`*/ack_sync1` 已覆盖）。ADC 时钟是 sd_card_clk 分频出来的寄存器时钟，只接 ADC 原语，
  TD 不把它当时钟网络，报它 unconstrained 可以忽略。
- 改了 .al 之后要在 TD 图形界面里重新打开工程，再自己编译下载。

## 仿真

`sim/tb_ambient_light_ctrl.v`（自带 EG_PHY_ADC 行为模型，时钟 1MHz、`ADC_CLK_DIV=8`，和本工程用的分频一样）：

```
cd light_sensor/sim
vsim -c -do run.do          # ModelSim（Quartus 自带的 ASE 版即可），12 项全过打印 ALL PASS（含 SW4 开/关）
```

## 上板验证

| # | 操作 | 预期 | 不对时看哪里 |
|---|---|---|---|
| 1 | TD 编译 | 无 undefined module；EG_PHY_ADC 不报参数错；资源报告里 `#adc 1 out of 1` | 参数名不认就在 TD 里用 Primitive IP -> ADC 生成一个，对照它的写法改 `ALS_ADC_INST` |
| 2 | 正常室内上电 | 画面接近满亮（约 240/255） | — |
| 3 | 手捂住光敏电阻 | 平滑变暗，无台阶、无闪；越暗压得越狠，完全遮光（码 ≥ 3840）约 5s 内降到几乎全黑；环带亮度不变 | 不动 -> AO 线是不是在 J1-37；乱跳 -> AO 悬空 |
| 4 | 手机电筒照 | 平滑回到满亮 | — |
| 5 | 手在上方快速晃 | 亮度基本不动（平均 + IIR + 死区） | — |
| 6 | 串口 `BRT=80` | 在自动值上整体再暗一半，面板 `B:128` | — |
| 7 | 火灾图（PIC12/13）覆盖时捂住传感器 | 火灾图一样跟着变暗（pipeline 对火灾图也乘亮度）；ROM 逃生画面不受影响 | — |
| 8 | 拔掉 AO 线、`LIGHT_USE_ADC=0` 重编 | 只剩两档，拧电位器能改翻转点，模块 DO-LED 同步亮灭 | H4 约束 |
| 9 | SW4 拨到关，再捂住传感器 | 5s 内平滑回到满亮，捂住也不再变暗 | 一直不变 -> C5 约束；方向反了 -> 改 `LIGHT_SW_ON_LEVEL` |
| 10 | 捂住传感器时 SW4 拨回开 | 平滑变暗，无突跳 | — |
