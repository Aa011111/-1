`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// ambient_light_ctrl 回归：EG_PHY_ADC 用下面的行为模型代替（不进 TD 工程）。
// 跑法（在 light_sensor/sim 下）：vsim -c -do run.do
//   或 iverilog -g2005 -o tb.vvp tb_ambient_light_ctrl.v ../ambient_light_ctrl.v ../../common/sync_2ff.v && vvp tb.vvp
// 为了仿得快，CLK_FREQ_HZ 取 1MHz，SAMPLE_MS/RAMP_MS 都是 1（= 1000 拍）。
// -----------------------------------------------------------------------------

// 行为模型：soc 上升后 16 个 ADC 时钟出结果，eoc 保持到下一次 soc
module EG_PHY_ADC #(
    parameter CH0 = "DISABLE", parameter CH1 = "DISABLE",
    parameter CH2 = "DISABLE", parameter CH3 = "DISABLE",
    parameter CH4 = "DISABLE", parameter CH5 = "DISABLE",
    parameter CH6 = "DISABLE", parameter CH7 = "DISABLE"
) (
    input  wire        clk,
    input  wire        pd,
    input  wire [2:0]  s,
    input  wire        soc,
    output reg         eoc,
    output reg  [11:0] dout
);
    reg [4:0] cnt;
    reg       busy;
    initial begin eoc = 1'b0; dout = 12'd0; cnt = 0; busy = 1'b0; end
    always @(posedge clk) begin
        if (tb_ambient_light_ctrl.adc_dead) begin
            busy <= 1'b0;
            eoc  <= 1'b0;
        end
        else if (soc) begin
            busy <= 1'b1;
            cnt  <= 5'd0;
            eoc  <= 1'b0;
        end
        else if (busy) begin
            cnt <= cnt + 5'd1;
            if (cnt == 5'd15) begin
                busy <= 1'b0;
                eoc  <= 1'b1;
                dout <= tb_ambient_light_ctrl.ao_code;
            end
        end
    end
endmodule

module tb_ambient_light_ctrl;
    reg         clk = 1'b0;
    reg         rst_n = 1'b0;
    reg         light_do = 1'b0;
    reg         light_en = 1'b1;     // SW4，1 = 启用
    reg  [11:0] ao_code = 12'd512;
    reg         adc_dead = 1'b0;

    wire [7:0]  auto_level;
    wire [11:0] light_code;
    wire        adc_ok;
    wire        light_dark;

    integer errors = 0;

    always #500 clk = ~clk;     // 1MHz

    ambient_light_ctrl #(
        .CLK_FREQ_HZ   (1_000_000),
        .USE_ADC       (1),
        .ADC_CHANNEL   (3'd7),
        .ADC_CLK_DIV   (8),
        .SAMPLE_MS     (1),
        .AVG_SHIFT     (6),
        .IIR_SHIFT     (3),
        .RAMP_MS       (1),
        .DEADBAND      (8'd4),
        .DO_DARK_LEVEL (8'd176),
        .EN_ACTIVE_LEVEL(1'b1)
    ) dut (
        .clk        (clk),
        .rst_n      (rst_n),
        .light_do   (light_do),
        .light_en   (light_en),
        .auto_level (auto_level),
        .light_code (light_code),
        .adc_ok     (adc_ok),
        .light_dark (light_dark)
    );

    task expect_level;
        input [7:0] lo;
        input [7:0] hi;
        input [8*24-1:0] what;
        begin
            if (auto_level < lo || auto_level > hi) begin
                $display("FAIL %0s: auto_level=%0d, expect %0d~%0d (code=%0d adc_ok=%0d)",
                         what, auto_level, lo, hi, light_code, adc_ok);
                errors = errors + 1;
            end
            else begin
                $display("PASS %0s: auto_level=%0d (code=%0d)", what, auto_level, light_code);
            end
        end
    endtask

    // 每级 1000 拍，一次平均 64000 拍；IIR 1/8 从满量程收敛到 1 码约 60 次平均
    // ≈ 3.9M 拍，取 6M 拍留余量
    task settle;
        begin
            repeat (6_000_000) @(posedge clk);
        end
    endtask

    // 爬坡期间相邻两拍 auto_level 最多变 1（不跳变）
    reg [7:0] level_d;
    always @(posedge clk) begin
        level_d <= auto_level;
        // 9 位比较：8 位下 255 + 1 会回绕成 0
        if (rst_n && ({1'b0, auto_level} > {1'b0, level_d} + 9'd1 ||
                      {1'b0, level_d} > {1'b0, auto_level} + 9'd1)) begin
            $display("FAIL jump: %0d -> %0d", level_d, auto_level);
            errors = errors + 1;
        end
    end

    initial begin
        repeat (20) @(posedge clk);
        rst_n = 1'b1;

        // 1) 明亮室内：码 768 -> 表上 248
        ao_code = 12'd768;
        settle;
        expect_level(8'd246, 8'd250, "bright room 768");

        // 2) 关灯：码 3900 -> 4（下限，几乎熄灭）。曲线这段很陡，爬坡会在 IIR
        //    收敛尾段追上目标后停住，剩下 <= 死区，所以停在 4 上方 4 级以内
        ao_code = 12'd3900;
        settle;
        expect_level(8'd4, 8'd8, "dark 3900");

        // 2b) 很暗：码 3072 -> 88（从下往上追，同理停在 88 下方 4 级以内）
        ao_code = 12'd3072;
        settle;
        expect_level(8'd84, 8'd88, "very dim 3072");

        // 3) 中间：码 2048 -> 200
        ao_code = 12'd2048;
        settle;
        expect_level(8'd198, 8'd202, "dim 2048");

        // 4) 小抖动不应该动（死区）：码 2048 -> 2080，目标 197，差 3 级 <= 死区
        //    （2048 往上这段每 256 码降 28 级，比原来陡，2150 已经出死区了）
        ao_code = 12'd2080;
        settle;
        expect_level(8'd199, 8'd202, "deadband 2080");

        // 5) ADC 不应答 -> 退回 DO：DO=1（暗）-> 176
        adc_dead = 1'b1;
        light_do = 1'b1;
        settle;
        if (adc_ok) begin
            $display("FAIL adc_ok still 1 after ADC dead");
            errors = errors + 1;
        end
        expect_level(8'd176, 8'd176, "DO fallback dark");

        // 6) DO=0（亮）-> 255
        light_do = 1'b0;
        settle;
        expect_level(8'd255, 8'd255, "DO fallback bright");

        // 7) ADC 恢复 -> 回到连续调光
        adc_dead = 1'b0;
        ao_code  = 12'd1024;
        settle;
        if (!adc_ok) begin
            $display("FAIL adc_ok not recovered");
            errors = errors + 1;
        end
        // 从 255 往下走时目标（197 -> 240）也在往上涨，半路碰上就停，
        // 之后差值一直 <= 死区，所以会停在 240 下方 4 级以内
        expect_level(8'd235, 8'd242, "ADC recovered 1024");

        // 8) SW4 关：关灯也不压暗，平滑爬回 255（跳过死区，必须正好 255）
        ao_code = 12'd3900;
        settle;
        expect_level(8'd4, 8'd8, "dark before SW4 off");
        light_en = 1'b0;
        settle;
        expect_level(8'd255, 8'd255, "SW4 off");

        // 9) SW4 关时 ADC 坏了也一样是 255
        adc_dead = 1'b1;
        light_do = 1'b1;
        settle;
        expect_level(8'd255, 8'd255, "SW4 off, DO dark");
        adc_dead = 1'b0;
        light_do = 1'b0;

        // 10) SW4 重新打开 -> 平滑回到光照对应的亮度
        light_en = 1'b1;
        settle;
        expect_level(8'd4, 8'd8, "SW4 on again 3900");

        if (errors == 0) $display("ALL PASS");
        else             $display("%0d ERROR(S)", errors);
        $finish;
    end
endmodule
