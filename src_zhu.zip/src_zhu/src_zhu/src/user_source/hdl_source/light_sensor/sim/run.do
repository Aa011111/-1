# ambient_light_ctrl 回归（自带 EG_PHY_ADC 行为模型）：vsim -c -do run.do
onbreak {resume}
vlib work
vlog ../../common/sync_2ff.v ../ambient_light_ctrl.v tb_ambient_light_ctrl.v
vsim -c -quiet tb_ambient_light_ctrl
run -all
quit -f
