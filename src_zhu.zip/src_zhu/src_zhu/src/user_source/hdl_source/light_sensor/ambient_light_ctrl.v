`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 环境光自动亮度：光敏电阻模块（LM393 四线版）-> 片内 ADC -> 自动亮度系数
//
// 模块电路（光敏电阻传感器模块电路图.pdf）：
//     VCC ──10K──┬── AO ──光敏电阻── GND
//                └── LM393 反相端，和电位器 VR1 比较 -> DO
//   光越强，光敏电阻越小，AO 越低；DO：光弱于阈值 = 高，光强于阈值 = 低。
//   VR1 只调 DO 的翻转阈值，不影响 AO。
//
// 两个光源输入：
//   AO  -> EG4S20 片内 12 位 SAR ADC（EG_PHY_ADC），主路，连续调光
//   DO  -> 普通 IO，ADC 没开（USE_ADC=0）或 ADC 连续不应答时的兜底：
//          只有"亮/暗"两档，暗 = DO_DARK_LEVEL，亮 = 255
//
// 总开关 light_en：板上 SW4 拨动开关（6_EX_DEVICE "4 bit Switch"，SW_4 在
// 3V3 / GND 之间二选一，经 RN38 120R 成 SWKEY_4 进 C5，电平由开关硬拉）。
// 读到 EN_ACTIVE_LEVEL = 启用；否则目标固定 255（不压暗），auto_level 照样
// 按爬坡速度平滑回到 255，重新启用时再平滑降到光照对应的亮度，不会突跳。
// 开关抖动只有几 ms，爬坡 RAMP_MS 才看一次目标，最多多走 1 级，不需要单独消抖。
//
// 处理链（全部在 clk = sd_card_clk 域）：
//   每 SAMPLE_MS 转换一次 -> 2^AVG_SHIFT 次求平均（滤掉日光灯 100Hz 闪烁）
//   -> 一阶 IIR（时间常数约 2^AVG_SHIFT * SAMPLE_MS * 2^IIR_SHIFT）
//   -> light_curve 分段线性映射成目标亮度（人眼对亮度是对数感知，
//      暗处降得慢、亮处很快到满）
//   -> 死区 + 限速爬坡：|目标-当前| > DEADBAND 才开始动，动起来每 RAMP_MS
//      走 1 级直到追上。255->4（关灯）约 5s，看不出台阶，也不会跟着手影来回闪。
//
// EG_PHY_ADC 时钟：手册限制 <= 16MHz，PLL 五路输出已用满，这里由 clk
// 分频出一根寄存器时钟（ADC_CLK_DIV=16 -> 6.25MHz）。ADC 侧的 soc 驱动和
// eoc/dout 采样都只在 adc_tick（ADC 时钟低电平正中）这一拍做，
// 离 ADC 时钟上升沿各有 ADC_CLK_DIV/4 个 clk 的余量，不需要再跨域同步。
//
// 输出 auto_level：255 = 不压暗。顶层把它和 BRT=/KEY3 的手动亮度相乘后
// 再送像素链路，所以手动亮度仍然有效，是在自动值上再打个折。
// -----------------------------------------------------------------------------

module ambient_light_ctrl #(
        parameter integer CLK_FREQ_HZ   = 100_000_000,
        parameter integer USE_ADC       = 1,        // 0 = 只用 DO 两档
        parameter [2:0]   ADC_CHANNEL   = 3'd7,     // ADC_CH_7 = R16（J1-37）
        parameter integer ADC_CLK_DIV   = 16,       // clk / ADC 时钟，偶数且 >= 8
        parameter integer SAMPLE_MS     = 1,        // 转换间隔
        parameter integer AVG_SHIFT     = 6,        // 64 次求平均
        parameter integer IIR_SHIFT     = 3,        // IIR 系数 1/8
        parameter integer RAMP_MS       = 20,       // 爬坡每级间隔
        parameter [7:0]   DEADBAND      = 8'd4,     // 死区，单位：亮度级
        parameter [7:0]   DO_DARK_LEVEL = 8'd176,   // DO 兜底时"暗"那一档
        parameter         EN_ACTIVE_LEVEL = 1'b1    // light_en 读到这个电平 = 启用光敏
    ) (
        input  wire        clk,                     // sd_card_clk
        input  wire        rst_n,
        input  wire        light_do,                // 模块 DO，异步
        input  wire        light_en,                // SW4（SWKEY_4），异步

        output reg  [7:0]  auto_level,              // 自动亮度系数，255 = 原样
        output wire [11:0] light_code,              // 滤波后的 ADC 码（越小越亮）
        output reg         adc_ok,                  // 0 = ADC 不应答，已退回 DO
        output wire        light_dark               // DO 同步后，1 = 暗
    );
    localparam integer HALF          = ADC_CLK_DIV / 2;
    localparam integer QUARTER       = ADC_CLK_DIV / 4;
    localparam [31:0]  SAMPLE_CYCLES = (CLK_FREQ_HZ / 1000) * SAMPLE_MS;
    localparam [31:0]  RAMP_CYCLES   = (CLK_FREQ_HZ / 1000) * RAMP_MS;
    localparam [7:0]   EOC_TIMEOUT   = 8'd64;       // 正常 16 个 ADC 时钟出结果
    localparam [3:0]   FAIL_LIMIT    = 4'd8;        // 连续超时多少次判 ADC 坏

    // ---------------- DO 同步 ----------------
    // 第一级叫 s1，已被 sdc 的 */s1 通配 false_path 覆盖
    sync_2ff #(.RESET_VAL(1'b0)) u_do_sync (
        .clk      (clk),
        .rst_n    (rst_n),
        .async_in (light_do),
        .sync_out (light_dark)
    );

    // ---------------- SW4 总开关同步 ----------------
    // 复位值 = 关闭：目标 255，和 auto_level 的复位值一致，复位释放瞬间不动
    wire light_en_s;
    sync_2ff #(.RESET_VAL(!EN_ACTIVE_LEVEL)) u_en_sync (
        .clk      (clk),
        .rst_n    (rst_n),
        .async_in (light_en),
        .sync_out (light_en_s)
    );
    wire als_on = (light_en_s == EN_ACTIVE_LEVEL);

    // ---------------- ADC 时钟与 tick ----------------
    // div_cnt 变成 HALF 时 adc_clk 上升，变成 0 时下降；
    // adc_tick 落在低电平正中（div_cnt 由 QUARTER-1 变 QUARTER 的那个沿）
    reg [7:0] div_cnt;
    reg       adc_clk;
    wire      adc_tick = (div_cnt == QUARTER - 1);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_cnt <= 8'd0;
            adc_clk <= 1'b0;
        end
        else begin
            div_cnt <= (div_cnt == ADC_CLK_DIV - 1) ? 8'd0 : div_cnt + 8'd1;
            if (div_cnt == HALF - 1)
                adc_clk <= 1'b1;
            else if (div_cnt == ADC_CLK_DIV - 1)
                adc_clk <= 1'b0;
        end
    end

    // ---------------- 片内 ADC ----------------
    reg         adc_soc;
    wire        adc_eoc;
    wire [11:0] adc_dout;

    // 模拟输入管脚由 CHx("ENABLE") 直接连到焊盘，不出现在端口表里，
    // pin.adc 里也不要再约束这个管脚。只给要用的那个通道传参数（和 TD
    // 的 ADC IP 生成的写法一致），其余通道保持原语默认（不使能）。
    // BG256 上：CH1=M10 CH2=L10 CH3=P11 CH4=M12 CH5=N12 CH6=P12 CH7=R16，
    // CH0=N11 是配置脚 M1，本板接了 470R 下拉，不能用。
`define ALS_ADC_INST(CH_PARAM) \
            EG_PHY_ADC #(.CH_PARAM("ENABLE")) u_adc ( \
                .clk(adc_clk), .pd(1'b0), .s(ADC_CHANNEL), \
                .soc(adc_soc), .eoc(adc_eoc), .dout(adc_dout))
    generate
        if (USE_ADC != 0) begin : g_adc
            case (ADC_CHANNEL)
                3'd1:    begin : g_ch1 `ALS_ADC_INST(CH1); end
                3'd2:    begin : g_ch2 `ALS_ADC_INST(CH2); end
                3'd3:    begin : g_ch3 `ALS_ADC_INST(CH3); end
                3'd5:    begin : g_ch5 `ALS_ADC_INST(CH5); end
                3'd6:    begin : g_ch6 `ALS_ADC_INST(CH6); end
                3'd7:    begin : g_ch7 `ALS_ADC_INST(CH7); end
                default: begin : g_ch4 `ALS_ADC_INST(CH4); end
            endcase
        end
        else begin : g_no_adc
            assign adc_eoc  = 1'b0;
            assign adc_dout = 12'd0;
        end
    endgenerate
`undef ALS_ADC_INST

    // ---------------- 转换状态机（只在 adc_tick 动） ----------------
    // eoc 先等它变低再等它变高，避免把上一次残留的 eoc 当成这次的结果。
    localparam [1:0] S_IDLE     = 2'd0;
    localparam [1:0] S_SOC      = 2'd1;
    localparam [1:0] S_WAIT_LOW = 2'd2;
    localparam [1:0] S_WAIT_HI  = 2'd3;

    reg [1:0]  st;
    reg [23:0] sample_cnt;         // 24 位：100MHz 下最长 167ms，够用
    reg        sample_due;
    reg [7:0]  wait_cnt;
    reg [3:0]  fail_cnt;
    reg        conv_done;          // 单拍：拿到一个新样本
    reg [11:0] conv_data;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st         <= S_IDLE;
            sample_cnt <= 24'd0;
            sample_due <= 1'b0;
            wait_cnt   <= 8'd0;
            fail_cnt   <= 4'd0;
            adc_ok     <= (USE_ADC != 0);
            adc_soc    <= 1'b0;
            conv_done  <= 1'b0;
            conv_data  <= 12'd0;
        end
        else begin
            conv_done <= 1'b0;

            if (sample_cnt >= SAMPLE_CYCLES - 1) begin
                sample_cnt <= 24'd0;
                sample_due <= 1'b1;
            end
            else begin
                sample_cnt <= sample_cnt + 24'd1;
            end

            if (USE_ADC != 0 && adc_tick) begin
                case (st)
                    S_IDLE: begin
                        if (sample_due) begin
                            sample_due <= 1'b0;
                            adc_soc    <= 1'b1;
                            st         <= S_SOC;
                        end
                    end
                    S_SOC: begin                // soc 保持一个 ADC 时钟
                        adc_soc  <= 1'b0;
                        wait_cnt <= 8'd0;
                        st       <= S_WAIT_LOW;
                    end
                    S_WAIT_LOW, S_WAIT_HI: begin
                        wait_cnt <= wait_cnt + 8'd1;
                        if (st == S_WAIT_LOW && !adc_eoc) begin
                            st <= S_WAIT_HI;
                        end
                        else if (st == S_WAIT_HI && adc_eoc) begin
                            conv_data <= adc_dout;
                            conv_done <= 1'b1;
                            fail_cnt  <= 4'd0;
                            adc_ok    <= 1'b1;
                            st        <= S_IDLE;
                        end
                        else if (wait_cnt >= EOC_TIMEOUT) begin
                            if (fail_cnt == FAIL_LIMIT - 1)
                                adc_ok <= 1'b0;
                            else
                                fail_cnt <= fail_cnt + 4'd1;
                            st <= S_IDLE;
                        end
                    end
                endcase
            end
        end
    end

    // ---------------- 求平均 + IIR ----------------
    // filt_q 带 4 位小数，IIR 小步长时不会卡在差值 < 2^IIR_SHIFT 的地方
    reg [11+AVG_SHIFT:0] acc;
    reg [AVG_SHIFT-1:0]  acc_cnt;
    reg [15:0]           filt_q;
    reg                  have_avg;

    wire [11:0]       avg_now  = (acc + conv_data) >> AVG_SHIFT;
    wire signed [17:0] iir_diff = $signed({2'b00, avg_now, 4'b0000}) - $signed({2'b00, filt_q});
    wire signed [17:0] iir_step = iir_diff >>> IIR_SHIFT;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            acc      <= 0;
            acc_cnt  <= 0;
            filt_q   <= 16'd0;
            have_avg <= 1'b0;
        end
        else if (conv_done) begin
            if (&acc_cnt) begin
                acc      <= 0;
                acc_cnt  <= 0;
                have_avg <= 1'b1;
                // 第一个平均值直接装载，上电不用从 0 慢慢爬
                filt_q   <= have_avg ? filt_q + iir_step[15:0] : {avg_now, 4'b0000};
            end
            else begin
                acc     <= acc + conv_data;
                acc_cnt <= acc_cnt + 1'b1;
            end
        end
    end

    assign light_code = filt_q[15:4];

    // ---------------- 光照 -> 目标亮度 ----------------
    // 16 段分段线性，按 ADC 码高 4 位分段，低 8 位插值。
    // 下表按常见 5528 光敏电阻（10lux 约 10k）估算，R = 10k * code / (4096 - code)：
    //   码 0~512    R < 1.4k   强光/窗边   255
    //   码 ~1024    R ~ 3.3k   普通室内    240
    //   码 ~2048    R ~ 10k    台灯/昏暗   200
    //   码 ~3072    R ~ 30k    很暗         88
    //   码 ~3584    R ~ 70k    几乎全黑     32
    //   码 ~3840    R > 150k   关灯          4（下限，画面几乎熄灭）
    // （第一版是 255/200/136/88/64，上板觉得整体偏暗，整条抬高了一截；
    //   之后又嫌关灯时 128 的下限太亮，2048 以上的暗段改成每段降 28 直到 4，
    //   2048 以下的亮段不动）
    // 下限想要全黑就把末端改成 0（x * 1/256 = 0）。
    // 换了别的光敏电阻或想整体更亮/更暗，只改这张表（保持单调不增）。
    function [7:0] curve_point;
        input [4:0] idx;
        begin
            case (idx)
                5'd0:  curve_point = 8'd255;
                5'd1:  curve_point = 8'd255;
                5'd2:  curve_point = 8'd255;
                5'd3:  curve_point = 8'd248;
                5'd4:  curve_point = 8'd240;
                5'd5:  curve_point = 8'd232;
                5'd6:  curve_point = 8'd222;
                5'd7:  curve_point = 8'd212;
                5'd8:  curve_point = 8'd200;
                5'd9:  curve_point = 8'd172;
                5'd10: curve_point = 8'd144;
                5'd11: curve_point = 8'd116;
                5'd12: curve_point = 8'd88;
                5'd13: curve_point = 8'd60;
                5'd14: curve_point = 8'd32;
                default: curve_point = 8'd4;    // 15 和 16（末端）
            endcase
        end
    endfunction

    // 查表 -> 插值 -> 选源 -> 比较 一共 4 级流水（P1~P4）。第一版这一串
    // 全是组合逻辑、一拍走完，100MHz 下 place 后 setup 差 2.9ns。
    // 这些量 64ms 才变一次、爬坡 20ms 才看一次，晚几拍没有任何影响。
    reg [7:0] curve_p0_q;          // P1：段起点
    reg [7:0] curve_dlt_q;         // P1：段内落差（表单调不增，>= 0）
    reg [7:0] curve_frac_q;        // P1：段内位置
    reg [7:0] adc_target_q;        // P2：插值结果
    reg [7:0] target_q;            // P3：选源后的目标
    reg       target_ok_q;
    reg       tgt_eq_q;            // P4：target == auto_level
    reg       tgt_up_q;            // P4：target >  auto_level
    reg       tgt_far_q;           // P4：|target - auto_level| > DEADBAND

    wire [7:0]  curve_p0   = curve_point({1'b0, light_code[11:8]});
    wire [7:0]  curve_p1   = curve_point({1'b0, light_code[11:8]} + 5'd1);
    wire [15:0] curve_dmul = curve_dlt_q * curve_frac_q;

    wire [7:0] do_target = light_dark ? DO_DARK_LEVEL : 8'd255;

    // ADC 正常但第一个平均值还没出来（上电约 64ms）时保持当前值不动
    wire       use_adc   = (USE_ADC != 0) && adc_ok;
    wire [7:0] diff_abs  = tgt_up_q ? target_q - auto_level : auto_level - target_q;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            curve_p0_q   <= 8'd255;
            curve_dlt_q  <= 8'd0;
            curve_frac_q <= 8'd0;
            adc_target_q <= 8'd255;
            target_q     <= 8'd255;
            target_ok_q  <= 1'b0;
            tgt_eq_q     <= 1'b1;
            tgt_up_q     <= 1'b0;
            tgt_far_q    <= 1'b0;
        end
        else begin
            curve_p0_q   <= curve_p0;
            curve_dlt_q  <= curve_p0 - curve_p1;
            curve_frac_q <= light_code[7:0];

            adc_target_q <= curve_p0_q - curve_dmul[15:8];

            // SW4 关：目标固定 255，不等 ADC 平均值
            target_q     <= !als_on ? 8'd255 : use_adc ? adc_target_q : do_target;
            target_ok_q  <= !als_on ? 1'b1   : use_adc ? have_avg : 1'b1;

            // diff_abs 用的是上一拍的 tgt_up_q：auto_level 只在爬坡点变，
            // 两次爬坡之间隔 RAMP_CYCLES 拍，到下次爬坡时比较结果早就稳定了
            tgt_eq_q     <= (target_q == auto_level);
            tgt_up_q     <= (target_q >  auto_level);
            // SW4 关时跳过死区，保证一路爬回 255，而不是停在 251~254
            tgt_far_q    <= (diff_abs > DEADBAND) || !als_on;
        end
    end

    // ---------------- 死区 + 限速爬坡 ----------------
    reg [23:0] ramp_cnt;
    reg        tracking;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            auto_level <= 8'd255;
            ramp_cnt   <= 24'd0;
            tracking   <= 1'b0;
        end
        else begin
            if (ramp_cnt >= RAMP_CYCLES - 1) begin
                ramp_cnt <= 24'd0;
                if (target_ok_q) begin
                    if (tgt_eq_q) begin
                        tracking <= 1'b0;
                    end
                    else if (tracking || tgt_far_q) begin
                        tracking   <= 1'b1;
                        auto_level <= tgt_up_q ? auto_level + 8'd1 : auto_level - 8'd1;
                    end
                end
            end
            else begin
                ramp_cnt <= ramp_cnt + 24'd1;
            end
        end
    end
endmodule
