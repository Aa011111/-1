`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十五讲：thumbnail_controller 自检仿真（对应讲义 3.2.3 上板验证 1~4）
//
//   iverilog -g2005 -o tb.vvp tb_thumbnail_controller.v ../thumbnail_controller.v
//   vvp tb.vvp            -> 最后一行打印 PASS / FAIL (n errors)
//
// 周边用行为模型代替：
//   - 转场：收到 transition_req 后 busy 拉高，FAKE_FADE_CYCLES 拍后打一拍放行
//     脉冲（按 owned 分流，和 media_video_pipeline 一样）；drop_next=1 时丢掉
//     下一次请求，用来测 S_BLACK 超时兜底。
//   - 播放控制：select_event 那一拍 current_index <= select_index。
// image_complete = 4'b1011：图片3（index 2）缺失。
// -----------------------------------------------------------------------------
module tb_thumbnail_controller;
    localparam integer FAKE_FADE_CYCLES = 40;

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #5 clk = ~clk;

    reg        key_right = 0, key_left = 0, key_confirm = 0, key_mode = 0;
    reg        mode_cfg_valid = 0, mode_cfg_thumb = 0;
    reg  [3:0] image_complete = 4'b1011;
    reg  [1:0] current_index = 2'd0;

    wire       view_mode;
    wire [1:0] focus_index;
    wire       select_event;
    wire [1:0] select_index;
    wire       transition_req;
    wire       transition_owned;
    wire       auto_hold;

    // ---- 转场行为模型 ----
    reg        fade_busy = 1'b0;
    reg [7:0]  fade_cnt = 8'd0;
    reg        fade_release = 1'b0;
    reg        drop_next = 1'b0;
    always @(posedge clk) begin
        fade_release <= 1'b0;
        if (transition_req && !fade_busy) begin
            if (drop_next)
                drop_next <= 1'b0;
            else begin
                fade_busy <= 1'b1;
                fade_cnt  <= 8'd0;
            end
        end else if (fade_busy) begin
            fade_cnt <= fade_cnt + 8'd1;
            if (fade_cnt == FAKE_FADE_CYCLES) begin
                fade_release <= 1'b1;
                fade_busy    <= 1'b0;
            end
        end
    end
    wire transition_black = fade_release && transition_owned;

    // ---- 播放控制行为模型 ----
    integer select_count = 0;
    always @(posedge clk) begin
        if (select_event) begin
            current_index <= select_index;
            select_count  <= select_count + 1;
        end
    end

    thumbnail_controller #(
        .BLACK_TIMEOUT_CYCLES(32'd500)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .key_right(key_right), .key_left(key_left),
        .key_confirm(key_confirm), .key_mode(key_mode),
        .mode_cfg_valid(mode_cfg_valid), .mode_cfg_thumb(mode_cfg_thumb),
        .image_complete(image_complete),
        .current_index(current_index), .select_busy(1'b0),
        .transition_busy(fade_busy), .transition_black(transition_black),
        .view_mode(view_mode), .focus_index(focus_index),
        .select_event(select_event), .select_index(select_index),
        .transition_req(transition_req), .transition_owned(transition_owned),
        .auto_hold(auto_hold)
    );

    integer errors = 0;
    integer req_count = 0;
    always @(posedge clk) if (transition_req) req_count <= req_count + 1;

    task pulse_right;   begin @(negedge clk) key_right   = 1; @(negedge clk) key_right   = 0; end endtask
    task pulse_left;    begin @(negedge clk) key_left    = 1; @(negedge clk) key_left    = 0; end endtask
    task pulse_confirm; begin @(negedge clk) key_confirm = 1; @(negedge clk) key_confirm = 0; end endtask
    task pulse_mode;    begin @(negedge clk) key_mode    = 1; @(negedge clk) key_mode    = 0; end endtask
    task cfg_mode(input thumb);
        begin
            @(negedge clk) begin mode_cfg_valid = 1; mode_cfg_thumb = thumb; end
            @(negedge clk) mode_cfg_valid = 0;
        end
    endtask
    task settle; begin repeat (1000) @(posedge clk); end endtask

    task check(input cond, input [8*48-1:0] what);
        begin
            if (!cond) begin
                errors = errors + 1;
                $display("[%0t] FAIL: %0s (view=%0d focus=%0d current=%0d)",
                         $time, what, view_mode, focus_index, current_index);
            end
        end
    endtask

    integer req_before;
    initial begin
        repeat (5) @(posedge clk);
        rst_n = 1'b1;
        repeat (5) @(posedge clk);

        // 1) 全屏下方向键不动焦点、不发转场
        pulse_right; pulse_left; settle;
        check(focus_index == 2'd0 && req_count == 0 && !view_mode, "full: arrows ignored");
        check(!auto_hold, "full: auto not held");

        // 2) 从第2张进缩略图：焦点落在当前图，模式在转场全黑后才翻
        current_index = 2'd1;
        pulse_mode;
        repeat (10) @(posedge clk);
        check(!view_mode, "mode flips only after black");
        check(auto_hold, "auto held during transition");
        settle;
        check(view_mode && focus_index == 2'd1 && current_index == 2'd1, "enter thumb, focus = current");
        check(req_count == 1, "one transition for mode enter");

        // 3) 右移 1->2->3->0（wrap），左移 0->3
        pulse_right; check(focus_index == 2'd2, "right 1->2");
        pulse_right; check(focus_index == 2'd3, "right 2->3");
        pulse_right; check(focus_index == 2'd0, "right 3->0 wrap");
        pulse_left;  check(focus_index == 2'd3, "left 0->3 wrap");
        check(current_index == 2'd1, "moving focus does not switch image");

        // 4) 焦点移到未加载的图片3（index 2），确认无反应
        pulse_left; check(focus_index == 2'd2, "left 3->2");
        req_before = req_count;
        pulse_confirm; settle;
        check(view_mode && req_count == req_before, "confirm on unloaded ignored");

        // 5) 焦点到 index 3 确认：回全屏、切到 3、带一次转场
        pulse_right; pulse_confirm; settle;
        check(!view_mode && current_index == 2'd3, "confirm selects focus");
        check(req_count == req_before + 1, "one transition for confirm");
        check(!auto_hold, "auto released in full");

        // 6) 串口 THUMB 进、FULL 回：不换图；已在全屏时 FULL 无动作
        req_before = req_count;
        cfg_mode(1'b0); settle;
        check(req_count == req_before, "FULL in full = no-op");
        cfg_mode(1'b1); settle;
        check(view_mode && focus_index == 2'd3, "THUMB enters, focus = current");
        pulse_left; pulse_left;              // 焦点 3->2->1
        cfg_mode(1'b0); settle;
        check(!view_mode && current_index == 2'd3, "FULL returns without switching");

        // 7) 缩略图下按 mode（KEY2 短按）返回同样不换图
        pulse_mode; settle;
        pulse_right;                         // 焦点 3->0
        pulse_mode; settle;
        check(!view_mode && current_index == 2'd3, "mode key returns without switching");

        // 8) 转场请求被丢掉时，超时后照样生效，不卡死
        drop_next = 1'b1;
        pulse_mode; settle;
        check(view_mode, "timeout fallback applies mode");

        if (errors == 0) $display("PASS (%0d selects, %0d transitions)", select_count, req_count);
        else             $display("FAIL (%0d errors)", errors);
        $finish;
    end
endmodule
