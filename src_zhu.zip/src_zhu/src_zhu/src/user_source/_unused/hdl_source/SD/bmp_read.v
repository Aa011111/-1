// 扇区流驱动：负责 SD 扇区的寻址与顺序读取，把字节流喂给 bmp24_decoder，
// 由后者完成 BMP 头解析、合法性校验和像素输出。本模块不再自己解析 BMP。
module bmp_read #(
        parameter integer BMP_WIDTH  = 640,
        parameter integer BMP_HEIGHT = 480,
        // 未命中时的扫描步长。图片拷进格式化的卡时文件对齐到簇边界，
        // 按 8 步进可把"爬到第一张图"的时间缩到约 1/8。
        // 万一实际起始扇区没对齐到这个步长，粗扫会一无所获，
        // 此时自动退回步长 1 再扫一遍，保证仍能找到图（见 fine_pass）。
        parameter integer SCAN_STEP_SECTORS = 8
    )(
        input                       clk,
        input                       rst,
        output                      ready,

        // 上电扫描：从 scan_start_sector 开始，顺序寻找前 scan_target_count 张 BMP
        input                       scan_start,
        input  [31:0]               scan_start_sector,
        input  [31:0]               scan_max_sector,
        input  [2:0]                scan_target_count,
        output reg                  scan_done,
        output reg                  scan_found_valid,
        output reg [31:0]           scan_found_sector,
        output reg [2:0]            scan_found_total,

        // 按指定扇区加载一张图到 SDRAM
        input                       load_start,
        input  [31:0]               load_sector,
        input                       load_abort,

        input                       sd_init_done,
        output reg [3:0]            state_code,
        output reg                  load_fail,          // 本次加载失败（1 拍脉冲）
        output     [7:0]            bmp_error,          // 解析器给出的故障码

        output reg                  write_req,
        input                       write_req_ack,

        output reg                  sd_sec_read,
        output reg [31:0]           sd_sec_read_addr,
        input  [7:0]                sd_sec_read_data,
        input                       sd_sec_read_data_valid,
        input                       sd_sec_read_end,

        output                      bmp_data_wr_en,
        output     [23:0]           bmp_data
    );

    // 所有图都是 BMP_WIDTH x BMP_HEIGHT 的 24bpp 无压缩图，文件长度为定值，
    // 因此每张图固定占用 SECTORS_PER_FILE 个扇区，扫描即按此步进。
    // 传给解析器的 file_size 取整扇区窗口而非精确字节数，
    // 好让带少量尾部填充的图仍能通过截断校验。
    localparam integer BMP_ROW_STRIDE   = ((BMP_WIDTH * 3 + 3) / 4) * 4;
    localparam integer BMP_DATA_BYTES   = BMP_ROW_STRIDE * BMP_HEIGHT;
    localparam integer BMP_FILE_BYTES   = 54 + BMP_DATA_BYTES;
    localparam integer SECTORS_PER_FILE = (BMP_FILE_BYTES + 511) / 512;
    localparam integer FILE_WINDOW      = SECTORS_PER_FILE * 512;

    localparam [3:0] ST_IDLE          = 4'd0;
    localparam [3:0] ST_SCAN_ARM      = 4'd1;
    localparam [3:0] ST_SCAN_READ     = 4'd2;
    localparam [3:0] ST_HDR_ARM       = 4'd3;
    localparam [3:0] ST_HDR_READ      = 4'd4;
    localparam [3:0] ST_LOAD_REQ      = 4'd5;
    localparam [3:0] ST_DATA_ARM      = 4'd6;
    localparam [3:0] ST_DATA_READ     = 4'd7;
    localparam [3:0] ST_DATA_FLUSH    = 4'd8;

    reg [3:0]  state;
    reg [31:0] scan_sector;
    reg [31:0] load_sector_latched;
    reg [31:0] stream_offset;
    reg [15:0] sector_index;
    reg        file_start;
    reg        file_end;
    reg        in_load_mode;       // 只有加载阶段的像素才允许写入 FIFO
    reg        fine_pass;          // 0=粗扫(步长 SCAN_STEP_SECTORS)，1=细扫(步长 1)

    wire        dec_header_accepted;
    wire        dec_pixel_valid;
    wire [23:0] dec_pixel_rgb;
    wire        dec_frame_commit;
    wire        dec_bmp_done;

    // 粗扫只用于跨越"从起点到第一张图"那段长距离。一旦找到第一张，
    // 后续跳转基点是 上一张起点+文件长度，不再落在粗扫网格上，
    // 继续粗扫会错过按簇对齐的后几张图，因此这里切回步长 1。
    // 后几张图本来就紧邻，细扫至多多读几个扇区，代价可忽略。
    wire [31:0] scan_step_now = (fine_pass || (scan_found_total != 3'd0))
                                ? 32'd1 : SCAN_STEP_SECTORS;
    wire [31:0] next_scan_sector_if_match = scan_sector + SECTORS_PER_FILE;
    wire [31:0] next_scan_sector_if_miss  = scan_sector + scan_step_now;

    assign ready          = (state == ST_IDLE);
    assign bmp_data_wr_en = dec_pixel_valid && in_load_mode;
    assign bmp_data       = dec_pixel_rgb;

    bmp24_decoder #(
                      .EXPECTED_WIDTH  (BMP_WIDTH),
                      .EXPECTED_HEIGHT (BMP_HEIGHT),
                      .ALLOW_2X_SOURCE (0)
                  ) u_bmp24_decoder (
                      .clk              (clk),
                      .rst_n            (~rst),
                      .file_start       (file_start),
                      .file_size        (FILE_WINDOW),
                      .file_valid       (sd_sec_read_data_valid),
                      .file_byte        (sd_sec_read_data),
                      .file_byte_offset (stream_offset),
                      .file_end         (file_end),
                      .upstream_error   (8'd0),
                      .header_accepted  (dec_header_accepted),
                      .pixel_valid      (dec_pixel_valid),
                      .pixel_rgb        (dec_pixel_rgb),
                      .pixel_x          (),
                      .pixel_y          (),
                      .frame_commit     (dec_frame_commit),
                      .bmp_done         (dec_bmp_done),
                      .bmp_error        (bmp_error),
                      .top_down         (),
                      .pixel_offset     (),
                      .row_stride       (),
                      .source_scale_2x  ()
                  );

    // 字节偏移随扇区流连续累加，file_start 时归零
    always @(posedge clk or posedge rst) begin
        if (rst)
            stream_offset <= 32'd0;
        else if (file_start)
            stream_offset <= 32'd0;
        else if (sd_sec_read_data_valid)
            stream_offset <= stream_offset + 32'd1;
    end

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            state               <= ST_IDLE;
            state_code          <= 4'd0;
            sd_sec_read         <= 1'b0;
            sd_sec_read_addr    <= 32'd0;
            write_req           <= 1'b0;
            scan_done           <= 1'b0;
            scan_found_valid    <= 1'b0;
            scan_found_sector   <= 32'd0;
            scan_found_total    <= 3'd0;
            scan_sector         <= 32'd0;
            load_sector_latched <= 32'd0;
            sector_index        <= 16'd0;
            file_start          <= 1'b0;
            file_end            <= 1'b0;
            in_load_mode        <= 1'b0;
            load_fail           <= 1'b0;
            fine_pass           <= 1'b0;
        end
        else if (!sd_init_done) begin
            state               <= ST_IDLE;
            state_code          <= 4'd0;
            sd_sec_read         <= 1'b0;
            sd_sec_read_addr    <= 32'd0;
            write_req           <= 1'b0;
            scan_done           <= 1'b0;
            scan_found_valid    <= 1'b0;
            scan_found_sector   <= 32'd0;
            scan_found_total    <= 3'd0;
            scan_sector         <= 32'd0;
            load_sector_latched <= 32'd0;
            sector_index        <= 16'd0;
            file_start          <= 1'b0;
            file_end            <= 1'b0;
            in_load_mode        <= 1'b0;
            load_fail           <= 1'b0;
            fine_pass           <= 1'b0;
        end
        else begin
            scan_found_valid <= 1'b0;
            file_start       <= 1'b0;
            file_end         <= 1'b0;
            load_fail        <= 1'b0;

            if (load_abort) begin
                state        <= ST_IDLE;
                state_code   <= 4'd1;
                sd_sec_read  <= 1'b0;
                write_req    <= 1'b0;
                in_load_mode <= 1'b0;
            end
            else case (state)
                ST_IDLE: begin
                    state_code   <= 4'd1;
                    sd_sec_read  <= 1'b0;
                    write_req    <= 1'b0;
                    in_load_mode <= 1'b0;

                    if (scan_start) begin
                        scan_done        <= 1'b0;
                        scan_found_total <= 3'd0;
                        scan_sector      <= scan_start_sector;
                        sd_sec_read_addr <= scan_start_sector;
                        fine_pass        <= 1'b0;      // 新一轮扫描从粗扫开始
                        file_start       <= 1'b1;
                        state            <= ST_SCAN_ARM;
                    end
                    else if (load_start) begin
                        load_sector_latched <= load_sector;
                        sd_sec_read_addr    <= load_sector;
                        file_start          <= 1'b1;
                        state               <= ST_HDR_ARM;
                    end
                end

                // file_start 已发出，下一拍才拉读使能，保证偏移计数从 0 起算
                ST_SCAN_ARM: begin
                    state_code  <= 4'd2;
                    sd_sec_read <= 1'b1;
                    state       <= ST_SCAN_READ;
                end

                ST_SCAN_READ: begin
                    state_code  <= 4'd2;
                    sd_sec_read <= 1'b1;

                    if (sd_sec_read_end) begin
                        sd_sec_read <= 1'b0;

                        if (dec_header_accepted) begin
                            scan_found_valid  <= 1'b1;
                            scan_found_sector <= scan_sector;
                            scan_found_total  <= scan_found_total + 3'd1;

                            sd_sec_read_addr <= next_scan_sector_if_match;
                            scan_sector      <= next_scan_sector_if_match;

                            if ((scan_found_total + 3'd1 >= scan_target_count) ||
                                (next_scan_sector_if_match > scan_max_sector)) begin
                                scan_done <= 1'b1;
                                state     <= ST_IDLE;
                            end
                            else begin
                                file_start <= 1'b1;
                                state      <= ST_SCAN_ARM;
                            end
                        end
                        else begin
                            if (scan_sector >= scan_max_sector) begin
                                // 粗扫扫到头却一张都没找到，退回逐扇区细扫再来一遍。
                                // 细扫固定从 0 开始（而不是 scan_start_sector）：
                                // 这样即便步长没对齐、或起始扇区设得比实际图片还靠后，
                                // 都还能兜住，不会变成永久黑屏。
                                if (!fine_pass && (scan_found_total == 3'd0) &&
                                    ((SCAN_STEP_SECTORS > 1) || (scan_start_sector != 32'd0))) begin
                                    fine_pass        <= 1'b1;
                                    scan_sector      <= 32'd0;
                                    sd_sec_read_addr <= 32'd0;
                                    file_start       <= 1'b1;
                                    state            <= ST_SCAN_ARM;
                                end
                                else begin
                                    scan_done <= 1'b1;
                                    state     <= ST_IDLE;
                                end
                            end
                            else begin
                                sd_sec_read_addr <= next_scan_sector_if_miss;
                                scan_sector      <= next_scan_sector_if_miss;
                                file_start       <= 1'b1;
                                state            <= ST_SCAN_ARM;
                            end
                        end
                    end
                end

                ST_HDR_ARM: begin
                    state_code  <= 4'd2;
                    sd_sec_read <= 1'b1;
                    state       <= ST_HDR_READ;
                end

                // 第一遍只读首扇区做头部校验，通过后再回到起始扇区正式读像素
                ST_HDR_READ: begin
                    state_code  <= 4'd2;
                    sd_sec_read <= 1'b1;

                    if (sd_sec_read_end) begin
                        sd_sec_read <= 1'b0;
                        if (dec_header_accepted) begin
                            write_req        <= 1'b1;
                            sd_sec_read_addr <= load_sector_latched;
                            state            <= ST_LOAD_REQ;
                        end
                        else begin
                            load_fail <= 1'b1;
                            state     <= ST_IDLE;
                        end
                    end
                end

                ST_LOAD_REQ: begin
                    state_code <= 4'd3;
                    if (write_req_ack) begin
                        write_req    <= 1'b0;
                        sector_index <= 16'd0;
                        in_load_mode <= 1'b1;
                        file_start   <= 1'b1;
                        state        <= ST_DATA_ARM;
                    end
                end

                ST_DATA_ARM: begin
                    state_code  <= 4'd4;
                    sd_sec_read <= 1'b1;
                    state       <= ST_DATA_READ;
                end

                ST_DATA_READ: begin
                    state_code  <= 4'd4;
                    sd_sec_read <= 1'b1;

                    if (sd_sec_read_end) begin
                        sd_sec_read <= 1'b0;
                        if (sector_index == SECTORS_PER_FILE - 1) begin
                            file_end <= 1'b1;
                            state    <= ST_DATA_FLUSH;
                        end
                        else begin
                            sector_index     <= sector_index + 16'd1;
                            sd_sec_read_addr <= sd_sec_read_addr + 32'd1;
                            state            <= ST_DATA_ARM;
                        end
                    end
                end

                // bmp_done 与 frame_commit / bmp_error 同一拍更新，可直接判读
                ST_DATA_FLUSH: begin
                    state_code   <= 4'd4;
                    sd_sec_read  <= 1'b0;
                    if (dec_bmp_done) begin
                        in_load_mode <= 1'b0;
                        if (!dec_frame_commit)
                            load_fail <= 1'b1;
                        state <= ST_IDLE;
                    end
                end

                default: begin
                    state        <= ST_IDLE;
                    state_code   <= 4'd1;
                    sd_sec_read  <= 1'b0;
                    write_req    <= 1'b0;
                    in_load_mode <= 1'b0;
                end
            endcase
        end
    end

endmodule
