
module sd_card_bmp #(
        parameter integer CLK_FREQ_HZ       = 100_000_000,      // 时钟频率，100MHz
        parameter [31:0]  SCAN_START_SECTOR = 32'd0,            //扫描起始扇区，0~131071
        parameter [31:0]  SCAN_MAX_SECTOR   = 32'd131071,      //扫描最大扇区，0~131071，建议不要超过 131071（32MB），否则可能扫描到 FAT 表或根目录而误判
        parameter [2:0]   SCAN_TARGET_COUNT = 3'd4,             // 扫描目标数量，最多 4 张图
        // === 新增：长按时间和轮播周期可配置 ===
        parameter integer LONG_PRESS_MS      = 1000,   // KEY2长按触发时间，默认1秒
        parameter integer AUTO_PLAY_MS       = 3000,   // 自动轮播间隔，默认3秒
        // BMP 尺寸改为参数：解析器需要在编译期确定行跨距和文件长度
        parameter integer BMP_WIDTH          = 640,
        parameter integer BMP_HEIGHT         = 480,
        // 扫描未命中时的步长，见 bmp_read。设 1 即为原来的逐扇区扫描
        parameter integer SCAN_STEP_SECTORS  = 8
    )(
        input                       clk,                      // 系统时钟，100MHz
        input                       rst,                      // 系统复位，高电平有效
        input                       key_next,                 // 下一张图片按键，低电平有效
        input                       key_auto,                 // 自动播放按键
        output reg                  display_valid,            // 显示有效信号，首图提交前为0，
        // 原来：output [3:0] state_code,
        // 改成：
        output       [3:0]          state_code,         // 数码管显示（复用端口，内容改为图片编号）
        output       [1:0]          media_id,                 // 当前显示中的图片编号，供音频侧选择对应旋律
        output                      auto_play_on,             // 自动播放使能状态，供 OSD 显示
        output       [7:0]          player_error_code,        // 当前故障码，恢复后自动清零，供 OSD 显示

        input                       write_finish_toggle,      // 写帧完成脉冲，是电平反转？来自 mem_clk 域的 write_finish_toggle 同步到 clk 域
        output reg [1:0]            write_buf_idx,            // 当前正在写入的缓冲区编号，0/1
        output reg [1:0]            disp_buf_idx,             // 当前正在显示的缓冲区编号，0/1

        output                      write_req,                // 写帧请求，bmp_read 发起写帧请求，sd_card_bmp 看到后会把 bmp_data 写入 FIFO
        input                       write_req_ack,            // 写帧请求应答，sd_card_bmp 收到写帧请求后会应答，表示可以开始写入 bmp_data
        output                      write_en,                 // 写入使能，bmp_read 发起写帧请求后，sd_card_bmp 会把 bmp_data 写入 FIFO 时拉高
        output [31:0]               write_data,               // 写入数据，bmp_read 发起写帧请求后，sd_card_bmp 会把 bmp_data 写入 FIFO 时输出
        output                      SD_nCS,                   // SD 卡片选通信号，低电平有效
        output                      SD_DCLK,
        output                      SD_MOSI,
        input                       SD_MISO
    );

    wire key_next_press;
    wire key_auto_press;

    wire             sd_sec_read;
    wire [31:0]      sd_sec_read_addr;
    wire [7:0]       sd_sec_read_data;
    wire             sd_sec_read_data_valid;
    wire             sd_sec_read_end;
    wire [3:0]       state_code_i;
    wire             bmp_data_wr_en;
    wire [23:0]      bmp_data;
    wire             sd_init_done;
    wire             bmp_ready;
    wire             scan_done;
    wire             scan_found_valid;
    wire [31:0]      scan_found_sector;
    wire [2:0]       scan_found_total;

    reg              scan_start_pulse;    // 扫描前 4 张 BMP 的起始扇区脉冲
    reg              load_start_pulse;    // 加载 BMP 到缓冲区的起始扇区脉冲
    reg [31:0]       load_sector;       // 当前正在加载的 BMP 的起始扇区
    reg              scan_kicked;        // 扫描前 4 张 BMP 的起始扇区脉冲已经发过了，避免重复发起的标志信号
    reg              first_image_committed;     // 首图已经提交到显示缓冲区的标志信号，避免在首图提交前就自动播放下一张
    reg              auto_play_en;              // 自动播放使能标志信号，按下自动播放按键后翻转
    reg [31:0]       auto_cnt;                  // 自动播放计数器，1s 计数，100MHz 时钟下计数到 100_000_000
    reg [2:0]        img_found_count;       // 扫描到的 BMP 图片数量，最多 4 张
    reg [1:0]        img_idx;              // 当前真正显示中的图片编号
    reg [1:0]        load_idx;             // 当前正在写入的图片编号
    reg [1:0]        pending_buf_idx;      // 当前正在写入的目标缓冲区
    reg [31:0]       img_sector0;           // 扫描到的 BMP 图片 0 的起始扇区
    reg [31:0]       img_sector1;           // 扫描到的 BMP 图片 1 的起始扇区
    reg [31:0]       img_sector2;           // 扫描到的 BMP 图片 2 的起始扇区
    reg [31:0]       img_sector3;           // 扫描到的 BMP 图片 3 的起始扇区
    reg              next_req_pending;      // 手动下一张请求挂起标志，按下下一张按键后置位，直到写入完成后清零
    reg              load_busy;             // 正在加载 BMP 到缓冲区的标志信号，bmp_read 发起写帧请求后置位，直到写入完成后清零
    reg [31:0]       load_timeout_cnt;

    reg              load_abort;

    // === 加载失败自动重试/跳过 ===
    localparam [7:0] ERR_LOAD_TIMEOUT = 8'hA1;
    reg              load_fail_pulse;       // 本次加载超时放弃
    reg              load_ok_pulse;         // 本次加载成功提交
    reg              retry_req_pending;     // 重试同一张的请求
    reg              skip_req_pending;      // 跳过这张、换下一张的请求
    wire             recovery_retry;
    wire             recovery_skip;
    wire  [7:0]      recovery_sticky_error;
    wire  [1:0]      recovery_state;
    wire  [1:0]      skip_from_load;
    wire             bmp_load_fail;         // 解析器判定本张图无效
    wire  [7:0]      bmp_error_code;
    reg   [7:0]      fail_code;             // 本次失败原因，喂给恢复 FSM
    // === 新增：KEY2长按检测相关寄存器 ===
    wire        key_auto_stable;      // KEY2消抖后的稳定状态（1=松开，0=按下）
    reg [31:0]  long_press_cnt;       // 长按计数器
    reg         long_press_marked;     // 长按已触发标记（防止按住不放重复触发）
    reg         prev_req_pending;      // 上一张请求挂起标志（和next_req_pending对称）
    reg         key_auto_stable_d;     // key_auto_stable 打一拍，用于检测“松开”边沿
    wire        key_auto_release;      // 松开边沿：0(按下)->1(松开)

    // bmp_ready 先表示“源文件读取/送 FIFO 完成”；真正切显示要等 write_finish_toggle 同步后
    reg              source_done_seen;          // 记住 bmp_read 已经把源图送完 FIFO，但还不能切显示，得等整帧写完
    reg              write_done_seen;           // 记住写帧完成脉冲，避免“先写完后源结束”导致脉冲丢失而卡死



    // 同步 mem_clk 域的 write_finish_toggle，电平反转加三级寄存器同步，加异或检测脉冲，避免 clk 域漏掉 write_finish_toggle 脉冲
    reg [2:0]        wrfin_tgl_sync;            // 写完成脉冲同步寄存器
    wire             write_finish_pulse;        // 写帧完成脉冲，来自 mem_clk 域的 write_finish_toggle 同步到 clk 域



    wire auto_tick;
    wire [1:0] next_from_current;
    wire [1:0] prev_from_current;

    assign write_en   = bmp_data_wr_en;
    assign write_data = {bmp_data[23:16], bmp_data[15:8], bmp_data[7:0], 8'b0};
    // 原来：assign auto_tick = (auto_cnt == (CLK_FREQ_HZ - 1));
    // 改成：
    wire [31:0] auto_play_cycles = (CLK_FREQ_HZ / 1000) * AUTO_PLAY_MS;
    assign auto_tick = (auto_cnt == (auto_play_cycles - 1));
    assign next_from_current = next_index_limited(img_idx, img_found_count);
    assign prev_from_current = prev_index_limited(img_idx, img_found_count);
    assign write_finish_pulse = wrfin_tgl_sync[2] ^ wrfin_tgl_sync[1];
    assign key_auto_release   = key_auto_stable & ~key_auto_stable_d;
    // assign state_code = state_code_i;
    assign state_code = display_valid ? ({2'b0, img_idx} + 4'd1) : state_code_i;    // 数码管显示：首图提交前显示 bmp_read 状态码，首图提交后显示当前图片编号（1~4）
    assign media_id     = img_idx;
    assign auto_play_on = auto_play_en;
    // 只在重试用尽真正跳过（ST_DEGRADED=2）时才报错；重试期间(ST_RETRY=1)
    // 即便偶发一次失败也不亮红，重试成功就静默恢复，避免偶发瞬时错误闪烁 OSD
    assign player_error_code = (recovery_state == 2'd2) ? recovery_sticky_error : 8'd0;
    assign skip_from_load    = next_index_limited(load_idx, img_found_count);

    media_recovery_fsm #(
                           .MAX_RETRIES (2)
                       ) u_media_recovery (
                           .clk                     (clk),
                           .rst_n                   (~rst),
                           .error_valid             (load_fail_pulse),
                           .error_code              (fail_code),
                           .retry_complete          (load_ok_pulse | load_fail_pulse),
                           .retry_success           (load_ok_pulse),
                           .manual_rescan           (key_next_press),
                           .retry_pulse             (recovery_retry),
                           .skip_pulse              (recovery_skip),
                           .rescan_pulse            (),
                           .preserve_previous_frame (),
                           .sticky_error            (recovery_sticky_error),
                           .retry_count             (),
                           .state                   (recovery_state)
                       );

    key_press_debounce #(
                           .CLK_FREQ_HZ (CLK_FREQ_HZ),
                           .DEBOUNCE_MS (50)
                       ) u_key_next (
                           .clk        (clk),
                           .rst        (rst),
                           .button_in  (key_next),
                           .press_pulse(key_next_press)
                       );

    key_press_debounce #(
                           .CLK_FREQ_HZ(CLK_FREQ_HZ),
                           .DEBOUNCE_MS(20)
                       ) u_key_auto (
                           .clk(clk),
                           .rst(rst),
                           .button_in(key_auto),
                           .press_pulse(key_auto_press),
                           .button_stable_out(key_auto_stable)   // 新增：连接消抖后的稳定状态
                       );
    function [1:0] next_index_limited;              // 根据当前图片编号和扫描到的图片数量，计算下一张图片编号，最多 4 张
        input [1:0] cur;                            // 当前图片编号，0~3
        input [2:0] count;                          // 扫描到的图片数量，0~4
        begin
            case (count)
                3'd0:
                    next_index_limited = 2'd0;      // 没有图片，下一张还是 0
                3'd1:
                    next_index_limited = 2'd0;      // 只有一张图片，下一张还是 0
                3'd2:
                    next_index_limited = (cur == 2'd1) ? 2'd0 : (cur + 2'd1);       // 只有两张图片，0->1, 1->0
                3'd3:
                    next_index_limited = (cur == 2'd2) ? 2'd0 : (cur + 2'd1);       // 只有三张图片，0->1, 1->2, 2->0
                default:
                    next_index_limited = (cur == 2'd3) ? 2'd0 : (cur + 2'd1);       // 四张图片，0->1, 1->2, 2->3, 3->0
            endcase
        end
    endfunction

    // === 新增：计算上一张图片编号（和next_index_limited对称，减1而不是加1）===
    function [1:0] prev_index_limited;
        input [1:0] cur;      // 当前图片编号
        input [2:0] count;    // 已找到的图片总数
        begin
            case (count)
                3'd0:
                    prev_index_limited = 2'd0;
                3'd1:
                    prev_index_limited = 2'd0;
                3'd2:
                    prev_index_limited = (cur == 2'd0) ? 2'd1 : (cur - 2'd1);
                3'd3:
                    prev_index_limited = (cur == 2'd0) ? 2'd2 : (cur - 2'd1);
                default:
                    prev_index_limited = (cur == 2'd0) ? 2'd3 : (cur - 2'd1);
            endcase
        end
    endfunction

    function [31:0] sector_lut;             // 根据图片编号返回对应的起始扇区，最多 4 张
        input [1:0] idx;                    // 图片编号，0~3
        begin
            case (idx)
                2'd0:
                    sector_lut = img_sector0;
                2'd1:
                    sector_lut = img_sector1;
                2'd2:
                    sector_lut = img_sector2;
                2'd3:
                    sector_lut = img_sector3;
                default:
                    sector_lut = img_sector0;
            endcase
        end
    endfunction

    function [1:0] next_buf_lut;        // 根据当前显示缓冲区编号和显示有效信号，计算下一张图片的目标缓冲区编号，最多 2 块缓冲区
        input [1:0] cur_disp_buf;       // 当前显示缓冲区编号，0/1
        input       valid_now;          // 当前显示有效信号，首图提交前为0
        begin
            if (!valid_now)
                next_buf_lut = 2'd0;                 // 首图固定写 buffer0
            else if (cur_disp_buf == 2'd0)
                next_buf_lut = 2'd1;
            else
                next_buf_lut = 2'd0;
        end
    endfunction

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            wrfin_tgl_sync        <= 3'b000;
            scan_start_pulse      <= 1'b0;
            load_start_pulse      <= 1'b0;
            load_sector           <= 32'd0;
            scan_kicked           <= 1'b0;
            first_image_committed <= 1'b0;
            auto_play_en          <= 1'b0;
            auto_cnt              <= 32'd0;
            img_found_count       <= 3'd0;
            img_idx               <= 2'd0;
            load_idx              <= 2'd0;
            pending_buf_idx       <= 2'd0;
            write_buf_idx         <= 2'd0;
            disp_buf_idx          <= 2'd0;
            img_sector0           <= 32'd0;
            img_sector1           <= 32'd0;
            img_sector2           <= 32'd0;
            img_sector3           <= 32'd0;
            next_req_pending      <= 1'b0;
            load_busy             <= 1'b0;
            load_timeout_cnt      <= 32'd0;
            load_abort            <= 1'b0;
            source_done_seen      <= 1'b0;
            write_done_seen       <= 1'b0;
            display_valid         <= 1'b0;
            prev_req_pending      <= 1'b0;
            long_press_cnt        <= 32'd0;
            long_press_marked     <= 1'b0;
            key_auto_stable_d     <= 1'b1;
            load_fail_pulse       <= 1'b0;
            load_ok_pulse         <= 1'b0;
            retry_req_pending     <= 1'b0;
            skip_req_pending      <= 1'b0;
            fail_code             <= 8'd0;
        end
        else begin
            wrfin_tgl_sync   <= {wrfin_tgl_sync[1:0], write_finish_toggle};
            scan_start_pulse <= 1'b0;
            load_start_pulse <= 1'b0;
            load_abort       <= 1'b0;
            load_fail_pulse  <= 1'b0;
            load_ok_pulse    <= 1'b0;

            // 恢复 FSM 的重试/跳过请求要挂起，等 bmp_read 退出中止状态后才能发起。
            // 用户手动按下一张即接管控制权，作废未服务的自动恢复请求。
            if (key_next_press) begin
                retry_req_pending <= 1'b0;
                skip_req_pending  <= 1'b0;
            end
            if (recovery_retry)
                retry_req_pending <= 1'b1;
            if (recovery_skip)
                skip_req_pending <= 1'b1;

            if (!sd_init_done) begin
                scan_kicked           <= 1'b0;
                first_image_committed <= 1'b0;
                auto_play_en          <= 1'b0;
                auto_cnt              <= 32'd0;
                img_found_count       <= 3'd0;
                img_idx               <= 2'd0;
                load_idx              <= 2'd0;
                pending_buf_idx       <= 2'd0;
                write_buf_idx         <= 2'd0;
                disp_buf_idx          <= 2'd0;
                img_sector0           <= 32'd0;
                img_sector1           <= 32'd0;
                img_sector2           <= 32'd0;
                img_sector3           <= 32'd0;
                next_req_pending      <= 1'b0;
                load_busy             <= 1'b0;
                load_timeout_cnt      <= 32'd0;
                load_abort            <= 1'b0;
                source_done_seen      <= 1'b0;
                write_done_seen       <= 1'b0;
                display_valid         <= 1'b0;
                prev_req_pending      <= 1'b0;
                long_press_cnt        <= 32'd0;
                long_press_marked     <= 1'b0;
                key_auto_stable_d     <= 1'b1;
                retry_req_pending     <= 1'b0;
                skip_req_pending      <= 1'b0;
            end
            else begin
                // 扫描阶段缓存前 4 张图的起始 sector
                if (scan_found_valid) begin
                    case (img_found_count)
                        3'd0:
                            img_sector0 <= scan_found_sector;
                        3'd1:
                            img_sector1 <= scan_found_sector;
                        3'd2:
                            img_sector2 <= scan_found_sector;
                        3'd3:
                            img_sector3 <= scan_found_sector;
                        default:
                            ;
                    endcase

                    if (img_found_count < 3'd4)
                        img_found_count <= img_found_count + 3'd1;
                end

                // 记住 bmp_read 已经把源图送完 FIFO，但还不能切显示，得等整帧写完
                if (load_busy && bmp_ready)
                    source_done_seen <= 1'b1;

                // 记住写帧完成脉冲，避免“先写完后源结束”导致脉冲丢失而卡死
                if (load_busy && write_finish_pulse)
                    write_done_seen <= 1'b1;

                // 只有“源图送完 + 整帧写完”都满足，才提交新图并切换显示缓冲区
                if (load_busy && source_done_seen && write_done_seen) begin
                    load_busy             <= 1'b0;
                    load_timeout_cnt      <= 32'd0;
                    source_done_seen      <= 1'b0;
                    write_done_seen       <= 1'b0;
                    disp_buf_idx          <= pending_buf_idx;
                    img_idx               <= load_idx;
                    display_valid         <= 1'b1;
                    first_image_committed <= 1'b1;
                    load_ok_pulse         <= 1'b1;
                end
                else if (load_busy && bmp_load_fail) begin
                    // 解析器已判定这张图无效并自行回到空闲，不必再等超时
                    load_busy        <= 1'b0;
                    load_timeout_cnt <= 32'd0;
                    source_done_seen <= 1'b0;
                    write_done_seen  <= 1'b0;
                    load_fail_pulse  <= 1'b1;
                    fail_code        <= bmp_error_code;
                end
                else if (load_busy) begin
                    if (load_timeout_cnt > 32'd100_000_000) begin
                        // 超时（例如读到坏图或截断的文件导致死锁），强制释放 busy 以恢复按键响应
                        load_busy             <= 1'b0;
                        load_timeout_cnt      <= 32'd0;
                        source_done_seen      <= 1'b0;
                        write_done_seen       <= 1'b0;
                        load_abort            <= 1'b1;
                        load_fail_pulse       <= 1'b1;
                        fail_code             <= ERR_LOAD_TIMEOUT;
                    end
                    else begin
                        load_timeout_cnt <= load_timeout_cnt + 32'd1;
                    end
                end
                else begin
                    load_timeout_cnt <= 32'd0;
                end

                // 上电后自动发起一次“扫描前 4 张 BMP”
                if (!scan_kicked && bmp_ready) begin
                    scan_start_pulse      <= 1'b1;
                    scan_kicked           <= 1'b1;
                    first_image_committed <= 1'b0;
                    auto_play_en          <= 1'b0;
                    auto_cnt              <= 32'd0;
                    img_found_count       <= 3'd0;
                    img_idx               <= 2'd0;
                    load_idx              <= 2'd0;
                    pending_buf_idx       <= 2'd0;
                    write_buf_idx         <= 2'd0;
                    disp_buf_idx          <= 2'd0;
                    next_req_pending      <= 1'b0;
                    display_valid         <= 1'b0;
                    load_busy             <= 1'b0;
                    source_done_seen      <= 1'b0;
                    write_done_seen       <= 1'b0;
                end
                else begin
                    // 忙的时候也只记 1 次“下一张”请求，不会累积成连跳两张
                    if (key_next_press && scan_done && (img_found_count > 3'd0))
                        next_req_pending <= 1'b1;

                    // 自动播放开/关：改到松开时按“短按/长按”二选一裁决，见下方 KEY2 长按检测块

                    // 自动播放 1s 计数：只有当前没有写图任务时才计时
                    if (scan_done && auto_play_en && display_valid && !load_busy && first_image_committed && (img_found_count > 3'd1)) begin
                        if (auto_tick)
                            auto_cnt <= 32'd0;
                        else
                            auto_cnt <= auto_cnt + 32'd1;
                    end
                    else begin
                        auto_cnt <= 32'd0;
                    end

                    // === KEY2 短按/长按：只在“松开”那一刻二选一裁决 ===
                    // 之前的问题：短按动作（切自动播放）在“按下”边沿就立刻触发，
                    // 和长按计时是两条独立线路，同一次按压会先切一次自动播放、
                    // 保持够久又追加一次“上一张”，两个动作互相打架。
                    // 现改成：按住只负责计时/打标记，真正的动作只在松开时按
                    // long_press_marked 二选一触发，保证一次按压只有一个结果。
                    key_auto_stable_d <= key_auto_stable;
                    if (key_auto_stable == 1'b0) begin  // 按键按住：只计时，不出动作
                        if (long_press_cnt < ((CLK_FREQ_HZ / 1000) * LONG_PRESS_MS - 1))
                            long_press_cnt <= long_press_cnt + 32'd1;
                        else
                            long_press_marked <= 1'b1;
                    end
                    else begin  // 按键松开
                        if (key_auto_release) begin
                            if (long_press_marked)
                                prev_req_pending <= 1'b1;                 // 长按松开 -> 上一张
                            else if (scan_done && (img_found_count > 3'd1)) begin
                                auto_play_en <= ~auto_play_en;             // 短按松开 -> 切换自动播放
                                auto_cnt     <= 32'd0;
                            end
                        end
                        long_press_cnt    <= 32'd0;
                        long_press_marked <= 1'b0;
                    end

                    // 恢复优先：重试同一张（沿用上次的 load_idx / load_sector / 目标 buffer）
                    if (scan_done && bmp_ready && !load_busy && retry_req_pending && (img_found_count != 3'd0)) begin
                        load_start_pulse  <= 1'b1;
                        load_busy         <= 1'b1;
                        source_done_seen  <= 1'b0;
                        write_done_seen   <= 1'b0;
                        retry_req_pending <= 1'b0;
                        auto_cnt          <= 32'd0;
                    end
                    // 重试用尽：跳过这张坏图，换加载它的下一张
                    else if (scan_done && bmp_ready && !load_busy && skip_req_pending && (img_found_count > 3'd1)) begin
                        load_idx         <= skip_from_load;
                        load_sector      <= sector_lut(skip_from_load);
                        pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                        write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                        load_start_pulse <= 1'b1;
                        load_busy        <= 1'b1;
                        source_done_seen <= 1'b0;
                        write_done_seen  <= 1'b0;
                        skip_req_pending <= 1'b0;
                        auto_cnt         <= 32'd0;
                    end
                    // 首图自动加载到 buffer0
                    else if (scan_done && !first_image_committed && bmp_ready && !load_busy && (img_found_count != 3'd0)) begin
                        load_idx         <= 2'd0;
                        load_sector      <= img_sector0;
                        pending_buf_idx  <= 2'd0;
                        write_buf_idx    <= 2'd0;
                        load_start_pulse <= 1'b1;
                        load_busy        <= 1'b1;
                        source_done_seen <= 1'b0;
                        write_done_seen  <= 1'b0;
                        next_req_pending <= 1'b0;
                        auto_cnt         <= 32'd0;
                        prev_req_pending <= 1'b0;
                    end
                    // 手动下一张优先：写到“非当前显示”的另一块 buffer
                    else if (scan_done && bmp_ready && display_valid && !load_busy && next_req_pending && (img_found_count != 3'd0)) begin
                        load_idx         <= next_from_current;
                        load_sector      <= sector_lut(next_from_current);
                        pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                        write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                        load_start_pulse <= 1'b1;
                        load_busy        <= 1'b1;
                        source_done_seen <= 1'b0;
                        write_done_seen  <= 1'b0;
                        next_req_pending <= 1'b0;
                        auto_cnt         <= 32'd0;
                    end
                    // 手动上一张：写到“非当前显示”的另一块 buffer
                    else if (scan_done && bmp_ready && display_valid && !load_busy && prev_req_pending && (img_found_count != 3'd0)) begin
                        load_idx         <= prev_from_current;
                        load_sector      <= sector_lut(prev_from_current);
                        pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                        write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                        load_start_pulse <= 1'b1;
                        load_busy        <= 1'b1;
                        source_done_seen <= 1'b0;
                        write_done_seen  <= 1'b0;
                        prev_req_pending <= 1'b0;
                        auto_cnt         <= 32'd0;
                    end
                    // 自动播放下一张：同样写到“非当前显示”的另一块 buffer
                    else if (scan_done && bmp_ready && display_valid && !load_busy && auto_play_en && auto_tick && (img_found_count > 3'd1)) begin
                        load_idx         <= next_from_current;
                        load_sector      <= sector_lut(next_from_current);
                        pending_buf_idx  <= next_buf_lut(disp_buf_idx, display_valid);
                        write_buf_idx    <= next_buf_lut(disp_buf_idx, display_valid);
                        load_start_pulse <= 1'b1;
                        load_busy        <= 1'b1;
                        source_done_seen <= 1'b0;
                        write_done_seen  <= 1'b0;
                        auto_cnt         <= 32'd0;
                    end
                end
            end
        end
    end

    bmp_read #(
                 .BMP_WIDTH         (BMP_WIDTH),
                 .BMP_HEIGHT        (BMP_HEIGHT),
                 .SCAN_STEP_SECTORS (SCAN_STEP_SECTORS)
             ) bmp_read_m0(
                 .clk                    (clk),
                 .rst                    (rst),
                 .ready                  (bmp_ready),

                 .scan_start             (scan_start_pulse),
                 .scan_start_sector      (SCAN_START_SECTOR),
                 .scan_max_sector        (SCAN_MAX_SECTOR),
                 .scan_target_count      (SCAN_TARGET_COUNT),
                 .scan_done              (scan_done),
                 .scan_found_valid       (scan_found_valid),
                 .scan_found_sector      (scan_found_sector),
                 .scan_found_total       (scan_found_total),

                 .load_start             (load_start_pulse),
                 .load_abort             (load_abort),
                 .load_sector            (load_sector),

                 .sd_init_done           (sd_init_done),
                 .state_code             (state_code_i),
                 .load_fail              (bmp_load_fail),
                 .bmp_error              (bmp_error_code),
                 .write_req              (write_req),
                 .write_req_ack          (write_req_ack),
                 .sd_sec_read            (sd_sec_read),
                 .sd_sec_read_addr       (sd_sec_read_addr),
                 .sd_sec_read_data       (sd_sec_read_data),
                 .sd_sec_read_data_valid (sd_sec_read_data_valid),
                 .sd_sec_read_end        (sd_sec_read_end),
                 .bmp_data_wr_en         (bmp_data_wr_en),
                 .bmp_data               (bmp_data)
             );

    sd_card_top sd_card_top_m0(
                    .clk                    (clk),
                    .rst                    (rst),
                    .SD_nCS                 (SD_nCS),
                    .SD_DCLK                (SD_DCLK),
                    .SD_MOSI                (SD_MOSI),
                    .SD_MISO                (SD_MISO),
                    .sd_init_done           (sd_init_done),
                    .sd_sec_read            (sd_sec_read),
                    .sd_sec_read_addr       (sd_sec_read_addr),
                    .sd_sec_read_data       (sd_sec_read_data),
                    .sd_sec_read_data_valid (sd_sec_read_data_valid),
                    .sd_sec_read_end        (sd_sec_read_end),
                    .sd_sec_write           (1'b0),
                    .sd_sec_write_addr      (32'd0),
                    .sd_sec_write_data      (),
                    .sd_sec_write_data_req  (),
                    .sd_sec_write_end       ()
                );

endmodule
//按下触发
module key_press_debounce #(
        parameter integer CLK_FREQ_HZ = 100_000_000,
        parameter integer DEBOUNCE_MS = 20
    )(
        input  wire clk,
        input  wire rst,
        input  wire button_in,    // 默认：松开=1，按下=0
        output reg  press_pulse,
        // === 新增：消抖后的稳定状态输出（用于长按检测）===
        output reg  button_stable_out
    );

    localparam integer DEBOUNCE_CYCLES = (CLK_FREQ_HZ / 1000) * DEBOUNCE_MS;

    reg button_sync0;
    reg button_sync1;
    reg button_stable;
    reg [31:0] cnt;

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            button_sync0  <= 1'b1;   //同步寄存器，消除亚稳态
            button_sync1  <= 1'b1;  //同步寄存器，消除亚稳态
            button_stable <= 1'b1;  //默认松开状态
            cnt           <= 32'd0;
            press_pulse   <= 1'b0;
            button_stable_out <= 1'b1;  // 新增：初始化为松开状态
        end
        else begin
            button_sync0 <= button_in;
            button_sync1 <= button_sync0;      //同步寄存器，消除亚稳态
            press_pulse  <= 1'b0;

            if (button_sync1 == button_stable) begin
                cnt <= 32'd0;
            end
            else begin
                if (cnt >= DEBOUNCE_CYCLES - 1) begin
                    if (button_stable && !button_sync1)
                        press_pulse   <= 1'b1;
                    button_stable <= button_sync1;
                    // 在更新button_stable的地方，同时更新button_stable_out
                    button_stable_out <= button_sync1;  // 新增：同步输出
                    cnt           <= 32'd0;
                end
                else begin
                    cnt <= cnt + 32'd1;
                end
            end
        end
    end

endmodule
