`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十讲 图片转场特效：video_fade_transition + media_player_control 联合仿真
//
// 接法与 media_video_pipeline 内部完全一致（next_event 先进转场模块，
// 全黑时才放给 control），只是把帧周期缩短到 FRAME_CYCLES 个像素钟，
// 其余时钟频率照搬工程：ctrl=100MHz，pix=25MHz。
//
// 检查项：
//  1) 手动 next：alpha 255 -> 递减 -> 0(HOLD) -> index 切换 -> 递增 -> 255
//     且 alpha 只在 frame_start 后变化（一帧内恒定，不撕裂）
//  2) 转场进行中再按 next：被 fade_busy 丢弃，index 只前进一次
//  3) 自动轮播切换：不经过全黑，走 wipe_active，ramp 0..FADE_FRAMES-1
//  4) 只有一张图时手动 next 也能走完（control 选回同一张，index_commit 照发，
//     不会卡死在 S_HOLD 全黑）
// -----------------------------------------------------------------------------
module tb_video_fade_transition;
    localparam integer FADE_FRAMES  = 16;
    localparam integer FRAME_CYCLES = 200;   // 缩短后的一帧（pix 周期数）

    reg ctrl_clk = 1'b0;
    reg pix_clk  = 1'b0;
    always #5  ctrl_clk = ~ctrl_clk;   // 100MHz
    always #20 pix_clk  = ~pix_clk;    // 25MHz

    reg ctrl_rst_n = 1'b0;
    reg pix_rst_n  = 1'b0;

    // 帧起点：每 FRAME_CYCLES 个像素钟一拍
    integer pix_cnt;
    reg frame_start;
    always @(posedge pix_clk or negedge pix_rst_n) begin
        if (!pix_rst_n) begin
            pix_cnt <= 0;
            frame_start <= 1'b0;
        end else begin
            frame_start <= (pix_cnt == FRAME_CYCLES - 1);
            pix_cnt <= (pix_cnt == FRAME_CYCLES - 1) ? 0 : pix_cnt + 1;
        end
    end

    reg        next_event = 1'b0;
    reg        auto_cfg_valid = 1'b0;
    reg        auto_cfg_enabled = 1'b0;
    reg [3:0]  image_complete = 4'b1111;

    wire       fade_next_event;
    wire       fade_busy;
    wire [7:0] alpha;
    wire       fade_active;
    wire       wipe_active;
    wire [4:0] ramp;
    wire [1:0] transition_kind;
    wire [1:0] active_index;
    wire [1:0] pending_index;
    wire       index_commit;
    wire [7:0] control_error;

    video_fade_transition #(.FADE_FRAMES(FADE_FRAMES)) dut_fade (
        .ctrl_clk(ctrl_clk), .ctrl_rst_n(ctrl_rst_n),
        .next_event_in(next_event), .next_event_out(fade_next_event),
        .fade_busy(fade_busy),
        .pix_clk(pix_clk), .pix_rst_n(pix_rst_n),
        .player_active(1'b1), .frame_start(frame_start),
        .index_commit(index_commit), .active_index(active_index),
        .alpha_out(alpha), .fade_active(fade_active),
        .wipe_active(wipe_active), .ramp_out(ramp),
        .transition_kind(transition_kind)
    );

    // 周期取小值，让自动轮播在仿真里几帧就触发
    media_player_control #(
        .DEFAULT_PERIOD_CYCLES(32'd20000),
        .MIN_PERIOD_CYCLES(32'd1000),
        .MAX_PERIOD_CYCLES(32'd100000000)
    ) dut_ctrl (
        .sys_clk(ctrl_clk), .sys_rst_n(ctrl_rst_n),
        .next_event(fade_next_event), .prev_event(1'b0),
        .init_event(1'b0), .toggle_auto_event(1'b0),
        .period_cfg_valid(1'b0), .period_cfg_cycles(32'd0),
        .auto_cfg_valid(auto_cfg_valid), .auto_cfg_enabled(auto_cfg_enabled),
        .image_complete(image_complete),
        .select_event(1'b0), .select_index(2'd0),   // 第十五讲新增口，本仿真不用
        .auto_hold(1'b0),
        .auto_enabled(),
        .active_period_cycles(), .pending_index(pending_index),
        .control_error(control_error), .request_busy(),
        .pix_clk(pix_clk), .pix_rst_n(pix_rst_n), .frame_start(frame_start),
        .active_index(active_index), .index_commit(index_commit)
    );

    integer errors = 0;

    // ---- 不撕裂检查：alpha 只允许在 frame_start 之后的那一拍变化 ----
    // （S_HOLD->S_IN 由 index_commit 触发，而 index_commit 本身就是
    //   frame_start 的下一拍，所以同样落在帧边界）
    reg [7:0] alpha_q;
    reg       frame_start_q, frame_start_qq;
    always @(posedge pix_clk) begin
        alpha_q <= alpha;
        frame_start_q <= frame_start;
        frame_start_qq <= frame_start_q;
        if (pix_rst_n && alpha_q !== alpha && !frame_start_q && !frame_start_qq) begin
            // 例外：请求在帧中间到达 IDLE->OUT 时 alpha 保持 255（ramp==FADE_FRAMES），
            // 真正的变化仍然在帧边界，这里如果报错说明逻辑被改坏了
            $display("[%0t] ERROR: alpha changed mid-frame %0d -> %0d", $time, alpha_q, alpha);
            errors = errors + 1;
        end
    end

    // ---- 记录一次转场里 alpha 的轨迹 ----
    integer min_alpha;
    integer commits;
    integer wipe_frames;
    integer max_ramp;
    always @(posedge pix_clk) begin
        if (alpha < min_alpha) min_alpha = alpha;
        if (index_commit) commits = commits + 1;
        if (frame_start && wipe_active) begin
            wipe_frames = wipe_frames + 1;
            if (ramp > max_ramp) max_ramp = ramp;
        end
    end

    task pulse_next;
        begin
            @(posedge ctrl_clk); next_event <= 1'b1;
            @(posedge ctrl_clk); next_event <= 1'b0;
        end
    endtask

    task wait_idle;
        integer guard;
        begin
            guard = 0;
            // 先等转场真正开始（跨域有几拍延迟），再等它结束
            // 自动轮播周期约 25 帧，这里给足 40 帧
            while (!fade_active && guard < FRAME_CYCLES * 40) begin
                @(posedge pix_clk); guard = guard + 1;
            end
            guard = 0;
            while (fade_active && guard < FRAME_CYCLES * (FADE_FRAMES * 3 + 8)) begin
                @(posedge pix_clk); guard = guard + 1;
            end
            if (fade_active) begin
                $display("[%0t] ERROR: transition never returned to IDLE (state=%0d alpha=%0d)",
                         $time, dut_fade.g_fade.state, alpha);
                errors = errors + 1;
            end
            // busy 回到 ctrl 域还要 2 拍
            repeat (4) @(posedge ctrl_clk);
        end
    endtask

    reg [1:0] idx_before;

    initial begin
        #200;
        ctrl_rst_n = 1'b1;
        pix_rst_n  = 1'b1;
        repeat (FRAME_CYCLES * 2) @(posedge pix_clk);

        // ---------- 1) 手动 next：淡出 -> 全黑 -> 淡入 ----------
        idx_before = active_index;
        min_alpha = 255; commits = 0; wipe_frames = 0; max_ramp = 0;
        // 故意在帧中间发请求
        repeat (FRAME_CYCLES / 2) @(posedge pix_clk);
        pulse_next;
        wait_idle;
        if (min_alpha != 0) begin
            $display("ERROR: manual fade never reached black (min alpha=%0d)", min_alpha);
            errors = errors + 1;
        end
        if (commits != 1 || active_index != idx_before + 2'd1) begin
            $display("ERROR: manual next committed %0d times, index %0d -> %0d",
                     commits, idx_before, active_index);
            errors = errors + 1;
        end
        if (wipe_frames != 0) begin
            $display("ERROR: manual next should fade, not wipe");
            errors = errors + 1;
        end
        if (alpha != 8'd255) begin
            $display("ERROR: alpha not back to 255 after fade-in (%0d)", alpha);
            errors = errors + 1;
        end
        $display("case1 manual fade      : min_alpha=%0d commits=%0d index %0d->%0d",
                 min_alpha, commits, idx_before, active_index);

        // ---------- 2) 转场中连按：第二下被丢弃 ----------
        idx_before = active_index;
        commits = 0;
        pulse_next;
        repeat (FRAME_CYCLES * 3) @(posedge pix_clk);   // 已进入淡出
        if (!fade_busy) begin
            $display("ERROR: fade_busy not asserted during fade");
            errors = errors + 1;
        end
        pulse_next;
        pulse_next;
        wait_idle;
        repeat (FRAME_CYCLES * 3) @(posedge pix_clk);
        if (commits != 1 || active_index != idx_before + 2'd1) begin
            $display("ERROR: presses during fade leaked through: commits=%0d index %0d->%0d",
                     commits, idx_before, active_index);
            errors = errors + 1;
        end
        $display("case2 busy drop        : commits=%0d index %0d->%0d",
                 commits, idx_before, active_index);

        // ---------- 3) 自动轮播：Wipe 揭示，不经过全黑 ----------
        idx_before = active_index;
        min_alpha = 255; commits = 0; wipe_frames = 0; max_ramp = 0;
        @(posedge ctrl_clk);
        auto_cfg_valid <= 1'b1; auto_cfg_enabled <= 1'b1;
        @(posedge ctrl_clk);
        auto_cfg_valid <= 1'b0;
        wait_idle;
        // 关掉自动轮播，免得干扰后面的用例
        @(posedge ctrl_clk);
        auto_cfg_valid <= 1'b1; auto_cfg_enabled <= 1'b0;
        @(posedge ctrl_clk);
        auto_cfg_valid <= 1'b0;
        if (commits != 1 || wipe_frames == 0 || min_alpha != 255 ||
            max_ramp != FADE_FRAMES - 1) begin
            $display("ERROR: auto switch wipe wrong: commits=%0d wipe_frames=%0d min_alpha=%0d max_ramp=%0d",
                     commits, wipe_frames, min_alpha, max_ramp);
            errors = errors + 1;
        end
        $display("case3 auto wipe        : commits=%0d wipe_frames=%0d max_ramp=%0d kind=%0d",
                 commits, wipe_frames, max_ramp, transition_kind);
        repeat (FRAME_CYCLES * 2) @(posedge pix_clk);

        // ---------- 4) 只剩一张图：不能卡死在全黑 ----------
        image_complete = 4'b0001 << active_index;
        idx_before = active_index;
        min_alpha = 255; commits = 0;
        pulse_next;
        wait_idle;
        if (commits != 1 || active_index != idx_before || alpha != 8'd255) begin
            $display("ERROR: single-image next: commits=%0d index %0d->%0d alpha=%0d",
                     commits, idx_before, active_index, alpha);
            errors = errors + 1;
        end
        $display("case4 single image     : commits=%0d index %0d->%0d min_alpha=%0d",
                 commits, idx_before, active_index, min_alpha);

        if (control_error != 8'h00) begin
            $display("ERROR: control_error=%02h", control_error);
            errors = errors + 1;
        end

        if (errors == 0) $display("TB PASS");
        else             $display("TB FAIL: %0d error(s)", errors);
        $finish;
    end

    // 看门狗
    initial begin
        #50_000_000;
        $display("TB FAIL: timeout");
        $finish;
    end
endmodule
