`timescale 1ns/1ps
// bilinear_8q8 自检：讲义 3.3.1 给的两条回归基准 + 一条通道独立性检查
//   ① wx=wy=0      -> 输出 == p00
//   ② wx=wy=128    -> 输出 == 4 像素平均（定点截断，允许 -1 误差）
//   ③ 三个通道喂不同数据，输出互不串扰
// iverilog -o tb display/sim/tb_bilinear_8q8.v display/bilinear_8q8.v && vvp tb
module tb_bilinear_8q8;
    reg  [7:0] p00_r, p10_r, p01_r, p11_r;
    reg  [7:0] p00_g, p10_g, p01_g, p11_g;
    reg  [7:0] p00_b, p10_b, p01_b, p11_b;
    reg  [7:0] wx, wy;
    wire [7:0] out_r, out_g, out_b;
    integer errors = 0;

    bilinear_8q8 dut (
        .p00_r(p00_r), .p10_r(p10_r), .p01_r(p01_r), .p11_r(p11_r),
        .p00_g(p00_g), .p10_g(p10_g), .p01_g(p01_g), .p11_g(p11_g),
        .p00_b(p00_b), .p10_b(p10_b), .p01_b(p01_b), .p11_b(p11_b),
        .wx(wx), .wy(wy), .out_r(out_r), .out_g(out_g), .out_b(out_b)
    );

    task check;
        input [7:0] got;
        input [7:0] expect_hi;
        input [7:0] expect_lo;
        input [8*8-1:0] name;
        begin
            if (got > expect_hi || got < expect_lo) begin
                $display("FAIL %0s: got %0d, expect %0d..%0d", name, got, expect_lo, expect_hi);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        p00_r = 8'd200; p10_r = 8'd100; p01_r = 8'd50;  p11_r = 8'd10;
        p00_g = 8'd255; p10_g = 8'd255; p01_g = 8'd255; p11_g = 8'd255;
        p00_b = 8'd0;   p10_b = 8'd80;  p01_b = 8'd160; p11_b = 8'd240;

        wx = 8'd0; wy = 8'd0; #1;
        check(out_r, 8'd200, 8'd200, "r_p00");
        check(out_g, 8'd255, 8'd255, "g_p00");
        check(out_b, 8'd0,   8'd0,   "b_p00");

        wx = 8'd128; wy = 8'd128; #1;
        check(out_r, 8'd90,  8'd89,  "r_avg");   // (200+100+50+10)/4 = 90
        check(out_g, 8'd255, 8'd254, "g_avg");
        check(out_b, 8'd120, 8'd119, "b_avg");   // (0+80+160+240)/4 = 120

        if (errors == 0) $display("PASS tb_bilinear_8q8");
        else             $display("FAILED tb_bilinear_8q8: %0d errors", errors);
        $finish;
    end
endmodule
