`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 第十三讲（讲义第12课 3.3.1 选做）bilinear_8q8：双线性插值定点核
// 输入：4个相邻像素 p00/p10/p01/p11（左上/右上/左下/右下）
//       wx = (x的小数部分)<<8, wy = (y的小数部分)<<8  (0~255)
// 思路：先按行加权，再按列加权，每步乘16位再取高8位
//
// 讲义骨架只给了 R 通道，G/B 两个 TODO 在这里补齐（照 R 通道换信号名）。
// 两个综合陷阱照讲义避开：
//  ① 8'd256 会截成 0 —— 权重补数用 9'd256；
//  ② 行加权结果最大 255*256=65280，必须先取 [15:8] 再做列加权，
//     否则乘积约 1670 万，16 位装不下被静默截断。
//
// 【本工程没有把它接进显示链路】和完赛工程一样：双线性要求 reader 同时拿到
// 周围 4 个像素（两行各 2 个），media_frame_reader 是顺序流式读取，要支持得
// 先加行缓存 + 4 倍读带宽。本工程缩略图是 2:1 缩小，最近邻已经足够。
// 文件不在 TD 工程清单里，只作为练习核保留；自检用 display/sim/tb_bilinear_8q8.v。
// -----------------------------------------------------------------------------
module bilinear_8q8 (
    input  wire [7:0] p00_r, p10_r, p01_r, p11_r,
    input  wire [7:0] p00_g, p10_g, p01_g, p11_g,
    input  wire [7:0] p00_b, p10_b, p01_b, p11_b,
    input  wire [7:0] wx, wy,
    output wire [7:0] out_r, out_g, out_b
);
    wire [8:0]  inv_wx       = 9'd256 - {1'b0, wx};                    // 256-wx，范围1~256
    wire [8:0]  inv_wy       = 9'd256 - {1'b0, wy};

    // ---- R通道 ----
    wire [15:0] row_top_r    = p00_r * inv_wx + p10_r * wx;            // 顶行: p00*(256-wx)+p10*wx，≤65280
    wire [15:0] row_bottom_r = p01_r * inv_wx + p11_r * wx;            // 底行
    wire [15:0] out_r_full   = row_top_r[15:8] * inv_wy + row_bottom_r[15:8] * wy;
    assign out_r = out_r_full[15:8];                                   // 列加权后取高8位

    // ---- G通道 ----
    wire [15:0] row_top_g    = p00_g * inv_wx + p10_g * wx;
    wire [15:0] row_bottom_g = p01_g * inv_wx + p11_g * wx;
    wire [15:0] out_g_full   = row_top_g[15:8] * inv_wy + row_bottom_g[15:8] * wy;
    assign out_g = out_g_full[15:8];

    // ---- B通道 ----
    wire [15:0] row_top_b    = p00_b * inv_wx + p10_b * wx;
    wire [15:0] row_bottom_b = p01_b * inv_wx + p11_b * wx;
    wire [15:0] out_b_full   = row_top_b[15:8] * inv_wy + row_bottom_b[15:8] * wy;
    assign out_b = out_b_full[15:8];
endmodule
