`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// tb_media_uart_console：串口控制台的功能自检激励。
//
// 结构照 11 UART环回与命令控制 的 tb_uart_system_top：从 host_tx 逐帧注入
// 字节，另挂一个 uart_rx_byte 实例当 TX 监视器解码回复字节流。
//
// 只跑功能闭环，不是时序验证——本机没有 TD，综合/时序结论必须由 TD 给。
//
// 仿真里把 CLKS_PER_BIT 压到 16（真实值 868），只为缩短波特周期；
// 对被测逻辑而言 CLKS_PER_BIT 只是计数上限，握手时序与真实值无关。
//
// 覆盖场景：
//   1. banner            report_enable 上升沿 -> "MEDIA PLAYER READY\r\n"
//   2. AUTO ON           -> "OK\r\n" + "PIC 1 A\r\n"（status_event 那条路）
//   3. VOL=80            -> "OK\r\n" + "VOL 80\r\n"，且 volume 输出 == 0x80
//   4. BRT=40            -> "OK\r\n" + "BRT 40\r\n"，且 brightness 输出 == 0x40
//   4b. CON=C0           -> "OK\r\n" + "CON C0\r\n"，且 contrast 输出 == 0xC0（第十四讲）
//   5. PRD=1388 (5000ms) -> "OK\r\n" + "PRD 01388ms\r\n"，
//                           且 period_cfg_cycles == 5000*100000 = 500_000_000
//   6. NEXT              -> "OK\r\n"，且 next_event 打出一拍
//   7. BAD（未知命令）   -> "ERR\r\n"
//   8. 裸 LF             -> "ERR\r\n"
//   9. media_id 变化     -> "PIC 2 A\r\n"（reporter 自发的图片切换日志）
//
// 第二阶段——故障边界（第10课讲义"测试激励与故障边界"那一节的项目）：
//  10. 半行不执行        只发 "NEXT" 不带 CRLF，无输出、next_event 不动
//  11. 补上 CRLF         半行变成完整命令 -> "OK"
//  12. 参数非法          VOL=GG -> "ERR"，且 volume 保持不变
//  13. 重复 CR           缓冲恰好是 NEXT 也不得执行 -> "ERR"
//  14. 超长行            17 个字符 -> "ERR"
//  15. 帧错清行          "NE" + 坏停止位 + "XT" -> "ERR"，不能拼成 NEXT
//                        被执行；diag_code 变 0x72
//  16. drop-new 拥塞     ERR 回复期间提交的空行被丢弃，无第二条回复，
//                        diag_code 抬到 0x71
// 全部通过时打印 TEST_PASS。
// -----------------------------------------------------------------------------

module tb_media_uart_console;
    localparam integer CLK_PERIOD_NS = 10;      // 100MHz，与 sd_card_clk 一致
    localparam integer CPB           = 16;      // 仿真用的 CLKS_PER_BIT

    reg clk = 1'b0;
    reg rst_n = 1'b0;
    always #(CLK_PERIOD_NS/2) clk = ~clk;

    reg        host_tx = 1'b1;
    reg        report_enable = 1'b0;
    reg [1:0]  media_id = 2'd0;
    reg        auto_enabled = 1'b0;
    reg [7:0]  error_code = 8'h00;

    wire        uart_txd;
    wire        next_event, prev_event;
    wire        auto_cfg_valid, auto_cfg_enabled;
    wire        period_cfg_valid;
    wire [31:0] period_cfg_cycles;
    wire [7:0]  volume, brightness, diag_code;
    wire [7:0]  contrast;
    wire        bright_cfg_valid, contrast_cfg_valid;

    media_uart_console #(
        .CLKS_PER_BIT      (CPB),
        .DEFAULT_VOLUME    (8'd255),
        .DEFAULT_BRIGHTNESS(8'd255)
    ) dut (
        .clk              (clk),
        .rst_n            (rst_n),
        .uart_rxd         (host_tx),
        .uart_txd         (uart_txd),
        .report_enable    (report_enable),
        .media_id         (media_id),
        .auto_enabled     (auto_enabled),
        .error_code       (error_code),
        .next_event       (next_event),
        .prev_event       (prev_event),
        .auto_cfg_valid   (auto_cfg_valid),
        .auto_cfg_enabled (auto_cfg_enabled),
        .period_cfg_valid (period_cfg_valid),
        .period_cfg_cycles(period_cfg_cycles),
        .volume           (volume),
        .brightness       (brightness),
        .thumb_cfg_valid  (),
        .thumb_cfg_enabled(),
        .contrast         (contrast),
        .bright_cfg_valid (bright_cfg_valid),
        .contrast_cfg_valid(contrast_cfg_valid),
        .key_bright_event (1'b0),
        .key_bright_value (8'h00),
        .key_contrast_event(1'b0),
        .key_contrast_value(8'h00),
        .diag_code        (diag_code)
    );

    // 模拟 media_player_control 对 auto_cfg 的响应，这样 reporter 的
    // PIC 行里的 A/M 标志才有真实来源
    always @(posedge clk)
        if (auto_cfg_valid)
            auto_enabled <= auto_cfg_enabled;

    // ---- TX 监视器：复用第五讲的接收核心解码回复 ----
    wire [7:0] mon_data;
    wire       mon_valid;
    uart_rx_byte #(.CLKS_PER_BIT(CPB)) u_monitor (
        .clk(clk), .rst_n(rst_n), .rx(uart_txd),
        .data(mon_data), .valid(mon_valid), .framing_error()
    );

    reg [7:0] rx_log [0:255];
    integer   rx_count = 0;
    always @(posedge clk)
        if (mon_valid) begin
            rx_log[rx_count] = mon_data;
            rx_count = rx_count + 1;
        end

    integer errors = 0;
    integer expect_base = 0;
    integer i_main = 0;

    // stop_value = 0 时故意发坏停止位，用来触发 uart_rx_byte 的 framing_error
    task host_send_frame;
        input [7:0] value;
        input       stop_value;
        integer i;
        begin
            @(negedge clk);
            host_tx = 1'b0;                              // start
            #(CPB * CLK_PERIOD_NS);
            for (i = 0; i < 8; i = i + 1) begin
                host_tx = value[i];
                #(CPB * CLK_PERIOD_NS);
            end
            host_tx = stop_value;                        // stop
            #(CPB * CLK_PERIOD_NS);
            host_tx = 1'b1;
        end
    endtask

    task host_send_byte;
        input [7:0] value;
        begin
            host_send_frame(value, 1'b1);
        end
    endtask

    // 发一行文本 + CRLF。Verilog 字符串字面量在宽向量里是【右对齐】的
    // （高位补 0），所以第 i 个字符取 line[8*(len-1-i) +: 8]，len 必须等于
    // 字符串的实际长度，写错了会发出一串 0x00。
    task host_send_line;
        input [8*16-1:0] line;
        input integer    len;
        integer i;
        begin
            for (i = 0; i < len; i = i + 1)
                host_send_byte(line[8*(len-1-i) +: 8]);
            host_send_byte(8'h0D);
            host_send_byte(8'h0A);
        end
    endtask

    // 等监视器累计收到 n 个字节（相对当前 expect_base）
    task wait_bytes;
        input integer n;
        integer guard;
        begin
            guard = 0;
            while (rx_count < expect_base + n && guard < 200000) begin
                @(posedge clk);
                guard = guard + 1;
            end
            if (rx_count < expect_base + n) begin
                $display("TEST_FAIL timeout waiting %0d bytes (have %0d, want %0d)",
                         n, rx_count - expect_base, n);
                errors = errors + 1;
            end
        end
    endtask

    // 比对从 expect_base 起的 len 个字节，然后把 base 推过去
    task expect_line;
        input [8*16-1:0] text;
        input integer    len;
        input [8*16-1:0] label;
        integer i;
        reg [7:0] got, want;
        begin
            wait_bytes(len);
            for (i = 0; i < len; i = i + 1) begin
                got  = rx_log[expect_base + i];
                want = text[8*(len-1-i) +: 8];
                if (got !== want) begin
                    $display("TEST_FAIL %0s byte[%0d] got 0x%02x want 0x%02x",
                             label, i, got, want);
                    errors = errors + 1;
                end
            end
            expect_base = expect_base + len;
        end
    endtask

    task expect_crlf;
        input [8*16-1:0] label;
        begin
            wait_bytes(2);
            if (rx_log[expect_base] !== 8'h0D || rx_log[expect_base+1] !== 8'h0A) begin
                $display("TEST_FAIL %0s CRLF got 0x%02x 0x%02x",
                         label, rx_log[expect_base], rx_log[expect_base+1]);
                errors = errors + 1;
            end
            expect_base = expect_base + 2;
        end
    endtask

    reg next_seen = 1'b0;
    always @(posedge clk) if (next_event) next_seen <= 1'b1;

    initial begin
        rst_n = 1'b0;
        repeat (20) @(posedge clk);
        rst_n = 1'b1;
        repeat (20) @(posedge clk);

        // ---- 1. banner ----
        report_enable = 1'b1;
        expect_line("MEDIA PLAYER RE", 15, "banner1");
        expect_line("ADY", 3, "banner2");
        expect_crlf("banner");

        // ---- 2. AUTO ON -> OK + PIC 1 A ----
        host_send_line("AUTO ON", 7);
        expect_line("OK", 2, "autoon-ok");
        expect_crlf("autoon-ok");
        expect_line("PIC 1 A", 7, "autoon-pic");
        expect_crlf("autoon-pic");
        if (auto_enabled !== 1'b1) begin
            $display("TEST_FAIL auto_enabled not set");
            errors = errors + 1;
        end

        // ---- 3. VOL=80 ----
        host_send_line("VOL=80", 6);
        expect_line("OK", 2, "vol-ok");
        expect_crlf("vol-ok");
        expect_line("VOL 80", 6, "vol-log");
        expect_crlf("vol-log");
        if (volume !== 8'h80) begin
            $display("TEST_FAIL volume got 0x%02x want 0x80", volume);
            errors = errors + 1;
        end

        // ---- 4. BRT=40 ----
        host_send_line("BRT=40", 6);
        expect_line("OK", 2, "brt-ok");
        expect_crlf("brt-ok");
        expect_line("BRT 40", 6, "brt-log");
        expect_crlf("brt-log");
        if (brightness !== 8'h40) begin
            $display("TEST_FAIL brightness got 0x%02x want 0x40", brightness);
            errors = errors + 1;
        end

        // ---- 4b. CON=C0（第十四讲）----
        host_send_line("CON=C0", 6);
        expect_line("OK", 2, "con-ok");
        expect_crlf("con-ok");
        expect_line("CON C0", 6, "con-log");
        expect_crlf("con-log");
        if (contrast !== 8'hC0) begin
            $display("TEST_FAIL contrast got 0x%02x want 0xC0", contrast);
            errors = errors + 1;
        end

        // ---- 5. PRD=1388 (0x1388 = 5000ms) -> 500_000_000 拍 ----
        host_send_line("PRD=1388", 8);
        expect_line("OK", 2, "prd-ok");
        expect_crlf("prd-ok");
        expect_line("PRD 01388ms", 11, "prd-log");
        expect_crlf("prd-log");
        if (period_cfg_cycles !== 32'd500_000_000) begin
            $display("TEST_FAIL period_cfg_cycles got %0d want 500000000",
                     period_cfg_cycles);
            errors = errors + 1;
        end

        // ---- 6. NEXT ----
        next_seen = 1'b0;
        host_send_line("NEXT", 4);
        expect_line("OK", 2, "next-ok");
        expect_crlf("next-ok");
        if (next_seen !== 1'b1) begin
            $display("TEST_FAIL next_event never pulsed");
            errors = errors + 1;
        end

        // ---- 7. 未知命令 ----
        host_send_line("BAD", 3);
        expect_line("ERR", 3, "bad-err");
        expect_crlf("bad-err");

        // ---- 8. 裸 LF ----
        host_send_byte(8'h0A);
        expect_line("ERR", 3, "barelf-err");
        expect_crlf("barelf-err");

        // ---- 9. 图片切换的自发日志 ----
        // 在 negedge 上改，别在 posedge：posedge + 阻塞赋值会和 DUT 里
        // media_id_q <= media_id 的采样撞在同一时刻，DUT 可能同沿就采到
        // 新值，media_changed 永远不为真（这是激励的竞态，不是设计问题）。
        @(negedge clk) media_id = 2'd1;
        expect_line("PIC 2 A", 7, "switch-pic");
        expect_crlf("switch-pic");

        // ---- 中间检查点：到这里串口自身应该一次故障都没有 ----
        repeat (4000) @(posedge clk);
        if (rx_count !== expect_base) begin
            $display("TEST_FAIL extra %0d unexpected byte(s), first 0x%02x",
                     rx_count - expect_base, rx_log[expect_base]);
            errors = errors + 1;
        end
        if (diag_code !== 8'h00) begin
            $display("TEST_FAIL diag_code got 0x%02x want 0x00 (clean phase)",
                     diag_code);
            errors = errors + 1;
        end

        // =====================================================================
        // 第二阶段：故障边界（第10课讲义"测试激励与故障边界"那一节的项目）
        // 这一段会把粘滞的 diag_code 置起来，所以放在干净场景之后。
        // =====================================================================

        // ---- 10. 半行不执行：CRLF 才是提交边界 ----
        next_seen = 1'b0;
        host_send_byte("N");
        host_send_byte("E");
        host_send_byte("X");
        host_send_byte("T");
        repeat (5000) @(posedge clk);
        if (rx_count !== expect_base) begin
            $display("TEST_FAIL half line produced %0d byte(s)",
                     rx_count - expect_base);
            errors = errors + 1;
        end
        if (next_seen !== 1'b0) begin
            $display("TEST_FAIL half line executed next_event");
            errors = errors + 1;
        end

        // ---- 11. 补上 CRLF，半行变成完整命令 ----
        host_send_byte(8'h0D);
        host_send_byte(8'h0A);
        expect_line("OK", 2, "halfline-ok");
        expect_crlf("halfline-ok");
        if (next_seen !== 1'b1) begin
            $display("TEST_FAIL completed line did not execute");
            errors = errors + 1;
        end

        // ---- 12. 参数非法：hex 字符不合法整条按错误行走，音量不动 ----
        host_send_line("VOL=GG", 6);
        expect_line("ERR", 3, "badhex-err");
        expect_crlf("badhex-err");
        if (volume !== 8'h80) begin
            $display("TEST_FAIL volume changed on bad hex: 0x%02x", volume);
            errors = errors + 1;
        end

        // ---- 13. 重复 CR：缓冲内容即使能匹配也不得执行 ----
        next_seen = 1'b0;
        host_send_byte("N"); host_send_byte("E");
        host_send_byte("X"); host_send_byte("T");
        host_send_byte(8'h0D);
        host_send_byte(8'h0D);          // 第二个 CR -> 判错误行
        host_send_byte(8'h0A);
        expect_line("ERR", 3, "dupcr-err");
        expect_crlf("dupcr-err");
        if (next_seen !== 1'b0) begin
            $display("TEST_FAIL duplicate CR still executed NEXT");
            errors = errors + 1;
        end

        // ---- 14. 超长行：第 17 个字符触发超长 ----
        for (i_main = 0; i_main < 17; i_main = i_main + 1)
            host_send_byte("A");
        host_send_byte(8'h0D);
        host_send_byte(8'h0A);
        expect_line("ERR", 3, "overlong-err");
        expect_crlf("overlong-err");

        // ---- 15. 帧错清行：坏停止位丢弃残行，不污染后续文本 ----
        // "NE" 进缓冲 -> 坏帧把残行清掉 -> "XT" 单独成行 -> 未知命令 ERR。
        // 如果 line_abort 没生效，"NE"+"XT" 会拼成 NEXT 而被执行，那就错了。
        next_seen = 1'b0;
        host_send_byte("N");
        host_send_byte("E");
        host_send_frame("Z", 1'b0);     // 坏停止位
        repeat (3 * CPB) @(posedge clk);
        host_send_byte("X");
        host_send_byte("T");
        host_send_byte(8'h0D);
        host_send_byte(8'h0A);
        expect_line("ERR", 3, "frameabort-err");
        expect_crlf("frameabort-err");
        if (next_seen !== 1'b0) begin
            $display("TEST_FAIL framing error did not discard partial line");
            errors = errors + 1;
        end
        if (diag_code !== 8'h72) begin
            $display("TEST_FAIL diag_code got 0x%02x want 0x72 (framing)",
                     diag_code);
            errors = errors + 1;
        end

        // ---- 16. drop-new 拥塞：回复还在发时提交的命令被丢弃 ----
        // "BAD\r\n" 的 ERR 回复是 5 字节 = 800 拍；紧跟的空行只有 CR LF
        // 两个字节 = 320 拍就提交，落在回复窗口内，必被丢弃并置 overflow。
        host_send_line("BAD", 3);
        host_send_byte(8'h0D);
        host_send_byte(8'h0A);
        expect_line("ERR", 3, "overflow-err");
        expect_crlf("overflow-err");
        repeat (6000) @(posedge clk);
        if (rx_count !== expect_base) begin
            $display("TEST_FAIL dropped command still replied (%0d extra byte(s))",
                     rx_count - expect_base);
            errors = errors + 1;
        end
        // overflow 优先于 framing，diag 应从 0x72 抬到 0x71
        if (diag_code !== 8'h71) begin
            $display("TEST_FAIL diag_code got 0x%02x want 0x71 (overflow)",
                     diag_code);
            errors = errors + 1;
        end

        if (errors == 0)
            $display("TEST_PASS media_uart_console banner_commands_args_switchlog_boundaries_frameabort_overflow (%0d bytes)",
                     rx_count);
        else
            $display("TEST_FAIL total %0d error(s)", errors);
        $finish;
    end
endmodule
