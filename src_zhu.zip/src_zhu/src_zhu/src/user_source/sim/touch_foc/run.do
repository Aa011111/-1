# 触控屏 FOC=NN 自检：vsim -c -do run.do
if {[file exists work]} { vdel -lib work -all }
vlib work
foreach f {uart_rx_byte uart_tx_byte uart_line_parser uart_command_engine uart_response_tx uart_status_reporter uart_cmd_core media_uart_console} {
    vlog -quiet ../../hdl_source/uart/$f.v
}
vlog -quiet ../../hdl_source/control/thumbnail_controller.v
vlog -quiet tb_touch_foc.v
vsim -quiet -c -voptargs=+acc tb_touch_foc
run -all
quit -f
