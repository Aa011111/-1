`timescale 1ns/1ps
// rtc_clock_osd 画面自检：640x480@800x525 时序，底图是彩色渐变，
// 第 2 帧显示 12:34:56，第 4 帧 time_valid=0 显示 --:--:--，各存成 frame_N.txt
// （每行一个像素 RRGGBB），由 render.py 转 PNG 并逐像素核对。
module tb_rtc_osd;
    reg clk = 0;
    always #20 clk = ~clk;         // 25MHz
    reg rst_n = 0;

    reg [9:0] hc = 0, vc = 0;
    always @(posedge clk) begin
        if (hc == 799) begin
            hc <= 0;
            vc <= (vc == 524) ? 0 : vc + 1;
        end else hc <= hc + 1;
    end
    wire de = (hc < 640) && (vc < 480);
    wire vs = (vc >= 490) && (vc < 492);

    // 和顶层一样由 de/vs 反推坐标
    reg [11:0] px = 0, py = 0;
    reg de_d = 0, vs_d = 0;
    wire frame_start = vs & ~vs_d;
    always @(posedge clk) begin
        de_d <= de; vs_d <= vs;
        if (de) px <= px + 1;
        else begin
            px <= 0;
            if (de_d) py <= py + 1;
        end
        if (vs & ~vs_d) py <= 0;
    end

    wire [23:0] bg = {px[9:2], py[8:1], 8'h80};
    reg  [23:0] time_bcd = 24'h123456;
    reg         time_valid = 1'b1;
    wire [23:0] rgb_out;

    rtc_clock_osd dut (
        .clk (clk), .rst_n (rst_n), .enable (1'b1),
        .de (de), .frame_start (frame_start),
        .pixel_x (px), .pixel_y (py),
        .time_bcd (time_bcd), .time_valid (time_valid),
        .rgb_in (bg), .rgb_out (rgb_out), .clock_active ()
    );

    integer frames = 0;
    integer fd = 0;
    always @(posedge clk) begin
        if (frame_start) begin
            if (fd) begin $fclose(fd); fd = 0; end
            frames = frames + 1;
            if (frames == 2) fd = $fopen("frame_2.txt", "w");
            if (frames == 3) time_valid <= 1'b0;   // 第 4 帧起生效
            if (frames == 4) fd = $fopen("frame_4.txt", "w");
            if (frames == 5) begin
                $display("OSD frames dumped");
                $finish;
            end
        end
        if (fd && de) $fwrite(fd, "%06h\n", rgb_out);
    end

    initial #200 rst_n = 1;
endmodule
