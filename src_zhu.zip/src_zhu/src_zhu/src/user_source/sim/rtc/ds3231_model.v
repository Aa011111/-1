`timescale 1ns/1ps
// DS3231 I2C 从机行为模型（只为仿真）：地址 0x68，19 个寄存器，指针自动加一。
// present=0 时完全不应答，模拟模块没接。tick() 让时间走一秒（BCD 进位到 23:59:59 回零）。
module ds3231_model (
    inout wire scl,
    inout wire sda
);
    reg [7:0] regs [0:18];
    reg [4:0] ptr;
    reg       sda_low;
    reg       present;
    assign sda = sda_low ? 1'b0 : 1'bz;

    integer start_cnt = 0;
    integer stop_cnt  = 0;
    integer seen_start = 0;
    integer my_stop;
    integer i;
    integer write_count = 0;   // 收到过几次"写时间"事务（tb 用来断言）

    initial begin
        sda_low = 1'b0;
        present = 1'b1;
        ptr     = 5'd0;
        for (i = 0; i < 19; i = i + 1) regs[i] = 8'h00;
    end

    always @(negedge sda) if (scl === 1'b1) start_cnt = start_cnt + 1;
    always @(posedge sda) if (scl === 1'b1) stop_cnt  = stop_cnt + 1;

    task get_byte(output [7:0] b);
        integer k;
        begin
            for (k = 7; k >= 0; k = k - 1) begin
                @(posedge scl);
                b[k] = (sda !== 1'b0);
            end
        end
    endtask

    task send_ack;
        begin
            @(negedge scl); #100 sda_low = 1'b1;
            @(negedge scl); #100 sda_low = 1'b0;
        end
    endtask

    task do_txn;
        reg [7:0] b;
        reg       first;
        reg       m_ack;
        integer   k;
        begin
            get_byte(b);
            if (present && b[7:1] == 7'h68) begin
                send_ack;
                if (!b[0]) begin
                    first = 1'b1;
                    forever begin
                        get_byte(b);
                        send_ack;
                        if (first) begin
                            ptr = b[4:0];
                            first = 1'b0;
                        end else begin
                            regs[ptr] = b;
                            if (ptr == 5'd2) write_count = write_count + 1;
                            ptr = (ptr == 5'd18) ? 5'd0 : ptr + 5'd1;
                        end
                    end
                end else begin
                    forever begin
                        b = regs[ptr];
                        ptr = (ptr == 5'd18) ? 5'd0 : ptr + 5'd1;
                        for (k = 7; k >= 0; k = k - 1) begin
                            // 第一位在 ACK 后的 SCL 下降沿已经由 send_ack 之后放出
                            #100 sda_low = !b[k];
                            @(negedge scl);
                        end
                        #100 sda_low = 1'b0;
                        @(posedge scl);
                        m_ack = (sda === 1'b0);
                        @(negedge scl);
                        if (!m_ack) disable do_txn;
                    end
                end
            end
        end
    endtask

    always begin
        wait (start_cnt != seen_start);
        seen_start = start_cnt;
        my_stop    = stop_cnt;
        fork : txn
            do_txn;
            wait (start_cnt != seen_start || stop_cnt != my_stop);
        join_any
        disable txn;
        sda_low = 1'b0;
    end

    function [7:0] bcd_inc;
        input [7:0] v;
        begin
            bcd_inc = (v[3:0] == 4'd9) ? {v[7:4] + 4'd1, 4'd0} : v + 8'd1;
        end
    endfunction

    task tick;
        begin
            if (regs[0] == 8'h59) begin
                regs[0] = 8'h00;
                if (regs[1] == 8'h59) begin
                    regs[1] = 8'h00;
                    regs[2] = (regs[2][5:0] == 6'h23) ? 8'h00 : bcd_inc(regs[2]);
                end else regs[1] = bcd_inc(regs[1]);
            end else regs[0] = bcd_inc(regs[0]);
        end
    endtask
endmodule
