# RTC OSD self-check: vsim -c -do run.do  (then: python render.py)
# 本工程不接 DS3231，时间经 RS-485 从外部屏取（链路自检见 hdl_source/rs485/sim），
# 所以只跑显示部分 tb_rtc_osd。串口 TIM= -> I2C -> DS3231 的 tb_rtc 在 src 工程里跑。
if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -quiet ../../hdl_source/rtc/rtc_clock_osd.v
vlog -quiet -sv tb_rtc_osd.v
vsim -quiet -c -voptargs=+acc tb_rtc_osd
run -all
quit -sim
quit -f
