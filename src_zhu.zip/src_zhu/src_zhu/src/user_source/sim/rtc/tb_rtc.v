`timescale 1ns/1ps
// DS3231 链路自检：串口 TIM= -> media_uart_console -> ds3231_rtc -> I2C -> ds3231_model
// 场景：
//   1) 上电读到模型里的 23:59:58
//   2) 模型走一秒跨天 -> 00:00:00 之类的进位能被读出来
//   3) TIM=123456 写进模型（24h、BCD），并立即读回
//   4) 非法 TIM（时 24 / 分 60 / 位数不对 / 非数字）不发生写
//   5) 模块拔掉 -> time_valid=0；插回 -> 自动恢复
//   6) 模块处于 12 小时制时按 01~12 显示
module tb_rtc;
    reg clk = 0;
    always #5 clk = ~clk;          // 100MHz
    reg rst_n = 0;

    wire scl, sda;
    pullup (scl);
    pullup (sda);

    reg  uart_rxd = 1'b1;
    wire uart_txd;

    wire        rtc_set_valid;
    wire [23:0] rtc_set_bcd;
    wire [23:0] time_bcd;
    wire        time_valid;
    wire        read_ok;

    media_uart_console #(
        .CLK_FREQ_HZ (100_000_000),
        .BAUD_RATE   (115_200),
        .INDEX_W     (4),
        .FOCUS_COUNT (11)
    ) u_console (
        .clk (clk), .rst_n (rst_n),
        .uart_rxd (uart_rxd), .uart_txd (uart_txd),
        .report_enable (1'b0), .media_id (4'd0), .auto_enabled (1'b0), .error_code (8'h00),
        .next_event (), .prev_event (), .auto_cfg_valid (), .auto_cfg_enabled (),
        .period_cfg_valid (), .period_cfg_cycles (), .volume (), .brightness (),
        .thumb_cfg_valid (), .thumb_cfg_enabled (), .select_event (),
        .focus_cfg_valid (), .focus_cfg_index (),
        .contrast (), .bright_cfg_valid (), .contrast_cfg_valid (),
        .key_bright_event (1'b0), .key_bright_value (8'h00),
        .key_contrast_event (1'b0), .key_contrast_value (8'h00),
        .vis_cfg (),
        .rtc_set_valid (rtc_set_valid), .rtc_set_bcd (rtc_set_bcd),
        .diag_code ()
    );

    ds3231_rtc #(
        .CLK_FREQ_HZ (100_000_000),
        .I2C_HZ      (100_000),
        .POLL_MS     (2)            // 仿真里 2ms 轮询一次
    ) dut (
        .clk (clk), .rst_n (rst_n),
        .scl (scl), .sda (sda),
        .set_valid (rtc_set_valid), .set_bcd (rtc_set_bcd),
        .time_bcd (time_bcd), .time_valid (time_valid), .read_ok_pulse (read_ok)
    );

    ds3231_model model (.scl (scl), .sda (sda));

    integer errors = 0;
    integer set_pulses = 0;
    always @(posedge clk) if (rtc_set_valid) set_pulses = set_pulses + 1;

    // ---- UART 发送（8N1，115200 -> 868 拍 = 8680ns）----
    task uart_byte(input [7:0] b);
        integer k;
        begin
            uart_rxd = 1'b0; #8680;
            for (k = 0; k < 8; k = k + 1) begin uart_rxd = b[k]; #8680; end
            uart_rxd = 1'b1; #8680;
        end
    endtask

    task uart_line(input [8*12-1:0] s, input integer n);
        integer k;
        begin
            for (k = n - 1; k >= 0; k = k - 1) uart_byte(s[8*k +: 8]);
            uart_byte(8'h0D);
            uart_byte(8'h0A);
        end
    endtask

    task wait_reads(input integer n);
        integer k;
        begin
            for (k = 0; k < n; k = k + 1) @(posedge read_ok);
            @(posedge clk);
        end
    endtask

    task expect_time(input [23:0] v, input [8*24-1:0] what);
        begin
            if (!time_valid || time_bcd !== v) begin
                $display("FAIL %0s: valid=%b time=%h expect %h", what, time_valid, time_bcd, v);
                errors = errors + 1;
            end else
                $display("PASS %0s: %h", what, time_bcd);
        end
    endtask

    initial begin
        model.regs[0] = 8'h58;
        model.regs[1] = 8'h59;
        model.regs[2] = 8'h23;
        #200 rst_n = 1'b1;

        // 1) 上电读
        wait_reads(1);
        expect_time(24'h235958, "power-up read");

        // 2) 跨天进位
        model.tick; model.tick;
        wait_reads(2);
        expect_time(24'h000000, "midnight rollover");

        // 3) 串口校时
        uart_line("TIM=123456", 10);
        wait (model.write_count == 1);
        if (model.regs[0] !== 8'h56 || model.regs[1] !== 8'h34 || model.regs[2] !== 8'h12) begin
            $display("FAIL TIM write: regs = %h %h %h", model.regs[2], model.regs[1], model.regs[0]);
            errors = errors + 1;
        end else
            $display("PASS TIM write: model regs 12 34 56 (24h)");
        wait_reads(1);
        expect_time(24'h123456, "read back after TIM");

        // 4) 非法命令不写
        uart_line("TIM=245900", 10);
        uart_line("TIM=126000", 10);
        uart_line("TIM=12345",  9);
        uart_line("TIM=12A456", 10);
        #200000;
        if (set_pulses != 1 || model.write_count != 1) begin
            $display("FAIL bad TIM accepted: set_pulses=%0d writes=%0d", set_pulses, model.write_count);
            errors = errors + 1;
        end else
            $display("PASS bad TIM rejected");

        // 5) 拔掉 / 插回
        model.present = 1'b0;
        #5_000_000;
        if (time_valid !== 1'b0) begin
            $display("FAIL unplugged: time_valid still 1");
            errors = errors + 1;
        end else
            $display("PASS unplugged -> time_valid=0");
        model.present = 1'b1;
        wait_reads(1);
        expect_time(24'h123456, "re-plugged");

        // 6) 12 小时制：0x52 = 12h 模式，PM=0，12 点
        model.regs[2] = 8'h52;
        wait_reads(2);
        expect_time(24'h123456, "12h mode hour");

        if (errors == 0) $display("ALL RTC TESTS PASSED");
        else             $display("RTC TESTS FAILED: %0d", errors);
        $finish;
    end

    initial begin
        #100_000_000;
        $display("TIMEOUT");
        $finish;
    end
endmodule
