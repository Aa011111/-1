# -*- coding: utf-8 -*-
"""tb_rtc_osd 写出的 frame_2.txt / frame_4.txt -> PNG，并和参考模型逐像素比对。"""
import os
import sys

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
W, H = 640, 480
SCALE, PITCH = 8, 40
TEXT_W, TEXT_H = 8 * PITCH - SCALE, 6 * SCALE
X0, Y0 = (W - TEXT_W) // 2, (H - TEXT_H) // 2
PAD = 16

# 4x6 字模，'#' = 亮（与 rtc_clock_osd.v 的 font_pixel 同一张图）
FONT = {
    "0": [".##.", "#..#", "#..#", "#..#", "#..#", ".##."],
    "1": [".##.", "..#.", "..#.", "..#.", "..#.", ".###"],
    "2": [".##.", "...#", ".##.", ".#..", "#...", ".###"],
    "3": [".##.", "...#", ".##.", "...#", "...#", ".##."],
    "4": ["#..#", "#..#", "####", "...#", "...#", "...#"],
    "5": ["####", "#...", "###.", "...#", "...#", ".##."],
    "6": [".##.", "#...", "###.", "#..#", "#..#", ".##."],
    "7": ["####", "...#", "..#.", "..#.", "..#.", "..#."],
    "8": [".##.", "#..#", ".##.", "#..#", "#..#", ".##."],
    "9": [".##.", "#..#", ".###", "...#", "...#", ".##."],
    ":": ["....", ".##.", "....", "....", ".##.", "...."],
    "-": ["....", "....", "####", "....", "....", "...."],
}


def expected(text):
    img = []
    for y in range(H):
        for x in range(W):
            bg = ((x >> 2) & 0xFF, (y >> 1) & 0xFF, 0x80)
            px = bg
            if X0 - PAD <= x < X0 + TEXT_W + PAD and Y0 - PAD <= y < Y0 + TEXT_H + PAD:
                px = tuple(c >> 1 for c in bg)
            if X0 <= x < X0 + TEXT_W and Y0 <= y < Y0 + TEXT_H:
                dx, dy = x - X0, y - Y0
                slot, within = dx // PITCH, dx % PITCH
                col, row = within // SCALE, dy // SCALE
                if col < 4 and FONT[text[slot]][row][col] == "#":
                    px = (0xFF, 0xFF, 0xFF)
            img.append(px)
    return img


def check(name, text):
    path = os.path.join(HERE, name + ".txt")
    vals = [int(l, 16) for l in open(path) if l.strip()]
    if len(vals) != W * H:
        print("FAIL %s: %d pixels" % (name, len(vals)))
        return False
    got = [((v >> 16) & 0xFF, (v >> 8) & 0xFF, v & 0xFF) for v in vals]
    im = Image.new("RGB", (W, H))
    im.putdata(got)
    im.save(os.path.join(HERE, name + ".png"))
    exp = expected(text)
    bad = [i for i in range(W * H) if got[i] != exp[i]]
    if bad:
        i = bad[0]
        print("FAIL %s: %d mismatches, first at (%d,%d) got %s exp %s"
              % (name, len(bad), i % W, i // W, got[i], exp[i]))
        return False
    print("PASS %s: '%s' matches reference" % (name, text))
    return True


ok = check("frame_2", "12:34:56") & check("frame_4", "--:--:--")
sys.exit(0 if ok else 1)
