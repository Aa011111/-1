# 串口控制台回归（原 _unused/uart/sim 的 tb + VIS= 用例）：vsim -c -do run.do
if {[file exists work]} { vdel -lib work -all }
vlib work
foreach f {uart_rx_byte uart_tx_byte uart_line_parser uart_command_engine uart_response_tx uart_status_reporter uart_cmd_core media_uart_console} {
    vlog -quiet ../../hdl_source/uart/$f.v
}
vlog -quiet tb_media_uart_console_vis.v
vsim -quiet -c tb_media_uart_console
run -all
quit -f
