`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 照片缩放自适应回归（bmp24_decoder）
//   A. 640x480 / 1280x960：新解码器 与 改造前副本 ref_bmp24_decoder 逐拍比对全部输出
//   B. 其它尺寸：新解码器输出的 307200 个像素逐个与独立模型比对
//        crop: 3W>4H ? (cw=floor(4H/3), ch=H) : (cw=W, ch=floor(3W/4))
//        x0=(W-cw)/2, y0=(H-ch)/2
//        第 k 个输出像素 (ox=k%640, oy=k/640) 应等于源像素
//        (流行 y0+ceil(oy*ch/480), 列 x0+ceil(ox*cw/640))
//   C. 拒收：尺寸越界 -> 0x32；ALLOW_SCALE_SOURCE=0 时行为与原来相同；截断 -> 0x37
// 字节流节奏模拟 sd_sector_replay_buffer：每 512 字节连续一拍一个，扇区间隔若干拍。
// 运行：vsim -c -do run_bmp.do
// -----------------------------------------------------------------------------
module tb_bmp_scale;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;

    reg        file_start = 0, file_valid = 0, file_end = 0;
    reg [7:0]  file_byte = 0;
    reg [31:0] file_byte_offset = 0, file_size = 0;

    wire        n_hdr, n_pv, n_commit, n_done, n_td, n_2x;
    wire [23:0] n_rgb;
    wire [15:0] n_x, n_y;
    wire [7:0]  n_err;
    wire [31:0] n_off, n_stride;
    wire        r_hdr, r_pv, r_commit, r_done, r_td, r_2x;
    wire [23:0] r_rgb;
    wire [15:0] r_x, r_y;
    wire [7:0]  r_err;
    wire [31:0] r_off, r_stride;
    wire        o_pv, o_commit, o_done;
    wire [7:0]  o_err;

    bmp24_decoder #(.EXPECTED_WIDTH(640), .EXPECTED_HEIGHT(480),
                    .ALLOW_2X_SOURCE(1), .ALLOW_SCALE_SOURCE(1), .MAX_SOURCE_DIM(4096)) dut (
        .clk(clk), .rst_n(rst_n), .file_start(file_start), .file_size(file_size),
        .file_valid(file_valid), .file_byte(file_byte), .file_byte_offset(file_byte_offset),
        .file_end(file_end), .upstream_error(8'd0), .header_accepted(n_hdr),
        .pixel_valid(n_pv), .pixel_rgb(n_rgb), .pixel_x(n_x), .pixel_y(n_y),
        .frame_commit(n_commit), .bmp_done(n_done), .bmp_error(n_err),
        .top_down(n_td), .pixel_offset(n_off), .row_stride(n_stride), .source_scale_2x(n_2x));

    ref_bmp24_decoder #(.EXPECTED_WIDTH(640), .EXPECTED_HEIGHT(480), .ALLOW_2X_SOURCE(1)) ref0 (
        .clk(clk), .rst_n(rst_n), .file_start(file_start), .file_size(file_size),
        .file_valid(file_valid), .file_byte(file_byte), .file_byte_offset(file_byte_offset),
        .file_end(file_end), .upstream_error(8'd0), .header_accepted(r_hdr),
        .pixel_valid(r_pv), .pixel_rgb(r_rgb), .pixel_x(r_x), .pixel_y(r_y),
        .frame_commit(r_commit), .bmp_done(r_done), .bmp_error(r_err),
        .top_down(r_td), .pixel_offset(r_off), .row_stride(r_stride), .source_scale_2x(r_2x));

    // 不开缩放的新解码器：必须与原来一样只认 640x480 / 1280x960
    bmp24_decoder #(.EXPECTED_WIDTH(640), .EXPECTED_HEIGHT(480),
                    .ALLOW_2X_SOURCE(1), .ALLOW_SCALE_SOURCE(0)) dut_off (
        .clk(clk), .rst_n(rst_n), .file_start(file_start), .file_size(file_size),
        .file_valid(file_valid), .file_byte(file_byte), .file_byte_offset(file_byte_offset),
        .file_end(file_end), .upstream_error(8'd0), .header_accepted(),
        .pixel_valid(o_pv), .pixel_rgb(), .pixel_x(), .pixel_y(),
        .frame_commit(o_commit), .bmp_done(o_done), .bmp_error(o_err),
        .top_down(), .pixel_offset(), .row_stride(), .source_scale_2x());

    integer errors = 0;
    integer seed = 32'h0bad_cafe;

    // ---------------- 源像素内容：可由 (流行, 列) 唯一反推 ----------------
    function [23:0] src_pix;        // {R,G,B}
        input integer r, c;
        begin
            src_pix = {c[7:0], r[7:0], c[11:8], r[11:8]};
        end
    endfunction

    // ---------------- 期望模型 ----------------
    integer m_w, m_h, m_cw, m_ch, m_x0, m_y0;
    integer compare_mode;           // 0 不比 1 对 ref 逐拍 2 对模型
    integer k_out;
    function integer ceil_div;
        input integer a, b;
        begin
            ceil_div = (a + b - 1) / b;
        end
    endfunction

    always @(posedge clk) if (rst_n) begin
        #1;
        if (compare_mode == 1) begin
            if ({n_hdr, n_pv, n_commit, n_done, n_err, n_td, n_2x, n_off, n_stride} !==
                {r_hdr, r_pv, r_commit, r_done, r_err, r_td, r_2x, r_off, r_stride} ||
                (r_pv && ({n_rgb, n_x, n_y} !== {r_rgb, r_x, r_y}))) begin
                errors = errors + 1;
                if (errors < 20)
                    $display("[%0t] REF MISMATCH new pv=%b rgb=%h x=%0d y=%0d err=%h | ref pv=%b rgb=%h x=%0d y=%0d err=%h",
                             $time, n_pv, n_rgb, n_x, n_y, n_err, r_pv, r_rgb, r_x, r_y, r_err);
            end
        end else if (compare_mode == 2 && n_pv) begin
            if (n_rgb !== src_pix(m_y0 + ceil_div((k_out / 640) * m_ch, 480),
                                  m_x0 + ceil_div((k_out % 640) * m_cw, 640)) ||
                n_x !== (k_out % 640) || n_y !== (479 - k_out / 640)) begin
                errors = errors + 1;
                if (errors < 20)
                    $display("[%0t] MODEL MISMATCH k=%0d got rgb=%h x=%0d y=%0d exp rgb=%h (row %0d col %0d)",
                             $time, k_out, n_rgb, n_x, n_y,
                             src_pix(m_y0 + ceil_div((k_out / 640) * m_ch, 480),
                                     m_x0 + ceil_div((k_out % 640) * m_cw, 640)),
                             m_y0 + ceil_div((k_out / 640) * m_ch, 480),
                             m_x0 + ceil_div((k_out % 640) * m_cw, 640));
            end
        end
        if (n_pv) k_out = k_out + 1;
    end

    // ---------------- 发送一个 BMP 文件 ----------------
    reg [7:0] hdr [0:53];
    integer ref_pending = 0;
    integer send_limit = 0;        // 非0：只发前 N 字节（拒收用例不必把几 MB 的像素都发完）
    integer stride, total, i, b, r, c, ch_idx;
    reg [23:0] px;
    task automatic send_bmp;
        input integer w, h;
        input integer truncate_bytes;   // 文件尾部少发多少字节（并相应减小 file_size）
        integer data_bytes, fsize, real_size, off;
        begin
            stride = ((w * 3 + 3) / 4) * 4;
            data_bytes = stride * h;
            fsize = 54 + data_bytes;
            real_size = fsize - truncate_bytes;
            for (i = 0; i < 54; i = i + 1) hdr[i] = 8'd0;
            hdr[0] = "B"; hdr[1] = "M";
            {hdr[5], hdr[4], hdr[3], hdr[2]} = fsize;
            hdr[10] = 8'd54;
            hdr[14] = 8'd40;
            {hdr[21], hdr[20], hdr[19], hdr[18]} = w;
            {hdr[25], hdr[24], hdr[23], hdr[22]} = h;
            hdr[26] = 8'd1;
            hdr[28] = 8'd24;
            {hdr[37], hdr[36], hdr[35], hdr[34]} = data_bytes;

            @(negedge clk);
            file_size = real_size;
            file_start = 1'b1;
            @(negedge clk);
            file_start = 1'b0;
            // 对 ref 逐拍比对从 file_start 之后开始：上一张图留下的错误码两边本来就可能不同
            if (ref_pending) begin compare_mode = 1; ref_pending = 0; end
            repeat (5) @(negedge clk);

            off = 0;
            while (off < real_size && (send_limit == 0 || off < send_limit)) begin
                // 扇区边界：间隔几拍（模拟下一扇区读卡）
                if (off % 512 == 0 && off != 0) begin
                    file_valid = 1'b0;
                    repeat (3 + ($random(seed) & 7)) @(negedge clk);
                end
                if (off < 54) begin
                    file_byte = hdr[off];
                end else begin
                    b  = off - 54;
                    r  = b / stride;
                    c  = (b % stride) / 3;
                    ch_idx = (b % stride) % 3;
                    if ((b % stride) >= w * 3) begin
                        file_byte = 8'h00;
                    end else begin
                        px = src_pix(r, c);
                        file_byte = (ch_idx == 0) ? px[7:0] : (ch_idx == 1) ? px[15:8] : px[23:16];
                    end
                end
                file_valid = 1'b1;
                file_byte_offset = off;
                @(negedge clk);
                off = off + 1;
            end
            file_valid = 1'b0;
            repeat (4) @(negedge clk);
            file_end = 1'b1;
            @(negedge clk);
            file_end = 1'b0;
            repeat (4) @(negedge clk);
        end
    endtask

    // ---------------- 用例 ----------------
    integer pass_cnt = 0;
    task automatic run_model_case;
        input integer w, h;
        integer e0;
        begin
            m_w = w; m_h = h;
            if (3 * w > 4 * h) begin m_cw = (4 * h) / 3; m_ch = h; end
            else                begin m_cw = w;           m_ch = (3 * w) / 4; end
            m_x0 = (w - m_cw) / 2;
            m_y0 = (h - m_ch) / 2;
            e0 = errors;
            k_out = 0;
            compare_mode = 2;
            send_bmp(w, h, 0);
            compare_mode = 0;
            if (k_out != 307200 || n_err != 8'h00 || !n_hdr) begin
                errors = errors + 1;
                $display("CASE %0dx%0d FAILED: pixels=%0d err=%h hdr=%b", w, h, k_out, n_err, n_hdr);
            end
            // 不开缩放的实例必须照旧拒收这张图（除非恰好 640x480 / 1280x960）
            if (!((w == 640 && h == 480) || (w == 1280 && h == 960)) && o_err != 8'h32) begin
                errors = errors + 1;
                $display("CASE %0dx%0d: ALLOW_SCALE_SOURCE=0 should reject with 0x32, got %h", w, h, o_err);
            end
            $display("case %4dx%-4d crop %4dx%-4d @(%0d,%0d)  out=%0d  %s",
                     w, h, m_cw, m_ch, m_x0, m_y0, k_out, (errors == e0) ? "ok" : "FAIL");
        end
    endtask

    task automatic run_ref_case;
        input integer w, h;
        integer e0;
        begin
            e0 = errors;
            k_out = 0;
            ref_pending = 1;
            send_bmp(w, h, 0);
            compare_mode = 0;
            if (k_out != 307200 || n_err != 8'h00) begin
                errors = errors + 1;
                $display("REF CASE %0dx%0d FAILED: pixels=%0d err=%h", w, h, k_out, n_err);
            end
            $display("case %4dx%-4d vs original decoder (cycle-exact)  out=%0d  %s",
                     w, h, k_out, (errors == e0) ? "ok" : "FAIL");
        end
    endtask

    task automatic run_reject_case;
        input integer w, h, trunc;
        input [7:0] expect_err;
        begin
            k_out = 0;
            send_limit = 4096;
            send_bmp(w, h, trunc);
            send_limit = 0;
            if (n_err !== expect_err || k_out != 0 && expect_err == 8'h32 || n_commit) begin
                errors = errors + 1;
                $display("REJECT CASE %0dx%0d trunc=%0d: expected %h got %h (pixels %0d)", w, h, trunc, expect_err, n_err, k_out);
            end else
                $display("case %4dx%-4d trunc=%0d -> err %h  ok", w, h, trunc, n_err);
        end
    endtask

    initial begin
        compare_mode = 0;
        k_out = 0;
        repeat (4) @(negedge clk);
        rst_n = 1'b1;

        // A. 原有两种尺寸：与改造前逐拍一致
        run_ref_case(640, 480);
        // B. 新尺寸：4:3 放大源、宽图、高图、奇数尺寸带行填充、16:9
        run_model_case(800, 600);
        run_model_case(1000, 480);
        run_model_case(640, 900);
        run_model_case(643, 483);
        run_model_case(960, 540);
        // C. 拒收
        run_reject_case(639, 480, 0, 8'h32);
        run_reject_case(640, 479, 0, 8'h32);
        run_reject_case(4097, 600, 0, 8'h32);
        run_reject_case(700, 4100, 0, 8'h32);
        run_reject_case(800, 600, 2000, 8'h37);
        // A'. 1280x960 2x2 平均路径（最慢，放最后）
        run_ref_case(1280, 960);

        $display("------------------------------------------------------------");
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL  errors=%0d", errors);
        $finish;
    end
endmodule
