`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 资源优化回归：新旧模块喂同一套随机激励，每拍比对全部输出。
//   1) media_frame_loader：小参数随机压力（大量加载、反压、溢出、解码错误、卡死超时）
//      + 工程实际参数（640x480 / FIFO 512 / burst 128 / V_FLIP=1）完整加载一张图
//   2) sd_sector_replay_buffer：随机 busy/间隔/乱序/错误/字节数不对
//   3) fat32_file_streamer：簇号->扇区号 乘法 与 移位 的等价性
// 数据口只在有效拍比较（app_wr_data@app_wr_en、sector_byte@sector_valid），
// 下游也只在有效拍采样；新版本这两个口复位后是 X、不再清 0，这是唯一允许的差异。
// 运行：vsim -c -do run.do
// -----------------------------------------------------------------------------
module tb_opt_equiv;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n;
    integer errors = 0;
    integer seed = 32'h1234_5678;

    // ======================== 1a. loader 小参数随机 ========================
    localparam integer S_W = 16, S_H = 8, S_WORDS = S_W * S_H;
    reg        l_start;
    reg [1:0]  l_index;
    reg        l_pvalid;
    reg [23:0] l_rgb;
    reg        l_commit;
    reg [7:0]  l_derr;
    reg        l_init;

    wire        n_busy, r_busy, n_done, r_done, n_wen, r_wen;
    wire [3:0]  n_cpl, r_cpl, n_mask, r_mask;
    wire [7:0]  n_merr, r_merr;
    wire [20:0] n_addr, r_addr;
    wire [31:0] n_data, r_data;

    media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(S_WORDS), .FIFO_DEPTH(32), .BURST_SIZE(8),
        .STALL_TIMEOUT(40), .V_FLIP(1), .FRAME_WIDTH(S_W), .FRAME_HEIGHT(S_H)
    ) dut_new (
        .clk(clk), .rst_n(rst_n), .load_start(l_start), .image_index(l_index),
        .pixel_valid(l_pvalid), .pixel_rgb(l_rgb), .frame_commit(l_commit),
        .decode_error(l_derr), .load_busy(n_busy), .load_done(n_done),
        .image_complete(n_cpl), .memory_error(n_merr),
        .controller_init_done(l_init), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(n_wen), .app_wr_addr(n_addr), .app_wr_mask(n_mask), .app_wr_data(n_data)
    );
    ref_media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(S_WORDS), .FIFO_DEPTH(32), .BURST_SIZE(8),
        .STALL_TIMEOUT(40), .V_FLIP(1), .FRAME_WIDTH(S_W), .FRAME_HEIGHT(S_H)
    ) dut_ref (
        .clk(clk), .rst_n(rst_n), .load_start(l_start), .image_index(l_index),
        .pixel_valid(l_pvalid), .pixel_rgb(l_rgb), .frame_commit(l_commit),
        .decode_error(l_derr), .load_busy(r_busy), .load_done(r_done),
        .image_complete(r_cpl), .memory_error(r_merr),
        .controller_init_done(l_init), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(r_wen), .app_wr_addr(r_addr), .app_wr_mask(r_mask), .app_wr_data(r_data)
    );

    // ======================== 1b. loader 工程实际参数 ========================
    // FIFO 512 / burst 128 / 行宽 640 / V_FLIP 与工程一致；只把行数从 480 降到 16，
    // 免得 ModelSim 入门版限速跑太久。FIFO 指针回绕、行尾跳转都照样覆盖。
    localparam integer F_H = 16, F_WORDS = 640 * F_H;
    reg        f_start, f_pvalid, f_commit, f_init;
    reg [23:0] f_rgb;
    wire        fn_busy, fr_busy, fn_done, fr_done, fn_wen, fr_wen;
    wire [3:0]  fn_cpl, fr_cpl, fn_mask, fr_mask;
    wire [7:0]  fn_merr, fr_merr;
    wire [20:0] fn_addr, fr_addr;
    wire [31:0] fn_data, fr_data;

    media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(F_WORDS), .FIFO_DEPTH(512), .BURST_SIZE(128),
        .STALL_TIMEOUT(65535), .V_FLIP(1), .FRAME_WIDTH(640), .FRAME_HEIGHT(F_H)
    ) dut_full_new (
        .clk(clk), .rst_n(rst_n), .load_start(f_start), .image_index(2'd2),
        .pixel_valid(f_pvalid), .pixel_rgb(f_rgb), .frame_commit(f_commit),
        .decode_error(8'd0), .load_busy(fn_busy), .load_done(fn_done),
        .image_complete(fn_cpl), .memory_error(fn_merr),
        .controller_init_done(f_init), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(fn_wen), .app_wr_addr(fn_addr), .app_wr_mask(fn_mask), .app_wr_data(fn_data)
    );
    ref_media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(F_WORDS), .FIFO_DEPTH(512), .BURST_SIZE(128),
        .STALL_TIMEOUT(65535), .V_FLIP(1), .FRAME_WIDTH(640), .FRAME_HEIGHT(F_H)
    ) dut_full_ref (
        .clk(clk), .rst_n(rst_n), .load_start(f_start), .image_index(2'd2),
        .pixel_valid(f_pvalid), .pixel_rgb(f_rgb), .frame_commit(f_commit),
        .decode_error(8'd0), .load_busy(fr_busy), .load_done(fr_done),
        .image_complete(fr_cpl), .memory_error(fr_merr),
        .controller_init_done(f_init), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(fr_wen), .app_wr_addr(fr_addr), .app_wr_mask(fr_mask), .app_wr_data(fr_data)
    );

    // ======================== 2. replay buffer ========================
    reg        p_req;
    reg [31:0] p_lba;
    reg        p_rbusy, p_rvalid, p_rdone;
    reg [7:0]  p_rbyte, p_rerr;
    reg [8:0]  p_ridx;
    wire       pn_busy, pr_busy, pn_valid, pr_valid, pn_done, pr_done, pn_rreq, pr_rreq;
    wire [7:0] pn_byte, pr_byte, pn_err, pr_err;
    wire [8:0] pn_idx, pr_idx;
    wire [31:0] pn_rlba, pr_rlba;

    sd_sector_replay_buffer rp_new (
        .clk(clk), .rst_n(rst_n), .sector_req(p_req), .sector_lba(p_lba),
        .sector_busy(pn_busy), .sector_valid(pn_valid), .sector_byte(pn_byte),
        .sector_byte_index(pn_idx), .sector_done(pn_done), .sector_error(pn_err),
        .reader_req(pn_rreq), .reader_lba(pn_rlba), .reader_busy(p_rbusy),
        .reader_valid(p_rvalid), .reader_byte(p_rbyte), .reader_byte_index(p_ridx),
        .reader_done(p_rdone), .reader_error(p_rerr)
    );
    ref_sd_sector_replay_buffer rp_ref (
        .clk(clk), .rst_n(rst_n), .sector_req(p_req), .sector_lba(p_lba),
        .sector_busy(pr_busy), .sector_valid(pr_valid), .sector_byte(pr_byte),
        .sector_byte_index(pr_idx), .sector_done(pr_done), .sector_error(pr_err),
        .reader_req(pr_rreq), .reader_lba(pr_rlba), .reader_busy(p_rbusy),
        .reader_valid(p_rvalid), .reader_byte(p_rbyte), .reader_byte_index(p_ridx),
        .reader_done(p_rdone), .reader_error(p_rerr)
    );

    // ======================== 逐拍比对 ========================
    integer cmp_cycles = 0, l_writes = 0, f_writes = 0, p_bytes = 0;
    integer l_loads_ok = 0, l_loads_fail = 0, p_sectors = 0;
    always @(posedge clk) if (rst_n) begin
        #1;
        cmp_cycles = cmp_cycles + 1;
        if ({n_busy, n_done, n_cpl, n_merr, n_wen} !== {r_busy, r_done, r_cpl, r_merr, r_wen} ||
            (r_wen && ({n_addr, n_mask, n_data} !== {r_addr, r_mask, r_data}))) begin
            errors = errors + 1;
            if (errors < 20)
                $display("[%0t] LOADER MISMATCH new busy=%b done=%b cpl=%h err=%h wen=%b addr=%h data=%h | ref busy=%b done=%b cpl=%h err=%h wen=%b addr=%h data=%h",
                         $time, n_busy, n_done, n_cpl, n_merr, n_wen, n_addr, n_data,
                         r_busy, r_done, r_cpl, r_merr, r_wen, r_addr, r_data);
        end
        if (r_wen) l_writes = l_writes + 1;
        if (r_done && r_merr == 0) l_loads_ok = l_loads_ok + 1;
        if (r_done && r_merr != 0) l_loads_fail = l_loads_fail + 1;

        if ({fn_busy, fn_done, fn_cpl, fn_merr, fn_wen} !== {fr_busy, fr_done, fr_cpl, fr_merr, fr_wen} ||
            (fr_wen && ({fn_addr, fn_mask, fn_data} !== {fr_addr, fr_mask, fr_data}))) begin
            errors = errors + 1;
            if (errors < 20)
                $display("[%0t] FULL LOADER MISMATCH new wen=%b addr=%h data=%h | ref wen=%b addr=%h data=%h",
                         $time, fn_wen, fn_addr, fn_data, fr_wen, fr_addr, fr_data);
        end
        if (fr_wen) f_writes = f_writes + 1;

        if ({pn_busy, pn_valid, pn_done, pn_err, pn_rreq, pn_rlba} !==
            {pr_busy, pr_valid, pr_done, pr_err, pr_rreq, pr_rlba} ||
            (pr_valid && ({pn_byte, pn_idx} !== {pr_byte, pr_idx}))) begin
            errors = errors + 1;
            if (errors < 20)
                $display("[%0t] REPLAY MISMATCH new v=%b b=%h i=%0d d=%b e=%h | ref v=%b b=%h i=%0d d=%b e=%h",
                         $time, pn_valid, pn_byte, pn_idx, pn_done, pn_err,
                         pr_valid, pr_byte, pr_idx, pr_done, pr_err);
        end
        if (pr_valid) p_bytes = p_bytes + 1;
        if (pr_done)  p_sectors = p_sectors + 1;
    end

    // ======================== 激励：loader 小参数 ========================
    integer li, lsent, mode;
    task automatic small_load;
        input integer m;      // 0 正常 1 多发像素 2 中途解码错误 3 控制器长时间不就绪(超时) 4 少发像素
        integer target, k;
        begin
            @(negedge clk);
            l_start = 1'b1; l_index = $random(seed);
            @(negedge clk);
            l_start = 1'b0;
            target = (m == 1) ? S_WORDS + 3 : (m == 4) ? S_WORDS - 5 : S_WORDS;
            lsent = 0;
            while (lsent < target && n_busy) begin
                @(negedge clk);
                l_pvalid = ($random(seed) & 3) != 0;
                l_rgb    = $random(seed);
                l_init   = (m == 3 && lsent > 40) ? 1'b0 : (($random(seed) & 7) != 0);
                l_derr   = (m == 2 && lsent == 70 && l_pvalid) ? 8'h35 : 8'h00;
                if (l_pvalid) lsent = lsent + 1;
            end
            @(negedge clk);
            l_pvalid = 1'b0; l_derr = 8'h00;
            l_commit = 1'b1;
            @(negedge clk);
            l_commit = 1'b0;
            k = 0;
            while (n_busy && k < 400) begin
                @(negedge clk);
                l_init = (m == 3) ? 1'b0 : (($random(seed) & 3) != 0);
                k = k + 1;
            end
            l_init = 1'b1;
            repeat (3) @(negedge clk);
        end
    endtask

    // ======================== 激励：loader 工程参数 ========================
    integer fi;
    initial begin
        f_start = 0; f_pvalid = 0; f_commit = 0; f_init = 1; f_rgb = 0;
        wait (rst_n);
        repeat (5) @(negedge clk);
        f_start = 1'b1;
        @(negedge clk);
        f_start = 1'b0;
        fi = 0;
        while (fi < F_WORDS) begin
            @(negedge clk);
            // 模拟 SD 读速度远慢于 SDRAM：像素稀疏到达，偶尔一阵突发把 FIFO 推满
            f_pvalid = (fi % 2048 < 900) ? 1'b1 : (($random(seed) & 3) == 0);
            f_rgb    = {fi[7:0], fi[15:8], 8'h5a ^ fi[7:0]};
            // 周期性让控制器不收数据（放在稀疏段，积压约 300 字 < 512，不溢出）
            f_init   = (fi % 2048 >= 900 && fi % 2048 < 1200) ? 1'b0 : 1'b1;
            if (f_pvalid) fi = fi + 1;
        end
        @(negedge clk); f_pvalid = 1'b0; f_init = 1'b1; f_commit = 1'b1;
        @(negedge clk); f_commit = 1'b0;
    end

    // ======================== 激励：replay ========================
    task automatic one_sector;
        input integer m;      // 0 正常 1 乱序 2 读错误 3 少一字节
        integer b, nbytes;
        begin
            @(negedge clk);
            p_req = 1'b1; p_lba = $random(seed);
            @(negedge clk);
            p_req = 1'b0;
            repeat ($random(seed) & 7) begin p_rbusy = 1'b1; @(negedge clk); end
            p_rbusy = 1'b0;
            while (!pr_rreq) @(negedge clk);
            nbytes = (m == 3) ? 511 : 512;
            for (b = 0; b < nbytes; b = b + 1) begin
                while (($random(seed) & 3) == 0) begin
                    @(negedge clk); p_rvalid = 1'b0;
                end
                @(negedge clk);
                p_rvalid = 1'b1;
                p_rbyte  = $random(seed);
                p_ridx   = (m == 1 && b == 200) ? 9'd7 : b;
            end
            @(negedge clk);
            p_rvalid = 1'b0;
            p_rdone = 1'b1; p_rerr = (m == 2) ? 8'h0c : 8'h00;
            @(negedge clk);
            p_rdone = 1'b0; p_rerr = 8'h00;
            while (pr_busy) @(negedge clk);
        end
    endtask

    // ======================== 3. streamer 乘法 vs 移位 ========================
    function [2:0] shift_of;
        input [7:0] v;
        begin
            case (v)
                8'd2: shift_of = 1; 8'd4: shift_of = 2; 8'd8: shift_of = 3;
                8'd16: shift_of = 4; 8'd32: shift_of = 5; 8'd64: shift_of = 6;
                8'd128: shift_of = 7; default: shift_of = 0;
            endcase
        end
    endfunction
    integer si, sk;
    reg [31:0] s_base, s_clu, s_mul, s_shf;
    reg [7:0]  s_spc;

    // ======================== 主流程 ========================
    initial begin
        rst_n = 1'b0;
        l_start = 0; l_index = 0; l_pvalid = 0; l_rgb = 0; l_commit = 0; l_derr = 0; l_init = 1;
        p_req = 0; p_lba = 0; p_rbusy = 0; p_rvalid = 0; p_rdone = 0; p_rbyte = 0; p_rerr = 0; p_ridx = 0;
        repeat (4) @(negedge clk);
        rst_n = 1'b1;

        // 空闲时给像素 -> ERR_NOT_ACTIVE 分支
        @(negedge clk); l_pvalid = 1'b1; @(negedge clk); l_pvalid = 1'b0;

        fork
            begin
                for (li = 0; li < 120; li = li + 1) begin
                    mode = (li < 50) ? 0 : ($random(seed) & 32'h7fff_ffff) % 5;
                    small_load(mode);
                end
            end
            begin
                for (si = 0; si < 80; si = si + 1)
                    one_sector((si < 30) ? 0 : ($random(seed) & 32'h7fff_ffff) % 4);
            end
        join
        $display("[%0t] random phases done, errors so far = %0d", $time, errors);

        for (si = 0; si < 8; si = si + 1) begin
            s_spc = 8'd1 << si;
            for (sk = 0; sk < 5000; sk = sk + 1) begin
                s_base = $random(seed);
                s_clu  = 2 + (($random(seed) & 32'h0fff_ffff));
                s_mul  = s_base + (s_clu - 2) * s_spc;
                s_shf  = s_base + ((s_clu - 2) << shift_of(s_spc));
                if (s_mul !== s_shf) begin
                    errors = errors + 1;
                    $display("STREAMER MISMATCH spc=%0d clu=%h mul=%h shf=%h", s_spc, s_clu, s_mul, s_shf);
                end
            end
        end

        wait (!fr_busy && f_writes > 0);
        repeat (20) @(negedge clk);

        $display("------------------------------------------------------------");
        $display("compared cycles        : %0d", cmp_cycles);
        $display("small loader  loads ok : %0d  failed : %0d  sdram writes : %0d", l_loads_ok, l_loads_fail, l_writes);
        $display("full  loader  writes   : %0d  image_complete=%b err=%h", f_writes, fr_cpl, fr_merr);
        $display("replay sectors         : %0d  bytes replayed : %0d", p_sectors, p_bytes);
        if (errors == 0 && f_writes == F_WORDS && fr_cpl == 4'b0100 && l_loads_ok > 40 && l_loads_fail > 10)
            $display("RESULT: PASS");
        else
            $display("RESULT: FAIL  errors=%0d", errors);
        $finish;
    end
endmodule
