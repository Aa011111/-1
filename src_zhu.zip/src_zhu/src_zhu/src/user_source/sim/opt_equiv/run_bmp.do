if {[file exists work_bmp]} { vdel -lib work_bmp -all }
vlib work_bmp
vlog -quiet -work work_bmp ../../hdl_source/stable/bmp24_decoder.v
vlog -quiet -work work_bmp ref_bmp24_decoder.v tb_bmp_scale.v
vsim -quiet -c -lib work_bmp tb_bmp_scale
run -all
quit -f
