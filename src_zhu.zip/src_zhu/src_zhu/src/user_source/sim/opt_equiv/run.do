if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -quiet ../../hdl_source/framebuf4bank/media_frame_loader.v
vlog -quiet ../../hdl_source/fat32/sd_sector_replay_buffer.v
vlog -quiet ref_media_frame_loader.v ref_sd_sector_replay_buffer.v tb_opt_equiv.v
vsim -quiet -c tb_opt_equiv
run -all
quit -f
