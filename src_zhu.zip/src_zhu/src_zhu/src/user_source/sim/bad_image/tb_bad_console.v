`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 坏图明细记录 + reporter + 串口命令 "1" 的定向自检：vsim -c -do run.do
// 每个场景从复位开始（坏图记录只追加，一次上电最多 16 条）。
//   A. 13 条 bad 事件连续 13 拍到达 -> 13 行 BAD 按序、图号 01~13 两位十进制；
//      第 2 行发送期间 report_enable 上升、第 3 行期间 error_code=70
//      -> 13 行 BAD 发完才是 banner，再是 ERR 70（BAD > banner > ERR，banner 不丢）
//   A2. 接着发 "1" -> OK，再把 13 行 BAD、banner、ERR 70 原样补发一遍
//   B. 3 条 bad 事件 + 第 1 行发送期间收到 NEXT -> BAD, OK, BAD, BAD（回复插队）
//   C. 20 条连续事件：记录 16 条满了丢新来的 -> 只发 16 行
//   D. 第 1 行 BAD 还在发时收到 "1" -> 发完的那行之后先 OK，再发完剩下的，
//      然后从头补发全部 3 行（不在显示、没有错误码：不补 banner / ERR）
//   E. 没有坏图、没在显示、没有错误码时发 "1" -> 只回 OK
// 仿真里 CLKS_PER_BIT 压到 16。只是功能闭环，不是时序验证。
// -----------------------------------------------------------------------------
module tb_bad_console;
    localparam integer CPB = 16;
    localparam integer LINE = 11 * 10 * CPB;   // 一行 BAD 的发送时间（拍）

    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    integer errors = 0;

    reg        host_tx = 1'b1;
    reg        report_enable = 1'b0;
    reg [7:0]  error_code = 8'h00;
    reg        bad_valid = 1'b0;
    reg [3:0]  bad_index = 4'd0;
    reg [7:0]  bad_code = 8'h00;
    wire       uart_txd;
    wire       next_event;

    media_uart_console #(
        .CLKS_PER_BIT(CPB), .INDEX_W(4), .FOCUS_COUNT(11)
    ) dut (
        .clk(clk), .rst_n(rst_n), .uart_rxd(host_tx), .uart_txd(uart_txd),
        .report_enable(report_enable), .media_id(4'd0), .auto_enabled(1'b0),
        .error_code(error_code),
        .bad_valid(bad_valid), .bad_index(bad_index), .bad_code(bad_code),
        .next_event(next_event), .prev_event(), .auto_cfg_valid(), .auto_cfg_enabled(),
        .period_cfg_valid(), .period_cfg_cycles(), .volume(), .brightness(),
        .thumb_cfg_valid(), .thumb_cfg_enabled(), .select_event(),
        .focus_cfg_valid(), .focus_cfg_index(),
        .contrast(), .bright_cfg_valid(), .contrast_cfg_valid(),
        .key_bright_event(1'b0), .key_bright_value(8'h00),
        .key_contrast_event(1'b0), .key_contrast_value(8'h00),
        .vis_cfg(), .diag_code()
    );

    // ---- TX 监视器 ----
    wire [7:0] mon_data;
    wire       mon_valid;
    uart_rx_byte #(.CLKS_PER_BIT(CPB)) u_monitor (
        .clk(clk), .rst_n(1'b1), .rx(uart_txd),
        .data(mon_data), .valid(mon_valid), .framing_error()
    );

    reg [7:0] rx_log [0:4095];
    integer   rx_count = 0;
    integer   expect_base = 0;
    always @(posedge clk)
        if (mon_valid) begin
            rx_log[rx_count] = mon_data;
            rx_count = rx_count + 1;
        end

    // 比对一行（不含 CRLF，自动补）
    task expect_line;
        input [8*20-1:0] text;
        input integer    len;
        integer i, guard;
        reg [7:0] got, want;
        begin
            guard = 0;
            while (rx_count < expect_base + len + 2 && guard < 200000) begin
                @(posedge clk);
                guard = guard + 1;
            end
            if (rx_count < expect_base + len + 2) begin
                $display("FAIL timeout waiting for \"%0s\"", text);
                errors = errors + 1;
            end else begin
                for (i = 0; i < len + 2; i = i + 1) begin
                    got  = rx_log[expect_base + i];
                    want = (i == len) ? 8'h0d : (i == len + 1) ? 8'h0a : text[8*(len-1-i) +: 8];
                    if (got !== want) begin
                        $display("FAIL \"%0s\" byte[%0d] got %02x want %02x", text, i, got, want);
                        errors = errors + 1;
                    end
                end
            end
            expect_base = expect_base + len + 2;
        end
    endtask

    // "BAD nn xx"：nn = index+1 两位十进制，xx = code 两位十六进制
    function [7:0] hexc;
        input [3:0] v;
        begin
            hexc = (v < 10) ? ("0" + v) : ("A" + v - 10);
        end
    endfunction
    task expect_bad;
        input [3:0] index;
        input [7:0] code;
        reg [8*9-1:0] t;
        reg [7:0] ones;
        integer n;
        begin
            n = index + 1;
            ones = 8'd48 + n % 10;
            t = {"BAD ", (n >= 10) ? "1" : "0", ones, " ",
                 hexc(code[7:4]), hexc(code[3:0])};
            expect_line(t, 9);
        end
    endtask

    // 场景结束：再等一会儿，不该有多余的字节
    task expect_quiet;
        input [8*4-1:0] name;
        begin
            repeat (2 * LINE) @(posedge clk);
            if (rx_count !== expect_base) begin
                $display("FAIL %0s: %0d unexpected byte(s)", name, rx_count - expect_base);
                errors = errors + 1;
                expect_base = rx_count;
            end
        end
    endtask

    task host_send_byte;
        input [7:0] value;
        integer i;
        begin
            @(negedge clk);
            host_tx = 1'b0;
            #(CPB * 10);
            for (i = 0; i < 8; i = i + 1) begin
                host_tx = value[i];
                #(CPB * 10);
            end
            host_tx = 1'b1;
            #(CPB * 10);
        end
    endtask

    task host_send_line;
        input [8*8-1:0] text;
        input integer   len;
        integer i;
        begin
            for (i = 0; i < len; i = i + 1)
                host_send_byte(text[8*(len-1-i) +: 8]);
            host_send_byte(8'h0d);
            host_send_byte(8'h0a);
        end
    endtask

    task pulse_bad;
        input [3:0] index;
        input [7:0] code;
        begin
            @(negedge clk);
            bad_valid = 1'b1; bad_index = index; bad_code = code;
            @(negedge clk);
            bad_valid = 1'b0;
        end
    endtask

    task restart;
        begin
            repeat (4 * LINE) @(posedge clk);
            @(negedge clk);
            rst_n = 1'b0;
            report_enable = 1'b0;
            error_code = 8'h00;
            repeat (10) @(posedge clk);
            @(negedge clk);
            rst_n = 1'b1;
            repeat (20) @(posedge clk);
            expect_base = rx_count;
        end
    endtask

    integer i;

    initial begin
        repeat (20) @(posedge clk);
        rst_n = 1'b1;
        repeat (20) @(posedge clk);

        // ---- A ----
        @(negedge clk);
        for (i = 0; i < 13; i = i + 1) begin
            bad_valid = 1'b1; bad_index = i; bad_code = 8'h31 + i;
            @(negedge clk);
        end
        bad_valid = 1'b0;
        repeat (LINE + LINE / 2) @(posedge clk);
        report_enable = 1'b1;                 // 第 2 行发送中
        repeat (LINE) @(posedge clk);
        error_code = 8'h70;                   // 第 3 行发送中
        for (i = 0; i < 13; i = i + 1)
            expect_bad(i, 8'h31 + i);
        expect_line("MEDIA PLAYER READY", 18);
        expect_line("ERR 70", 6);
        expect_quiet("A");
        if (errors == 0)
            $display("ok   A: 13 x BAD in order, banner after them, ERR 70 last");

        // ---- A2：补发 ----
        host_send_line("1", 1);
        expect_line("OK", 2);
        for (i = 0; i < 13; i = i + 1)
            expect_bad(i, 8'h31 + i);
        expect_line("MEDIA PLAYER READY", 18);
        expect_line("ERR 70", 6);
        expect_quiet("A2");
        if (errors == 0)
            $display("ok   A2: \"1\" -> OK + 13 x BAD + banner + ERR 70 again");

        // ---- B ----
        restart;
        fork
            begin
                pulse_bad(4'd1, 8'h34);
                pulse_bad(4'd4, 8'h35);
                pulse_bad(4'd12, 8'h39);
            end
            begin
                host_send_line("NEXT", 4);
            end
        join
        expect_bad(4'd1, 8'h34);
        expect_line("OK", 2);
        expect_bad(4'd4, 8'h35);
        expect_bad(4'd12, 8'h39);
        expect_quiet("B");
        if (errors == 0)
            $display("ok   B: command reply jumps the BAD queue");

        // ---- C ----
        restart;
        @(negedge clk);
        for (i = 0; i < 20; i = i + 1) begin
            bad_valid = 1'b1; bad_index = i % 16; bad_code = 8'h40 + i;
            @(negedge clk);
        end
        bad_valid = 1'b0;
        for (i = 0; i < 16; i = i + 1)
            expect_bad(i, 8'h40 + i);
        expect_quiet("C");
        if (errors == 0)
            $display("ok   C: record full at 16, newer events dropped");

        // ---- D：第 1 行还在发时收到 "1" ----
        restart;
        pulse_bad(4'd2, 8'h34);
        pulse_bad(4'd3, 8'h32);
        pulse_bad(4'd6, 8'h38);
        host_send_line("1", 1);               // 3 字节，第 1 行（11 字节）还没发完
        expect_bad(4'd2, 8'h34);
        expect_line("OK", 2);
        expect_bad(4'd3, 8'h32);
        expect_bad(4'd6, 8'h38);
        expect_bad(4'd2, 8'h34);
        expect_bad(4'd3, 8'h32);
        expect_bad(4'd6, 8'h38);
        expect_quiet("D");
        if (errors == 0)
            $display("ok   D: \"1\" mid-send -> OK, rest of queue, then full replay");

        // ---- E：什么都没有 ----
        restart;
        host_send_line("1", 1);
        expect_line("OK", 2);
        expect_quiet("E");
        if (errors == 0)
            $display("ok   E: nothing recorded -> just OK");

        if (errors == 0)
            $display("TEST_PASS bad_console");
        else
            $display("TEST_FAIL bad_console (%0d error(s))", errors);
        $finish;
    end

    initial begin
        #(200_000_000);
        $display("TEST_FAIL bad_console global timeout");
        $finish;
    end
endmodule
