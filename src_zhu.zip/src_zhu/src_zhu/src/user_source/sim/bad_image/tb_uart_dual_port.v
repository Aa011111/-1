`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// uart_dual_port 自检：vsim -c -do run_dual.do
//   1. 口 B 从上电起就被拉死在低（板载 USB 串口芯片没上电）-> 口 A 发的字节照收，
//      没有帧错，合并后的线上不冒假字节
//   2. 口 B 放开（芯片上电）-> 接上以后口 B 发的字节照收
//   3. 口 A 运行中被拉死在低 -> 一段时间后屏蔽，之后口 B 照常收
//   4. 两个口都空闲 -> 什么都收不到
//   5. TX 同时出现在两个脚上
// CLKS_PER_BIT 压到 16。只是功能闭环，不是时序验证。
// -----------------------------------------------------------------------------
module tb_uart_dual_port;
    localparam integer CPB = 16;
    localparam integer BIT_NS = CPB * 10;

    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    integer errors = 0;

    reg  rxd_a = 1'b1;
    reg  rxd_b = 1'b0;          // 1：口 B 一上电就被拉死在低
    reg  txd = 1'b1;
    wire rxd, txd_a, txd_b;

    uart_dual_port #(.CLKS_PER_BIT(CPB)) dut (
        .clk(clk), .rst_n(rst_n),
        .rxd_a(rxd_a), .rxd_b(rxd_b), .rxd(rxd),
        .txd(txd), .txd_a(txd_a), .txd_b(txd_b)
    );

    wire [7:0] rx_data;
    wire       rx_valid, rx_ferr;
    uart_rx_byte #(.CLKS_PER_BIT(CPB)) u_rx (
        .clk(clk), .rst_n(rst_n), .rx(rxd),
        .data(rx_data), .valid(rx_valid), .framing_error(rx_ferr)
    );

    reg [7:0] got [0:63];
    integer   n_got = 0;
    integer   n_ferr = 0;
    always @(posedge clk) begin
        if (rx_valid) begin
            got[n_got] = rx_data;
            n_got = n_got + 1;
        end
        if (rx_ferr)
            n_ferr = n_ferr + 1;
    end

    task send_a;
        input [7:0] v;
        integer i;
        begin
            rxd_a = 1'b0; #(BIT_NS);
            for (i = 0; i < 8; i = i + 1) begin rxd_a = v[i]; #(BIT_NS); end
            rxd_a = 1'b1; #(BIT_NS * 2);
        end
    endtask

    task send_b;
        input [7:0] v;
        integer i;
        begin
            rxd_b = 1'b0; #(BIT_NS);
            for (i = 0; i < 8; i = i + 1) begin rxd_b = v[i]; #(BIT_NS); end
            rxd_b = 1'b1; #(BIT_NS * 2);
        end
    endtask

    task check;
        input [8*40-1:0] what;
        input            ok;
        begin
            if (ok)
                $display("ok   %0s", what);
            else begin
                $display("FAIL %0s", what);
                errors = errors + 1;
            end
        end
    endtask

    integer i, base;
    reg [7:0] msg [0:3];
    initial begin
        msg[0] = "1"; msg[1] = 8'h0d; msg[2] = 8'h0a; msg[3] = 8'h00;
        #(200);
        rst_n = 1'b1;
        #(BIT_NS * 40);

        // ---- 1 ----
        check("1 stuck-low B: no bytes while idle", n_got == 0 && n_ferr == 0);
        for (i = 0; i < 4; i = i + 1)
            send_a(msg[i]);
        #(BIT_NS * 4);
        check("1 stuck-low B: A bytes received", n_got == 4 && got[0] == "1" &&
              got[1] == 8'h0d && got[2] == 8'h0a && got[3] == 8'h00);
        check("1 stuck-low B: no framing error", n_ferr == 0);

        // ---- 2 ----
        rxd_b = 1'b1;
        #(BIT_NS * 4);                       // 接上要先见 2 位高电平
        base = n_got;
        send_b(8'h55);
        send_b(8'ha3);
        #(BIT_NS * 4);
        check("2 B released: B bytes received", n_got == base + 2 &&
              got[base] == 8'h55 && got[base + 1] == 8'ha3);
        check("2 B released: no framing error", n_ferr == 0);

        // ---- 3 ----
        rxd_a = 1'b0;                        // A 运行中被拉死
        #(BIT_NS * 40);                      // 超过 20 位就屏蔽
        base = n_got;
        send_b(8'h31);
        send_b(8'h0d);
        #(BIT_NS * 4);
        check("3 A dies: B still received", n_got == base + 2 &&
              got[base] == 8'h31 && got[base + 1] == 8'h0d);

        // ---- 4 ----
        rxd_a = 1'b1;
        base = n_got;
        #(BIT_NS * 100);
        check("4 both idle: nothing received", n_got == base);

        // ---- 5 ----
        txd = 1'b0; #(20);
        check("5 tx low on both pins", txd_a == 1'b0 && txd_b == 1'b0);
        txd = 1'b1; #(20);
        check("5 tx high on both pins", txd_a == 1'b1 && txd_b == 1'b1);

        if (errors == 0)
            $display("TEST_PASS uart_dual_port");
        else
            $display("TEST_FAIL uart_dual_port (%0d error(s))", errors);
        $finish;
    end
endmodule
