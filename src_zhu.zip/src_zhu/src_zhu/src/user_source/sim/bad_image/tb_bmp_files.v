`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 卡上图片预检：把 files/ 下的 PIC1~13.BMP 逐个喂给 bmp24_decoder（参数同顶层：
// 640x480，ALLOW_2X_SOURCE=1，ALLOW_SCALE_SOURCE=1，MAX_SOURCE_DIM=4096），
// 打印每张的结果：正常（307200 像素 + frame_commit），还是串口会报的 BAD 行。
//   先把要测的 BMP 拷到 sim/bad_image/files/，再 vsim -c -do run_files.do
// 字节按 1 字节/拍连续喂（同 sd_sector_replay_buffer 的重放节奏），
// file_size = 文件长度（= FAT 目录项里的大小）。
// 只覆盖解码器这一级；FAT/SD/loader/串口见 run_ingest.do。读卡超时（0x39）
// 和 SDRAM 写侧故障在这里看不出来。
// +DUMP：每张的输出像素按流顺序写到 files/outN.txt（一行一个 RRGGBB）。
// -----------------------------------------------------------------------------
module tb_bmp_files;
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;

    reg        file_start = 1'b0;
    reg [31:0] file_size = 32'd0;
    reg        file_valid = 1'b0;
    reg [7:0]  file_byte = 8'd0;
    reg [31:0] file_byte_offset = 32'd0;
    reg        file_end = 1'b0;

    wire        pixel_valid, frame_commit;
    wire [23:0] pixel_rgb;
    wire [7:0]  bmp_error;

    bmp24_decoder #(
        .EXPECTED_WIDTH(640), .EXPECTED_HEIGHT(480), .ALLOW_2X_SOURCE(1),
        .ALLOW_SCALE_SOURCE(1), .MAX_SOURCE_DIM(4096)
    ) dut (
        .clk(clk), .rst_n(rst_n), .file_start(file_start), .file_size(file_size),
        .file_valid(file_valid), .file_byte(file_byte), .file_byte_offset(file_byte_offset),
        .file_end(file_end), .upstream_error(8'h00), .header_accepted(),
        .pixel_valid(pixel_valid), .pixel_rgb(pixel_rgb), .pixel_x(), .pixel_y(),
        .frame_commit(frame_commit), .bmp_done(), .bmp_error(bmp_error),
        .top_down(), .pixel_offset(), .row_stride(), .source_scale_2x()
    );

    integer pixels = 0;
    integer dump_fd = 0;
    reg     committed = 1'b0;
    always @(posedge clk) begin
        if (pixel_valid) begin
            pixels = pixels + 1;
            if (dump_fd != 0)
                $fdisplay(dump_fd, "%06x", pixel_rgb);
        end
        if (frame_commit)
            committed = 1'b1;
    end

    integer k, i, fd, size, c, found, dump_on;
    reg [8*32-1:0] path;
    initial begin
        dump_on = $test$plusargs("DUMP");
        found = 0;
        repeat (5) @(posedge clk);
        rst_n = 1'b1;
        for (k = 1; k <= 13; k = k + 1) begin
            $sformat(path, "files/PIC%0d.BMP", k);
            fd = $fopen(path, "rb");
            if (fd != 0) begin
                found = found + 1;
                c = $fseek(fd, 0, 2);
                size = $ftell(fd);
                c = $fseek(fd, 0, 0);
                pixels = 0;
                committed = 1'b0;
                if (dump_on) begin
                    $sformat(path, "files/out%0d.txt", k);
                    dump_fd = $fopen(path, "w");
                end
                @(negedge clk);
                file_size  = size;
                file_start = 1'b1;
                @(negedge clk);
                file_start = 1'b0;
                for (i = 0; i < size; i = i + 1) begin
                    c = $fgetc(fd);
                    file_valid       = 1'b1;
                    file_byte        = c[7:0];
                    file_byte_offset = i;
                    @(negedge clk);
                end
                file_valid = 1'b0;
                repeat (3) @(negedge clk);
                file_end = 1'b1;
                @(negedge clk);
                file_end = 1'b0;
                repeat (3) @(negedge clk);
                $fclose(fd);
                if (dump_fd != 0) begin
                    $fclose(dump_fd);
                    dump_fd = 0;
                end
                if (bmp_error == 8'h00 && committed && pixels == 640 * 480)
                    $display("PIC%0d.BMP %8d bytes  OK   %0d pixels, frame_commit", k, size, pixels);
                else
                    $display("PIC%0d.BMP %8d bytes  BAD %0d%0d %x  (%0d pixels)",
                             k, size, k / 10, k % 10, bmp_error, pixels);
            end
        end
        if (found == 0)
            $display("no files/PIC*.BMP found");
        $finish;
    end
endmodule
