# 坏图明细队列 + reporter 定向自检：vsim -c -do run.do
# 整链路（SD 卡模型 -> 摄入 -> loader -> BAD 行）见 run_ingest.do
if {[file exists work]} { vdel -lib work -all }
vlib work
foreach f {uart_rx_byte uart_tx_byte uart_line_parser uart_command_engine uart_response_tx uart_status_reporter uart_cmd_core media_uart_console} {
    vlog -quiet ../../hdl_source/uart/$f.v
}
vlog -quiet tb_bad_console.v
vsim -quiet -c tb_bad_console
run -all
quit -f
