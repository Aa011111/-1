# 卡上图片预检：先把 PIC1~13.BMP 拷到 files/，再 vsim -c -do run_files.do
# 输出每张会不会显示、不显示的话串口报哪一行 BAD
if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -quiet ../../hdl_source/stable/bmp24_decoder.v
vlog -quiet tb_bmp_files.v
# 3534 = 打不开文件（没放进 files/ 的那几张），不算错
vsim -quiet -c -suppress 3534 tb_bmp_files
run -all
quit -f
