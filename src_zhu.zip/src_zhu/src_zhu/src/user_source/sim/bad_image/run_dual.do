# 双串口口合并（J2 排针 + 板载 USB 串口）自检：vsim -c -do run_dual.do
if {[file exists work]} { vdel -lib work -all }
vlib work
foreach f {uart_rx_byte uart_tx_byte uart_line_parser uart_command_engine uart_response_tx uart_status_reporter uart_cmd_core media_uart_console} {
    vlog -quiet ../../hdl_source/uart/$f.v
}
vlog -quiet tb_uart_dual_port.v
vsim -quiet -c tb_uart_dual_port
run -all
quit -f
