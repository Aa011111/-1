# 坏图整链路回归（SD 卡模型 -> 摄入 -> loader -> BAD 行）：vsim -c -do run_ingest.do
if {[file exists work]} { vdel -lib work -all }
vlib work
foreach f {sd_spi_byte_engine sd_spi_command sd_spi_init sd_spi_sector_reader sd_media_service sd_sector_replay_buffer fat32_volume_scanner fat32_file_streamer fat32_storage_ingest_top} {
    vlog -quiet ../../hdl_source/fat32/$f.v
}
vlog -quiet ../../hdl_source/stable/bmp24_decoder.v
vlog -quiet ../../hdl_source/framebuf4bank/media_frame_loader.v
foreach f {uart_rx_byte uart_tx_byte uart_line_parser uart_command_engine uart_response_tx uart_status_reporter uart_cmd_core media_uart_console} {
    vlog -quiet ../../hdl_source/uart/$f.v
}
vlog -quiet sd_spi_card_model.v
vlog -quiet +define+BADLOG tb_bad_ingest.v
vsim -quiet -c tb_bad_ingest
run -all
quit -f
