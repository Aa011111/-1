`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// SPI 模式 SD 卡行为模型（SDHC，块寻址），给 fat32_storage_ingest_top 整链路仿真用。
//
// 只实现 sd_spi_init / sd_spi_sector_reader 用到的命令：
//   CMD0 -> R1=01；CMD8 -> R1=01 + R7 回显 1AA；CMD55 -> R1={空闲位}；
//   ACMD41 -> R1=00（一次就绪）；CMD58 -> R1=00 + OCR C0FF8000（上电完成 + CCS）；
//   CMD17 -> R1=00、TOKEN_DELAY 个 FF、FE、512 字节、CRC16；其余命令回 R1=04。
// 每条应答前垫 1 个 FF（NCR=1）。
//
// 时序按 SPI 模式 0：上升沿采 MOSI，下降沿换 MISO；CS 拉高时复位位计数、
// 丢掉正在进行的应答。扇区内容由外部组合给出：模型提前一个字节把
// rd_lba/rd_index 摆好，到字节边界才取 rd_data（同一时刻组合回读会拿到旧值）。
// rd_crc_corrupt=1 时这一扇区回错误的 CRC16，用来造扇区读错。
// -----------------------------------------------------------------------------
module sd_spi_card_model #(
    parameter integer TOKEN_DELAY = 3
) (
    input  wire        cs_n,
    input  wire        sclk,
    input  wire        mosi,
    output wire        miso,
    output reg  [31:0] rd_lba,
    output reg  [8:0]  rd_index,
    input  wire [7:0]  rd_data,
    input  wire        rd_crc_corrupt
);
    localparam [1:0] M_IDLE = 2'd0;
    localparam [1:0] M_RESP = 2'd1;
    localparam [1:0] M_READ = 2'd2;

    reg [7:0]  rx_sr;
    reg [2:0]  bit_cnt;
    reg [7:0]  tx_sr;
    reg [47:0] cmd_buf;
    reg [2:0]  cmd_bytes;
    reg        idle_state;
    reg        app_cmd;
    reg [1:0]  mode;
    reg [7:0]  resp [0:7];
    reg [3:0]  resp_len;
    reg [3:0]  resp_ptr;
    integer    rd_pos;          // CMD17 应答里的字节序号
    reg [15:0] crc;
    reg        crc_bad;

    assign miso = cs_n ? 1'b1 : tx_sr[7];

    function [15:0] crc16_byte;
        input [15:0] crc_in;
        input [7:0]  data_in;
        integer i;
        reg [15:0] c;
        begin
            c = crc_in;
            for (i = 0; i < 8; i = i + 1) begin
                if (c[15] ^ data_in[7-i])
                    c = {c[14:0], 1'b0} ^ 16'h1021;
                else
                    c = {c[14:0], 1'b0};
            end
            crc16_byte = c;
        end
    endfunction

    task set_resp2;
        input [7:0] r1;
        begin
            resp[0] = 8'hff; resp[1] = r1; resp_len = 4'd2; resp_ptr = 4'd0;
            mode = M_RESP;
        end
    endtask

    task execute_command;
        reg [5:0]  idx;
        reg [31:0] arg;
        begin
            idx = cmd_buf[45:40];
            arg = cmd_buf[39:8];
            if (app_cmd && idx == 6'd41) begin
                app_cmd = 1'b0;
                idle_state = 1'b0;
                set_resp2(8'h00);
            end else begin
                app_cmd = 1'b0;
                case (idx)
                    6'd0: begin
                        idle_state = 1'b1;
                        set_resp2(8'h01);
                    end
                    6'd8: begin
                        resp[0] = 8'hff; resp[1] = {7'd0, idle_state};
                        resp[2] = 8'h00; resp[3] = 8'h00;
                        resp[4] = {4'd0, arg[11:8]}; resp[5] = arg[7:0];
                        resp_len = 4'd6; resp_ptr = 4'd0; mode = M_RESP;
                    end
                    6'd55: begin
                        app_cmd = 1'b1;
                        set_resp2({7'd0, idle_state});
                    end
                    6'd58: begin
                        resp[0] = 8'hff; resp[1] = {7'd0, idle_state};
                        resp[2] = 8'hc0; resp[3] = 8'hff; resp[4] = 8'h80; resp[5] = 8'h00;
                        resp_len = 4'd6; resp_ptr = 4'd0; mode = M_RESP;
                    end
                    6'd17: begin
                        rd_lba   <= arg;
                        rd_index <= 9'd0;
                        rd_pos   = 0;
                        crc      = 16'd0;
                        mode     = M_READ;
                    end
                    default: set_resp2(8'h04);
                endcase
            end
        end
    endtask

    // 下一个要从 MISO 发出去的字节
    task next_out_byte;
        output [7:0] b;
        begin
            b = 8'hff;
            case (mode)
                M_RESP: begin
                    b = resp[resp_ptr];
                    resp_ptr = resp_ptr + 1'b1;
                    if (resp_ptr == resp_len)
                        mode = M_IDLE;
                end
                M_READ: begin
                    if (rd_pos == 0)
                        b = 8'hff;                          // NCR
                    else if (rd_pos == 1)
                        b = 8'h00;                          // R1
                    else if (rd_pos < 2 + TOKEN_DELAY)
                        b = 8'hff;
                    else if (rd_pos == 2 + TOKEN_DELAY) begin
                        b = 8'hfe;                          // 数据令牌
                        crc_bad = rd_crc_corrupt;
                    end else if (rd_pos < 3 + TOKEN_DELAY + 512) begin
                        b = rd_data;
                        crc = crc16_byte(crc, rd_data);
                        rd_index <= rd_index + 1'b1;        // 下一个字节提前摆好
                    end else if (rd_pos == 3 + TOKEN_DELAY + 512)
                        b = crc_bad ? ~crc[15:8] : crc[15:8];
                    else begin
                        b = crc[7:0];
                        mode = M_IDLE;
                    end
                    rd_pos = rd_pos + 1;
                end
                default: b = 8'hff;
            endcase
        end
    endtask

    initial begin
        rx_sr = 8'hff; bit_cnt = 3'd0; tx_sr = 8'hff; cmd_buf = 48'd0; cmd_bytes = 3'd0;
        idle_state = 1'b1; app_cmd = 1'b0; mode = M_IDLE; resp_len = 4'd0; resp_ptr = 4'd0;
        rd_pos = 0; crc = 16'd0; crc_bad = 1'b0; rd_lba = 32'd0; rd_index = 9'd0;
    end

    // 上升沿收字节；CS 拉高复位
    always @(posedge sclk or posedge cs_n) begin
        if (cs_n) begin
            bit_cnt   = 3'd0;
            cmd_bytes = 3'd0;
            mode      = M_IDLE;
        end else begin
            rx_sr   = {rx_sr[6:0], mosi};
            bit_cnt = bit_cnt + 1'b1;
            if (bit_cnt == 3'd0) begin                      // 凑满一个字节
                if (cmd_bytes == 3'd0) begin
                    if (rx_sr[7:6] == 2'b01) begin
                        cmd_buf   = {rx_sr, 40'd0};
                        cmd_bytes = 3'd1;
                    end
                end else begin
                    cmd_buf[47 - 8*cmd_bytes -: 8] = rx_sr;
                    cmd_bytes = cmd_bytes + 1'b1;
                    if (cmd_bytes == 3'd6) begin
                        cmd_bytes = 3'd0;
                        execute_command;
                    end
                end
            end
        end
    end

    // 下降沿换 MISO：字节边界装下一个字节，字节内左移
    reg [7:0] nb;
    always @(negedge sclk or posedge cs_n) begin
        if (cs_n)
            tx_sr <= 8'hff;
        else if (bit_cnt == 3'd0) begin
            next_out_byte(nb);
            tx_sr <= nb;
        end else
            tx_sr <= {tx_sr[6:0], 1'b1};
    end
endmodule
