`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 坏图整链路回归：vsim -c -do run_ingest.do
//   SPI SD 卡模型 -> fat32_storage_ingest_top -> media_frame_loader
//   （+BADLOG 时再接 bad_image_capture -> media_uart_console，检查串口输出）
//
// 卡上 13 张 16x12 的 24 位 BMP（每张 630 字节，两个扇区），好坏交替：
//   PIC1 好   PIC2 16 位色(34)   PIC3 好   PIC4 签名 "BX"(31)   PIC5 好
//   PIC6 数据扇区 CRC 错 -> 读文件出错(38)   PIC7 好   PIC8 缺
//   PIC9 64KB 长文件，读不完 -> 单张 watchdog(39)   PIC10 压缩(35)   PIC11 缺
//   PIC12 好（前面隔着缺的 PIC11，紧挨着的是坏图 PIC10）   PIC13 宽 15(32)
// 期望：loader 只有 PIC1/3/5/7/12 装好（坏图不能连带后面那张好图）；
//       串口按顺序打 BAD 02 34 / 04 31 / 06 38 / 09 39 / 10 35 / 13 32，
//       然后才是 MEDIA PLAYER READY（摄入结束时 BAD 行还在排队，banner 不能丢）。
//       之后电脑从板载 USB 口发 "1" -> OK + 上面 7 行原样再来一遍。
//       串口经 uart_dual_port 接两个口（同顶层）：口 A（J2）空闲，电脑在口 B（USB），
//       输出在口 B 的 TX 脚上看。
// 只是功能闭环，不是时序验证。
// -----------------------------------------------------------------------------
module tb_bad_ingest;
    localparam integer W = 16, H = 12, PIX = W * H;   // 4:3，bmp24_decoder 通用路径按 4:3 居中裁
    localparam integer IMG_BYTES = 48 * H;               // 行跨度 48 字节
    localparam integer FILE_SIZE = 54 + IMG_BYTES;       // 630，跨两个扇区
    localparam integer DATA_START = 2032;                // VBR: rsvd 32 + 2 FAT x 1000
    localparam integer LONG_CLUSTER = 100;               // PIC9：簇 100~115，连续 16 簇
    localparam integer LONG_SIZE = 65536;
    localparam integer CRC_BAD_LBA = DATA_START + 6 * 8; // PIC6 的数据扇区
    localparam integer WATCHDOG = 1_000_000;             // 正常一张图约 4 万拍
    localparam integer CPB = 2000;                       // 串口放慢，让 BAD 行排队
    localparam [12:0]  NAV_MASK = 13'b0_0111_1111_1111;
    localparam [12:0]  EXPECT_COMPLETE = 13'b0_1000_0101_0101;  // PIC1/3/5/7/12

    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;
    integer errors = 0;

    // ---------------- 卡镜像 ----------------
    function [7:0] bmp_byte;
        input integer k;              // 图片序号 0~12
        input integer i;              // 文件内偏移
        begin
            bmp_byte = 8'h00;
            case (i)
                0:  bmp_byte = "B";
                1:  bmp_byte = (k == 3) ? "X" : "M";
                2:  bmp_byte = FILE_SIZE[7:0];
                3:  bmp_byte = FILE_SIZE[15:8];
                10: bmp_byte = 8'd54;
                14: bmp_byte = 8'd40;
                18: bmp_byte = (k == 12) ? 8'd15 : W[7:0];
                22: bmp_byte = H[7:0];
                26: bmp_byte = 8'd1;
                28: bmp_byte = (k == 1) ? 8'd16 : 8'd24;
                30: bmp_byte = (k == 9) ? 8'd1 : 8'd0;
                34: bmp_byte = IMG_BYTES[7:0];
                35: bmp_byte = IMG_BYTES[15:8];
                default: if (i >= 54 && i < FILE_SIZE) bmp_byte = i * 7 + k * 31;
            endcase
        end
    endfunction

    function present;
        input integer k;
        begin
            present = (k != 7) && (k != 10);
        end
    endfunction

    function [31:0] first_cluster;
        input integer k;
        begin
            first_cluster = (k == 8) ? LONG_CLUSTER : 3 + k;
        end
    endfunction

    function [7:0] dir_byte;
        input integer i;
        integer k, off, n;
        reg [31:0] clu, sz;
        begin
            k = i / 32; off = i % 32; n = k + 1;
            clu = first_cluster(k);
            sz  = (k == 8) ? LONG_SIZE : FILE_SIZE;
            dir_byte = 8'h00;
            if (k < 13 && present(k)) begin
                case (off)
                    0: dir_byte = "P";
                    1: dir_byte = "I";
                    2: dir_byte = "C";
                    3: dir_byte = (n < 10) ? ("0" + n) : "1";
                    4: dir_byte = (n < 10) ? " " : ("0" + n - 10);
                    5, 6, 7: dir_byte = " ";
                    8: dir_byte = "B";
                    9: dir_byte = "M";
                    10: dir_byte = "P";
                    11: dir_byte = 8'h20;
                    26: dir_byte = clu[7:0];
                    27: dir_byte = clu[15:8];
                    28: dir_byte = sz[7:0];
                    29: dir_byte = sz[15:8];
                    30: dir_byte = sz[23:16];
                    31: dir_byte = sz[31:24];
                    default: dir_byte = 8'h00;
                endcase
            end
        end
    endfunction

    // FAT 第 0 扇区：PIC9 的簇链 100->101->...->115->EOC，其余全 EOC
    function [7:0] fat_byte;
        input integer i;
        integer c;
        reg [31:0] v;
        begin
            c = i / 4;
            v = (c >= LONG_CLUSTER && c < LONG_CLUSTER + 15) ? c + 1 : 32'h0fffffff;
            fat_byte = v[(i % 4) * 8 +: 8];
        end
    endfunction

    function [7:0] card_byte;
        input [31:0] lba;
        input [8:0]  i;
        integer k, base;
        begin
            card_byte = 8'h00;
            if (lba == 0) begin
                case (i)
                    0: card_byte = 8'heb; 12: card_byte = 8'h02; 13: card_byte = 8'd8;
                    14: card_byte = 8'd32; 16: card_byte = 8'd2;
                    34: card_byte = 8'h10;
                    36: card_byte = 8'he8; 37: card_byte = 8'h03;
                    44: card_byte = 8'd2;
                    510: card_byte = 8'h55; 511: card_byte = 8'haa;
                    default: card_byte = 8'h00;
                endcase
            end else if (lba == 32) begin
                card_byte = fat_byte(i);
            end else if (lba == DATA_START) begin
                card_byte = dir_byte(i);
            end else begin
                // 文件 k 从首簇的第一个扇区起连续存放；PIC9 占 16 簇，其余一簇
                for (k = 0; k < 13; k = k + 1) begin
                    base = DATA_START + (first_cluster(k) - 2) * 8;
                    if (lba >= base && lba < base + ((k == 8) ? 128 : 8))
                        card_byte = bmp_byte(k, (lba - base) * 512 + i);
                end
            end
        end
    endfunction

    wire        sd_ncs, sd_dclk, sd_mosi, sd_miso;
    wire [31:0] card_lba;
    wire [8:0]  card_index;
    wire [7:0]  card_data = card_byte(card_lba, card_index);

    sd_spi_card_model #(.TOKEN_DELAY(3)) u_card (
        .cs_n(sd_ncs), .sclk(sd_dclk), .mosi(sd_mosi), .miso(sd_miso),
        .rd_lba(card_lba), .rd_index(card_index), .rd_data(card_data),
        .rd_crc_corrupt(card_lba == CRC_BAD_LBA)
    );

    // ---------------- 摄入 + loader（接法照 top_tf_hdmi_audio.v）----------------
    reg         ingest_kicked;
    wire        ingest_start = ~ingest_kicked;
    wire        ingest_done;
    wire [12:0] resource_valid;
    wire [7:0]  ingest_diag_code;
    wire        load_start, load_busy, load_done;
    wire [3:0]  image_index;
    wire        pixel_valid, frame_commit;
    wire [23:0] pixel_rgb;
    wire [7:0]  decode_error, memory_error;
    wire [12:0] image_complete;

    always @(posedge clk or negedge rst_n)
        if (!rst_n) ingest_kicked <= 1'b0;
        else        ingest_kicked <= 1'b1;

    fat32_storage_ingest_top #(
        .INIT_SPI_CLK_DIV(2), .READ_SPI_CLK_DIV(2),
        .BMP_WIDTH(W), .BMP_HEIGHT(H),
        .INIT_STARTUP_DELAY_CYCLES(100),
        .IMAGE_TIMEOUT_CYCLES(WATCHDOG),
        .ALLOW_2X_SOURCE(0), .ALLOW_SCALE_SOURCE(0), .MAX_SOURCE_DIM(4096),
        .IMAGE_COUNT(13), .INDEX_W(4)
    ) u_ingest (
        .clk(clk), .rst_n(rst_n), .start(ingest_start), .busy(),
        .ingest_done(ingest_done), .card_ready(), .resource_valid(resource_valid),
        .image_complete(), .diag_code(ingest_diag_code), .diag2_code(),
        .sd_ncs(sd_ncs), .sd_dclk(sd_dclk), .sd_mosi(sd_mosi), .sd_miso(sd_miso),
        .cdc_idle(1'b1),
        .load_start(load_start), .load_busy(load_busy), .load_done(load_done),
        .image_index(image_index), .pixel_valid(pixel_valid), .pixel_rgb(pixel_rgb),
        .frame_commit(frame_commit), .decode_error(decode_error),
        .track_valid(), .track_start_lba(), .track_sectors(),
        .ext_ready(), .ext_sector_req(1'b0), .ext_sector_lba(32'd0),
        .ext_sector_busy(), .ext_sector_done(), .ext_sector_valid(),
        .ext_sector_byte(), .ext_sector_byte_index(), .ext_sector_error()
    );

    media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(64), .BURST_SIZE(16),
        .STALL_TIMEOUT(65535), .V_FLIP(0), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(0), .IMAGE_COUNT(13), .INDEX_W(4)
    ) u_loader (
        .clk(clk), .rst_n(rst_n), .load_start(load_start), .image_index(image_index),
        .pixel_valid(pixel_valid), .pixel_rgb(pixel_rgb), .frame_commit(frame_commit),
        .decode_error(decode_error), .load_busy(load_busy), .load_done(load_done),
        .image_complete(image_complete), .memory_error(memory_error),
        .controller_init_done(1'b1), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(), .app_wr_addr(), .app_wr_mask(), .app_wr_data()
    );

    // 顶层的 ingest_finished / display_valid / ingest_failed（同拍寄存）
    reg ingest_finished, display_valid, ingest_failed;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            ingest_finished <= 1'b0;
            display_valid   <= 1'b0;
            ingest_failed   <= 1'b0;
        end else begin
            if (ingest_done)
                ingest_finished <= 1'b1;
            display_valid <= ingest_finished &&  ((image_complete & NAV_MASK) != 0);
            ingest_failed <= ingest_finished && !((image_complete & NAV_MASK) != 0);
        end
    end

    // 每张图 loader 的收尾结果（只做日志）
    reg [3:0] log_index;
    always @(posedge clk) begin
        if (load_start)
            log_index <= image_index;
        if (load_done)
            $display("[%0t] load_done PIC%0d memory_error=%02x", $time, log_index + 1, memory_error);
    end

`ifdef BADLOG
    // ---------------- 坏图明细 -> 串口 ----------------
    wire       bad_valid;
    wire [3:0] bad_index;
    wire [7:0] bad_code;
    bad_image_capture #(.INDEX_W(4)) u_capture (
        .clk(clk), .rst_n(rst_n),
        .load_start(load_start), .image_index(image_index), .decode_error(decode_error),
        .load_busy(load_busy), .load_done(load_done), .memory_error(memory_error),
        .bad_valid(bad_valid), .bad_index(bad_index), .bad_code(bad_code)
    );

    // 口 A = J2（空闲），口 B = 板载 USB 串口（电脑），接法同顶层
    reg  usb_host_tx = 1'b1;
    wire console_rxd, console_txd, j2_txd, usb_txd;
    uart_dual_port #(.CLKS_PER_BIT(CPB)) u_dual (
        .clk(clk), .rst_n(rst_n),
        .rxd_a(1'b1), .rxd_b(usb_host_tx), .rxd(console_rxd),
        .txd(console_txd), .txd_a(j2_txd), .txd_b(usb_txd)
    );

    media_uart_console #(
        .CLKS_PER_BIT(CPB), .INDEX_W(4), .FOCUS_COUNT(11)
    ) u_console (
        .clk(clk), .rst_n(rst_n), .uart_rxd(console_rxd), .uart_txd(console_txd),
        .report_enable(display_valid), .media_id(4'd0), .auto_enabled(1'b0),
        .error_code(ingest_failed ? 8'h70 : 8'h00),
        .bad_valid(bad_valid), .bad_index(bad_index), .bad_code(bad_code),
        .next_event(), .prev_event(), .auto_cfg_valid(), .auto_cfg_enabled(),
        .period_cfg_valid(), .period_cfg_cycles(), .volume(), .brightness(),
        .thumb_cfg_valid(), .thumb_cfg_enabled(), .select_event(),
        .focus_cfg_valid(), .focus_cfg_index(),
        .contrast(), .bright_cfg_valid(), .contrast_cfg_valid(),
        .key_bright_event(1'b0), .key_bright_value(8'h00),
        .key_contrast_event(1'b0), .key_contrast_value(8'h00),
        .vis_cfg(), .diag_code()
    );

    wire [7:0] mon_data;
    wire       mon_valid;
    uart_rx_byte #(.CLKS_PER_BIT(CPB)) u_monitor (
        .clk(clk), .rst_n(rst_n), .rx(usb_txd),
        .data(mon_data), .valid(mon_valid), .framing_error()
    );

    task usb_send_byte;
        input [7:0] value;
        integer i;
        begin
            @(negedge clk);
            usb_host_tx = 1'b0;
            #(CPB * 10);
            for (i = 0; i < 8; i = i + 1) begin
                usb_host_tx = value[i];
                #(CPB * 10);
            end
            usb_host_tx = 1'b1;
            #(CPB * 10);
        end
    endtask

    reg [7:0] rx_log [0:255];
    integer   rx_count = 0;
    integer   expect_base = 0;
    reg [8*40-1:0] line_buf = 0;
    always @(posedge clk)
        if (mon_valid) begin
            rx_log[rx_count] = mon_data;
            rx_count = rx_count + 1;
            if (mon_data == 8'h0a) begin
                $display("[%0t] UART: %0s", $time, line_buf);
                line_buf = 0;
            end else if (mon_data != 8'h0d)
                line_buf = {line_buf[8*39-1:0], mon_data};
        end

    task expect_line;
        input [8*20-1:0] text;
        input integer    len;
        integer i, guard;
        reg [7:0] got, want;
        begin
            guard = 0;
            while (rx_count < expect_base + len + 2 && guard < 8_000_000) begin
                @(posedge clk);
                guard = guard + 1;
            end
            if (rx_count < expect_base + len + 2) begin
                $display("FAIL timeout waiting for \"%0s\"", text);
                errors = errors + 1;
            end else begin
                for (i = 0; i < len + 2; i = i + 1) begin
                    got  = rx_log[expect_base + i];
                    want = (i == len) ? 8'h0d : (i == len + 1) ? 8'h0a : text[8*(len-1-i) +: 8];
                    if (got !== want) begin
                        $display("FAIL \"%0s\" byte[%0d] got %02x want %02x", text, i, got, want);
                        errors = errors + 1;
                    end
                end
            end
            expect_base = expect_base + len + 2;
        end
    endtask
`endif

    initial begin
        repeat (20) @(posedge clk);
        rst_n = 1'b1;

        wait (ingest_finished === 1'b1);
        repeat (10) @(posedge clk);
        $display("resource_valid = %013b", resource_valid);
        $display("image_complete = %013b (expect %013b)", image_complete, EXPECT_COMPLETE);
        if (image_complete !== EXPECT_COMPLETE) begin
            $display("FAIL image_complete mismatch");
            errors = errors + 1;
        end

`ifdef BADLOG
        expect_line("BAD 02 34", 9);
        expect_line("BAD 04 31", 9);
        expect_line("BAD 06 38", 9);
        expect_line("BAD 09 39", 9);
        expect_line("BAD 10 35", 9);
        expect_line("BAD 13 32", 9);
        expect_line("MEDIA PLAYER READY", 18);
        repeat (40 * CPB) @(posedge clk);
        if (rx_count !== expect_base) begin
            $display("FAIL %0d unexpected byte(s) after banner", rx_count - expect_base);
            errors = errors + 1;
        end

        // 串口助手晚打开：从 USB 口发 "1"，全部补发一遍
        $display("[%0t] host sends \"1\" on USB port", $time);
        usb_send_byte("1");
        usb_send_byte(8'h0d);
        usb_send_byte(8'h0a);
        expect_line("OK", 2);
        expect_line("BAD 02 34", 9);
        expect_line("BAD 04 31", 9);
        expect_line("BAD 06 38", 9);
        expect_line("BAD 09 39", 9);
        expect_line("BAD 10 35", 9);
        expect_line("BAD 13 32", 9);
        expect_line("MEDIA PLAYER READY", 18);
        repeat (40 * CPB) @(posedge clk);
        if (rx_count !== expect_base) begin
            $display("FAIL %0d unexpected byte(s) after replay", rx_count - expect_base);
            errors = errors + 1;
        end
`endif

        if (errors == 0)
            $display("TEST_PASS bad_ingest");
        else
            $display("TEST_FAIL bad_ingest (%0d error(s))", errors);
        $finish;
    end

    initial begin
        #(120_000_000);
        $display("TEST_FAIL bad_ingest global timeout");
        $finish;
    end
endmodule
