# 13 张图回归：vsim -c -do run.do
if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -quiet ../../hdl_source/framebuf4bank/media_frame_loader.v
vlog -quiet ../../hdl_source/framebuf4bank/media_frame_reader.v
vlog -quiet ../../hdl_source/framebuf4bank/fifo_prefetch_2.v
vlog -quiet ../../hdl_source/IP/afifo_32_16_256.v
vlog -quiet ../../hdl_source/display/thumbnail_layout.v
vlog -quiet tb_img13.v
vsim -quiet -c tb_img13
run -all
quit -f
