`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 13 张图播放控制回归：vsim -c -do run_nav.do
//   media_player_control(IMAGE_COUNT=13, NAV_MASK=PIC1~11) + thumbnail_controller
//   - 首图落位：PIC1 缺失时落到 PIC2
//   - next：跳过未加载的图，第 11 张之后回到第 1 张，永远不进 12/13
//   - prev：从第 1 张往回到第 11 张
//   - 自动轮播同 next
//   - select 能直接切到 12/13；从 13 next 回到第一张可用的
//   - select 未加载的图报 0x53
//   - 缩略图焦点 0..12 循环（右移 12->0，左移 0->12）
// -----------------------------------------------------------------------------
module tb_nav13;
    reg sys_clk = 0, pix_clk = 0;
    always #5  sys_clk = ~sys_clk;
    always #20 pix_clk = ~pix_clk;
    reg rst_n = 0;
    integer errors = 0;

    reg next_e = 0, prev_e = 0, init_e = 0, tog_auto = 0, sel_e = 0;
    reg [3:0] sel_idx = 0;
    reg auto_cfg_v = 0, auto_cfg_en = 0;
    // PIC1(bit0) 缺、PIC6(bit5) 缺，其余 11 张都在（含 12、13）
    reg [12:0] complete = 13'b1_1111_1101_1110;
    wire auto_en, req_busy, idx_commit;
    wire [31:0] period;
    wire [3:0] pending, active;
    wire [7:0] cerr;

    // 帧起点：每 2us 一次，加快仿真
    reg frame_start = 0;
    always begin
        repeat (49) @(posedge pix_clk);
        frame_start <= 1; @(posedge pix_clk); frame_start <= 0;
    end

    media_player_control #(
        .DEFAULT_PERIOD_CYCLES(32'd2000), .MIN_PERIOD_CYCLES(32'd100),
        .MAX_PERIOD_CYCLES(32'd100000),
        .IMAGE_COUNT(13), .INDEX_W(4), .NAV_MASK(13'b0_0111_1111_1111)
    ) dut (
        .sys_clk(sys_clk), .sys_rst_n(rst_n),
        .next_event(next_e), .prev_event(prev_e), .init_event(init_e),
        .toggle_auto_event(tog_auto),
        .period_cfg_valid(1'b0), .period_cfg_cycles(32'd0),
        .auto_cfg_valid(auto_cfg_v), .auto_cfg_enabled(auto_cfg_en),
        .image_complete(complete),
        .select_event(sel_e), .select_index(sel_idx), .auto_hold(1'b0),
        .auto_enabled(auto_en), .active_period_cycles(period),
        .pending_index(pending), .control_error(cerr), .request_busy(req_busy),
        .pix_clk(pix_clk), .pix_rst_n(rst_n), .frame_start(frame_start),
        .active_index(active), .index_commit(idx_commit)
    );

    // ---- 缩略图控制器：只测焦点循环 ----
    reg k_right = 0, k_left = 0, k_mode = 0;
    wire view_mode; wire [3:0] focus; wire t_sel_e; wire [3:0] t_sel_idx;
    wire t_req, t_owned, t_hold;
    thumbnail_controller #(.BLACK_TIMEOUT_CYCLES(32'd50), .IMAGE_COUNT(13), .INDEX_W(4)) u_tc (
        .clk(sys_clk), .rst_n(rst_n),
        .key_right(k_right), .key_left(k_left), .key_confirm(1'b0), .key_mode(k_mode),
        .mode_cfg_valid(1'b0), .mode_cfg_thumb(1'b0),
        .focus_cfg_valid(1'b0), .focus_cfg_index(4'd0),
        .image_complete(complete), .current_index(4'd0), .select_busy(1'b0),
        .transition_busy(1'b0), .transition_black(t_req),
        .view_mode(view_mode), .focus_index(focus),
        .select_event(t_sel_e), .select_index(t_sel_idx),
        .transition_req(t_req), .transition_owned(t_owned), .auto_hold(t_hold)
    );

    task pulse_next; begin @(posedge sys_clk) next_e <= 1; @(posedge sys_clk) next_e <= 0; end endtask
    task pulse_prev; begin @(posedge sys_clk) prev_e <= 1; @(posedge sys_clk) prev_e <= 0; end endtask
    task wait_idle;  begin repeat (5) @(posedge sys_clk); while (req_busy) @(posedge sys_clk);
                           repeat (5) @(posedge sys_clk); end endtask
    task expect_idx;
        input [8*20-1:0] what;
        input integer exp;
        begin
            wait_idle;
            if (pending !== exp || active !== exp) begin
                errors = errors + 1;
                $display("FAIL %0s: pending=%0d active=%0d expect %0d", what, pending, active, exp);
            end else
                $display("ok   %0s -> PIC%0d", what, exp + 1);
        end
    endtask

    integer i, seen_fire;
    initial begin
        repeat (5) @(posedge sys_clk);
        rst_n = 1;
        repeat (5) @(posedge sys_clk);

        @(posedge sys_clk) init_e <= 1; @(posedge sys_clk) init_e <= 0;
        expect_idx("init (PIC1 missing)", 1);
        pulse_next; expect_idx("next", 2);
        pulse_next; expect_idx("next", 3);
        pulse_next; expect_idx("next", 4);
        pulse_next; expect_idx("next skip PIC6", 6);
        for (i = 0; i < 4; i = i + 1) pulse_next_wait;
        expect_idx("next x4", 10);
        pulse_next; expect_idx("next wraps past 12/13", 1);
        pulse_prev; expect_idx("prev wraps to PIC11", 10);
        pulse_prev; expect_idx("prev", 9);

        // 自动轮播 20 次，不得出现 11/12
        seen_fire = 0;
        @(posedge sys_clk) auto_cfg_v <= 1; auto_cfg_en <= 1;
        @(posedge sys_clk) auto_cfg_v <= 0;
        for (i = 0; i < 20; i = i + 1) begin
            @(posedge idx_commit);
            if (active >= 11) seen_fire = seen_fire + 1;
        end
        @(posedge sys_clk) auto_cfg_v <= 1; auto_cfg_en <= 0;
        @(posedge sys_clk) auto_cfg_v <= 0;
        if (seen_fire != 0) begin
            errors = errors + 1; $display("FAIL autoplay visited PIC12/13 %0d times", seen_fire);
        end else $display("ok   autoplay x20 never showed PIC12/13");
        wait_idle;

        @(posedge sys_clk) begin sel_e <= 1; sel_idx <= 12; end
        @(posedge sys_clk) sel_e <= 0;
        expect_idx("select PIC13", 12);
        @(posedge sys_clk) begin sel_e <= 1; sel_idx <= 11; end
        @(posedge sys_clk) sel_e <= 0;
        expect_idx("select PIC12", 11);
        pulse_next; expect_idx("next from PIC12", 1);
        @(posedge sys_clk) begin sel_e <= 1; sel_idx <= 0; end
        @(posedge sys_clk) sel_e <= 0;
        wait_idle;
        if (cerr !== 8'h53) begin
            errors = errors + 1; $display("FAIL select missing PIC1: err=%h expect 53", cerr);
        end else $display("ok   select missing PIC1 -> err 53");

        // ---- 缩略图焦点 ----
        @(posedge sys_clk) k_mode <= 1; @(posedge sys_clk) k_mode <= 0;
        repeat (20) @(posedge sys_clk);
        if (!view_mode) begin errors = errors + 1; $display("FAIL not in thumb mode"); end
        for (i = 0; i < 12; i = i + 1) begin
            @(posedge sys_clk) k_right <= 1; @(posedge sys_clk) k_right <= 0;
        end
        @(posedge sys_clk);
        if (focus !== 12) begin errors = errors + 1; $display("FAIL focus after 12 right = %0d", focus); end
        @(posedge sys_clk) k_right <= 1; @(posedge sys_clk) k_right <= 0;
        @(posedge sys_clk);
        if (focus !== 0) begin errors = errors + 1; $display("FAIL focus 12->right = %0d", focus); end
        @(posedge sys_clk) k_left <= 1; @(posedge sys_clk) k_left <= 0;
        @(posedge sys_clk);
        if (focus !== 12) begin errors = errors + 1; $display("FAIL focus 0->left = %0d", focus); end
        else $display("ok   thumbnail focus cycles 0..12");

        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL (%0d)", errors);
        $finish;
    end

    task pulse_next_wait; begin pulse_next; wait_idle; end endtask
endmodule
