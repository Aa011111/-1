`timescale 1ns/1ps
// next/prev 新写法（掩码+优先级）与旧写法（绕圈取模）穷举对比
module navfunc #(parameter integer N = 13, parameter integer W = 4);
    function [W:0] next_old; input [W-1:0] cur; input [N-1:0] c; integer s, cand;
        begin next_old = {1'b0, cur};
            for (s = 1; s <= N; s = s + 1) begin cand = cur + s; if (cand >= N) cand = cand - N;
                if (!next_old[W] && c[cand]) next_old = {1'b1, cand[W-1:0]}; end end endfunction
    function [W:0] prev_old; input [W-1:0] cur; input [N-1:0] c; integer s, cand;
        begin prev_old = {1'b0, cur};
            for (s = 1; s <= N; s = s + 1) begin cand = cur - s; if (cand < 0) cand = cand + N;
                if (!prev_old[W] && c[cand]) prev_old = {1'b1, cand[W-1:0]}; end end endfunction
    function [W:0] next_new; input [W-1:0] cur; input [N-1:0] c; integer k; reg [W:0] hi, any;
        begin hi = 0; any = 0;
            for (k = N-1; k >= 0; k = k - 1) begin
                if (c[k] && k > cur) hi = {1'b1, k[W-1:0]}; if (c[k]) any = {1'b1, k[W-1:0]}; end
            next_new = hi[W] ? hi : any[W] ? any : {1'b0, cur}; end endfunction
    function [W:0] prev_new; input [W-1:0] cur; input [N-1:0] c; integer k; reg [W:0] lo, any;
        begin lo = 0; any = 0;
            for (k = 0; k < N; k = k + 1) begin
                if (c[k] && k < cur) lo = {1'b1, k[W-1:0]}; if (c[k]) any = {1'b1, k[W-1:0]}; end
            prev_new = lo[W] ? lo : any[W] ? any : {1'b0, cur}; end endfunction
    integer cur, m, err = 0, cnt = 0;
    initial begin
        #1;
        // 只比 cur < N（pending_index 永远不会越界）；无效结果只比有效位
        for (cur = 0; cur < N; cur = cur + 1)
            for (m = 0; m < (1 << N); m = m + 1) begin
                cnt = cnt + 1;
                if (next_old(cur, m) !== next_new(cur, m) || prev_old(cur, m) !== prev_new(cur, m)) begin
                    if (err < 5) $display("MISMATCH N=%0d cur=%0d m=%b next %h/%h prev %h/%h", N, cur, m,
                        next_old(cur,m), next_new(cur,m), prev_old(cur,m), prev_new(cur,m));
                    err = err + 1;
                end
            end
        $display("N=%0d: %0d cases, %0d mismatches", N, cnt, err);
    end
endmodule
module tb_navfunc;
    navfunc #(13, 4) a();
    navfunc #(4, 2)  b();
endmodule
