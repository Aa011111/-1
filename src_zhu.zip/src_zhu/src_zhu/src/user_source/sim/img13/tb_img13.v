`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// 13 张图回归：vsim -c -do run.do
//   loader(IMAGE_COUNT=13, RGB565) 依次写 13 张图 -> SDRAM 模型 -> reader
//   - 全屏：挑 0/1/9/11/12 号图逐像素比对
//   - 4x4 缩略图：13 个有图的格子逐像素比对（每格 4:1 最近邻），后 3 格不查
//     （pix 侧会涂底色）
//   - 每个读 burst：地址连续、不跨 256 字 SDRAM 行、不越出 13 张图的范围
//   - 写地址不越界；13 张都 image_complete
// 帧高降到 16 行（4x4 每格 4 行），行宽仍 640，burst 对齐关系与工程一致。
// -----------------------------------------------------------------------------
module tb_img13;
    localparam integer W = 640, H = 16, PIX = W * H;
    localparam integer N = 13;
    localparam integer BANK = PIX / 2;
    localparam integer LAT = 24;
    localparam integer MEM_WORDS = N * BANK;

    reg sd_clk = 0, mem_clk = 0, pix_clk = 0;
    always #5  sd_clk  = ~sd_clk;
    always #4  mem_clk = ~mem_clk;
    always #20 pix_clk = ~pix_clk;
    reg rst_n = 0;
    integer errors = 0;

    function [23:0] pat;
        input integer idx, x, y;
        reg [7:0] r, g, b;
        begin
            r = x * 7 + y * 13 + idx * 51;
            g = (x * 3) ^ (y * 29 + idx * 90);
            b = x * x + y * 5 + idx * 17 + (x >> 3);
            pat = {r, g, b};
        end
    endfunction
    function [23:0] rt565;
        input [23:0] c;
        begin
            rt565 = {c[23:19], c[23:21], c[15:10], c[15:14], c[7:3], c[7:5]};
        end
    endfunction

    // ---------------- loader ----------------
    reg        l_start = 0;
    reg [3:0]  l_index = 0;
    reg        l_pvalid = 0;
    reg [23:0] l_rgb = 0;
    reg        l_commit = 0;
    wire        l_busy, l_done, l_wen;
    wire [12:0] l_cpl;
    wire [3:0]  l_mask;
    wire [7:0]  l_merr;
    wire [20:0] l_waddr;
    wire [31:0] l_wdata;
    reg         done_seen = 0, clr_done = 0;

    media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512), .BURST_SIZE(128),
        .STALL_TIMEOUT(65535), .V_FLIP(1), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(1), .IMAGE_COUNT(N), .INDEX_W(4)
    ) u_loader (
        .clk(sd_clk), .rst_n(rst_n), .load_start(l_start), .image_index(l_index),
        .pixel_valid(l_pvalid), .pixel_rgb(l_rgb), .frame_commit(l_commit),
        .decode_error(8'd0), .load_busy(l_busy), .load_done(l_done),
        .image_complete(l_cpl), .memory_error(l_merr),
        .controller_init_done(1'b1), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(l_wen), .app_wr_addr(l_waddr), .app_wr_mask(l_mask), .app_wr_data(l_wdata)
    );

    reg [31:0] mem [0:MEM_WORDS-1];
    always @(posedge sd_clk) begin
        if (clr_done) done_seen <= 0; else if (l_done) done_seen <= 1;
        if (l_wen) begin
            if (l_waddr >= MEM_WORDS) begin
                errors = errors + 1;
                $display("ERR write addr %0d out of range", l_waddr);
            end else
                mem[l_waddr] <= l_wdata;
        end
    end

    // ---------------- reader + SDRAM 读口模型 ----------------
    reg       frame_start = 0;
    reg [3:0] act_index = 0;
    reg       thumb = 0;
    reg       consume = 0;
    reg       rd_enable = 0;

    wire        rd_en;
    wire [20:0] rd_addr;
    reg  [LAT-1:0] vpipe = 0;
    reg  [20:0] apipe [0:LAT-1];
    wire        rd_valid = vpipe[LAT-1];
    wire [31:0] rd_data = mem[apipe[LAT-1]];
    reg  prev_en = 0;
    reg  [20:0] prev_addr = 0, bstart = 0;
    integer blen = 0, bmin = 99999, bmax = 0, bursts = 0, k;
    always @(posedge mem_clk) begin
        vpipe <= {vpipe[LAT-2:0], rd_en};
        apipe[0] <= rd_addr;
        for (k = 1; k < LAT; k = k + 1) apipe[k] <= apipe[k-1];
        prev_en <= rd_en;
        if (rd_en) begin
            prev_addr <= rd_addr;
            if (rd_addr >= MEM_WORDS) begin
                errors = errors + 1; $display("ERR read addr %0d out of range", rd_addr);
            end
            if (!prev_en) begin
                bstart <= rd_addr; blen = 1; bursts = bursts + 1;
            end else begin
                blen = blen + 1;
                if (rd_addr != prev_addr + 1) begin
                    errors = errors + 1; $display("ERR burst not contiguous @%0d", rd_addr);
                end
                if (rd_addr[20:8] != bstart[20:8]) begin
                    errors = errors + 1;
                    $display("ERR burst crosses 256-word row: start %0d addr %0d", bstart, rd_addr);
                end
            end
        end else if (prev_en) begin
            if (blen > bmax) bmax = blen;
            if (blen < bmin) bmin = blen;
        end
    end

    wire [23:0] r_rgb;
    wire r_pv, r_uf, r_busy, r_done;
    wire [3:0] r_idx;
    wire [7:0] r_err;
    media_frame_reader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512), .FIFO_MARGIN(16),
        .MAX_INFLIGHT_BURSTS(2), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(1), .IMAGE_COUNT(N), .INDEX_W(4),
        .THUMB_COLS(4), .THUMB_ROWS(4), .CELL_W(4)
    ) u_reader (
        .mem_clk(mem_clk), .mem_rst_n(rst_n), .controller_init_done(rd_enable),
        .controller_busy(1'b0), .refresh_active(1'b0),
        .app_rd_en(rd_en), .app_rd_addr(rd_addr),
        .sdram_rd_valid(rd_valid), .sdram_rd_data(rd_data),
        .pix_clk(pix_clk), .pix_rst_n(rst_n), .frame_start(frame_start),
        .active_index(act_index), .thumb_mode(thumb), .pixel_consume(consume),
        .pixel_rgb(r_rgb), .pixel_valid(r_pv), .underflow(r_uf),
        .reader_busy(r_busy), .frame_read_done(r_done),
        .reader_index(r_idx), .reader_error(r_err)
    );

    // ---------------- 逐像素检查 ----------------
    integer cur_x = 0, cur_y = 0;
    integer px_err = 0, px_checked = 0, px_skipped = 0;
    integer t_cell, sx, sy;
    reg     chk;
    reg [23:0] exp_raw;
    always @(posedge pix_clk) if (consume) begin
        chk = 1;
        if (thumb) begin
            t_cell = (cur_y / (H / 4)) * 4 + (cur_x / (W / 4));
            sx = 4 * (cur_x % (W / 4));
            sy = 4 * (cur_y % (H / 4));
            exp_raw = pat(t_cell, sx, sy);
            if (t_cell >= N) chk = 0;
        end else
            exp_raw = pat(act_index, cur_x, cur_y);
        if (!r_pv) begin
            if (px_err < 8) $display("ERR no pixel at (%0d,%0d)", cur_x, cur_y);
            px_err = px_err + 1;
        end else if (chk && r_rgb !== rt565(exp_raw)) begin
            if (px_err < 8)
                $display("ERR pixel idx=%0d thumb=%0d (%0d,%0d) got %h exp %h",
                         act_index, thumb, cur_x, cur_y, r_rgb, rt565(exp_raw));
            px_err = px_err + 1;
        end
        if (chk) px_checked = px_checked + 1; else px_skipped = px_skipped + 1;
    end

    task load_image;
        input integer idx;
        integer n, xr, yr;
        begin
            @(posedge sd_clk);
            l_index <= idx; l_start <= 1; clr_done <= 1;
            @(posedge sd_clk);
            l_start <= 0; clr_done <= 0;
            for (n = 0; n < PIX; n = n + 1) begin
                xr = n % W; yr = H - 1 - (n / W);
                l_rgb <= pat(idx, xr, yr); l_pvalid <= 1;
                @(posedge sd_clk); l_pvalid <= 0;
                @(posedge sd_clk);
            end
            l_commit <= 1; @(posedge sd_clk); l_commit <= 0;
            while (!done_seen) @(posedge sd_clk);
            @(posedge sd_clk);
            if (l_merr !== 0) begin
                errors = errors + 1; $display("ERR load idx=%0d err=%h", idx, l_merr);
            end
        end
    endtask

    task show_frame;
        input integer idx;
        input integer t;
        integer x, y;
        begin
            @(posedge pix_clk);
            act_index <= idx; thumb <= t;
            @(posedge pix_clk);
            frame_start <= 1; @(posedge pix_clk); frame_start <= 0;
            repeat (200) @(posedge pix_clk);
            for (y = 0; y < H; y = y + 1) begin
                repeat (160) @(posedge pix_clk);
                for (x = 0; x < W; x = x + 1) begin
                    cur_x <= x; cur_y <= y; consume <= 1;
                    @(posedge pix_clk);
                end
                consume <= 0;
            end
            repeat (20) @(posedge pix_clk);
            $display("frame idx=%0d thumb=%0d: err=%h uf=%b", idx, t, r_err, r_uf);
        end
    endtask

    integer i;
    initial begin
        repeat (10) @(posedge sd_clk);
        rst_n = 1;
        repeat (10) @(posedge sd_clk);
        for (i = 0; i < N; i = i + 1) load_image(i);
        if (l_cpl !== 13'h1fff) begin
            errors = errors + 1; $display("ERR image_complete = %b", l_cpl);
        end else
            $display("13 images loaded, image_complete = %b", l_cpl);

        rd_enable = 1;
        show_frame(0, 0);
        show_frame(12, 0);
        show_frame(5, 1);     // 4x4 缩略图
        show_frame(9, 0);
        show_frame(11, 0);
        show_frame(0, 1);
        show_frame(1, 0);
        show_frame(2, 0);     // 让上一帧的 underflow 判据走完

        if (r_err !== 0 || r_uf !== 0) begin
            errors = errors + 1; $display("ERR reader flags err=%h uf=%b", r_err, r_uf);
        end
        errors = errors + px_err;
        $display("pixels checked / skipped : %0d / %0d", px_checked, px_skipped);
        $display("read bursts              : %0d  len min/max %0d/%0d", bursts, bmin, bmax);
        $display("pixel errors             : %0d", px_err);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL (%0d)", errors);
        $finish;
    end
endmodule
