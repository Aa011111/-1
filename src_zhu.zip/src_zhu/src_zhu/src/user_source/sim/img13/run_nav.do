# 13 张图播放控制回归：vsim -c -do run_nav.do
if {[file exists work_nav]} { vdel -lib work_nav -all }
vlib work_nav
vlog -quiet -work work_nav ../../hdl_source/framebuf4bank/media_player_control.v
vlog -quiet -work work_nav ../../hdl_source/control/thumbnail_controller.v
vlog -quiet -work work_nav tb_nav13.v
vsim -quiet -c -lib work_nav tb_nav13
run -all
quit -f
