# 一图一音回归：vsim -c -do run.do
vlib work
vlog ../../hdl_source/fat32/fat32_volume_scanner.v ../../hdl_source/audio/wav_stream_player.v tb_one_pic_one_wav.v
vsim -c -quiet tb_one_pic_one_wav
run -all
quit -f
