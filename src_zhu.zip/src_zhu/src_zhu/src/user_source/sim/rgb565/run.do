# RGB565 存储回归：vsim -c -do run.do
if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -quiet ../../hdl_source/framebuf4bank/media_frame_loader.v
vlog -quiet ../../hdl_source/framebuf4bank/media_frame_reader.v
vlog -quiet ../../hdl_source/framebuf4bank/fifo_prefetch_2.v
vlog -quiet ../../hdl_source/IP/afifo_32_16_256.v
vlog -quiet ../../hdl_source/display/thumbnail_layout.v
vlog -quiet ref_media_frame_reader.v
vlog -quiet -sv tb_rgb565.v
vsim -quiet -c tb_rgb565
run -all
quit -f
