`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// RGB565 两像素一字存储回归：vsim -c -do run.do
//
// 两套并行环境，共用同一路像素激励和同一路显示时序：
//   P：PACK_RGB565=1 的 loader -> memP -> reader_p
//      逐像素对比 "截成 565 再高位回填" 的期望值（全屏 + 缩略图两种模式），
//      并检查每个读 burst 地址连续、不跨 256 字 SDRAM 行、不越出 4 张图的范围。
//   Z：PACK_RGB565=0 的 loader -> memZ -> 新 reader_z 与改造前 ref reader 各读一份，
//      两者所有输出逐拍比对（回退开关的等价性），另外对比原始 24 位像素。
// loader 额外覆盖：短帧(0x45)、像素过多(0x43) 之后同一 bank 重新正常加载。
// 帧高降到 16 行（行宽仍 640，burst 128 / 缩略图 64 的对齐关系与工程一致），
// 免得 ModelSim 入门版跑太久。
// -----------------------------------------------------------------------------
module tb_rgb565;
    localparam integer W = 640, H = 16, PIX = W * H;
    // SDRAM 模型读延迟（mem 拍）。不能太短：reader 每帧复位读 FIFO 后要等
    // pix 域 2 拍(80~120ns)才放开写，读数据早于这个时刻回来会被 FIFO 丢掉
    // （改造前的 reader 同样如此，真实控制器的读延迟比这长）。
    localparam integer LAT = 24;
    localparam integer MEM_WORDS = 4 * PIX;     // 两套里较大的那套（Z）

    reg sd_clk = 0, mem_clk = 0, pix_clk = 0;
    always #5  sd_clk  = ~sd_clk;    // 100MHz
    always #4  mem_clk = ~mem_clk;   // 125MHz
    always #20 pix_clk = ~pix_clk;   // 25MHz
    reg rst_n = 0;
    integer errors = 0;

    // ---------------- 测试图案 ----------------
    function [23:0] pat;
        input integer idx, x, y;
        reg [7:0] r, g, b;
        begin
            r = x * 7 + y * 13 + idx * 51;
            g = (x * 3) ^ (y * 29 + idx * 90);
            b = x * x + y * 5 + idx * 17 + (x >> 3);
            pat = {r, g, b};
        end
    endfunction
    function [23:0] rt565;            // 截位 + 高位回填
        input [23:0] c;
        begin
            rt565 = {c[23:19], c[23:21], c[15:10], c[15:14], c[7:3], c[7:5]};
        end
    endfunction

    // ---------------- 像素激励（sd 域，两套 loader 共用） ----------------
    reg        l_start = 0;
    reg [1:0]  l_index = 0;
    reg        l_pvalid = 0;
    reg [23:0] l_rgb = 0;
    reg        l_commit = 0;
    // load_done 是 1 拍脉冲，像素过多时会在送流途中出现，用粘滞位接住
    reg        p_done_seen = 0, z_done_seen = 0, clr_done = 0;

    wire        p_busy, p_done, p_wen; wire [3:0] p_cpl, p_mask; wire [7:0] p_merr;
    wire [20:0] p_waddr; wire [31:0] p_wdata;
    wire        z_busy, z_done, z_wen; wire [3:0] z_cpl, z_mask; wire [7:0] z_merr;
    wire [20:0] z_waddr; wire [31:0] z_wdata;

    media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512), .BURST_SIZE(128),
        .STALL_TIMEOUT(65535), .V_FLIP(1), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(1)
    ) loader_p (
        .clk(sd_clk), .rst_n(rst_n), .load_start(l_start), .image_index(l_index),
        .pixel_valid(l_pvalid), .pixel_rgb(l_rgb), .frame_commit(l_commit),
        .decode_error(8'd0), .load_busy(p_busy), .load_done(p_done),
        .image_complete(p_cpl), .memory_error(p_merr),
        .controller_init_done(1'b1), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(p_wen), .app_wr_addr(p_waddr), .app_wr_mask(p_mask), .app_wr_data(p_wdata)
    );
    media_frame_loader #(
        .ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512), .BURST_SIZE(128),
        .STALL_TIMEOUT(65535), .V_FLIP(1), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(0)
    ) loader_z (
        .clk(sd_clk), .rst_n(rst_n), .load_start(l_start), .image_index(l_index),
        .pixel_valid(l_pvalid), .pixel_rgb(l_rgb), .frame_commit(l_commit),
        .decode_error(8'd0), .load_busy(z_busy), .load_done(z_done),
        .image_complete(z_cpl), .memory_error(z_merr),
        .controller_init_done(1'b1), .controller_busy(1'b0), .refresh_active(1'b0),
        .app_wr_en(z_wen), .app_wr_addr(z_waddr), .app_wr_mask(z_mask), .app_wr_data(z_wdata)
    );

    // ---------------- SDRAM 模型 ----------------
    reg [31:0] memP [0:MEM_WORDS-1];
    reg [31:0] memZ [0:MEM_WORDS-1];
    integer p_wr_count = 0;
    always @(posedge sd_clk) begin
        if (clr_done) begin p_done_seen <= 0; z_done_seen <= 0; end
        else begin
            if (p_done) p_done_seen <= 1;
            if (z_done) z_done_seen <= 1;
        end
        if (p_wen) begin
            if (p_waddr >= 4 * (PIX / 2)) begin
                errors = errors + 1;
                $display("ERR P write addr %0d out of 4 banks", p_waddr);
            end else begin
                memP[p_waddr] <= p_wdata;
                p_wr_count = p_wr_count + 1;
            end
        end
        if (z_wen) begin
            if (z_waddr >= 4 * PIX) begin
                errors = errors + 1;
                $display("ERR Z write addr %0d out of 4 banks", z_waddr);
            end else
                memZ[z_waddr] <= z_wdata;
        end
    end

    // ---------------- 显示侧激励（pix 域，三个 reader 共用） ----------------
    reg       frame_start = 0;
    reg [1:0] act_index = 0;
    reg       thumb = 0;
    reg       consume = 0;
    reg       rd_enable = 0;    // = 时间互斥里的 player_enable，加载完才放开读

    // 读口 + 延迟线 + burst 形态检查，三个 reader 各一份
    `define READ_PORT(N, MEM, LIMIT) \
        wire N``_rd_en; wire [20:0] N``_rd_addr; \
        reg [LAT-1:0] N``_vpipe = 0; reg [20:0] N``_apipe [0:LAT-1]; \
        wire N``_rd_valid = N``_vpipe[LAT-1]; \
        wire [31:0] N``_rd_data = MEM[N``_apipe[LAT-1]]; \
        reg N``_prev_en = 0; reg [20:0] N``_prev_addr = 0, N``_bstart = 0; \
        integer N``_blen = 0, N``_bmax = 0, N``_bmin = 99999, N``_bursts = 0; \
        integer N``_k; \
        always @(posedge mem_clk) begin \
            N``_vpipe <= {N``_vpipe[LAT-2:0], N``_rd_en}; \
            N``_apipe[0] <= N``_rd_addr; \
            for (N``_k = 1; N``_k < LAT; N``_k = N``_k + 1) N``_apipe[N``_k] <= N``_apipe[N``_k-1]; \
            N``_prev_en <= N``_rd_en; \
            if (N``_rd_en) begin \
                N``_prev_addr <= N``_rd_addr; \
                if (N``_rd_addr >= LIMIT) begin \
                    errors = errors + 1; $display("ERR %s read addr %0d >= %0d", `"N`", N``_rd_addr, LIMIT); \
                end \
                if (!N``_prev_en) begin \
                    N``_bstart <= N``_rd_addr; N``_blen = 1; N``_bursts = N``_bursts + 1; \
                end else begin \
                    N``_blen = N``_blen + 1; \
                    if (N``_rd_addr != N``_prev_addr + 1) begin \
                        errors = errors + 1; $display("ERR %s burst not contiguous @%0d", `"N`", N``_rd_addr); \
                    end \
                    if (N``_rd_addr[20:8] != N``_bstart[20:8]) begin \
                        errors = errors + 1; $display("ERR %s burst crosses 256-word row: start %0d addr %0d", `"N`", N``_bstart, N``_rd_addr); \
                    end \
                end \
            end else if (N``_prev_en) begin \
                if (N``_blen > N``_bmax) N``_bmax = N``_blen; \
                if (N``_blen < N``_bmin) N``_bmin = N``_blen; \
            end \
        end

    `READ_PORT(rp, memP, 4 * (PIX / 2))
    `READ_PORT(rz, memZ, 4 * PIX)
    `READ_PORT(rr, memZ, 4 * PIX)

    `define READER_PORTS(N) \
        .mem_clk(mem_clk), .mem_rst_n(rst_n), .controller_init_done(rd_enable), \
        .controller_busy(1'b0), .refresh_active(1'b0), \
        .app_rd_en(N``_rd_en), .app_rd_addr(N``_rd_addr), \
        .sdram_rd_valid(N``_rd_valid), .sdram_rd_data(N``_rd_data), \
        .pix_clk(pix_clk), .pix_rst_n(rst_n), .frame_start(frame_start), \
        .active_index(act_index), .thumb_mode(thumb), .pixel_consume(consume), \
        .pixel_rgb(N``_rgb), .pixel_valid(N``_pv), .underflow(N``_uf), \
        .reader_busy(N``_busy), .frame_read_done(N``_done), \
        .reader_index(N``_idx), .reader_error(N``_err)

    wire [23:0] rp_rgb, rz_rgb, rr_rgb;
    wire rp_pv, rz_pv, rr_pv, rp_uf, rz_uf, rr_uf;
    wire rp_busy, rz_busy, rr_busy, rp_done, rz_done, rr_done;
    wire [1:0] rp_idx, rz_idx, rr_idx;
    wire [7:0] rp_err, rz_err, rr_err;

    media_frame_reader #(.ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512),
        .FIFO_MARGIN(16), .MAX_INFLIGHT_BURSTS(2), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(1)) reader_p (`READER_PORTS(rp));
    media_frame_reader #(.ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512),
        .FIFO_MARGIN(16), .MAX_INFLIGHT_BURSTS(2), .FRAME_WIDTH(W), .FRAME_HEIGHT(H),
        .PACK_RGB565(0)) reader_z (`READER_PORTS(rz));
    ref_media_frame_reader #(.ADDR_WIDTH(21), .IMAGE_WORDS(PIX), .FIFO_DEPTH(512),
        .FIFO_MARGIN(16), .MAX_INFLIGHT_BURSTS(2), .FRAME_WIDTH(W), .FRAME_HEIGHT(H)
        ) reader_r (`READER_PORTS(rr));

    // ---------------- 新旧 reader（PACK=0）逐拍等价 ----------------
    integer eq_mem_err = 0, eq_pix_err = 0;
    always @(posedge mem_clk) if (rst_n) begin
        if ({rz_rd_en, rz_rd_addr, rz_busy, rz_done, rz_idx, rz_err} !==
            {rr_rd_en, rr_rd_addr, rr_busy, rr_done, rr_idx, rr_err}) begin
            if (eq_mem_err < 5) $display("ERR Z/ref mem-side mismatch @%0t", $time);
            eq_mem_err = eq_mem_err + 1;
        end
    end
    always @(posedge pix_clk) if (rst_n) begin
        if ({rz_pv, rz_uf} !== {rr_pv, rr_uf} || (rz_pv && rz_rgb !== rr_rgb)) begin
            if (eq_pix_err < 5) $display("ERR Z/ref pix-side mismatch @%0t", $time);
            eq_pix_err = eq_pix_err + 1;
        end
    end

    // ---------------- 显示侧逐像素检查 ----------------
    integer cur_x = 0, cur_y = 0;
    integer px_err_p = 0, px_err_z = 0, px_checked = 0;
    reg [23:0] exp_raw;
    integer t_cell, sx, sy;
    always @(posedge pix_clk) if (consume) begin
        if (thumb) begin
            t_cell = (cur_y >= H / 2 ? 2 : 0) + (cur_x >= W / 2 ? 1 : 0);
            sx = 2 * (cur_x % (W / 2));
            sy = 2 * (cur_y % (H / 2));
            exp_raw = pat(t_cell, sx, sy);
        end else
            exp_raw = pat(act_index, cur_x, cur_y);
        if (!rp_pv || rp_rgb !== rt565(exp_raw)) begin
            if (px_err_p < 8)
                $display("ERR P pixel idx=%0d thumb=%0d (%0d,%0d) got %h valid=%b exp %h",
                         act_index, thumb, cur_x, cur_y, rp_rgb, rp_pv, rt565(exp_raw));
            px_err_p = px_err_p + 1;
        end
        if (!rz_pv || rz_rgb !== exp_raw) begin
            if (px_err_z < 8)
                $display("ERR Z pixel idx=%0d thumb=%0d (%0d,%0d) got %h exp %h",
                         act_index, thumb, cur_x, cur_y, rz_rgb, exp_raw);
            px_err_z = px_err_z + 1;
        end
        px_checked = px_checked + 1;
    end

    // ---------------- 任务 ----------------
    // 按 BMP 顺序（自底向上）送一张图：流第 r 行 = 显示第 H-1-r 行
    task load_image;
        input integer idx;
        input integer npix;      // 正常 = PIX
        input [7:0] exp_err;
        integer n, xr, yr;
        begin
            @(posedge sd_clk);
            l_index <= idx; l_start <= 1; clr_done <= 1;
            @(posedge sd_clk);
            l_start <= 0; clr_done <= 0;
            for (n = 0; n < npix; n = n + 1) begin
                xr = n % W; yr = H - 1 - ((n / W) % H);
                l_rgb <= pat(idx, xr, yr); l_pvalid <= 1;
                @(posedge sd_clk); l_pvalid <= 0;
                @(posedge sd_clk);
                @(posedge sd_clk);
            end
            l_commit <= 1; @(posedge sd_clk); l_commit <= 0;
            while (!(p_done_seen && z_done_seen)) @(posedge sd_clk);
            @(posedge sd_clk);
            if (p_merr !== exp_err || z_merr !== exp_err) begin
                errors = errors + 1;
                $display("ERR load idx=%0d npix=%0d: P err=%h Z err=%h exp %h",
                         idx, npix, p_merr, z_merr, exp_err);
            end
            $display("load idx=%0d npix=%0d -> P err=%h cpl=%b | Z err=%h cpl=%b",
                     idx, npix, p_merr, p_cpl, z_merr, z_cpl);
        end
    endtask

    task show_frame;
        input integer idx;
        input integer t;
        integer x, y, b;
        begin
            @(posedge pix_clk);
            act_index <= idx; thumb <= t;
            @(posedge pix_clk);
            frame_start <= 1; @(posedge pix_clk); frame_start <= 0;
            repeat (200) @(posedge pix_clk);       // 场消隐
            for (y = 0; y < H; y = y + 1) begin
                repeat (160) @(posedge pix_clk);   // 行消隐
                for (x = 0; x < W; x = x + 1) begin
                    cur_x <= x; cur_y <= y; consume <= 1;
                    @(posedge pix_clk);
                end
                consume <= 0;
            end
            repeat (20) @(posedge pix_clk);
            $display("frame idx=%0d thumb=%0d done: P err=%h uf=%b | Z err=%h uf=%b",
                     idx, t, rp_err, rp_uf, rz_err, rz_uf);
        end
    endtask

    initial begin
        repeat (10) @(posedge sd_clk);
        rst_n = 1;
        repeat (10) @(posedge sd_clk);

        load_image(0, PIX, 8'h00);
        load_image(1, PIX, 8'h00);
        load_image(2, PIX, 8'h00);
        load_image(3, PIX - 1, 8'h45);   // 短帧
        load_image(3, PIX + 1, 8'h43);   // 像素过多
        load_image(3, PIX, 8'h00);       // 同 bank 重新正常加载
        if (p_cpl !== 4'b1111 || z_cpl !== 4'b1111) begin
            errors = errors + 1;
            $display("ERR image_complete P=%b Z=%b", p_cpl, z_cpl);
        end

        rd_enable = 1;
        show_frame(0, 0);
        show_frame(1, 0);
        show_frame(2, 0);
        show_frame(3, 0);
        show_frame(0, 1);
        show_frame(2, 1);
        show_frame(3, 0);
        show_frame(1, 1);
        show_frame(1, 0);
        // 最后一帧的 underflow 在下一个 frame_start 才判，再空跑一帧触发它
        show_frame(2, 0);

        if (rp_err !== 0 || rp_uf !== 0 || rz_err !== 0 || rz_uf !== 0) begin
            errors = errors + 1;
            $display("ERR reader flags P err=%h uf=%b Z err=%h uf=%b", rp_err, rp_uf, rz_err, rz_uf);
        end
        errors = errors + px_err_p + px_err_z + eq_mem_err + eq_pix_err;
        $display("pixels checked          : %0d", px_checked);
        $display("P words written (all)   : %0d", p_wr_count);
        $display("P read bursts           : %0d  len min/max %0d/%0d", rp_bursts, rp_bmin, rp_bmax);
        $display("Z read bursts           : %0d  len min/max %0d/%0d", rz_bursts, rz_bmin, rz_bmax);
        $display("pixel errors P/Z        : %0d / %0d", px_err_p, px_err_z);
        $display("Z vs ref mismatches     : mem %0d  pix %0d", eq_mem_err, eq_pix_err);
        if (errors == 0) $display("RESULT: PASS");
        else             $display("RESULT: FAIL (%0d)", errors);
        $finish;
    end
endmodule
