# -*- coding: utf-8 -*-
"""从 MUSIC1.WAV 截 40000 个样本（6.0s 起）写 samples.hex，给 tb_spectrum 用"""
import os, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, '..', '..', 'hdl_source', 'spectrum'))
import spectrum_model as m

wav = os.path.join(here, '..', '..', '..', '..', '..', 'TF卡文件', 'MUSIC1.WAV')
pcm = m.load_wav(os.path.normpath(wav))
start = int(6.0 * m.FS)
seg = pcm[start:start + 40000]
with open(os.path.join(here, 'samples.hex'), 'w') as f:
    for s in seg:
        f.write('%04x\n' % (s & 0xffff))
print('samples.hex: %d samples' % len(seg))
