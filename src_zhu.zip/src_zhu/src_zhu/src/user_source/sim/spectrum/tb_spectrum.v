`timescale 1ns/1ps
// -----------------------------------------------------------------------------
// tb_spectrum：四边环绕频谱 spectrum_border_overlay 回归
//
//   vsim -c -do run.do        然后  python check_spectrum.py
//
// 激励：
//   - 640x480@60 时序（800x525，hs/vs 低有效，vs 上升沿之后 33 行才进有效区，
//     和 video_timing_ctrl 一致），25MHz
//   - 48kHz 采样节拍：和顶层同一个相位累加器；样本取自 samples.hex
//     （gen_vectors.py 从 MUSIC1.WAV 截的一段）
//   - 背景像素 = 坐标的确定性函数，checker 里同一个公式
//   - 第 ALARM_FROM 帧之后拉高 alarm（下一个帧起点生效），后半段比对火警特效
// 输出（给 check_spectrum.py）：
//   events.txt   每个被分析器接受的样本 "S xxxx"、每个帧起点 "F a"（a = 当拍 alarm），按发生顺序
//                （同拍时先 F 后 S，和分析器的约定一致）
//   disp.txt     每帧第 0 行开始时显示表 35 项
//   frame_N.txt  指定几帧的整帧输出像素（hex，一行一个）
// -----------------------------------------------------------------------------
module tb_spectrum;
    parameter integer NFRAMES  = 40;
    parameter integer NSAMPLES = 40000;
    parameter integer ALARM_FROM = 20;

    reg clk = 1'b0;
    always #20 clk = ~clk;              // 25MHz
    reg rst_n = 1'b0;
    reg alarm = 1'b0;

    // ---------------- 视频时序 ----------------
    localparam H_ACT = 640, H_FP = 16, H_SYNC = 96, H_BP = 48, H_TOT = 800;
    localparam V_ACT = 480, V_FP = 10, V_SYNC = 2,  V_BP = 33, V_TOT = 525;
    reg [9:0] hc = 0, vc = 0;
    wire de_in = (hc < H_ACT) && (vc < V_ACT);
    wire hs_in = !((hc >= H_ACT + H_FP) && (hc < H_ACT + H_FP + H_SYNC));
    wire vs_in = !((vc >= V_ACT + V_FP) && (vc < V_ACT + V_FP + V_SYNC));
    wire [23:0] rgb_in = de_in ? {hc[7:0], vc[7:0], hc[9:2] ^ vc[7:0]} : 24'd0;

    always @(posedge clk) if (rst_n) begin
        if (hc == H_TOT - 1) begin
            hc <= 0;
            vc <= (vc == V_TOT - 1) ? 0 : vc + 1;
        end
        else hc <= hc + 1;
    end

    // ---------------- 音频 ----------------
    reg [15:0] smp_mem [0:NSAMPLES-1];
    initial $readmemh("samples.hex", smp_mem);
    reg [24:0] acc = 0;
    reg        tick = 0;
    reg        audio_on = 0;
    integer    sidx = 0;
    reg signed [15:0] smp = 0;
    always @(posedge clk) begin
        if (acc >= 25_000_000 - 48_000) begin
            acc  <= acc + 48_000 - 25_000_000;
            tick <= audio_on;
        end
        else begin
            acc  <= acc + 48_000;
            tick <= 1'b0;
        end
        if (tick) begin
            sidx <= sidx + 1;
        end
    end
    always @(*) smp = smp_mem[sidx % NSAMPLES];

    // ---------------- DUT ----------------
    wire        hs_o, vs_o, de_o, overrun;
    wire [23:0] rgb_o;
    spectrum_border_overlay #(
        .COEF_FILE ("../../hdl_source/spectrum/spectrum_coef.hex")
    ) dut (
        .clk          (clk),
        .rst_n        (rst_n),
        .cfg          (8'h12),
        .thumb        (1'b0),
        .alarm        (alarm),
        .sample_valid (tick),
        .sample       (smp),
        .hs_in        (hs_in),
        .vs_in        (vs_in),
        .de_in        (de_in),
        .rgb_in       (rgb_in),
        .hs_out       (hs_o),
        .vs_out       (vs_o),
        .de_out       (de_o),
        .rgb_out      (rgb_o),
        .overrun      (overrun)
    );

    // ---------------- 记录 ----------------
    integer fev, fdisp, fpix;
    integer frame_no = -1;     // 第几个 frame_start
    integer k;
    reg     dump_this;
    wire    fs = dut.frame_start;

    function dump_frame;
        input integer n;
        dump_frame = (n == 1) || (n == 15) || (n == ALARM_FROM + 5) || (n == NFRAMES - 2);
    endfunction

    // 输出侧坐标（延迟 5 拍后的 de/vs）
    reg [9:0] ox = 0, oy = 0;
    reg       ode_d = 0, ovs_d = 0;
    always @(posedge clk) begin
        ode_d <= de_o; ovs_d <= vs_o;
        if (de_o) ox <= ox + 1;
        else begin ox <= 0; if (ode_d) oy <= oy + 1; end
        if (vs_o & ~ovs_d) oy <= 0;
    end

    always @(posedge clk) if (rst_n) begin
        if (fs) begin
            $fwrite(fev, "F %0d\n", alarm);
            frame_no = frame_no + 1;
        end
        if (tick && !dut.u_spectrum_analyzer.clearing)
            $fwrite(fev, "S %04h\n", smp);
        // 输出侧每帧第 0 行第 0 个像素：显示表此时已稳定
        if (de_o && ox == 0 && oy == 0) begin
            $fwrite(fdisp, "%0d", frame_no);
            for (k = 0; k < 35; k = k + 1)
                $fwrite(fdisp, " %03h", dut.u_spectrum_analyzer.disp_mem[k]);
            $fwrite(fdisp, "\n");
            if (dump_frame(frame_no)) begin
                fpix = $fopen($sformatf("frame_%0d.txt", frame_no), "w");
                dump_this = 1'b1;
            end
        end
        if (dump_this && de_o)
            $fwrite(fpix, "%06h\n", rgb_o);
        if (dump_this && de_o && ox == H_ACT - 1 && oy == V_ACT - 1) begin
            $fclose(fpix);
            dump_this = 1'b0;
        end
        if (overrun) begin
            $display("ERROR: analyzer overrun");
            $finish;
        end
    end

    // 分析器一遍的最长拍数（应 < 520）
    integer busy_len = 0, busy_max = 0;
    always @(posedge clk) begin
        if (dut.u_spectrum_analyzer.busy) busy_len = busy_len + 1;
        else begin
            if (busy_len > busy_max) busy_max = busy_len;
            busy_len = 0;
        end
    end

    initial begin
        dump_this = 1'b0;
        fev   = $fopen("events.txt", "w");
        fdisp = $fopen("disp.txt", "w");
        #1000 rst_n = 1'b1;
        // 等分析器上电清零（245 拍）结束再开音频
        repeat (400) @(posedge clk);
        audio_on = 1'b1;
        wait (frame_no == ALARM_FROM);
        @(negedge clk) alarm = 1'b1;
        wait (frame_no == NFRAMES);
        repeat (10) @(posedge clk);
        $display("frames=%0d samples=%0d busy_max=%0d cycles", frame_no, sidx, busy_max);
        $fclose(fev);
        $fclose(fdisp);
        $finish;
    end
endmodule
