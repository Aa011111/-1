# 四边环绕频谱回归：vsim -c -do run.do ，跑完再 python check_spectrum.py
if {[file exists work]} { vdel -lib work -all }
vlib work
vlog -quiet ../../hdl_source/spectrum/spectrum_analyzer.v
vlog -quiet ../../hdl_source/spectrum/spectrum_border_overlay.v
vlog -quiet -sv tb_spectrum.v
vsim -quiet -c tb_spectrum
run -all
quit -f
