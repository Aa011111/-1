# -*- coding: utf-8 -*-
"""
tb_spectrum 结果比对：按 events.txt 的顺序重放 spectrum_model，
  1) 每帧显示表 35 项（disp.txt）逐项比对；
  2) frame_N.txt 整帧 640x480 输出像素逐点比对（alarm 帧比火警特效 fire_pixel）。
"""
import glob, os, re, sys
here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(here, '..', '..', 'hdl_source', 'spectrum'))
import spectrum_model as m

def enc(d):
    hseg, pv, pseg = d
    return (hseg << 5) | (pv << 4) | pseg

an = m.Analyzer()
fx = m.FireFx()
rot, fidx, pending, alarm = 0, -1, False, 0
snap = {}                               # frame -> (disp, rot, alarm, bars, f, inten)
for line in open(os.path.join(here, 'events.txt')):
    if line[0] == 'F':
        fidx += 1
        pending = True
        rot = rot + m.SPIN_STEP - (m.PERIM if rot + m.SPIN_STEP >= m.PERIM else 0)
        alarm = int(line.split()[1])
        fx.frame(an.bar_sum)            # 帧起点：用上一遍 frame pass 的柱高和
    else:
        v = int(line.split()[1], 16)
        v = v - 65536 if v & 0x8000 else v
        fp = pending
        an.sample(v, frame_pass=fp)
        pending = False
        if fp:
            snap[fidx] = (list(an.disp), rot, alarm, list(an.bar), fx.f, fx.inten())

errors = 0
nd = 0
for line in open(os.path.join(here, 'disp.txt')):
    f = line.split()
    n = int(f[0])
    if n < 1:      # 第 0 帧 = 复位释放那拍 vs_d=0 产生的帧起点，导出时清零还没做完
        continue
    rtl = [int(x, 16) for x in f[1:]]
    exp = [enc(d) for d in snap[n][0]]
    nd += 1
    if rtl != exp:
        errors += 1
        if errors <= 5:
            bad = [k for k in range(35) if rtl[k] != exp[k]]
            print('frame %d disp mismatch at bands %s: rtl %s exp %s' %
                  (n, bad[:6], [hex(rtl[k]) for k in bad[:6]], [hex(exp[k]) for k in bad[:6]]))
print('disp: %d frames compared, %d mismatched' % (nd, errors))

lit_total = 0
for fn in sorted(glob.glob(os.path.join(here, 'frame_*.txt'))):
    n = int(re.findall(r'frame_(\d+)', fn)[0])
    disp, r, al, bars, ff, inten = snap[n]
    pix = [int(l, 16) for l in open(fn) if l.strip()]
    assert len(pix) == 640 * 480, (fn, len(pix))
    bad = 0
    changed = 0
    for y in range(480):
        for x in range(640):
            bg = (x & 255, y & 255, ((x >> 2) ^ y) & 255)
            e = m.fire_pixel(x, y, bg, bars, ff, inten) if al else m.pixel_out(x, y, bg, disp, r)
            ev = (e[0] << 16) | (e[1] << 8) | e[2]
            got = pix[y * 640 + x]
            if e != bg:
                changed += 1
            if got != ev:
                bad += 1
                if bad <= 5:
                    print('  frame %d (%d,%d): rtl %06x exp %06x' % (n, x, y, got, ev))
    lit = sum(1 for d in disp if d[0] > 0)
    print('frame %d%s: %d pixels overlaid, %d bands lit, %d mismatches' %
          (n, ' [alarm]' if al else '', changed, lit, bad))
    errors += bad
print('PASS' if errors == 0 else 'FAIL (%d)' % errors)
