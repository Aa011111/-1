SWNS: 0.157ns, STNS: 0.000ns.
HWNS: -0.070ns, HTNS: -0.482ns.
